# -*- coding: utf-8 -*-
"""
/***************************************************************************
 herrCTRAS_controlCalidadGDB.py
                                 A QGIS4 plugin
 jcml_bar
                             -------------------
        begin                : 2019-02-14
        git sha              : $Format:%H$
        copyright            : (C) 2016 by ASS
        email                : asolabre@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import QIcon, QPixmap
from qgis.PyQt.QtCore import QSettings, QCoreApplication, QTranslator, qVersion, Qt, QVariant, QUrl, QMetaType
from qgis.PyQt.QtWidgets import QApplication, QMessageBox, QToolButton, QMenu, QAction, QDialog, QCheckBox, QFileDialog
from qgis.PyQt import uic

from qgis.gui import QgsMessageBar
from qgis.core import ( QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsApplication,
                        QgsExpression, QgsFeatureRequest, QgsField, QgsFeature, QgsGeometry, QgsPoint, QgsPointXY,
                        QgsLineString, QgsMultiLineString, QgsProviderRegistry)
from qgis.utils import iface
from qgis.PyQt.QtPrintSupport import QPrinter, QPrintDialog
from qgis.PyQt.QtWebEngineWidgets import QWebEngineView

import os
from osgeo import ogr, osr
import urllib
import json
from time import sleep
import glob, codecs
from functools import partial
import shutil
import datetime
import locale
import tempfile
import sys
import subprocess
import csv
import io
import math
import timeit

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .settings import Settings           # CLASE DE CONFIGURACIÓN DE VARIABLES GLOBALES

from .GDBDominios import GDBdominios

conf = configuration()

# VARIABLES
srcVal = conf.general["EPSG"]
FICHsalida = 'c:/temp/catalogo_ctrl.csv'
nomFichPKS = 'c:/temp/catalogo_ctrl_pks.json'

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrCTRAS_controlCalidadGDB.ui'))


class herrCTRAS_controlCalidadGDB(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(herrCTRAS_controlCalidadGDB, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        
        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        self.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/9_incidencia.jpg'))
        self.logo.setPixmap(QPixmap(f":/plugins/jccm_bar4/iconos/logo_general.jpg"))

        self.fun = Functions()

        self.GDBDom = GDBdominios()
        self.Sett = Settings()
        global tipoUser

        # Comprobamos el rol del usuario
        userSIG, tipoUser = self.Sett.entrarUser()

        self.plugin_dir = os.path.dirname(__file__)
        self.QgisVersion = Qgis.QGIS_VERSION_INT

        # PDF print options
        self.maxLinesPerPage = 40
        self.maxAttributesBeforeSmallFontSize = 15
        self.orientation = QPrinter.Landscape
        self.pageSize = QPrinter.A4

        # CSS template file
        self.cssPath = os.path.join(
            self.plugin_dir, "templates/table.css" )

        self.gpbVista.setVisible(False)
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)
        self.progressBar.setValue(0)
        self.lblINFO.setText('INFO:')

        self.buttonBoxOK.clicked.connect(self.ctrlGDBcarreteras)
        self.strPrecision = "{:."+str(self.spnPRECISION.value())+"f}"

        # COMBOS DESPLEGABLES
        #  Combo Funcionalidad
        lista_Valores = self.fun.getValoresCampo('Funcionalidad','')
        valpredet = "Todo"
        ################################################################################
                                        ####   todo CONTROL   ####
        ################################################################################
        if tipoUser == 'ADMINISTRADOR':
            # valpredet = u'Básica'
            pass
        ################################################################################
                                        ####   todo CONTROL   ####
        ################################################################################
        self.cbxFuncionalidad.clear()
        if lista_Valores is not None:
            self.cbxFuncionalidad.addItem("Todo")
            self.cbxFuncionalidad.addItems(lista_Valores)
            if valpredet in lista_Valores:
                self.cbxFuncionalidad.setCurrentIndex(1+lista_Valores.index(valpredet))

        #  Combo Titularidad
        lista_Valores = self.fun.getValoresCampo('Titularidad','')
        valpredet = u'JCCM'
        self.cbxTitularidad.clear()
        if lista_Valores is not None:
            self.cbxTitularidad.addItem("Todo")
            self.cbxTitularidad.addItems(lista_Valores)
            if valpredet in lista_Valores:
                self.cbxTitularidad.setCurrentIndex(1+lista_Valores.index(valpredet))

        #  Combo Provincia
        lista_Valores = self.fun.getValoresCampo('Provincia','')
        self.cbxProvincia.clear()
        ################################################################################
                                        ####  todo  CONTROL PKS  ####
        ################################################################################
        if tipoUser == 'ADMINISTRADOR':
            valpredet = u'Albacete'
        ################################################################################
                                        ####  todo  CONTROL PKS  ####
        ################################################################################
        if lista_Valores is not None:
            self.cbxProvincia.addItems(lista_Valores)
            if valpredet in lista_Valores:
                self.cbxProvincia.setCurrentIndex(lista_Valores.index(valpredet))
            else:
                self.cbxProvincia.setCurrentIndex(1)

        # Campos para controlar Dominios
        if self.cbx_dominios.isChecked():
            listaCamposDOM = ['Titularidad','Funcionalidad','Tipologia_DobleC','Tipologia_UnaC','idOrdenCtra']

        # Controles inacticos
        self.lblTipologia_DobleC.hide()
        self.cbxTipologia_DobleC.hide()
        self.lblTipologia_UnaC.hide()
        self.cbxTipologia_UnaC.hide()

        self.cbx_idmatricula.setEnabled(True)
        self.cbx_idmatricula.setChecked(True)
        self.cbx_calibracion.setEnabled(True)
        self.cbx_calibracion.setChecked(True)
        self.cbx_longPks.setEnabled(True)
        self.cbx_longPks.setChecked(True)
        self.cbx_dominios.setEnabled(True)
        self.cbx_dominios.setChecked(True)
        self.cbx_inicioNeg.setEnabled(True)
        self.cbx_inicioNeg.setChecked(True)
        self.cbx_PKSxCtra.setEnabled(True)
        self.cbx_PKSxCtra.setChecked(True)
        self.cbx_calcPKS.setEnabled(True)
        self.cbx_calcPKS.setChecked(False)
        self.lblDISTejePK.setEnabled(False)
        self.lneDISTejePK.setEnabled(False)
        self.cbx_calibrPKS.setEnabled(True)
        self.cbx_calibrPKS.setChecked(False)
        self.lblTOLcalibrPKS.setEnabled(False)
        self.lneTOLcalibrPKS.setEnabled(False)
        self.cbx_congrPKStramos.setEnabled(True)
        self.cbx_congrPKStramos.setChecked(False)
        self.cbx_cargaPKS.setEnabled(True)
        self.cbx_cargaPKS.setChecked(False)

        self.cbx_calcPKS.clicked.connect(self.cambiaDisteje)
        self.cbx_calibrPKS.clicked.connect(self.cambiaTolCalibr)

    def cambiaDisteje(self):
        if self.cbx_calcPKS.isChecked():
            self.lblDISTejePK.setEnabled(True)
            self.lneDISTejePK.setEnabled(True)
        else:
            self.lblDISTejePK.setEnabled(False)
            self.lneDISTejePK.setEnabled(False)

    def cambiaTolCalibr(self):
        if self.cbx_calibrPKS.isChecked():
            self.lblTOLcalibrPKS.setEnabled(True)
            self.lneTOLcalibrPKS.setEnabled(True)
        else:
            self.lblTOLcalibrPKS.setEnabled(False)
            self.lneTOLcalibrPKS.setEnabled(False)

    def closeEvent(self, event):
        QApplication.restoreOverrideCursor()


    def encode(self,text):
        """
        For printing unicode characters to the console.
        """
        # return text.encode('utf-8')
        return text.encode('ISO-8859-14')


    def ctrlGDBcarreteras(self):
        start = timeit.default_timer()
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        fileTipe = self.cbxTipoExport.currentText()
        if fileTipe == 'IMPRESORA':
            fileTipe = 'printer'
        if fileTipe == u'Solo CSV':
            fileTipe = 'csv'

        valcbxTitularidad = self.cbxTitularidad.currentText()
        valcbxFuncionalidad = self.cbxFuncionalidad.currentText()
        valcbxProvincia = self.cbxProvincia.currentText()

        ### DATOS DE ENTRADA PARA HTML
        dataEntrada = [valcbxTitularidad, valcbxFuncionalidad, 'n/a - n/a)',valcbxProvincia, 'n/a']

        if valcbxTitularidad == "Todo":
            valcbxTitularidad = '%'
        if valcbxFuncionalidad == "Todo":
            valcbxFuncionalidad = '%'

        whereTXT = '('
        whereTXT+= ' Titularidad LIKE '+"'"+valcbxTitularidad+"'"
        whereTXT+= ' AND Funcionalidad LIKE '+"'"+valcbxFuncionalidad+"'"
        whereTXT+= ' AND Provincia LIKE '+"'"+valcbxProvincia+"')"

        # if self.cbx_calibrPKS.isChecked():
            # whereTXTPKS = '('
            # whereTXTPKS+= ' Provincia LIKE '+"'"+valcbxProvincia+"')"

        if self.chbMATR9000.isChecked():
            whereTXT+= ' AND Matricula <>'+ "'9000'"

        # COMPROBACIÓN DE CONTROLES PARA AÑADIR CAMPOS CONTROL
        self.listCamposCTRL = []
        chkDominios = False
        if self.cbx_idmatricula.isChecked():
            self.listCamposCTRL.append('idMatr')
        if self.cbx_denomTramos.isChecked():
            self.listCamposCTRL.append('ErrDENOM')
        if self.cbx_calibracion.isChecked():
            self.listCamposCTRL.append('calib_sentido')
        if self.cbx_longPks.isChecked():
            self.listCamposCTRL.append('long_PI_PF_KM')
        if self.cbx_dominios.isChecked():
            chkDominios = True
        if self.cbx_inicioNeg.isChecked():
            self.listCamposCTRL.append('IniNegat')

        ################################################################################
        ## TODO
        if self.cbx_congrPKStramos.isChecked():
            self.listCamposCTRL.append('ErrPksCONT')
            msg = 'ESTÁ PENDIENTE LA COMPROBACIÓN DE CONGRUENCIA DE PKs EN TRAMOS CONTIGUOS\n'
            QApplication.restoreOverrideCursor()
            self.fun.showMessage(msg)
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        ## TODO
        ################################################################################

        if self.cbx_PKSxCtra.isChecked():
            if self.cbx_calcPKS.isChecked():
                self.creacapaPKSausentes()
            self.listCamposCTRL.append('FALTA_PK')

        if self.cbx_calcEJESCAL.isChecked():
            self.creacapaEJESCAL()

        if self.cbx_calibrPKS.isChecked():
            self.listCamposCTRL.append('Pks_ERR')
            pass

        # CAMPOS A PONER EN ENCABEZAMIENTOS
        outfields = '*'
        self.listCamposCOMP = ['OBJECTID', 'idMatricula','Matricula','Longitud','PkINI','PkFin','Matricula_Plan',
            'Titularidad','Funcionalidad','Tipologia_DobleC','Tipologia_UnaC','Denominacion',
            'Long_Km','idOrdenCtra','Origen','Destino','Provincia','Shape.STLength()']

        self.listCampos = ['OBJECTID', 'Matricula', 'idMatricula', 'Funcionalidad','Provincia', 'Origen', 'Destino']
        if self.cbx_denomTramos.isChecked():
            self.listCampos = self.listCampos + ['Denominacion']
        self.listCampos = self.listCampos + ['Longitud','PkINI','PkFin','Long_Km']
        self.listCamposCOMP += self.listCamposCTRL
        if chkDominios == True:
            self.listCampos+=['Tipologia_DobleC','Tipologia_UnaC','idOrdenCtra']

        self.listCampos += self.listCamposCTRL

        self.listCamposOrder = ['Titularidad', 'idOrdenCtra', 'Funcionalidad', 'Matricula', 'PkINI', 'Provincia']


        # Comprobamos CAMPOS INCLUIDOS en la salida
        listBorrar = []
        for campo in self.listCampos:
            if not campo in self.listCamposCOMP:
                listBorrar.append(campo)
        for campo in listBorrar:
            self.listCampos.remove(campo)


        # Comprobamos CAMPOS INCLUIDOS en la lista de orden de campos
        listBorrar = []
        for campo in self.listCamposOrder:
            if not campo in self.listCamposCOMP:
                listBorrar.append(campo)
        for campo in listBorrar:
            self.listCamposOrder.remove(campo)
        orderByFields = ",".join(self.listCamposOrder)

        self.lblINFO.setText('INFO: Leyendo url .....')

        TipoExport = self.cbxTipoExport.currentText()


        # CONSULTA DE LA CAPA DE CARRETERAS
        #   QUERY AL WFS Plan_Carreteras_BTA_WFS -- PARCIAL --
        url = conf.general["rest_carreteras"]

        values = {'where' : whereTXT,
                  'text': '',
                  'objectIds': '',
                  'returnGeometry' : False,
                  'returnM': False,
                  'outFields': outfields,
                  'orderByFields' : orderByFields,
                  'f': 'json'}

        restfeatures = self.fun.getFeaturesBTAcalibrada(values)

        if self.cbx_PKSxCtra.isChecked() or self.cbx_calibrPKS.isChecked():
            # DESCARGAMOS LA CAPA DE PKS DE LA PROVINCIA
            nomLayerPKS = 'JCCM CTRAS PKS '+valcbxProvincia
            nomFichPKS = 'C:/TEMP/JCCM_CTRAS_PKS.json'
            layerEXIST = QgsProject.instance().mapLayersByName(nomLayerPKS)
            if layerEXIST:
                self.layerPKS = layerEXIST[0]
                print ('EXISTE ',nomLayerPKS)
            else:
                print ('NO EXISTE ',nomLayerPKS)
                ###  LECTURA DE DATOS DE PKS ###
                self.lblINFO.setText('INFO: Descargando fichero de PKS')
                whereTXTPKS = 'Provincia LIKE '+"'"+valcbxProvincia+"'"
                resultPKS = self.GetJSONPKS(whereTXTPKS)

                self.layerPKS = QgsVectorLayer(json.dumps(resultPKS), nomLayerPKS, "ogr")

                if self.cbx_cargaPKS.isChecked():
                    # Cargar capa solo si se ve necesario
                    #######################################################
                    #####  TODO SUSTITUIR LA CARGA DE LA CAPA  ############
                    # QgsProject.instance().addMapLayer(self.layerPKS, False)
                    QgsProject.instance().addMapLayer(self.layerPKS, True)
                    #######################################################
                    # Colocamos la capa arriba del todo
                    root = QgsProject.instance().layerTreeRoot()
                    root.insertLayer(0, self.layerPKS)

                self.lblINFO.setText('INFO: Leido fichero de PKS')


        numfeats = len(restfeatures)
        nfeat = 0
        if numfeats==0:
            return

        # FICHEROS Y CAPAS
        fich_csv = FICHsalida
        # Comprobamos que existe el directorio y si no, se crea
        dirCsv,nameFichCsv = os.path.split(fich_csv)
        if not os.path.exists(dirCsv):
            os.makedirs(dirCsv)
        fich = FICHsalida.replace('csv', fileTipe)

        QgsMessageLog.logMessage( "Creando archivo de log",self.nombre_plugin)

        # ESCRIBIMOS ENCABEZADOS FICHERO 'CSV'
        target  = codecs.open(fich_csv, 'w+',encoding='utf-8')
        encabezado = ''
        for campo in self.listCamposCOMP:
            encabezado += campo + u';'


        target.write(encabezado)
        target.write("\n")

        # ESCRIBIMOS LISTA DE DATOS
        # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
        countFeat = 0

        for feat in restfeatures:
            attributes = feat["attributes"]
            datErr = False
            # COMPROBAMOS DOBLE VIA
            grabar = True
            if not self.chbDOBLEVIA.isChecked():
                # if attributes['Tipologia_DobleC'] == 'ATV' or attributes['Tipologia_DobleC'] == 'ATP':
                if attributes['Tipologia_DobleC'] == 'ATV' or attributes['Tipologia_DobleC'] == 'ATP' or attributes['Tipologia_DobleC'] == 'MTC':
                    ctraCalzada = attributes['Matricula_Plan'].split(u' ')
                    if len(ctraCalzada)>1:
                        if attributes['Matricula_Plan'].split(u' ')[1] == 'D' or attributes['Matricula_Plan'].split(u' ')[1] == 'd':
                            grabar = False
                        pass


            if grabar:  # En caso de DOBLE VIA desmarcado, solo grabamos CALZADA D
                datos = u''
                for attr in self.listCamposCOMP:
                    if attr not in self.listCamposCTRL:
                        dat = u''
                        if isinstance(attributes[attr], str):
                            dat = attributes[attr]
                        elif isinstance(attributes[attr], unicode):
                            dat = attributes[attr]
                        elif isinstance(attributes[attr], int):
                            dat = str(attributes[attr])
                        elif isinstance(attributes[attr], float):
                            # print attr, attributes[attr], 'float', ("{:.3f}".format(attributes[attr]))
                            dat = (self.strPrecision.format(attributes[attr]))
                            # self.strPrecision = "{:.3f}"

                        ################################################################################
                        # --- SE REALIZA EL CONTROL DE DOMINIOS ---
                        ################################################################################
                        if self.cbx_dominios.isChecked():
                            if attr == 'Titularidad':
                                if dat not in self.GDBDom.Titularidad:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'Funcionalidad':
                                if dat not in self.GDBDom.Funcionalidad:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'Tipologia_DobleC':
                                if dat not in self.GDBDom.Tipologia_DobleC:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'Tipologia_UnaC':
                                if dat not in self.GDBDom.Tipologia_UnaC:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'Provincia':
                                if dat not in self.GDBDom.Provincia:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'idOrdenCtra':
                                # Comprobamos la concordancia entre 'Funcionalidad' e 'idOrdenCtra'
                                dataFunc = attributes['Funcionalidad']
                                if dat in self.GDBDom.idOrdenCtra.keys():
                                    if dataFunc != self.GDBDom.idOrdenCtra[dat]:
                                        dat = '(x) '+dat
                                        datErr = True
                                else:
                                    dat = '(x) '+dat+ ' DATO ERRONEO'
                                    datErr = True

                        datos += (dat + u';')

                ################################################################################
                # --- SE REALIZA EL CONTROL DE IDMATRÍCULA DUPLICADO ---
                ################################################################################
                if self.cbx_idmatricula.isChecked():
                    idMatBusq = attributes['idMatricula']
                    result = self.ControlAtributos(idMatBusq)
                    if result != 'OK':
                        datErr = True
                    datos += result + u';'

                ################################################################################
                # --- SE REALIZA EL CONTROL DE DENOMINACION DIFERENTE ---
                ################################################################################
                if self.cbx_denomTramos.isChecked():
                    matriculaFEAT = attributes['Matricula']
                    denominacionFEAT = attributes['Denominacion']
                    if matriculaFEAT[-1] != 'a': # Solo se revisan tramos troncales, no 'a'
                        result = self.ControlDenomTramo(matriculaFEAT, denominacionFEAT)
                        if result != 'OK':
                            datErr = True
                    datos += result + u';'

                ################################################################################
                # --- SE REALIZA EL CONTROL DE CALIBRACIÓN ---
                ################################################################################
                if self.cbx_calibracion.isChecked() or self.cbx_longPks.isChecked():
                    objIdBusq = attributes['OBJECTID']
                    # print ('OBJECTID:', objIdBusq, ' Matricula: ', attributes['Matricula'])
                    result = self.ControlGeometrico(objIdBusq)
                    if result != None:

                        if self.cbx_calibracion.isChecked():
                            datos += result[0] + u';'
                            if result[0] != 'OK':
                                datErr = True
                        if self.cbx_longPks.isChecked():
                            datos += result[1] + u';'
                            if result[1] != 'OK':
                                datErr = True
                        if self.cbx_inicioNeg.isChecked():
                            datos += result[2] + u';'
                            if result[2] != 'OK':
                                datErr = True
                        if self.cbx_congrPKStramos.isChecked():
                            datos +=  'OK' + u';'

                ################################################################################
                # --- SE REALIZA EL CONTROL DE PKS ---
                ################################################################################
                if self.cbx_PKSxCtra.isChecked() or self.cbx_calibrPKS.isChecked():
                    objIdBusq = attributes['OBJECTID']
                    resultPKSxCtra, resultcalibrPKS = self.ControlPKS(objIdBusq)

                    if self.cbx_PKSxCtra.isChecked():
                        if isinstance(resultPKSxCtra,str):
                            datos += resultPKSxCtra + u';'
                            if resultPKSxCtra == 'COMPLETO':
                                datErr = True

                        if isinstance(resultPKSxCtra,list):
                            dataResult = '/'.join(str(e) for e in resultPKSxCtra)
                            datos += dataResult + u';'
                            datErr = True

                    if self.cbx_calibrPKS.isChecked():
                        if isinstance(resultcalibrPKS,str):
                            datos += resultcalibrPKS + u';'
                            if resultcalibrPKS == 'COMPLETO':
                                datErr = True

                        if isinstance(resultcalibrPKS,list):
                            dataResult = '/'.join(str(e) for e in resultcalibrPKS)
                            datos += dataResult + u';'
                            datErr = True


                #####################################
                # --- AÑADIENDO LINEA AL FICHERO ---
                #####################################
                items = datos.split(";")
                # print (datos)
                # print ('TOTAL: ', len(items), items)

                if datErr == True or self.chbTODOSELEMEN.isChecked():
                    # print datos
                    target.write(datos)
                    target.write("\n")
                nfeat +=1
                prog = 50 * nfeat/numfeats
                self.progressBar.setValue(int(prog))
                self.lblINFO.setText(u'INFO: Añadiendo a CSV registro ' + str(nfeat) +'/' +str(numfeats)
                    +' Ctra: '+ attributes['Matricula'])

        #####################################
        # --- CERRANDO FICHERO target ---
        #####################################
        target.close()

        # Se carga la capa de EJES
        if self.cbx_calcEJESCAL.isChecked():
            QgsProject.instance().addMapLayer(self.dest_layerEJES, False)
            # TODO Habrá que crear un estilo
            # estiloCAPA = os.path.join(os.path.dirname(__file__), conf.general["carpeta_estilos"] + '/GDB_PKS_AUSENTES.qml')
            # self.dest_layerEJES.loadNamedStyle(estiloCAPA)

            # Colocamos la capa arriba del todo
            root = QgsProject.instance().layerTreeRoot()
            root.insertLayer(0, self.dest_layerEJES)


        # Se carga la capa de PKS
        if self.cbx_PKSxCtra.isChecked() and self.cbx_calcPKS.isChecked():
            QgsProject.instance().addMapLayer(self.dest_layerPKS, False)
            estiloCAPA = os.path.join(os.path.dirname(__file__), conf.general["carpeta_estilos"] + '/GDB_PKS_AUSENTES.qml')
            self.dest_layerPKS.loadNamedStyle(estiloCAPA)

            # Colocamos la capa arriba del todo
            root = QgsProject.instance().layerTreeRoot()
            root.insertLayer(0, self.dest_layerPKS)


        fich_csv_uri = u"file:///"+ fich_csv +"?type=csv&geomType=none&subsetIndex=no&delimiter=%s&watchFile=no" % (";")

        abstract = ''
        if self.cbxTitularidad.currentText() != '%':
                    abstract += u'Titularidad - %s / '%self.cbxTitularidad.currentText()
        if self.cbxFuncionalidad.currentText() != '%':
                    abstract += u'Funcionalidad - %s / '%self.cbxFuncionalidad.currentText()
        if self.cbxProvincia.currentText() != '%':
                    abstract += u'Provincia - %s / '%self.cbxProvincia.currentText()

        # Esto crea la capa CSV
        #   Si existe la capa se debe borrar
        nomcapa = u'CATALOGO CARRETERAS CTRL'
        csv_lyrLIST = QgsProject.instance().mapLayersByName(nomcapa)
        if len(csv_lyrLIST) >0:
            for csv_lyr in csv_lyrLIST:
                QgsProject.instance().removeMapLayer(csv_lyr.id())
        csv_lyr = QgsVectorLayer(fich_csv_uri, nomcapa,'delimitedtext')
        # csv_lyr.setAbstract (abstract)
        QgsProject.instance().addMapLayer(csv_lyr, False)

        # Colocamos la capa arriba del todo
        root = QgsProject.instance().layerTreeRoot()
        root.insertLayer(0, csv_lyr)
        self.iface.setActiveLayer(csv_lyr)


        self.tbrURLCOMPLETA.setHtml(self.creaHTML(''))
        pass

        # self.exportLayer(fileTipe, fich)
        self.exportLayer(dataEntrada, fileTipe, fich)


        # Abrir el fichero resultante
        if os.path.exists(self.exportedFile):
            os.startfile(self.exportedFile)
        else:
            self.iface.messageBar().pushMessage('Parece que no se ha creado el fichero ' +self.exportedFile, self.nombre_plugin, QgsMessageBar.WARNING, 5)

        self.progressBar.setValue(0)

        QApplication.restoreOverrideCursor()

        stop = timeit.default_timer()
        text = '  --- TERMINADO ---'
        tiempo = 'Tiempo: '+"%0.2f"%(stop - start)+' seg.'
        self.lblINFO.setText(text+tiempo)
        self.fun.showMessage(text+'\n\n'+tiempo)
        self.close


    def GetJSONPKS(self, whereTXTPKS):
        # url = u'https://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_PKS_WFS/MapServer/0/query?'
        url = conf.general["rest_Pks"]

        values = {
                  'where' : whereTXTPKS,
                  'text': '',
                  'objectIds': '',
                  'returnCountOnly': False,
                  'outFields': '*',
                  'geometryPrecision': 3,
                  'returnGeometry' : 'true',
                  'f': 'json'}

        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        print ('Descarga de PKS: ',url+data)

        try:
            response = json.load(urllib.request.urlopen(url + data))
            features =  response["features"]

            return response
        except:
            QApplication.restoreOverrideCursor()
            result = self.PrintException()
            self.fun.showMessageERR(result,text2="",tittle=f"{self.nombre_plugin} - Error de código",)
            return 'error'

        return response

    def creacapaPKSausentes(self):
        # CREACIÓN DE UNA CAPA VECTORIAL DE DESTINO EN MEMORIA AÑADIENDOLE LOS CAMPOS RESULTADO
        # dest_name = 'c:\temp\GDB_PKS_ausentes.gpkg|layername=GDB_PKS_ausentes'
        dest_name = 'GDB_PKS_ausentes'
        self.dest_layerPKS = QgsVectorLayer("point?crs=epsg:"+str(srcVal), dest_name, "memory")
        pr = self.dest_layerPKS.dataProvider()
        self.dest_layerPKS.startEditing()
        # Añadir CAMPOS
        pr.addAttributes( [ QgsField("OBJECTID",   QMetaType.Type.Int),
                            QgsField("idMatricula",QMetaType.Type.Int),
                            QgsField("idPK",       QMetaType.Type.Int),
                            QgsField("PKhito",     QMetaType.Type.Double),
                            QgsField("PKdist",     QMetaType.Type.Double),
                            QgsField("Provincia",  QMetaType.Type.QString),
                            QgsField("idctramo",   QMetaType.Type.QString)
                            ] )

        if self.cbx_calibrPKS.isChecked():
            pr.addAttributes( [ QgsField("PKcalc", QMetaType.Type.Double),
                                QgsField("DistEJE",QMetaType.Type.Double)
                            ] )
        self.dest_layerPKS.commitChanges()


    def creacapaEJESCAL(self):
        # CREACIÓN DE UNA CAPA VECTORIAL DE EJES CON DESTINO EN MEMORIA AÑADIENDOLE LOS CAMPOS RESULTADO
        msg = 'LA CREACIÓN DE EJES CALIBRADOS TIENE LAS SIGUIENTES FUNCIONES:\n'
        msg +='    - Reordena los tramos calibrados\n\n'
        QApplication.restoreOverrideCursor()
        self.fun.showMessage(msg)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        dest_name = 'GDB_EJES_corregidos'

        geometryType = "LineStringM"
        uri = geometryType
        uri += "?crs=%s" % self.fun.crsString(self.iface.mapCanvas().mapSettings().destinationCrs())
        pr = QgsProviderRegistry.instance().createProvider('memory', uri)

        # Añadir CAMPOS
        pr.addAttributes( [
                QgsField("OBJECTID",   QMetaType.Type.Int),
                QgsField("idMatricula",     QMetaType.Type.Int),
                QgsField("Matricula",       QMetaType.Type.QString),
                QgsField("Matricula_Plan",  QMetaType.Type.QString),
                QgsField("Longitud",        QMetaType.Type.Double),
                QgsField("PkINI",           QMetaType.Type.Double),
                QgsField("PkFin",           QMetaType.Type.Double),
                QgsField("Long_Km",         QMetaType.Type.Double),
                QgsField("Titularidad",     QMetaType.Type.QString),
                QgsField("Funcionalidad",   QMetaType.Type.QString),
                QgsField("Tipologia_DobleC",QMetaType.Type.QString),
                QgsField("Tipologia_UnaC",  QMetaType.Type.QString),
                QgsField("idOrdenCtra",     QMetaType.Type.Int),
                QgsField("Denominacion",    QMetaType.Type.QString),
                QgsField("Origen",          QMetaType.Type.QString),
                QgsField("Destino",         QMetaType.Type.QString),
                QgsField("Provincia",       QMetaType.Type.QString),
                QgsField("Shape.STLength()",QMetaType.Type.Double)
                ] )

        uri = pr.dataSourceUri()
        self.dest_layerEJES = QgsVectorLayer(uri, dest_name, 'memory')


    def ControlAtributos(self,idMatBusq):
        # QUERY AL WFS Plan_Carreteras_BTA_WFS para contar elementos con el 'idMatBusq'
        url = conf.general["rest_carreteras"]
        values = {
                  'where' : ' idMatricula = '+str(idMatBusq),
                  'text': '',
                  'objectIds': '',
                  'returnCountOnly': True,
                  'f': 'json'}

        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        self.tbrURLCOMPLETA.setHtml(self.creaHTML(url+data))
        # print url+data
        respuesta = self.fun.getFeaturesBTAcalibradaCount(values)
        if respuesta['count'] > 1:
            return str(respuesta['count'])
        else:
            return 'OK'
        pass


    def ControlDenomTramo(self, MatricBusq, DenomINI):
        # QUERY AL WFS Plan_Carreteras_BTA_WFS para buscar elementos con Matricula = 'MatricBusq' y determinar si todas las DENOMINACIÓN son idénticas
        url = conf.general["rest_carreteras"]
        values = {
                  'where' : 'Matricula'+ " = '" + MatricBusq + u"'",
                  'text': '',
                  'objectIds': '',
                  'outFields': '*',
                  'returnGeometry' : 'false',
                  'f': 'json'}

        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        self.tbrURLCOMPLETA.setHtml(self.creaHTML(url+data))
        # print (url+data)

        try:
            response = json.load(urllib.request.urlopen(url+data))
        except:
            QApplication.restoreOverrideCursor()
            result = self.PrintException()
            self.showMessageERR(result,text2="",tittle=f"{self.nombre_plugin} - Error de código",)
            return

        try:
            features =  response["features"]    # Los distintos features encontrados en la búsqueda
        except:
            QApplication.restoreOverrideCursor()
            return ('ERROR EN %s'%(MatricBusq))

        result = ''
        for feature in features:
            attributes =  feature["attributes"]
            DenomFeat = attributes['Denominacion']
            if DenomFeat != DenomINI:
                result += ', ' + str(attributes['idMatricula'])

        if result == '':
            return 'OK'
        else:
            return ('Distintos '+result)


    def ControlGeometrico(self, objIdBusq):
        # CONTROL GEOMETRICO TODO EN UNO
        # QUERY AL WFS Plan_Carreteras_BTA_WFS para obtener la geometría'
        url = conf.general["rest_carreteras"]
        values = {
                  'where' : ' OBJECTID = '+str(objIdBusq),
                  'text': '',
                  'objectIds': '',
                  'returnCountOnly': False,
                  'outFields': '*',
                  'returnGeometry' : 'true',
                  'returnM': 'true' ,
                  'f': 'json'}

        # print (url+data)
        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        req = urllib.request.urlopen(url+data)

        try:
            response = json.load(urllib.request.urlopen(url+data))
        except:
            QApplication.restoreOverrideCursor()
            result = self.PrintException()
            self.showMessageERR(result,text2="",tittle=f"{self.nombre_plugin} - Error de código",)
            return

        features =  response["features"]    # Los distintos features encontrados en la búsqueda

        #################################################
        ## CONTROL CALIBRACIÓN VARIABLES               ##
        #################################################
        datResult = 'F:'+str(len(features))
        FaltaM = False
        Sentido = 'D'
        Inversion = False
        TramosInv = False
        ctrlCalib = 'OK'
        ctrlCalib1= ''
        TolPKS = 0.001
        #################################################
        ## CONTROL LONG,PKINI,PKFIN,LONGPK VARIABLES   ##
        #################################################
        longMal = False
        PKiniMal = False
        PKfinMal = False
        longKMMal = False
        ctrlLongPks = 'OK'
        ctrlLongPks1= ''
        #################################################
        ## CONTROL INICIO NEGATIVO  VARIABLES          ##
        #################################################
        ctrlInicioNEG = 'OK'

        for feature in features:
            geometry = feature["geometry"]
            attributes =  feature["attributes"]

            ####################################
            ##      CONTROL CALIBRACIÓN       ##
            ####################################
            if self.cbx_calibracion.isChecked():
                datResult += ' P:'+str(len(geometry["paths"]))
                Mant = geometry["paths"][0][0][2]
                if Mant is None:
                    FaltaM = True
                else:
                    ntramo = 1
                    for path in geometry["paths"]:
                        # print '  Numero Puntos: ', len(path)
                        datResult += ' O:'+str(len(path))
                        npointpath = 1
                        for point in path:
                            if npointpath == 1: # Comprobamos si hay INVERSION entre tramos
                                if type(point[2]) == int or type(point[2]) == float:
                                    # if (point[2] < Mant) and (TramosInv == False):
                                        # TramosInv == True
                                    if point[2] < Mant:
                                        TramosInv = True
                                    Mant = point[2]
                            else:
                                if type(point[2]) == int or type(point[2]) == float:
                                    if (point[2] < Mant) and (Inversion == False):
                                        Inversion == True
                                    if point[2] < Mant:
                                        Sentido='I'
                                    Mant = point[2]
                                else:
                                    FaltaM = True
                            npointpath += 1
                        ntramo += 1

                if abs(attributes['Longitud']-attributes['Shape.STLength()'])>TolPKS:
                    longMal = True
                    Longitud = attributes['Shape.STLength()']
                    pass

            #########################################
            ##  CONTROL LONG,PKINI,PKFIN,LONGPK    ##
            #########################################
            if self.cbx_longPks.isChecked():
                PKinimin = 999999
                PKfinmax = 0
                for path in geometry["paths"]:
                    # datResult += ' O:'+str(len(path))
                    for point in path:
                        if point[2] is not None:
                            if point[2]<PKinimin:
                                PKinimin=point[2]
                            if point[2]>PKfinmax:
                                PKfinmax=point[2]
                if PKinimin == 999999:
                    PKinimin = 0
                if attributes['PkINI'] is not None:
                    if abs(PKinimin - attributes['PkINI'])>TolPKS:
                        PKiniMal = True
                else:
                    PKiniMal = True

                if attributes['PkFin'] is not None:
                    if abs(PKfinmax-attributes['PkFin'])>TolPKS:
                        PKfinMal = True
                else:
                    PKfinMal = True

                LongKMCalc=PKfinmax-PKinimin
                if attributes['Long_Km'] is not None:
                    if abs(LongKMCalc-attributes['Long_Km'])>TolPKS:
                        longKMMal = True
                else:
                    longKMMal = True


        ####################################
        ##      CONTROL CALIBRACIÓN       ##
        ####################################
        if FaltaM == True:
            ctrlCalib1 = 'FaltaM/'
        else:
            ctrlCalib1 = '-/'

        if Sentido == 'I':
            ctrlCalib1 += 'SenInv/'
        else:
            ctrlCalib1 += '-/'

        if TramosInv == True:
            ctrlCalib1 += 'TramInv/'
        else:
            ctrlCalib1 += '-/'

        if Inversion == True:
            ctrlCalib1 += 'Inversion'
        else:
            ctrlCalib1 += '-'

        if ctrlCalib1 != '-/-/-/-':
            ctrlCalib = ctrlCalib1

            if self.cbx_calcEJESCAL.isChecked():
                # --- AÑADIENDO ELEMENTO CORRECTO AL FICHERO DE EJES ---
                pr = self.dest_layerEJES.dataProvider()
                self.dest_layerEJES.startEditing()
                fet = QgsFeature(self.dest_layerEJES.fields())

                attributes =  feature["attributes"]

                gline = self.creaPolylineCORRECT(geometry) # Se convierte la geometria json en geometria qgis

                fet.setGeometry(gline)

                for attr in attributes:
                    fet.setAttribute(attr, attributes[attr])

                pr.addFeatures( [ fet ] )

                self.dest_layerEJES.updateExtents()
                self.dest_layerEJES.commitChanges()


        #########################################
        ##  CONTROL LONG,PKINI,PKFIN,LONGPK    ##
        #########################################
        if longMal == True:
            ctrlLongPks1 = "{:.3f}".format(Longitud)+'/'
        else:
            ctrlLongPks1 = '-/'
        if PKiniMal == True:
            ctrlLongPks1 += "{:.3f}".format(PKinimin)+'/'
        else:
            ctrlLongPks1 += '-/'
        if PKfinMal == True:
            ctrlLongPks1 += "{:.3f}".format(PKfinmax)+'/'
        else:
            ctrlLongPks1 += '-/'
        if longKMMal == True:
            ctrlLongPks1 += "{:.3f}".format(LongKMCalc)
        else:
            ctrlLongPks1 += '-'
        if ctrlLongPks1 != '-/-/-/-':
            ctrlLongPks = ctrlLongPks1

        return ctrlCalib, ctrlLongPks, ctrlInicioNEG


    def ControlPKS(self, objIdBusq):
        # CONTROL DE PKS
        # QUERY AL WFS Plan_Carreteras_BTA_WFS para obtener la geometría de la carretera'
        url = conf.general["rest_carreteras"]
        values = {
                  'where' : ' OBJECTID = '+str(objIdBusq),
                  'text': '',
                  'objectIds': '',
                  'returnCountOnly': False,
                  'outFields': '*',
                  'returnGeometry' : 'true',
                  'returnM': 'true' ,
                  'f': 'json'}

        # print (url+data)
        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        req = urllib.request.urlopen(url+data)

        try:
            response = json.load(urllib.request.urlopen(url+data))
        except:
            QApplication.restoreOverrideCursor()
            result = self.PrintException()
            self.showMessageERR(result,text2="",tittle=f"{self.nombre_plugin} - Error de código",)
            return

        tramo = '-'
        features =  response["features"]    # Los distintos features encontrados en la búsqueda
        listPKSFALTAN = []
        listPKSERR=  []
        for feature in features:
            geometry = feature["geometry"]
            attributes =  feature["attributes"]
            ctra = attributes['Matricula']
            listPKSFALTAN = []
            listPKSERR=  []
            #########################################
            ##  CONTROL EXISTENCIA TODOS LOS PKS   ##
            #########################################
            # Obtenemos PKinimin y PKfinmax del tramo
            PKinimin = 999999
            PKfinmax = 0
            for path in geometry["paths"]:
                for point in path:
                    if point[2] is not None:
                        if point[2]<PKinimin:
                            PKinimin=point[2]
                        if point[2]>PKfinmax:
                            PKfinmax=point[2]
                    else:
                        listPKSFALTAN = 's/d'
                        listPKSERR = 's/d'

            minPKENTERO = math.floor(PKinimin)+1    # El Pk 0 no se analiza
            maxPKENTERO = math.floor(PKfinmax)
            numPKStramo = 0
            numPKSerror = 0
            if maxPKENTERO < minPKENTERO:
                # print (ctra, 'numPKStramo:', numPKStramo, '  numPKSerror:', numPKSerror, listPKSFALTAN, listPKSERR)
                return 'OK', 'OK'

            # if ctra == 'CM-412a':
                # text = u'CTRA: {} - {}\n PKINImin: {} PKFINmax: {}\nPKINI: {} PKFIN: {}'.format( ctra, attributes['Matricula_Plan'], str(minPKENTERO), str(maxPKENTERO), attributes['PkINI'], attributes['PkFin'])
                # self.fun.showMessage(text)

            for valor in range(minPKENTERO, maxPKENTERO+1):
                addPKSxCtra = False
                addPKScalib = False
                # COMPROBAMOS EN BUCLE SI EXISTE EN EL FICH DE PKS CADA PK ENTERO DEL TRAMO
                if self.cbx_PKSxCtra.isChecked():
                    consulta = u'"idctramo" = \'{}\' and \"PKhito\" = {}'.format( ctra, str(valor))
                    # print (consulta)
                    expr = QgsExpression( consulta )
                    # print ('expr = ', expr)
                    it = self.layerPKS.getFeatures( QgsFeatureRequest( expr ) )    # Obtiene un iterador de elementos desde una expresión
                    # print ('Total: ', len(list(it)))
                    # if sum(1 for _ in it) == 0: # No existe el PK
                    if len(list(it)) == 0: # No existe el PK
                        print ('FALTA: ', ctra, str(valor))
                        listPKSFALTAN.append(str(valor))
                        if self.cbx_calcPKS.isChecked():
                            addPKSxCtra = True
                            numPKSerror += 1

                        result = self.fun.CtraPktoCoorsAcim(ctra, valor, self.lneDISTejePK.text(), 'CALIBRADO')

                        if not self.fun.isFloat(result[0]):
                            pass
                        else:
                            acim = result[2]
                            disteje = float(self.lneDISTejePK.text())
                            if (disteje != 0):
                                XP = result[0] + disteje * math.cos(acim*math.pi/180)
                                YP = result[1] - disteje * math.sin(acim*math.pi/180)
                            else:
                                XP,YP = result[0], result[1]
                    else:
                        print ('EXISTE: ', ctra, str(valor))
                        pass

                if self.cbx_calibrPKS.isChecked():
                    listPKSERR=  []
                    pass

                if (addPKSxCtra == True or addPKScalib == True) and self.cbx_calcPKS.isChecked():
                    # --- AÑADIENDO ELEMENTO AL FICHERO DE PKS ---
                    pr = self.dest_layerPKS.dataProvider()
                    self.dest_layerPKS.startEditing()
                    fet = QgsFeature(self.dest_layerPKS.fields())

                    fet.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(XP,YP)))
                    idMatricula = attributes["idMatricula"]
                    fet.setAttribute("idMatricula", idMatricula)
                    fet.setAttribute("idPK",        idMatricula*1000+valor)
                    fet.setAttribute("PKhito",      valor)
                    fet.setAttribute("PKdist",      valor)
                    fet.setAttribute("Provincia",   self.cbxProvincia.currentText())
                    fet.setAttribute("idctramo",    ctra)

                    if self.cbx_calibrPKS.isChecked():
                        fet.setAttribute("PKcalc",      0)
                        fet.setAttribute("DistEJE",     0)

                    pr.addFeatures( [ fet ] )
                    self.dest_layerPKS.updateExtents()
                    self.dest_layerPKS.commitChanges()

                numPKStramo += 1

        if len(listPKSFALTAN) == 0:
            listPKSFALTAN = 'OK'
        elif numPKStramo == numPKSerror or listPKSFALTAN == []:
            listPKSFALTAN = 'COMPLETO'

        if len(listPKSERR) == 0:
            listPKSERR = 'OK'
        elif numPKStramo == numPKSerror or listPKSERR == []:
            listPKSERR = 'COMPLETO'

        # print (ctra, 'numPKStramo:', numPKStramo, '  numPKSerror:', numPKSerror, listPKSFALTAN, listPKSERR)
        return listPKSFALTAN, listPKSERR


    ########################################################################
    ##                  FINAL  CONTROL  CALIDAD                           ##
    ########################################################################


    # def exportLayer(self, etype='csv', fich=''):
    def exportLayer(self, dataEntrada, etype='csv', fich=''):
        # Se exporta la tabla de atributos de la tabla seleccionada al tipo de fichero elegido

        # Establece propiedades del tipo de salida
        self.etype = etype
        self.exportHiddenAttributes = False
        self.csvDelimiter = '\t'

        # Cojemos la capa activa
        layer = self.iface.activeLayer()
        msg= None

        # Comprobamos si la capa es valida para exportar
        if layer and layer.type() == QgsMapLayer.VectorLayer and hasattr(layer, 'providerType'):

            # Se acude al método adecuado según el tipo seleccionado
            if etype != 'printer':

                ePath = fich
                self.exportedFile = fich

                if etype == 'csv':
                    self.lblINFO.setText(u'INFO: Capa CSV exportada adecuadamente')
                    msg = u'La capa ha sido cargada adecuadamente.'
                    status = 'info'

                elif etype == 'html':
                    self.lblINFO.setText(u'INFO: Exportando datos de CSV a HTML ')
                    msg, status = self.exportLayerToHtml(layer, dataEntrada, fich, False, 'html')

                elif etype == 'pdf':
                    self.lblINFO.setText(u'INFO: Exportando datos de CSV a PDF ')
                    msg, status = self.exportLayerToPdf(layer)

            else:
                msg, status = self.exportLayerToPdf(layer, True)

        else:
            self.lblINFO.setText(u'INFO: Falta seleccionar una capa vectorial')
            msg = u'Selecciona primero una capa vectorial'
            status = 'warning'


    def exportLayerToHtml(self, layer, dataEntrada, ePath=None, cutPages=False, etype=None):
        '''
        Exporta la capa a HTML
        usando una plantilla y leyendo los datos
        desde la capa seleccionada
        '''
        self.lblINFO.setText(u'INFO: Exportando datos de CSV a HTML ')

        # VALORES ENCABEZADOS
        title = u'CATÁLOGO DE CARRETERAS - CONTROL DE CALIDAD'

        campoGrupo = u'Funcionalidad'
        campoGrupo1 = u'Titularidad'

        campoSumaGrupo = u'Long_Km'
        udSuma = u'Km'

        # DEFINICIONES DE REDES (Funcionalidad)
        listaTitulos = [
            {'Grupo' : u'Autopistas Peaje', 'Titulo' : u'RED ESTATALES - Autopistas Peaje', 'Color' : u'rgb(90, 110, 255)'},
            {'Grupo' : u'Autopistas', 'Titulo' : u'RED ESTATALES - Autopistas', 'Color' : u'rgb(90, 110, 255)'},
            {'Grupo' : u'Convencionales', 'Titulo' : u'RED ESTATALES - Convencionales', 'Color' : u'rgb(255, 90, 90)'},
            {'Grupo' : u'Básica alta capacidad', 'Titulo' : u'RED REGIONAL - BÁSICA ALTA CAPACIDAD', 'Color' : u'rgb(255, 115, 223)'},
            {'Grupo' : u'Básica', 'Titulo' : u'RED REGIONAL - BÁSICA', 'Color' : u'rgb(255, 170, 0)'},
            {'Grupo' : u'Comarcal', 'Titulo' : u'RED REGIONAL - COMARCAL', 'Color' : u'rgb(85, 255, 0)'},
            {'Grupo' : u'Local', 'Titulo' : u'RED REGIONAL - LOCAL', 'Color' : u'rgb(255, 255, 0)'},
            {'Grupo' : u'Travesía', 'Titulo' : u'RED REGIONAL - TRAVESÍAS (RED LOCAL)', 'Color' : u'rgb(255, 255, 0)'},
            {'Grupo' : u'Ramal', 'Titulo' : u'RED REGIONAL - RAMALES (RED LOCAL)', 'Color' : u'rgb(255, 255, 0)'},
            {'Grupo' : u'Enlace', 'Titulo' : u'RED REGIONAL - ENLACES', 'Color' : u'rgb(200, 200, 200)'},
            {'Grupo' : u'Diputación', 'Titulo' : u'RED DIPUTACIÓN PROVINCIAL', 'Color' : u'rgb(254, 254, 254)'}
            ]

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        # Leemos el fichero de plantilla
        tplPath = os.path.join(
            self.plugin_dir,
            "templates/htmlTempCTRL.tpl"
        )
        fin = open(tplPath)
        data = fin.read()
        fin.close()

        # Se obtienen los datos de la capa
        layerData, nb = self.getLayerData(layer)

        # Obtenemos los tipos de cada campo
        fields = layer.fields()
        tipoCampos = []
        for field in fields:
            tipoCampos.append(field.typeName())


        # Nombres de campos de la capa
        fieldNames = layerData[0]
        nbAttr = len(fieldNames)
        numcampoGrupo = fieldNames.index(campoGrupo )
        numcampoGrupo1 = fieldNames.index(campoGrupo1)
        numcampoSumaGrupo = fieldNames.index(campoSumaGrupo )

        # Calculamos posiciones de los campos a listar
        numColumnas = u'"'+str(len(self.listCampos))+u'"'
        numColumnasDat  = u'"'+str(len(self.listCampos)-len(self.listCamposCTRL))+u'"'
        numColumnasCtrl = u'"'+str(len(self.listCamposCTRL))+u'"'
        poslistCampos = []
        poslistCamposCTRL = []
        for campo in self.listCampos:
            poslistCampos.append(self.listCamposCOMP.index(campo))
        for campo in self.listCamposCTRL:
            poslistCamposCTRL.append(self.listCamposCOMP.index(campo))


        # Creamos el contenido de 'tbody' con los datos de atributos de los elementos
        valcampoGrupo = ''
        tbody = ''
        i = 6 # num lineas
        page = 1
        totalGrup = 0
        totalGlobal = 0
        table = 0
        attrValues = layerData[1:]


        # Escribir la tabla de contenido como HTML
        for values in attrValues:
            prog = 50 +50 * attrValues.index(values)/len(attrValues)
            self.progressBar.setValue(int(prog))
            self.lblINFO.setText(u'INFO: Añadiendo a -'+etype+'- registro ' + str(attrValues.index(values)) +'/' +str(len(attrValues)))

            valorTestigo = values[numcampoGrupo]
            if valorTestigo == u'Básica alta capacidad' and values[numcampoGrupo1] == 'Estatal':
                valorTestigo = u'Autopistas'
            if valorTestigo == u'Básica' and values[numcampoGrupo1] == 'Estatal':
                valorTestigo = u'Convencionales'
            if values[numcampoGrupo1] == u'Diputación':
                valorTestigo = u'Diputación'

            if valorTestigo != valcampoGrupo:
                if table != 0:
                    totalGlobal += totalGrup
                    totalGrup = 0
                    i += 2
                thead = ''
                if table == 0:
                    thead+='        <table>\n'
                    thead+='            <tbody>\n'
                table+=1
                valcampoGrupo = valorTestigo
                tituloGrupo = ''
                colBck = 'rgb(200, 200, 200)'
                colBlanco = 'rgb(250, 250, 250)'
                colError = 'rgb(255, 150, 150)'
                for dataGrupos in listaTitulos:
                    if dataGrupos['Grupo'] == valcampoGrupo:
                        tituloGrupo = dataGrupos['Titulo']
                        colBck = dataGrupos["Color"]
                thead+='                <tr>\n'
                thead+='                    <th colspan=%s align="left" style="background: %s">%s</th>\n'%(numColumnasDat, colBck, tituloGrupo)
                thead+='                    <th colspan=%s align="left" style="background: %s">%s</th>\n'%(numColumnasCtrl, colBlanco, 'CONTROL')
                thead+='                </tr>\n\n'
                thead+='                <tr>\n'
                i += 3

                # GENERAR ENCABEZADO DE CADA GRUPO DE DATOS
                for field in self.listCampos:
                    if self.listCampos.index(field)<(len(self.listCampos)-len(self.listCamposCTRL)):
                        thead+= '                    <th style="background: %s">%s</th>\n' %(colBck, field)
                    else:
                        thead+= '                    <th style="background: %s">%s</th>\n' %(colBlanco, field)

                thead+= '                </tr>\n\n'
                tbody+= thead

            # Se crea la lista de valores de cada registro
            valuesLista = []
            tbody+= '                <tr>\n'
            for pos in poslistCampos:
                # Caso de que se trate de datos del CONTROL DE CALIDAD
                if pos in poslistCamposCTRL:
                    valueTD = values[pos]
                    if valueTD == 'OK':
                        tbody+= '                    <td align="left">' + valueTD + '</td>\n'
                    else:
                        tbody+= '                    <td align="left" style="background: %s">%s</td>\n'%(colError,valueTD)

                else:
                # Caso de que se trate de datos NORMALES
                    if tipoCampos[pos] == 'integer':
                        try:
                            valueTD = "{:.0f}".format(float(values[pos]))
                            tbody+= '                    <td align="right">' + valueTD + '</td>\n'
                        except:
                            valueTD = valueTD = values[pos]
                    elif tipoCampos[pos] == 'double':
                        try:
                            valueTD = "{:.3f}".format(float(values[pos]))
                            tbody+= '                    <td align="right">' + valueTD + '</td>\n'
                        except:
                            valueTD = valueTD = values[pos]
                    else:
                        valueTD = values[pos]
                        if valueTD[:3] != '(x)':
                            tbody+= '                    <td align="left">' + valueTD + '</td>\n'
                        else:
                            tbody+= '                    <td align="left" style="background: %s">%s</td>\n'%(colError,valueTD)

            tbody+= '                    </td>\n'
            tbody+= '                </tr>\n\n'


            try:
                totalGrup += float(values[numcampoSumaGrupo])

            except:
                pass
            i+=1
            if i == self.maxLinesPerPage and cutPages and self.QgisVersion > 10900:
                i = 3
                tbody+= '</table>\n\n'
                tbody+= '<span>Page %s</span>' % page
                tbody+= '<div class="saltopagina"></div>\n\n'
                tbody+= '<table><thead>' + thead + '</thead><tbody>'
                page+=1


        # LÍNEAS FINALES
        totalGlobal += totalGrup
        tbody+='            </tbody>\n'
        tbody+='        </table>\n'

        # Get creation date
        locale.setlocale(locale.LC_TIME,'')
        if hasattr(locale, 'nl_langinfo'):
            date_format = locale.nl_langinfo(locale.D_T_FMT)
        else:
            date_format = "%x %X"
        today = datetime.datetime.today()
        date = today.strftime(date_format)
        dt_date = u'JCCM. Dirección General de Carreteras '

        # Icono, Titulo, Resumen, número de Carreteras
        fileIcono = f'python/plugins/{self.nombre_plugin}/iconos/jccm.jpg'
        dirPYTJCCM = QgsApplication.qgisSettingsDirPath()
        fileIcono = os.path.normpath(os.path.join(os.path.dirname(dirPYTJCCM), fileIcono))
        dt_icono = '<img src="%s" border="0" width="100" height="80">'%fileIcono
        dt_title = u''
        dt_abstract = u'Datos'
        dt_info = u'Información'
        abstract = layer.abstract()
        info = u'TOTAL {:.0f} Carreteras - {:.3f} Km'.format(nb, totalGlobal)


        # Adapt style if needed
        style = ''
        # Get CSS style from table.css
        with open(self.cssPath, 'r') as content_file:
            style = content_file.read()
        if nbAttr > self.maxAttributesBeforeSmallFontSize:
            # style+= 'th, td {font-size:x-small;}'
            style+= 'th, td {font-size:10px;}'

        # Se confeccionan los datos de entrada
        datosEntrada = ''
        if self.cbx_idmatricula.isChecked():
            datosEntrada += 'idmatricula / '
        if self.cbx_dominios.isChecked():
            datosEntrada += 'CTRLdominios / '
        if self.cbx_denomTramos.isChecked():
            datosEntrada += 'CTRLdenomTramos / '
        if self.cbx_calibracion.isChecked():
            datosEntrada += 'CTRLcalibracion / '
        if self.cbx_longPks.isChecked():
            datosEntrada += 'CTRLpkini-pkfin / '
        if self.cbx_inicioNeg.isChecked():
            datosEntrada += 'CTRLinineg / '
        if self.cbx_PKSxCtra.isChecked():
            datosEntrada += 'PKSxCtra / '
        if self.cbx_calibrPKS.isChecked():
            datosEntrada += 'CalibrPKS / '


        # Replace values
        data = data.replace('$icono', dt_icono)
        data = data.replace('$dt_title', dt_title)
        data = data.replace('$title', title)
        data = data.replace('$dt_abstract', dt_abstract)
        data = data.replace('$abstract', abstract)
        data = data.replace('$dt_info', dt_info)
        data = data.replace('$info', info)
        data = data.replace('$tbody', tbody)
        # data = data.replace('$tbody1', tbody1)
        data = data.replace('$dt_date', dt_date)
        data = data.replace('$date', date)
        data = data.replace('$style', style)
        data = data.replace('$totalPages', "Pag. %s" % page)

        data = data.replace('$Campo1', 'Titularidad=')
        data = data.replace('$linea1', dataEntrada[0])
        data = data.replace('$Campo2', 'Funcionalidad=')
        data = data.replace('$linea2', dataEntrada[1])
        data = data.replace('$Campo3', 'TDC/TUC=')
        data = data.replace('$linea3', 's/d')
        data = data.replace('$Campo4', 'Provincia=')
        data = data.replace('$linea4', dataEntrada[3])
        data = data.replace('$Campo5', 'Otros=')
        data = data.replace('$linea5', dataEntrada[4])
        data = data.replace('$Campo6', 'CONTROL:')
        data = data.replace('$linea6', datosEntrada)

        # File path
        if not ePath:
            ePath = self.exportedFile

        try:
            # write html content
            f = open(ePath, 'w')
            # f.write(data.encode('utf-8'))
            f.write(data)
            f.close()

        # except IOError, e:
        except:
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación')
            status = 'critical'
        finally:
            msg = QApplication.translate("quickExport", u'La capa ha sido adecuadamente exportada')
            status = 'info'

        QApplication.restoreOverrideCursor()

        return msg, status


    def ListaIndices(self):
        numColumnas = 4
        colBck = 'rgb(200, 200, 200)'
        tituloGrupo= u'Lista de CÓDIGOS'
        tbody1+='                <tr>\n'
        tbody1+='                    <th colspan=%s align="left" style="background: %s">%s</th>\n'%(numColumnasDat, colBck, tituloGrupo)
        tbody1+='                </tr>\n\n'
        return tbody1
        pass


    def exportLayerToPdf(self, layer, doPrint=False):
        '''
        Exports the layer to PDF
        First export to HTML then convert to PDF.
        If not output file given, send directly to the printer
        '''

        # Create temporary file path
        temp = tempfile.NamedTemporaryFile()
        try:
            # Create temporary HTML file
            tPath = "%s.html" % temp.name

            msg, status = self.exportLayerToHtml(layer, tPath, True, 'pdf')

            # NOTE: this method already relied on QWebView and QPrintDialog
            # without ever importing them (a pre-existing bug, present
            # before the QGIS4/Qt6 migration - it would raise a NameError
            # the moment it was called under Qt5 too). Fixed here using
            # QWebEngineView, the QtWebEngine-based replacement for the
            # QtWebKit-based QWebView removed in Qt6, along with the
            # missing QPrintDialog import.
            #
            # Create a web view and fill it with the html file content
            web = QWebEngineView()
            web.load(QUrl.fromLocalFile(tPath))

            # Keep a strong reference so the QWebEngineView isn't garbage
            # collected before the asynchronous load/print finishes (this
            # wasn't a concern with the old, synchronous QWebView).
            if not hasattr(self, '_pdfExportWebViews'):
                self._pdfExportWebViews = []
            self._pdfExportWebViews.append(web)

            # Print only when HTML content is loaded
            def printIt(ok=True):
                # Open the printer dialog if needed
                if doPrint:
                    dialog = QPrintDialog()
                    if dialog.exec() == QDialog.DialogCode.Accepted:
                        printer = dialog.printer()
                    else:
                        return
                # No print, only PDF export
                else:
                    # Set page options for PDF
                    printer = QPrinter()
                    printer.setPageSize(self.pageSize)
                    printer.setOrientation(self.orientation)
                    printer.setFontEmbeddingEnabled(True)
                    printer.setColorMode(QPrinter.ColorMode.Color)
                    # set output file name in case of PDF export
                    printer.setOutputFileName(self.exportedFile)

                # Set some metadata
                printer.setCreator(u"QGIS - Complemento JCCM Carreteras")
                printer.setDocName(u"Exportado - %s" % layer.title() and layer.title() or layer.name())

                # Print (asynchronous under QWebEngineView; the callback
                # just releases our reference to the view once it is done)
                def _printFinished(success):
                    try:
                        self._pdfExportWebViews.remove(web)
                    except ValueError:
                        pass
                web.page().print(printer, _printFinished)

            # Only print when the HTML content has been loaded in the QWebEngineView
            web.loadFinished.connect(printIt)

        except:
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación.')
            status = 'critical'
        finally:
            # Automatically cleans up the file
            temp.close()
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación.')
            status = 'info'

        return msg, status




    def getLayerData(self, layer):
        '''
        Get fields and data from
        a vector layer
        '''
        data = []

        # Get layer fields names
        fields = layer.fields()
        if self.QgisVersion > 10900:
            fieldNames = [
                field.name() for i, field in enumerate(fields)
                # if layer.editType(i) != QgsVectorLayer.Hidden
                # or self.exportHiddenAttributes
            ]
        else:
            fieldNames = [
                str(fields[i].name()) for i in fields
                # if layer.editType(i) != QgsVectorLayer.Hidden
                # or self.exportHiddenAttributes
            ]
        data.append(fieldNames)

        # Get selected features or all features
        if layer.selectedFeatureCount():
            nb = layer.selectedFeatureCount()
        else:
            nb = layer.featureCount()



        # Get layer fields data

        # QGIS >= 2.0
        if self.QgisVersion > 10900:
            if layer.selectedFeatureCount():
                features = layer.selectedFeatures()
            else:
                features = layer.getFeatures()
            for feat in features:
                # Get attribute data
                values = [
                    self.displayAttributeValue(a) for i, a in enumerate(feat.attributes())
                    # if layer.editType(i) != QgsVectorLayer.Hidden
                    # or self.exportHiddenAttributes
                ]
                data.append(values)

        # QGIS 1.8
        else:
            provider = layer.dataProvider()
            allAttrs = provider.attributeIndexes()
            provider.select(allAttrs, QgsRectangle(), False)
            layer.select(allAttrs, QgsRectangle(), False)
            if layer.selectedFeatureCount():
                items = layer.selectedFeatures()
            else:
                items = layer
            for feat in items:
                attrs = feat.attributeMap()
                values = [
                    self.displayAttributeValue(v) for k,v in attrs.items()
                    # if layer.editType(k) != QgsVectorLayer.Hidden
                    # or self.exportHiddenAttributes
                ]
                data.append(values)

        return data, nb


    def displayAttributeValue(self, value):
        '''
        Convert QGIS attribute data into readable values
        '''
        # QGIS version
        isQgis2 = self.QgisVersion > 10900

        # Get locale date representation
        locale.setlocale(locale.LC_TIME,'')
        if hasattr(locale, 'nl_langinfo'):
            date_format = locale.nl_langinfo(locale.D_FMT)
            datetime_format = locale.nl_langinfo(locale.D_T_FMT)
        else:
            date_format = "%x"
            datetime_format = "%x %X"

        # Convert value depending of type
        if hasattr(value, 'toPyDate'):
            output = value.toPyDate().strftime(date_format)
        elif hasattr(value, 'toPyDateTime'):
            output = value.toPyDateTime().strftime(datetime_format)
        else:
            output = u"%s" % value if isQgis2 else u"%s" % value.toString()

        return output


    def creaHTML(self, url):
        textHTML = u'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">'
        textHTML+= u'<html><head><meta name="qrichtext" content="1" /><style type="text/css">'
        textHTML+= u'p, li { white-space: pre-wrap; }'
        textHTML+= u'</style></head><body style=" font-family:'+"'Tahoma'"+'; font-size:8.25pt; font-weight:400; font-style:normal;">'
        textHTML+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><a href="'
        textHTML+= url
        textHTML+= u'<span style=" font-size:8pt; text-decoration: underline; color:#0000ff;">'
        textHTML+= url
        textHTML+= u'</span></a></p></body></html>'
        return textHTML


    def creaPolylineCORRECT(self, geometry):
        # Se crea una geometría con los PATHS ordenados
        multiline = ogr.Geometry(ogr.wkbMultiLineStringM)

        # Ordenar los paths
        listaPaths = []
        multilineORD = []
        for path in geometry["paths"]:
            listaPaths.append([path[0][2], path])
        multilineORD = sorted(listaPaths, key=lambda pkini: pkini[0])

        for pathLine in multilineORD:
            path = pathLine[1]

            line1 = ogr.Geometry(ogr.wkbLineStringM)
            for point in path:
                line1.AddPoint(point[0],point[1],point[2])
            multiline.AddGeometry(line1)

        multilineTXT = (multiline.ExportToWkt()).replace('MULTILINESTRING','MULTILINESTRINGM')

        gLine = QgsGeometry.fromWkt(multilineTXT)
        return gLine

'''
################################################################################
                                ####   RESTOS  ####
################################################################################


        # Funcion de Query a GEOBTA
        # --- EJEMPLO ---
        # http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?
        # --- VALORES ---
        # where=Matricula_Plan+LIKE+%27%25%27&
        # text=&
        # objectIds=&
        # time=&
        # geometry=&
        # geometryType=esriGeometryEnvelope&
        # inSR=&
        # spatialRel=esriSpatialRelIntersects&
        # relationParam=&
        # outFields=*&
        # returnGeometry=true&
        # returnTrueCurves=false&
        # maxAllowableOffset=&
        # geometryPrecision=&
        # outSR=&
        # returnIdsOnly=false&
        # returnCountOnly=true&
        # orderByFields=&
        # groupByFieldsForStatistics=&
        # outStatistics=&
        # returnZ=false&
        # returnM=true&
        # gdbVersion=&
        # returnDistinctValues=false&
        # resultOffset=&
        # resultRecordCount=&
        # queryByDistance=&
        # returnExtentsOnly=false&
        # datumTransformation=&
        # parameterValues=&
        # rangeValues=&
        # f=pjson
'''