# -*- coding: utf-8 -*-
"""
/***************************************************************************
 balizas_carretera.py
                                 A QGIS4 plugin
Plugin:     jccm_bar4
Purpose:    Poner baliza en carretera
                             -------------------
        begin                : 2016-06-06
        validacion transfQG4 : 2026-10-23
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.core import *
import qgis.utils

import os
import urllib
import json


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/balizas_carretera.ui'))


class balizas_carreteraDialog(QtGui.QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(balizas_carreteraDialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface;
        self.setWindowIcon(QIcon(':/plugins/jccm_bar/iconos/jccm.jpg'))

    def encode(self,text):
        """
        For printing unicode characters to the console.
        """
        return text.encode('utf-8')
        
    def cancel(self):
        return 'CANCEL'