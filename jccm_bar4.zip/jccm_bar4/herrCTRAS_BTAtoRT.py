'''
herrCTRAS_BTAtoRT.py

NOTE: this module is not imported anywhere else in the plugin (superseded
by herrCTRAS_catalogoRT.py and similar files, which each define their own
createCatalogoRT()). Kept only for reference; fixed just enough (missing
imports, tab/space indentation) to be syntactically valid Python 3.
'''

from qgis.core import QgsField
from qgis.PyQt.QtCore import QMetaType

class herrCTRAS_RT:

    """
        RUTINAS DE CONFIGURACION INICIAL
    """


    def createCatalogoRT(self,uri,name,dest='memory'):
        #   Crea una capa alfanumérica con el CATALOGO DE CARETERAS en memoria añadiendoles campos
        #           'carretera', 'pk_ini', 'pk_fin', 'acimut', 'distancia'
        #   Devuelve la capa vectorial
        #   return vl

        QgsField('id_vial', QMetaType.Type.QString,''),
        QgsField('nombre', QMetaType.Type.QString,''),
        QgsField('nombre_alt', QMetaType.Type.QString,''),
        QgsField('codigo', QMetaType.Type.QString,''),
        QgsField('descripcion', QMetaType.Type.QString,''),
        QgsField('clase1', QMetaType.Type.QString,''),
        QgsField('clase2', QMetaType.Type.QString,''),
        QgsField('clase3', QMetaType.Type.QString,''),
        QgsField('clase4', QMetaType.Type.QString,''),
        QgsField('titular1', QMetaType.Type.QString,''),
        QgsField('titular2', QMetaType.Type.QString,''),
        QgsField('titular3', QMetaType.Type.QString,''),
        QgsField('titular4', QMetaType.Type.QString,''),
        QgsField('orden1', QMetaType.Type.QString,''),
        QgsField('orden2', QMetaType.Type.QString,''),
        QgsField('comentario', QMetaType.Type.QString,''),
        QgsField('fecha_alta', QMetaType.Type.QString,''),
        QgsField('alta_db', QMetaType.Type.QString,''),
        QgsField('fuente', QMetaType.Type.QString,''),
        QgsField('version', QMetaType.Type.QString,''),

        pass


    def createVectorLayer(self,uri,name,dest='memory'):
        # createVectorLayer(self,uri,name,dest='memory')
        #   Crea una capa vectorial de careteras en memoria añadiendoles campos
        #           'carretera', 'pk_ini', 'pk_fin', 'acimut', 'distancia'
        #   Devuelve la capa vectorial
        #   return vl

        vl = QgsVectorLayer(uri, name, dest)
        pr = vl.dataProvider()


        # Enter editing mode
        vl.startEditing()

        # add fields
        pr.addAttributes( [ 
                QgsField('codigo', QMetaType.Type.QString),
                QgsField('dgc_via', QMetaType.Type.Int),
                QgsField('dgc_viaD', QMetaType.Type.QString),
                QgsField('tipo_vial', QMetaType.Type.Int),
                QgsField('tipo_vialD', QMetaType.Type.QString),
                QgsField('clase', QMetaType.Type.Int),
                QgsField('claseD', QMetaType.Type.QString),
                QgsField('nombre', QMetaType.Type.QString),
                QgsField('nombre_alt', QMetaType.Type.QString),
                QgsField('fuente_v', QMetaType.Type.Int),
                QgsField('fuente_vD', QMetaType.Type.QString),
                QgsField('tipo_tramo', QMetaType.Type.Int),
                QgsField('tipo_tramD', QMetaType.Type.QString),
                QgsField('calzada', QMetaType.Type.Int),
                QgsField('calzadaD', QMetaType.Type.QString),
                QgsField('acceso', QMetaType.Type.Int),
                QgsField('accesoD', QMetaType.Type.QString),
                QgsField('firme', QMetaType.Type.Int),
                QgsField('firmeD', QMetaType.Type.QString),
                QgsField('ncarriles', QMetaType.Type.Int),
                QgsField('ncarrilesD', QMetaType.Type.QString),
                QgsField('sentido', QMetaType.Type.Int),
                QgsField('sentidoD', QMetaType.Type.QString),
                QgsField('situacion', QMetaType.Type.Int),
                QgsField('situacionD', QMetaType.Type.QString),
                QgsField('estadofis', QMetaType.Type.Int),
                QgsField('estadofisD', QMetaType.Type.QString),
                QgsField('tipovehic', QMetaType.Type.QString),
                QgsField('tipovehicD', QMetaType.Type.QString),
                QgsField('titular', QMetaType.Type.Int),
                QgsField('titularD', QMetaType.Type.QString),
                QgsField('orden', QMetaType.Type.QString),
                QgsField('ordenD', QMetaType.Type.QString),
                QgsField('fuente_t', QMetaType.Type.Int),
                QgsField('fuente_tD', QMetaType.Type.QString),
                QgsField('provincia', QMetaType.Type.QString)

                        ] )
        # Commit changes
        vl.commitChanges()
        return vl

