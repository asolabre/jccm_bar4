'''
/***************************************************************************
Name:            herr_EJE_PORDOSLINEAS.py
Purpose:        Calcula el eje medio de dos lineas seleccionadas en una capa
                CON DISTANCIA CONFIGURABLE Y DEPURACIÓN DE PUNTOS

                                 A QGIS4 plugin

        --------------------------------------------------------------------
        begin                : 2026-08-18
        validacion transfQG4 : 2026-10-20
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/
'''

from qgis.core import (
            QgsFeature, QgsGeometry, QgsPointXY, QgsField,
            QgsVectorLayer, QgsProject, QgsWkbTypes, Qgis
            )
# from qgis.PyQt.QtCore import QVariant, Qt
from qgis.PyQt.QtCore import Qt, QMetaType
from qgis.PyQt.QtWidgets import (
            QDialog, QVBoxLayout, QLabel, QPushButton,
            QDoubleSpinBox, QCheckBox, QHBoxLayout, QGroupBox
            )
from qgis.gui import QgsMapTool
import math

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA


class herr_EJE_PORDOSLINEAS(QgsMapTool):  # <-- AHORA HEREDA DE QgsMapTool
    """
    Herramienta para calcular la línea media entre dos líneas seleccionadas.
    """

    def __init__(self, iface):
        """Inicializa la herramienta"""
        super(herr_EJE_PORDOSLINEAS, self).__init__(iface.mapCanvas())  # <-- IMPORTANTE
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.cursor = Qt.CursorShape.CrossCursor
        self.msg_bar = iface.messageBar()

        self.conf = configuration()

        # Variables para rubberbands (reservado para uso futuro)
        self.rubberband = None

        # Variables para almacenar valores del diálogo
        self.distancia_entre_puntos = 2.0
        self.depurar_puntos = True
        self.tolerancia = 0.005

    def canvasPressEvent(self, event):
        """Ya no se usa para validar; todo se hace al activar la herramienta."""
        # Si por alguna razón el usuario llega aquí, no hacemos nada.
        # La lógica completa vive en preparar_herramienta() / ejecutar_proceso().
        pass


    def preparar_herramienta(self):
        """
        Valida la capa activa y la selección, y si todo está bien,
        ejecuta el proceso directamente (sin esperar clic en el mapa).
        Devuelve True si se lanzó el proceso, False si hubo error.
        """
        layer = self.iface.activeLayer()

        if not layer:
            self.msg_bar.pushMessage(
                "Error", "No hay una capa activa.",
                level=Qgis.Critical, duration=5
            )
            return False

        if layer.geometryType() != QgsWkbTypes.GeometryType.LineGeometry:
            self.msg_bar.pushMessage(
                "Error",
                f"La capa '{layer.name()}' no es de tipo línea. "
                f"Solo se permiten polilíneas.",
                level=Qgis.Critical, duration=5
            )
            return False

        selected = layer.selectedFeatures()
        if len(selected) != 2:
            self.msg_bar.pushMessage(
                "Error",
                f"Tienes {len(selected)} elementos seleccionados. "
                f"Debes seleccionar exactamente 2 polilíneas.",
                level=Qgis.Critical, duration=5
            )
            return False

        # Todo OK → lanzar el proceso
        self.ejecutar_proceso(layer, selected)
        return True


    # def canvasPressEvent(self, event):
        # """
        # Maneja el evento de clic en el canvas.
        # Al hacer clic, verifica que haya 2 líneas seleccionadas y ejecuta el proceso.
        # """
        # # Buscar la capa activa
        # layer = self.iface.activeLayer()

        # # --- VALIDACIONES ---
        # if not layer:
            # self.msg_bar.pushMessage(
                # "Error", "No hay una capa activa.",
                # level=Qgis.Critical, duration=5
            # )
            # return

        # if layer.geometryType() != QgsWkbTypes.GeometryType.LineGeometry:
            # self.msg_bar.pushMessage(
                # "Error",
                # f"La capa '{layer.name()}' es de tipo {layer.geometryType()}. Solo se permiten polilíneas.",
                # level=Qgis.Critical, duration=5
            # )
            # return

        # # Obtener selección actual
        # selected = layer.selectedFeatures()
        # if len(selected) != 2:
            # self.msg_bar.pushMessage(
                # "Error",
                # f"Tienes {len(selected)} elementos seleccionados. Debes seleccionar exactamente 2 polilíneas.",
                # level=Qgis.Critical, duration=5
            # )
            # return

        # # Ejecutar el proceso
        # self.ejecutar_proceso(layer, selected)

    def ejecutar_proceso(self, layer, selected_features):
        """
        Ejecuta el proceso principal con las líneas seleccionadas
        """
        try:
            # 1. Extraer las dos geometrías
            linea1 = selected_features[0].geometry()
            linea2 = selected_features[1].geometry()

            # Verificar que sean válidas
            if linea1.isNull() or linea2.isNull() or linea1.isEmpty() or linea2.isEmpty():
                self.msg_bar.pushMessage(
                    "Error", "Una de las geometrías seleccionadas no es válida.",
                    level=Qgis.Critical, duration=5
                )
                return

            # 2. Calcular longitudes
            long1 = linea1.length()
            long2 = linea2.length()
            long_max = max(long1, long2)

            # 3. Crear y mostrar el diálogo
            if not self.mostrar_dialogo(long1, long2, long_max):
                return

            # 4. Obtener valores del diálogo
            distancia = self.distancia_entre_puntos
            depurar = self.depurar_puntos
            tolerancia = self.tolerancia if depurar else 0.0

            # 5. Procesar las líneas
            self.procesar_lineas(layer, linea1, linea2, long1, long2,
                                distancia, depurar, tolerancia)

            # 6. Limpiar selección
            layer.removeSelection()

            # 7. Desactivar la herramienta automáticamente después de ejecutar
            self.canvas.unsetMapTool(self)

        except Exception as e:
            self.msg_bar.pushMessage(
                "Error", f"Ocurrió un error: {str(e)}",
                level=Qgis.Critical, duration=10
            )
            import traceback
            traceback.print_exc()

    def mostrar_dialogo(self, long1, long2, long_max):
        """
        Muestra el diálogo de configuración y retorna True si se aceptó
        """
        dialog = QDialog()
        dialog.setWindowTitle("Configurar línea media")
        dialog.setModal(True)
        dialog.setMinimumWidth(400)

        layout = QVBoxLayout()

        # --- Sección: Información de las líneas ---
        group_info = QGroupBox("Información de las líneas")
        info_layout = QVBoxLayout()
        info_layout.addWidget(QLabel(f"<b>Línea 1:</b> {long1:.2f} metros"))
        info_layout.addWidget(QLabel(f"<b>Línea 2:</b> {long2:.2f} metros"))
        info_layout.addWidget(QLabel(f"<b>Línea más larga:</b> {long_max:.2f} metros"))
        group_info.setLayout(info_layout)
        layout.addWidget(group_info)

        # --- Sección: Densidad de puntos ---
        group_densidad = QGroupBox("Densidad de puntos")
        densidad_layout = QVBoxLayout()

        densidad_layout.addWidget(QLabel("Distancia entre puntos a lo largo de la línea:"))

        spin_distancia = QDoubleSpinBox()
        spin_distancia.setRange(0.01, 1000.0)
        spin_distancia.setValue(self.distancia_entre_puntos)
        spin_distancia.setDecimals(2)
        spin_distancia.setSuffix(" m")
        spin_distancia.setSingleStep(0.5)
        densidad_layout.addWidget(spin_distancia)

        # Mostrar cuántos puntos se generarán
        label_puntos = QLabel()
        label_puntos.setStyleSheet("color: blue; font-weight: bold;")

        def actualizar_puntos():
            distancia = spin_distancia.value()
            if distancia > 0:
                num_puntos = int(long_max / distancia) + 1
                label_puntos.setText(f"Puntos generados: {num_puntos}")
            else:
                label_puntos.setText("Distancia debe ser mayor que 0")

        spin_distancia.valueChanged.connect(actualizar_puntos)
        actualizar_puntos()
        densidad_layout.addWidget(label_puntos)

        group_densidad.setLayout(densidad_layout)
        layout.addWidget(group_densidad)

        # --- Sección: Depuración de puntos ---
        group_depurar = QGroupBox("Depuración de puntos (opcional)")
        depurar_layout = QVBoxLayout()

        check_depurar = QCheckBox("Depurar puntos colineales")
        check_depurar.setChecked(self.depurar_puntos)
        check_depurar.setToolTip("Elimina puntos intermedios que estén prácticamente alineados")
        depurar_layout.addWidget(check_depurar)

        tol_layout = QHBoxLayout()
        tol_layout.addWidget(QLabel("Tolerancia:"))

        spin_tolerancia = QDoubleSpinBox()
        spin_tolerancia.setRange(0.0001, 10.0)
        spin_tolerancia.setValue(self.tolerancia)
        spin_tolerancia.setDecimals(4)
        spin_tolerancia.setSuffix(" m")
        spin_tolerancia.setSingleStep(0.001)
        spin_tolerancia.setToolTip("Distancia máxima permitida para considerar un punto colineal")
        tol_layout.addWidget(spin_tolerancia)

        depurar_layout.addLayout(tol_layout)

        label_tol_info = QLabel(
            "<span style='color: gray; font-size: 9pt;'>"
            "Ejemplo: 0.005 m = 5 mm de tolerancia (recomendado para precisión métrica)"
            "</span>"
        )
        label_tol_info.setWordWrap(True)
        depurar_layout.addWidget(label_tol_info)

        label_puntos_depurados = QLabel()
        label_puntos_depurados.setStyleSheet("color: green; font-weight: bold;")
        depurar_layout.addWidget(label_puntos_depurados)

        def actualizar_depuracion():
            if check_depurar.isChecked():
                distancia = spin_distancia.value()
                if distancia > 0:
                    num_puntos = int(long_max / distancia) + 1
                    estimado = max(2, int(num_puntos * 0.2))
                    label_puntos_depurados.setText(
                        f"Puntos después de depurar: ~{estimado} (depende de la geometría)"
                    )
                else:
                    label_puntos_depurados.setText("")
            else:
                label_puntos_depurados.setText("(Sin depuración)")

        check_depurar.stateChanged.connect(actualizar_depuracion)
        spin_tolerancia.valueChanged.connect(actualizar_depuracion)
        spin_distancia.valueChanged.connect(actualizar_depuracion)
        actualizar_depuracion()

        group_depurar.setLayout(depurar_layout)
        layout.addWidget(group_depurar)

        # --- Botones ---
        btn_layout = QHBoxLayout()

        btn_aceptar = QPushButton("Aceptar")
        btn_aceptar.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold; padding: 8px;")
        btn_aceptar.clicked.connect(dialog.accept)

        btn_cancelar = QPushButton("Cancelar")
        btn_cancelar.setStyleSheet("padding: 8px;")
        btn_cancelar.clicked.connect(dialog.reject)

        btn_layout.addWidget(btn_aceptar)
        btn_layout.addWidget(btn_cancelar)
        layout.addLayout(btn_layout)

        dialog.setLayout(layout)

        # Mostrar el diálogo y guardar resultados
        if dialog.exec() != QDialog.DialogCode.Accepted:
            self.msg_bar.pushMessage("Info", "Proceso cancelado por el usuario.",
                                     level=Qgis.Info, duration=3)
            return False

        # Guardar valores en atributos de la clase
        self.distancia_entre_puntos = spin_distancia.value()
        self.depurar_puntos = check_depurar.isChecked()
        self.tolerancia = spin_tolerancia.value() if self.depurar_puntos else 0.0

        return True

    def procesar_lineas(self, layer, linea1, linea2, long1, long2,
                        distancia, depurar, tolerancia):
        """
        Procesa las líneas y genera la línea media
        """
        # Determinar la línea más larga para muestrear
        if long1 >= long2:
            linea_referencia = linea1
            linea_objetivo = linea2
        else:
            linea_referencia = linea2
            linea_objetivo = linea1

        # Calcular el número de puntos
        longitud_referencia = linea_referencia.length()
        num_puntos = int(longitud_referencia / distancia) + 1

        if num_puntos < 2:
            self.msg_bar.pushMessage(
                "Advertencia",
                "La distancia es muy grande. Se usarán 2 puntos.",
                level=Qgis.Warning, duration=3
            )
            num_puntos = 2

        self.msg_bar.pushMessage(
            "Info",
            f"Generando {num_puntos} puntos con distancia {distancia:.2f} m",
            level=Qgis.Info, duration=3
        )

        # Generar puntos en la línea de referencia
        puntos_referencia = []
        longitud = linea_referencia.length()

        for i in range(num_puntos):
            if num_puntos > 1:
                dist = (i / (num_puntos - 1)) * longitud
            else:
                dist = 0

            punto = linea_referencia.interpolate(dist)
            if punto and not punto.isNull():
                puntos_referencia.append(punto.asPoint())

        if len(puntos_referencia) < 2:
            self.msg_bar.pushMessage(
                "Error", "No se pudieron generar suficientes puntos.",
                level=Qgis.Critical, duration=5
            )
            return

        # Encontrar puntos cercanos en la línea objetivo
        puntos_medios = []

        for pt in puntos_referencia:
            punto_cercano = self.encontrar_punto_cercano(linea_objetivo, pt)

            if punto_cercano:
                medio = QgsPointXY(
                    (pt.x() + punto_cercano.x()) / 2,
                    (pt.y() + punto_cercano.y()) / 2
                )
                puntos_medios.append(medio)

        if len(puntos_medios) < 2:
            self.msg_bar.pushMessage(
                "Error", "Se necesitan al menos 2 puntos medios.",
                level=Qgis.Critical, duration=5
            )
            return

        # Depurar puntos si está activado
        puntos_finales = puntos_medios
        puntos_originales = len(puntos_medios)

        if depurar and len(puntos_medios) > 2:
            self.msg_bar.pushMessage(
                "Info",
                f"Depurando puntos con tolerancia {tolerancia:.4f} m...",
                level=Qgis.Info, duration=3
            )
            puntos_finales = self.simplificar_linea(puntos_medios, tolerancia)

            if len(puntos_finales) < 2:
                self.msg_bar.pushMessage(
                    "Advertencia",
                    "La depuración dejó menos de 2 puntos. Se usará la línea sin depurar.",
                    level=Qgis.Warning, duration=5
                )
                puntos_finales = puntos_medios

        puntos_depurados = len(puntos_finales)

        if depurar:
            self.msg_bar.pushMessage(
                "Info",
                f"Puntos: {puntos_originales} → {puntos_depurados} "
                f"(eliminados {puntos_originales - puntos_depurados})",
                level=Qgis.Info, duration=3
            )

        # Crear la línea media
        linea_media_geom = QgsGeometry.fromPolylineXY(puntos_finales)

        if linea_media_geom.isNull() or linea_media_geom.isEmpty():
            self.msg_bar.pushMessage(
                "Error", "No se pudo crear la geometría de la línea media.",
                level=Qgis.Critical, duration=5
            )
            return

        # Crear la capa de salida
        self.crear_capa_salida(layer, linea_media_geom, puntos_originales,
                              puntos_depurados, distancia,
                              tolerancia if depurar else 0.0, depurar)

        mensaje = f"Línea media creada con {puntos_depurados} puntos"
        if depurar:
            mensaje += f" (depurado: {puntos_originales} → {puntos_depurados})"
        self.msg_bar.pushMessage("Éxito", mensaje, level=Qgis.Success, duration=5)

    def encontrar_punto_cercano(self, linea_objetivo, pt):
        """
        Encuentra el punto más cercano en la línea objetivo usando múltiples métodos
        """
        punto_cercano = None

        # Método 1: closestSegmentWithContext
        try:
            resultado = linea_objetivo.closestSegmentWithContext(pt)

            if len(resultado) >= 4 and isinstance(resultado[3], QgsPointXY):
                punto_cercano = resultado[3]
            elif len(resultado) >= 3 and isinstance(resultado[2], QgsPointXY):
                punto_cercano = resultado[2]
            elif len(resultado) >= 2 and isinstance(resultado[1], QgsPointXY):
                punto_cercano = resultado[1]
            else:
                vertice_idx = None
                if len(resultado) >= 2 and isinstance(resultado[1], int):
                    vertice_idx = resultado[1]
                elif len(resultado) >= 1 and isinstance(resultado[0], int):
                    vertice_idx = resultado[0]

                if vertice_idx is not None:
                    vertices = linea_objetivo.asPolyline()
                    if vertice_idx < len(vertices):
                        punto_cercano = vertices[vertice_idx]
        except:
            pass

        # Método 2: nearestPoint
        if punto_cercano is None:
            try:
                punto_geom = QgsGeometry.fromPointXY(pt)
                punto_cercano_geom = linea_objetivo.nearestPoint(punto_geom)
                if punto_cercano_geom and not punto_cercano_geom.isNull():
                    punto_cercano = punto_cercano_geom.asPoint()
            except:
                pass

        # Método 3: Manual (vértice más cercano)
        if punto_cercano is None:
            try:
                vertices = linea_objetivo.asPolyline()
                if vertices:
                    min_dist = float('inf')
                    for vert in vertices:
                        dist = pt.distance(vert)
                        if dist < min_dist:
                            min_dist = dist
                            punto_cercano = vert
            except:
                pass

        return punto_cercano

    def simplificar_linea(self, puntos, tolerancia):
        """
        Simplifica una línea eliminando puntos colineales dentro de una tolerancia.
        Usa el algoritmo de Douglas-Peucker adaptado para colinealidad.
        """
        if len(puntos) < 3:
            return puntos

        def distancia_perpendicular(p, p1, p2):
            """Calcula la distancia perpendicular del punto p a la línea p1-p2"""
            if p1.x() == p2.x() and p1.y() == p2.y():
                return p.distance(p1)

            numerador = abs((p2.x() - p1.x()) * (p1.y() - p.y()) -
                           (p1.x() - p.x()) * (p2.y() - p1.y()))
            denominador = math.sqrt((p2.x() - p1.x())**2 + (p2.y() - p1.y())**2)
            return numerador / denominador

        def simplificar_recursivo(pts, tol, inicio, fin):
            """Versión recursiva del algoritmo de Douglas-Peucker"""
            if fin - inicio <= 1:
                return [pts[inicio], pts[fin]]

            max_dist = 0
            idx_max = inicio

            p_inicio = pts[inicio]
            p_fin = pts[fin]

            for i in range(inicio + 1, fin):
                dist = distancia_perpendicular(pts[i], p_inicio, p_fin)
                if dist > max_dist:
                    max_dist = dist
                    idx_max = i

            if max_dist <= tol:
                return [pts[inicio], pts[fin]]
            else:
                izquierda = simplificar_recursivo(pts, tol, inicio, idx_max)
                derecha = simplificar_recursivo(pts, tol, idx_max, fin)
                return izquierda[:-1] + derecha

        return simplificar_recursivo(puntos, tolerancia, 0, len(puntos) - 1)

    def crear_capa_salida(self, layer, geometria, puntos_orig, puntos_final,
                          distancia, tolerancia, depurado):
        """
        Crea la capa de salida con la línea media
        """
        import os

        capa_salida = QgsVectorLayer(
            "LineString?crs=" + layer.crs().authid(),
            "Linea_Media",
            "memory"
        )
        provider = capa_salida.dataProvider()
        provider.addAttributes([
            QgsField("id", QMetaType.Type.Int),
            QgsField("puntos_orig", QMetaType.Type.Int),
            QgsField("puntos_final", QMetaType.Type.Int),
            QgsField("distancia", QMetaType.Type.Double),
            QgsField("tolerancia", QMetaType.Type.Double),
            QgsField("longitud", QMetaType.Type.Double),
            QgsField("depurado", QMetaType.Type.Int)
            ])

        capa_salida.updateFields()

        feature = QgsFeature()
        feature.setGeometry(geometria)
        feature.setAttributes([
            1,
            puntos_orig,
            puntos_final,
            distancia,
            tolerancia,
            geometria.length(),
            1 if depurado else 0
        ])
        provider.addFeature(feature)
        capa_salida.updateExtents()

        # --- APLICAR ESTILO DESDE QML ---
        try:
            # Construir la ruta al archivo de estilo
            estiloCAPA = os.path.join( os.path.dirname(__file__), self.conf.general["carpeta_estilos"], 'linea_media.qml')
            estiloCAPA = os.path.normpath(estiloCAPA)

            # Verificar si existe el archivo
            if os.path.exists(estiloCAPA):
                # Cargar el estilo desde el archivo QML
                resultado, mensaje = capa_salida.loadNamedStyle(estiloCAPA)

                if mensaje:
                    self.msg_bar.pushMessage(
                        "Info",
                        f"Estilo cargado desde: {estiloCAPA}",
                        level=Qgis.Info, duration=3
                    )
                else:
                    self.msg_bar.pushMessage(
                        "Advertencia",
                        f"No se pudo cargar el estilo: {resultado}",
                        level=Qgis.Warning, duration=3
                    )
                    # Aplicar estilo por defecto si falla
                    self.aplicar_estilo_defecto(capa_salida)
            else:
                # Si no existe el archivo, aplicar estilo por defecto
                self.msg_bar.pushMessage(
                    "Info",
                    f"No se encontró el archivo de estilo. Usando estilo por defecto.",
                    level=Qgis.Info, duration=3
                )
                self.aplicar_estilo_defecto(capa_salida)

        except Exception as e:
            # Si hay cualquier error, aplicar estilo por defecto
            self.msg_bar.pushMessage(
                "Advertencia",
                f"Error al cargar estilo: {str(e)}. Usando estilo por defecto.",
                level=Qgis.Warning, duration=3
            )
            self.aplicar_estilo_defecto(capa_salida)

        # Actualizar la capa después de aplicar el estilo
        capa_salida.updateFields()
        capa_salida.triggerRepaint()
        # --- FIN APLICAR ESTILO ---

        QgsProject.instance().addMapLayer(capa_salida)

    # def crear_capa_salida(self, layer, geometria, puntos_orig, puntos_final,
                          # distancia, tolerancia, depurado):
        # """
        # Crea la capa de salida con la línea media
        # """
        # capa_salida = QgsVectorLayer(
            # "LineString?crs=" + layer.crs().authid(),
            # "Linea_Media",
            # "memory"
        # )
        # provider = capa_salida.dataProvider()
        # provider.addAttributes([
            # QgsField("id", QVariant.Int),
            # QgsField("puntos_orig", QVariant.Int),
            # QgsField("puntos_final", QVariant.Int),
            # QgsField("distancia", QVariant.Double),
            # QgsField("tolerancia", QVariant.Double),
            # QgsField("longitud", QVariant.Double),
            # QgsField("depurado", QVariant.Int)
        # ])
        # capa_salida.updateFields()

        # feature = QgsFeature()
        # feature.setGeometry(geometria)
        # feature.setAttributes([
            # 1,
            # puntos_orig,
            # puntos_final,
            # distancia,
            # tolerancia,
            # geometria.length(),
            # 1 if depurado else 0
        # ])
        # provider.addFeature(feature)
        # capa_salida.updateExtents()

        # QgsProject.instance().addMapLayer(capa_salida)

        # estiloCAPA = os.path.join(os.path.dirname(__file__), self.conf.general["carpeta_estilos"] + '/linea media.qml')

    def aplicar_estilo_defecto(self, capa):
        """
        Aplica un estilo por defecto cuando no se puede cargar el QML
        """
        from qgis.core import QgsSingleSymbolRenderer, QgsLineSymbol

        try:
            simbolo = QgsLineSymbol.createSimple({
                'color': '#FF0000',
                'width': '1.5',
                'capstyle': 'round',
                'joinstyle': 'round'
            })
            renderer = QgsSingleSymbolRenderer(simbolo)
            capa.setRenderer(renderer)
        except:
            pass


    def deactivate(self):
        """Se ejecuta cuando la herramienta se desactiva"""
        if self.rubberband:
            self.canvas.scene().removeItem(self.rubberband)
            self.rubberband = None
        super(herr_EJE_PORDOSLINEAS, self).deactivate()