# depuraCapas.py


from qgis.core import QgsProject
from qgis.utils import iface

def eliminar_capas_no_visibles():
    """
    Detecta y elimina las capas cargadas en el proyecto QGIS que no están en la Tabla de Contenidos (TOC), mostrando una barra de progreso.
    """
    proyecto = QgsProject.instance()
    root = proyecto.layerTreeRoot()
    
    todas_las_capas = proyecto.mapLayers()
    capas_en_toc = [node.layerId() for node in root.findLayers()]
    capas_no_visibles = [capa for capa_id, capa in todas_las_capas.items() if capa_id not in capas_en_toc]
    
    total_capas = len(capas_no_visibles)
    if total_capas > 0:
        print(f"Capas no visibles detectadas: {[capa.name() for capa in capas_no_visibles]}")
        
        # Barra de progreso
        progress_message = "Eliminando capas no visibles..."
        progress_bar = iface.mainWindow().statusBar().showMessage(progress_message)
        
        for i, capa in enumerate(capas_no_visibles):
            print(f"Eliminando capa no visible: {capa.name()} ({i + 1}/{total_capas})")
            proyecto.removeMapLayer(capa.id())
            iface.mainWindow().statusBar().showMessage(f"{progress_message} ({i + 1}/{total_capas})")
        
        iface.mainWindow().statusBar().clearMessage()
        
    else:
        print("No se encontraron capas no visibles.")


eliminar_capas_no_visibles()