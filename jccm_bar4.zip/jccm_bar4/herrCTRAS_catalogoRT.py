# -*- coding: utf-8 -*-
'''
/***************************************************************************
herrCTRAS_catalogoRT.py                                 A QGIS4 plugin
                             -------------------
        begin                : 2024-11-19
        git sha              : $Format:%H$
        copyright            : (C) 2016 by ASS
        email                : asolabre@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.
 *
 *   Based in 'Quick Export' pluggin
 *                                                                         *
 ***************************************************************************/
'''

from qgis.PyQt.QtGui import QIcon, QPixmap
from qgis.PyQt.QtCore import (QSettings, QCoreApplication, QTranslator, qVersion, Qt, QFileInfo, QDate, QMetaType)
from qgis.PyQt.QtWidgets import (QApplication, QMessageBox, QToolButton, QMenu, QAction, QDialog, QCheckBox, QFileDialog,
                            QWidget, QTextEdit)
from qgis.PyQt import uic

from qgis.gui import QgsMessageBar
from qgis.core import (QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsApplication, QgsField,
                        QgsVectorFileWriter, QgsCoordinateTransformContext, QgsFeature, QgsExpression, QgsFeatureRequest,
                        QgsProcessingFeedback)

from qgis.utils import iface
from qgis.PyQt.QtPrintSupport import QPrinter
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtWidgets import QProgressBar

from os import path, makedirs, startfile
from osgeo import ogr, osr
from time import sleep
from functools import partial

import os
import timeit
import urllib
import json
import glob, codecs
import shutil
import datetime
import locale
import tempfile
import sys
import subprocess
import csv

import sqlite3

import xlrd     # Herramientas de lectura de EXCEL
import xlwt     # Herramientas de escritura de EXCEL

# ESTILOS xlwt https://github.com/python-excel/xlwt/blob/5a222d0315b6d3ce52a3cedd7c3e41309587c107/xlwt/Style.py#L103

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .settings import Settings           # CLASE DE CONFIGURACIÓN DE VARIABLES GLOBALES
from .cartoc_buscadorGeneral import cartoc_buscadorGeneral    # CLASE DE FUNCIONES DE BUSCADOR Y CARGA DE CARTOCIUDAD

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrCTRAS_catalogoRT.ui'))

class herrCTRAS_catalogoRT(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        '''Constructor.'''
        super(herrCTRAS_catalogoRT, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface;
        
        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        self.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/IGN_RT.jpg'))
        self.logo.setPixmap(QPixmap(f":/plugins/jccm_bar4/iconos/IGN_RT.jpg"))

        self.fun    = Functions()
        self.Sett   = Settings()
        self.conf   = configuration()
        self.cartoc = cartoc_buscadorGeneral(self.iface)

        # Comprobamos el rol del usuario
        userSIG, tipoUser = self.Sett.entrarUser()

        self.plugin_dir = QFileInfo(QgsApplication.qgisUserDatabaseFilePath()).path() + f"/python/plugins/{self.nombre_plugin}"

        self.QgisVersion = Qgis.QGIS_VERSION_INT


        self.btnCATALOGO_RT.setVisible(True)

        # CSS template file
        self.cssPath = os.path.join(
            self.plugin_dir,
            "templates/table.css"
            )

        # self.listProvs = 'Albacete', 'Ciudad Real', 'Cuenca' , 'Guadalajara', 'Toledo'

        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)
        self.progressBar.setValue(0)
        self.lblINFO.setText('INFO:')

        self.btnSeleccionfich.clicked.connect(self.salida_file_click)

        self.btnCATALOGO_RT.clicked.connect(lambda: self.catalogoGDB('catalogoRT'))

        self.strPrecision = "{:."+str(self.spnPRECISION.value())+"f}"

        # Se ocultan/activan/marcan herramienta innecesarias
        self.chbGenHojaCalc.setVisible(True)
        self.chbGenHojaCalc.setEnabled(True)
        self.chbGenHojaCalc.setChecked(True)

        self.chbIncCamposGDB.setVisible(True)
        self.chbIncCamposGDB.setEnabled(True)
        self.chbIncCamposGDB.setChecked(True)

        self.chbCompGDBorig.setVisible(True)
        self.chbCompGDBorig.setEnabled(True)
        self.chbCompGDBorig.setChecked(True)

        self.chbRevRTdatErroneos.setVisible(True)
        self.chbRevRTdatErroneos.setEnabled(True)
        self.chbRevRTdatErroneos.setChecked(True)
        
        self.chbCarTraRTErro.setVisible(True)
        self.chbCarTraRTErro.setEnabled(True)
        self.chbCarTraRTErro.setChecked(True)
        
        ####           TODO REVISAR SI QUITAR ESTO             ####
        self.chbMATR9000.setChecked(False)
        self.chbMATR9000.setVisible(False)
        self.chbMATR9000.setEnabled(False)
        
        self.lbl_spnPRECISION.setVisible(False)
        self.spnPRECISION.setVisible(False)
        ####           TODO REVISAR SI QUITAR ESTO             ####

        self.lbl_txeOUTFIELDS.setVisible(True)
        self.qlwOutFIELDS.setVisible(True)
        self.qlwOutFIELDS.setEnabled(False)
        self.qlwOutFIELDS.clear()
        self.qlwOutFIELDS.addItems(['Matricula', 'idMatricula', 'Provincia', 'Denominacion', 'PkINI', 'Origen', 'PkFin', 'Destino', 'Long_Km'])

        self.lbl_txeOrderByFields.setVisible(True)
        self.qlwOrderByFields.setVisible(True)
        self.qlwOrderByFields.setEnabled(True)
        self.qlwOrderByFields.clear()
        self.qlwOrderByFields.addItems(['Titularidad', 'idOrdenCtra', 'Funcionalidad', 'Matricula', 'PkINI', 'Provincia'])


        ###############################
        #   COMBOS DESPLEGABLES
        ###############################
        #  Combo Provincia
        lista_Valores = self.fun.getValoresCampo('Provincia','')
        self.cbxProvincia.clear()
        if lista_Valores is not None:
            self.cbxProvincia.addItem("Todo")
            self.cbxProvincia.addItems(lista_Valores)

        ##################   TODO BORRAR CONTROL PARA EXCEL #################
        # if tipoUser == 'ADMINISTRADOR':
            # lista_provincias = [self.cbxProvincia.itemText(i) for i in range(self.cbxProvincia.count())]
            # self.cbxProvincia.setCurrentIndex(lista_provincias.index('Albacete'))
        ##################   TODO BORRAR CONTROL PARA EXCEL #################

        #  Combo Funcionalidad
        lista_Valores = self.fun.getValoresCampo('Funcionalidad','')
        self.cbxFuncionalidad.clear()
        if lista_Valores is not None:
            self.cbxFuncionalidad.addItem("Todo")
            self.cbxFuncionalidad.addItems(lista_Valores)

        #  Combo Titularidad
        lista_Valores = self.fun.getValoresCampo('Titularidad','')
        self.cbxTitularidad.clear()
        if lista_Valores is not None:
            self.cbxTitularidad.addItem("Todo")
            self.cbxTitularidad.addItems(lista_Valores)
            if 'JCCM' in lista_Valores:
                self.cbxTitularidad.setCurrentIndex(1+lista_Valores.index('JCCM'))

        #  Combo Matricula
        lista_Valores = self.fun.getValoresCampo('Matricula','')
        self.cbxMatricula.clear()
        if lista_Valores is not None:
            lista_Valores.insert(0, "%")
            self.cbxMatricula.addItems(lista_Valores)

        # DEFINICIONES DE CAMPOS PARA PRESENTACIÓN
        self.listaCamposData = [
            {'campo':'Matricula',       'alias':u'Matricula',       'tipo': 'string', 'anchocol': 3000, 'comment': 'BTACAL:Nombre oficial de la Vía'},
            {'campo':'idMatricula',     'alias':u'idMatricula',     'tipo': 'int',    'anchocol': 3500, 'comment': 'BTACAL:Identificador único de la vía'},
            {'campo':'Matricula_Plan',  'alias':u'Matr. Alt.',      'tipo': 'string', 'anchocol': 4000, 'comment': 'BTACAL:Nombre alternativo de la Vía'},
            {'campo':'Titularidad',     'alias':u'Titul.',          'tipo': 'string', 'anchocol': 4000, 'comment': 'BTACAL:Titularidad del víal. Estatal, JCCM, Diputación, etc'},
            {'campo':'Funcionalidad',   'alias':u'Func.',           'tipo': 'string', 'anchocol': 4000, 'comment': 'BTACAL:Funcionalidad de la vía'},
            {'campo':'Provincia',       'alias':u'Provincia',       'tipo': 'string', 'anchocol': 3200, 'comment': 'BTACAL:Provincia del tramo'},
            {'campo':'Denominacion',    'alias':u'Denominación',    'tipo': 'string', 'anchocol':12000, 'comment': 'BTACAL:Denominación oficial en catálogo'},
            {'campo':'PkINI',           'alias':u'Pk INI',          'tipo': 'double', 'anchocol': 2500, 'comment': 'BTACAL:PK inicio del tramo'},
            {'campo':'Origen',          'alias':u'Origen',          'tipo': 'string', 'anchocol': 7500, 'comment': 'BTACAL:Descripción punto de inicio del tramo'},
            {'campo':'PkFin',           'alias':u'Pk FIN',          'tipo': 'double', 'anchocol': 2500, 'comment': 'BTACAL:PK final del tramo'},
            {'campo':'Destino',         'alias':u'Destino',         'tipo': 'string', 'anchocol': 7500, 'comment': 'BTACAL:Descripción punto de destino del tramo'},
            {'campo':'Tipologia_DobleC','alias':u'CALZ. Doble',     'tipo': 'string', 'anchocol': 2500, 'comment': 'BTACAL:Tipología de calzada doble'},
            {'campo':'Tipologia_UnaC',  'alias':u'CALZ. Unica',     'tipo': 'string', 'anchocol': 2500, 'comment': 'BTACAL:Tipología de calzada única'},
            {'campo':'Longitud',        'alias':u'Long',            'tipo': 'double', 'anchocol': 3000, 'comment': 'BTACAL:Longitud en metros del tramo'},
            {'campo':'Long_Km',         'alias':u'Long. Km',        'tipo': 'double', 'anchocol': 2500, 'comment': 'BTACAL:Longitud en kilómetros como diferencia entre PK_FIN y PK_INI'},
            {'campo':'idOrdenCtra',     'alias':u'idCtra',          'tipo': 'int',    'anchocol': 2000, 'comment': 'BTACAL:Identificador Tipología de del vial'},
            {'campo':'Shape.STLength()','alias':u'STLength()',      'tipo': 'double', 'anchocol': 3000, 'comment': 'BTACAL:Longitud geométrica'},
            {'campo':'OBJECTID',        'alias':u'OBJID',           'tipo': 'int',    'anchocol': 3000, 'comment': 'BTACAL:objId'},
            {'campo':'Long_Total',      'alias':u'Long Total',      'tipo': 'string', 'anchocol': 3500, 'comment': 'BTACAL:Long total suma de los tramos del vial'}
            ]

        self.listaCamposDataRT = [
            {'campo':'id_vial',         'alias':u'id_vial',         'tipo': 'string', 'anchocol': 3500, 'comment': 'Identificador único de vial de RT'},
            {'campo':'nombre',          'alias':u'nombre',          'tipo': 'string', 'anchocol': 3500, 'comment': 'Nombre de la carretera'},
            {'campo':'nombre_alt',      'alias':u'nombre_alt',      'tipo': 'string', 'anchocol': 4000, 'comment': 'Nombre alternativo'},
            {'campo':'codigo',          'alias':u'codigo',          'tipo': 'string', 'anchocol': 2000, 'comment': 'Código de carretera de DGT'},
            {'campo':'descripcion',     'alias':u'descripcion',     'tipo': 'string', 'anchocol':12000, 'comment': 'Descripción de inicio y fin de la carretera'},
            {'campo':'clase1',          'alias':u'c1',              'tipo': 'string', 'anchocol': 1250, 'comment': 'Clase de carretera'},
            {'campo':'clase2',          'alias':u'c2',              'tipo': 'string', 'anchocol': 1250, 'comment': 'Clase de carretera'},
            {'campo':'clase3',          'alias':u'c3',              'tipo': 'string', 'anchocol': 1250, 'comment': 'Clase de carretera'},
            {'campo':'clase4',          'alias':u'c4',              'tipo': 'string', 'anchocol': 1250, 'comment': 'Clase de carretera'},
            {'campo':'titular1',        'alias':u't1',              'tipo': 'string', 'anchocol': 1250, 'comment': 'Titular o competente de la vía'},
            {'campo':'titular2',        'alias':u't2',              'tipo': 'string', 'anchocol': 1250, 'comment': 'Titular o competente de la vía'},
            {'campo':'titular3',        'alias':u't3',              'tipo': 'string', 'anchocol': 1250, 'comment': 'Titular o competente de la vía'},
            {'campo':'titular4',        'alias':u't4',              'tipo': 'string', 'anchocol': 1250, 'comment': 'Titular o competente de la vía'},
            {'campo':'orden1',          'alias':u'o1',              'tipo': 'string', 'anchocol': 1250, 'comment': 'Categoría de las carreteras no estatales'},
            {'campo':'orden2',          'alias':u'o2',              'tipo': 'string', 'anchocol': 1250, 'comment': 'Categoría de las carreteras no estatales'},
            {'campo':'fecha_alta',      'alias':u'f.alta',          'tipo': 'string', 'anchocol': 2000, 'comment': 'Fecha de alta del registro en la tabla'},
            {'campo':'alta_db',         'alias':u'alta_db',         'tipo': 'string', 'anchocol': 3000, 'comment': 'Fecha del última modificación del registro en la tabla'},
            {'campo':'fuente',          'alias':u'fuente',          'tipo': 'string', 'anchocol': 2000, 'comment': 'Origen del que provienen los campos'},
            {'campo':'version',         'alias':u'ver.',            'tipo': 'string', 'anchocol': 2000, 'comment': 'Versión del Dato'},
            {'campo':'comentario',      'alias':u'comentario',      'tipo': 'string', 'anchocol':12000, 'comment': 'Comentario sobre la carretera'},
            {'campo':'no_nombre',       'alias':u'no',              'tipo': 'int',    'anchocol': 1000, 'comment': 'Número de elementos con igual nombre'},
            {'campo':'id_vial_encont',  'alias':u'id_vial_enc',     'tipo': 'string', 'anchocol': 6000, 'comment': 'id_vial localizados con igual nombre'}
            ]

    def closeEvent(self, event):
        QApplication.restoreOverrideCursor()


    def encode(self,text):
        '''
        For printing unicode characters to the console.
        '''
        return text.encode('ISO-8859-14')


    def salida_file_click(self):
        dirFile = self.lneFICHsalida.text()
        ext = "*.gpkg"
        filename = dirFile
        filename, tipofile = QFileDialog.getSaveFileName(self, "Fichero GPKG de salida", dirFile, ext)
        # Comprobamos que existe el directorio y si no se crea
        if not os.path.exists(os.path.dirname(filename)):
            os.makedirs(os.path.dirname(filename))
        self.lneFICHsalida.setText(filename)


    def defineListasGlobales(self):
        # Lstados generales de campos para consulta y listado
        # Campos a obtener en la CONSULTA
        self.listCamposCOMP = []
        for campo in self.listaCamposData:
            if campo['campo'] != 'Long_Total':
                self.listCamposCOMP.append(campo['campo'])

        self.listCampos = self.listCamposCOMP # Esto deriva del Catalgo de GDB, que listaba menos campos

        # Orden de Campos a obtener en la CONSULTA
        self.listCamposOrder = []
        for i in range(self.qlwOrderByFields.count()):
            dato = self.qlwOrderByFields.item(i).text()
            if dato not in self.listCamposOrder:
                self.listCamposOrder.append(dato)

        for campo in self.listCamposOrder:
            if campo not in self.listCamposCOMP:
                text = ' El campo %s no está en la lista de campos posibles'%(campo)
                self.fun.showMessageERR(text,text2="",tittle="JCCM")
                return 'error'


    def catalogoGDB(self, tipoCat='catalogoRT', GenHojaCalc = True,
                    FieldsOrdInc = True, AllFields = False, CtrasTRAMO= True,
                    MATR9000 = True):
        
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)   # ICONO DE ESPERA

        start = timeit.default_timer()

        self.close()

        # Obteniendo datos desde Geodatabas DGC
        self.iface.mainWindow().statusBar().showMessage("Obteniendo datos desde Geodatabas DGC...")

        ## Comprobamos la PROVINCIA, TITULARIDAD Y FUNCIONALIDAD seleccionadas
        prov = self.cbxProvincia.currentText()
        if prov == 'Todo':
            prov = 'JCCM'

        valcbxTitularidad = self.cbxTitularidad.currentText()
        valcbxFuncionalidad = self.cbxFuncionalidad.currentText()
        valcbxProvincia = self.cbxProvincia.currentText()
        if valcbxTitularidad == "Todo":
            valcbxTitularidad = '%'
        if valcbxFuncionalidad == "Todo":
            valcbxFuncionalidad = '%'
        if valcbxProvincia == "Todo":
            valcbxProvincia = '%'

        ## Se crea la consulta SQL
        whereTXT = '('
        whereTXT+= ' Titularidad LIKE '+"'"+valcbxTitularidad+"'"
        whereTXT+= ' AND Funcionalidad LIKE '+"'"+valcbxFuncionalidad+"'"
        whereTXT+= ' AND Provincia LIKE '+"'"+valcbxProvincia+"'"
        whereTXT+= ' AND Matricula LIKE '+"'"+self.cbxMatricula.currentText()+"'"

        if not self.chbMATR9000.isChecked():
            whereTXT+= ' AND Matricula <>'+ "'9000'"
        whereTXT+= ")"
        # print ('whereTXT:', whereTXT)

        # Campos a obtener en la CONSULTA
        outfields = '*'
        resp = self.defineListasGlobales()
        if resp == 'error':
            return

        # Comprobamos CAMPOS INCLUIDOS en la lista de orden de campos
        listBorrar = []
        for campo in self.listCamposOrder:
            if not campo in self.listCamposCOMP:
                listBorrar.append(campo)
        for campo in listBorrar:
            self.listCamposOrder.remove(campo)
        orderByFields = ",".join(self.listCamposOrder)

        self.lblINFO.setText('INFO: Leyendo url .....')

        # QUERY AL WFS Plan_Carreteras_BTA_WFS
        url = self.conf.general["rest_carreteras"]

        values = {'where' : whereTXT,
                  'text': '',
                  'objectIds': '',
                  'geometryType' : 'esriGeometryPolyline',
                  'returnGeometry' : False,
                  'returnM': False,
                  'outFields': outfields,
                  'orderByFields' : orderByFields,
                  # 'geometryPrecision' : 6
                  'f': 'json'}

        self.restfeatures = self.fun.getFeaturesBTAcalibrada(values)
        if self.restfeatures:
            restfeaturesDESC = self.restfeatures
        else:
            return

        numfeats = len(self.restfeatures)
        nfeat = 0
        # if numfeats==0:
            # self.fun.showMessage(u"Error de conexión a internet (catalogoGDB LIN:288")
            # return

        # FICHEROS Y CAPAS
        fich_ext = self.lneFICHsalida.text()
        fich_solo, extension = os.path.splitext(fich_ext)
        fich_csv=fich_solo+'_'+prov.replace(' ', '')+'.csv'
        directorio, archivo = os.path.split(fich_csv)

        if not self.fun.comprobar_directorio_archivo(directorio, archivo):
            return

        QgsMessageLog.logMessage( "Creando archivo de log",self.nombre_plugin)

        # ESCRIBIMOS ENCABEZADOS FICHERO 'CSV'
        target  = codecs.open(fich_csv, 'w+',encoding='utf-8')
        encabezado = ''
        for campo in self.listCamposCOMP:
            encabezado += campo + u';'

        # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
        encabezado += 'Long_Total;'

        target.write(encabezado)
        target.write("\n")

        # ESCRIBIMOS LISTA DE DATOS
        # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
        countFeat = 0
        Long_Total = 0
        self.listProvs = []
        self.listRESUMEN = []

        # Variables para grupos por tramos
        grupoProv = []
        grupoPkINI = 9999
        grupoOrigen = ''
        grupoPkFIN = 0
        grupoDestino = ''
        grupoLong_Km = 0

        self.listFUNCIONALIDAD = []

        self.iface.mainWindow().statusBar().showMessage("Escribiendo fichero CSV...")
        for feat in self.restfeatures:
            attributes = feat["attributes"]
            # print (attributes['idMatricula'],'attributes[Long_Km] =', attributes['Long_Km'])
            if attributes['Long_Km']:
                Long_Km_data = round(attributes['Long_Km'], 3)
            else:
                Long_Km_data = 0

            ## COMPROBAMOS DOBLE VIA
            # Si es doble carril se graba la mitad de Long_Km
            # if not self.chbDOBLEVIA.isChecked():
            # if attributes['Tipologia_DobleC'] == 'ATV' or attributes['Tipologia_DobleC'] == 'ATP':
            if attributes['Tipologia_DobleC'] == 'ATV' or attributes['Tipologia_DobleC'] == 'ATP' or attributes['Tipologia_DobleC'] == 'MTC':
                Long_Km_data = round(attributes['Long_Km']/2, 3)

            #######################################
            # AÑADIMOS DATOS A GRUPOS POR TRAMOS  #
            #######################################
            # Se añade la provincia al grupoProv para el caso de agrupar viales
            if attributes['Provincia'] not in grupoProv:
                grupoProv.append(attributes['Provincia'])
            # Se añade la provincia al self.listProvs para el caso de agrupar viales
            if attributes['Provincia'] not in self.listProvs:
                self.listProvs.append(attributes['Provincia'])
                self.listProvs.sort()

            # Se añade Long_Km a grupoLong_Km para el caso de agrupar viales
            grupoLong_Km += Long_Km_data

            # Se obtiene el PkINI, Origen -MINIMOS- y PkFin, Destino -MAXIMOS-  para el caso de agrupar viales
            if attributes['PkINI'] != None and attributes['PkFin'] != None:
                if attributes['PkINI'] < grupoPkINI:
                    grupoPkINI  = attributes['PkINI']
                    grupoOrigen = attributes['Origen']
                if attributes['PkFin'] > grupoPkFIN:
                    grupoPkFIN  = attributes['PkFin']
                    grupoDestino= attributes['Destino']


            #################################
            #      ANALISIS POR TRAMOS      #
            #################################
            if countFeat+1 < len(self.restfeatures):
                # SE ANALIZAN CASOS DE TRAMOS CM-XXXXa
                if 'a' in attributes['Matricula'] or 'A' in attributes['Matricula']:
                    if attributes['Matricula_Plan'] == self.restfeatures[countFeat+1]["attributes"]['Matricula_Plan']:
                        # print (attributes['Matricula_Plan'], attributes['Long_Km'], grupoLong_Km, grupoProv, ' NO GRABA')
                        countFeat += 1
                        continue
                        
                ###     TODO BORRAR      ###
                # SE ANALIZAN CASOS EN EL QUE EL SIGUIENTE ELEMENTO ES OTRO TRAMO DE LA MISMA CTRA o CARRIL DERECHO EN DOBLE VÍA
                # elif attributes['Matricula'] == self.restfeatures[countFeat+1]["attributes"]['Matricula']:
                        # # print (attributes['Matricula_Plan'], attributes['Long_Km'], grupoLong_Km, grupoProv, ' NO GRABA')
                        # countFeat += 1
                        # continue

            ## COMPROBAMOS DOBLE VIA
            # Si es doble carril no se graba EL ELEMENTO
            # if not self.chbDOBLEVIA.isChecked():
            ###     TODO BORRAR      ###
            
            # if attributes['Tipologia_DobleC'] == 'ATV' or attributes['Tipologia_DobleC'] == 'ATP':
            if attributes['Tipologia_DobleC'] == 'ATV' or attributes['Tipologia_DobleC'] == 'ATP' or attributes['Tipologia_DobleC'] == 'MTC':
                if attributes['Matricula'] == self.restfeatures[countFeat+1]["attributes"]['Matricula'] and attributes['Origen'] == self.restfeatures[countFeat+1]["attributes"]['Origen'] and attributes['Tipologia_DobleC'] == self.restfeatures[countFeat+1]["attributes"]['Tipologia_DobleC']:
                    countFeat +=1
                    continue

            # Se crea la linea 'datos' para el CSV y el HTML
            datos = u''
            for attr in self.listCamposCOMP:
                dat = u''
                # Análisis de tipología de datos
                if isinstance(attributes[attr], str):
                    dat = attributes[attr]
                elif isinstance(attributes[attr], unicode):
                    dat = attributes[attr]
                elif isinstance(attributes[attr], int):
                    dat = str(attributes[attr])
                elif isinstance(attributes[attr], float):
                    dat = (self.strPrecision.format(attributes[attr]))

                if attr == 'Provincia':
                    dat = u''
                    for prov in grupoProv:
                        dat += prov
                        # print ('grupoProv.index(prov)-', grupoProv.index(prov), 'len(grupoProv)-', len(grupoProv) )
                        if grupoProv.index(prov)<len(grupoProv)-1: dat += ' / '
                    grupoProv = []
                if attr == 'Long_Km':
                    dat = self.strPrecision.format(grupoLong_Km)

                if attr == 'PkINI':
                    dat = self.strPrecision.format(grupoPkINI)
                    grupoPkINI = 9999
                if attr == 'Origen':
                    dat = grupoOrigen
                    grupoOrigen = ''
                if attr == 'PkFin':
                    dat = self.strPrecision.format(grupoPkFIN)
                    grupoPkFIN = 0
                if attr == 'Destino':
                    dat = grupoDestino
                    grupoDestino = ''

                if dat is None:
                    dat = ''
                datos += (dat + u';')
            # print (attributes['Matricula'], attributes['Funcionalidad'], attributes['Provincia'])

            target.write(datos)
            target.write("\n")
            nfeat +=1
            prog = 50 * nfeat/numfeats
            self.progressBar.setValue(int(prog))
            self.lblINFO.setText(u'INFO: Añadiendo a CSV registro ' + str(nfeat) +'/' +str(numfeats))

            countFeat += 1

        target.close()

        fich_csv_uri = u"file:///"+ fich_csv +"?type=csv&geomType=none&subsetIndex=no&delimiter=%s&watchFile=no" % (";")

        abstract = ''
        if self.cbxTitularidad.currentText() != '%':
                    abstract += u'Titularidad - %s / '%self.cbxTitularidad.currentText()
        if self.cbxFuncionalidad.currentText() != '%':
                    abstract += u'Funcionalidad - %s / '%self.cbxFuncionalidad.currentText()
        if self.cbxProvincia.currentText() != '%':
                    abstract += u'Provincia - %s / '%self.cbxProvincia.currentText()

        # Esto crea la capa CSV
        #   Si existe la capa se debe borrar
        prov = self.cbxProvincia.currentText()
        if prov == 'Todo':
            prov = 'JCCM'
        nomcapa = u'CATALOGO CARRETERAS '+prov
        csv_lyrLIST = QgsProject.instance().mapLayersByName(nomcapa)
        if len(csv_lyrLIST) >0:
            for csv_lyr in csv_lyrLIST:
                QgsProject.instance().removeMapLayer(csv_lyr.id())

        csv_lyr = QgsVectorLayer(fich_csv_uri, nomcapa,'delimitedtext')
        # QgsProject.instance().addMapLayer(csv_lyr, False)

        # Generando Catalogo RT
        self.iface.mainWindow().statusBar().showMessage("Generando Catálogo RT...")
        uriCatRT = self.lneFICHsalida.text()
        # Comprobar si existe el directorio destino y si no, se crea
        # self.fun.comprobarDirectorio(os.path.dirname(uriCatRT)+'\\')
        nameCapaRT = self.lneNomCapa.text()
        
        self.layerRT = QgsVectorLayer("None", nameCapaRT, "memory")

        capaRtLIST = QgsProject.instance().mapLayersByName(nameCapaRT)
        if len(capaRtLIST) >0:
            for capaRt in capaRtLIST:
                QgsProject.instance().removeMapLayer(capaRt.id())

        # Obtener los atributos de todos los elementos en forma de lista de diccionarios
        features = csv_lyr.getFeatures()

        # Obtener nombres de campos para construir diccionarios con claves legibles
        field_names = [field.name() for field in csv_lyr.fields()]
        lista_dictionaries = [dict(zip(field_names, feature.attributes())) for feature in csv_lyr.getFeatures()]
        # print (lista_dictionaries)

        # Se llama a las funcionalidades de herrCTRAS_catalogoRT.py
        if self.chbGenHojaCalc.isChecked():  # Control para generar Hoja de Cálculo
            GenHojaCalc = True
        else:
            GenHojaCalc = False
        if self.chbIncCamposGDB.isChecked(): # Control para incluir los campos de GDB D.G.C.
            IncCamposGDB = True
        else:
            IncCamposGDB = False
        if self.chbCompGDBorig.isChecked(): # Comparar datos con RT Original
            CompGDBorig = True
        else:
            CompGDBorig = False
        if self.chbRevRTdatErroneos.isChecked(): # Control para revisar en RT datos erroneos de Red
            RevRTdatErroneos = True
        else:
            RevRTdatErroneos = False
        if self.chbCarTraRTErro.isChecked(): # Control para Cargar tramos de RT erróneos
            CarTraRTErro = True
            # Crear la capa si no existe
            layer_name = 'CARRETERAS RT ERRONEAS'
            geom_wkb = 'MultiLineString'
            estiloCAPA = os.path.join(os.path.dirname(__file__), self.conf.general["carpeta_estilos"] + '/cartoc_lin.qml')
            gpkg_path = 'c:/temp/cartoGeomRTerr.gpkg'
            if not os.path.exists(gpkg_path) or not QgsProject.instance().mapLayersByName(layer_name):
                # Se crea la capa
                self.cartocLayer = self.cartoc.creaCapaCartociudad(self.iface, layer_name, geom_wkb, estiloCAPA, gpkg_path)
                ### TODO QUITAR PARA QUE CARGUE LA CAPA ###
                QgsProject.instance().addMapLayer(self.cartocLayer)
        else:
            CarTraRTErro = False
            

        ### LLAMADA A LA RUTINA DE GENERACIÓN DE capaCatalogoRT ###
        # capaCatalogoRT = self.createCatalogoRT(lista_dictionaries, uriCatRT, nameCapaRT,
        self.createCatalogoRT(lista_dictionaries, uriCatRT, nameCapaRT,
                        GenHojaCalc,        # Generar Hoja de Cálculo
                        IncCamposGDB,       # Incluir los campos de GDB D.G.C.
                        CompGDBorig,        # Comparar datos con RT Original
                        RevRTdatErroneos,   # Revisar en RT datos erroneos de Red
                        CarTraRTErro)       # Cargar tramos de RT erróneos

        QApplication.restoreOverrideCursor()            # ICONO NORMAL

        # TERMINADA LA MIGRACIÓN DE CATÁLOGO
        stop = timeit.default_timer()

        # Clear the message bar when done
        self.iface.messageBar().clearWidgets()
        
        # if capaCatalogoRT != 'error':
        if self.layerRT != 'error':
            text =  'MIGRACIÓN CATÁLOGO A RT'
            text += '\n\n--- TERMINADO ---'
            tiempo_delta = datetime.timedelta(seconds=(stop - start))
            tiempo = 'Tiempo: {}'.format(str(tiempo_delta).split('.')[0])
            self.iface.mainWindow().statusBar().showMessage(f"TERMINADA LA MIGRACIÓN DE CATÁLOGO {str(tiempo_delta).split('.')[0]}")

            self.fun.showMessage(text, tiempo)
      
        return


    '''
        RUTINAS DE TRANSFORMACIÓN DE GDB A RT
    '''
    def createCatalogoRT(self, restfeaturesDESC, uri, name, GenHojaCalc, IncCamposGDB, CompGDBorig, RevRTdatErroneos, CarTraRTErro):
        #   Crea una capa alfanumérica con el CATALOGO DE CARETERAS en memoria añadiendoles campos
        #   Devuelve la capa de texto

        # Nombre de la capa de Catálogo RT
        nomCapaCatRT = 'rt_catcarreteras_a'

        # Obtener la capa del proyecto
        listCapaRT = QgsProject.instance().mapLayersByName(nomCapaCatRT)
        if not listCapaRT:
            text  = f'La capa \n\n     {nomCapaCatRT} \n\ncorrespondiente al CATALOGO DE CARRETERAS RT'
            text += '\n'+'no se encontró en el proyecto.'
            text += '\n\n'+' DEBE CARGARSE MANUALMENTE'
            self.fun.showMessageERR('MIGRACIÓN CATÁLOGO RT', text )
            return 'error'
        else:
            capaRT = listCapaRT[0]

        pr = self.layerRT.dataProvider()

        # Se añaden campos desde la listaCamposDataRT
        dataCamposRT = []
        for campo in self.listaCamposDataRT:
            if campo['tipo'] == 'string':
                dataCamposRT.append(QgsField(campo['campo'], QMetaType.Type.QString, comment=campo['comment'] ))
            elif campo['tipo'] == 'int':
                dataCamposRT.append(QgsField(campo['campo'], QMetaType.Type.Int, comment=campo['comment']))
            elif campo['tipo'] == 'double':
                dataCamposRT.append(QgsField(campo['campo'], QMetaType.Type.Double, comment=campo['comment']))
            else:       # Si la sintaxis no es correcta, se pone string
                dataCamposRT.append(QgsField(campo['campo'], QMetaType.Type.QString, comment=campo['comment']))

        if IncCamposGDB: # Se cargan todos los datos de la GDB D.G.C.
            for campo in self.listaCamposData:
                if campo['tipo'] == 'string':
                    dataCamposRT.append(QgsField(campo['campo'], QMetaType.Type.QString, comment=campo['comment'] ))
                elif campo['tipo'] == 'int':
                    dataCamposRT.append(QgsField(campo['campo'], QMetaType.Type.Int, comment=campo['comment']))
                elif campo['tipo'] == 'double':
                    dataCamposRT.append(QgsField(campo['campo'], QMetaType.Type.Double, comment=campo['comment']))
                else:       # Si la sintaxis no es correcta, se pone string
                    dataCamposRT.append(QgsField(campo['campo'], QMetaType.Type.QString, comment=campo['comment']))

        # Añadir campos
        pr.addAttributes(dataCamposRT)

        # Actualizar la capa con los cambios
        self.layerRT.updateFields()

        self.layerRT.startEditing()

        # Obtener la fecha actual en formato 'dd-mm-yyyy'
        fechaHoy = datetime.datetime.now().strftime('%d-%m-%Y')

        # # Crear barra de progreso
        progressMessageBar = self.iface.messageBar().createMessage('MIGRACIÓN RT','Procesando elementos de Catálogo ...')
        progress = QProgressBar()
        progress.setMaximum(100)
        progress.setAlignment(Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)
        progressMessageBar.layout().addWidget(progress)
        self.iface.messageBar().pushWidget(progressMessageBar, Qgis.Info)


        # ANALIZAMOS SI LA CAPA tiene elementos QgsFeature, Dictionary o JSON
        if all(isinstance(feat, QgsFeature) for feat in restfeaturesDESC):
            noFeatures = self.layerRT.featureCount()   # Todos los elementos son diccionarios QgsFeature
        elif all(isinstance(feat, dict) for feat in restfeaturesDESC):
            noFeatures = len(restfeaturesDESC)  # Todos los elementos son diccionarios JSON

        count = 0
        for feat in restfeaturesDESC:
            count +=1
            # #################   TODO BORRAR CONTROL LIMITADOR BUCLE #################
            # noFeatures = 50
            # if count > noFeatures: break
            # #################   TODO BORRAR CONTROL LIMITADOR BUCLE   #################

            # # Actualizar barra de progreso
            if RevRTdatErroneos:
                progress.setValue(int(count/noFeatures*50))
            else:
                progress.setValue(int(count/noFeatures*100))

            # ANALIZAMOS SI LA CAPA tiene elementos QgsFeature, Dictionary o JSON
            if isinstance(feat, QgsFeature):
                attributes = feat.attributes()  # Elemento tipo QgsFeature
            elif all(isinstance(feat, dict) and "attributes" not in feat for feat in restfeaturesDESC):
                attributes = feat               # Elemento tipo dictionary
            elif isinstance(feat, dict) and "attributes" in feat:
                attributes = feat["attributes"] # Elemento tipo dictionary y JSON

            # Analizamos el elemento en catalogoRT
            if self.cbxTitularidad.currentText() == 'Estatal':
                prefijoIDVIAL = '600'  # Prefijo de carreteras de la AGE
                clasePPAL = '1'
            elif self.cbxTitularidad.currentText() == 'JCCM':
                prefijoIDVIAL = '608'  # Prefijo de carreteras por Castilla la Mancha
                clasePPAL = '2'
            elif self.cbxTitularidad.currentText() == 'Diputación':
                prefijoIDVIAL = ''     # Prefijo de carreteras INDETERMINADO
                clasePPAL = '3'
            else:
                ##################   TODO analizar cómo identificar los datos de cada RED  #################
                prefijoIDVIAL = ''     # Prefijo de carreteras por Castilla la Mancha
                clasePPAL = '1'
                ##################   TODO analizar cómo identificar los datos de cada RED  #################

            elementoRT = self.analisisCatRT(attributes['Matricula'], capaRT, prefijoIDVIAL)

            #### Asignamos atributos al nuevo elemento RT
            fet = QgsFeature(self.layerRT.fields()) # Añade un elemento

            fet.setAttribute("id_vial",         elementoRT['id_vial'])
            fet.setAttribute("nombre",          attributes['Matricula'])
            nombre_alt =  attributes['Matricula_Plan']
            if attributes['Matricula'] != attributes['Matricula_Plan']: # Se elimina el valor 'D' O 'I' de Matrícula _Plan
                nombre_alt = attributes['Matricula_Plan'].replace( ' I ', ' ')
                nombre_alt =                   nombre_alt.replace( ' D ', ' ')
                nombre_alt = nombre_alt[:-2] if nombre_alt.endswith((' D', ' I')) else nombre_alt
            if attributes['Matricula'] != nombre_alt:
                fet.setAttribute("nombre_alt",  nombre_alt)
            else:
                fet.setAttribute("nombre_alt",  '')
            fet.setAttribute("codigo",          elementoRT['codigo'])
            fet.setAttribute("descripcion",     attributes['Denominacion'])

            clase1 = self.traduccionDatosRT(attributes, 'clase1')['clase1']
            fet.setAttribute("clase1",          clase1)
            fet.setAttribute("clase2",          '')
            fet.setAttribute("clase3",          '')
            fet.setAttribute("clase4",          '')

            titular1 = self.traduccionDatosRT(attributes, 'titular1')['titular1']
            fet.setAttribute("titular1",        titular1)
            fet.setAttribute("titular2",        '')
            fet.setAttribute("titular3",        '')
            fet.setAttribute("titular4",        '')

            orden1 = self.traduccionDatosRT(attributes, 'orden1')['orden1']
            fet.setAttribute("orden1",          orden1)
            fet.setAttribute("orden2",          '')

            fet.setAttribute("fecha_alta",      's/d')
            fet.setAttribute("alta_db",         fechaHoy)

            fuente = self.traduccionDatosRT(attributes, 'fuente')['fuente']
            fet.setAttribute("fuente",          fuente)

            fet.setAttribute("version",         's/d')

            comentario = self.traduccionDatosRT(attributes, 'comentario')['comentario']
            # Se añaden datos a 'comentario'
            if not fet['id_vial']:
                comentario = 'Falta en RT - '+ comentario
            fet.setAttribute("comentario",      comentario)

            fet.setAttribute("no_nombre",       elementoRT['no_nombre'])
            fet.setAttribute("id_vial_encont",  elementoRT['id_vial_encont'])

            # Añadimos los atributos de la capa GDB D.G.C. si procede
            #### TODO SE DEBE ANALIZAR LOS DATOS DISTINTOS EN TRAMOS, Y EL DATO ORIGEN Y FINAL
            if IncCamposGDB: # Se cargan todos los atributos de la GDB D.G.C.
                for campo in self.listaCamposData:
                    if campo['campo'] in attributes:
                        nombre_campo = campo["campo"]               # Usa el nombre del campo tal cual
                        valor = attributes.get(nombre_campo, None)  # Obtiene el valor del atributo con un valor predeterminado
                        fet.setAttribute(nombre_campo, valor)
            #### TODO SE DEBE ANALIZAR LOS DATOS DISTINTOS EN TRAMOS, Y EL DATO ORIGEN Y FINAL

            ## Análisis de duplicados
            # Expresiones para buscar en el campos 'nombre' si está ya la matrícula
            Matricula = fet['nombre']
            expression_nombre = QgsExpression(f'"nombre" = \'{Matricula}\'')
            # Preparar solicitudes
            request_nombre = QgsFeatureRequest(expression_nombre)

            featuresREP = list(self.layerRT.getFeatures(request_nombre))
            if not featuresREP or not elementoRT['id_vial'] or Matricula[-1] == 'a':
                # Caso de que el elemento no está ya registrado, o no se encuentra valor id_vial o sea un tramo 'alternativo', ej:'CM-3203a'
                pr.addFeatures( [ fet ] )
            else:
                # Modificar el primer elemento duplicado encontrado (asumiendo uno único)
                feature_to_update = featuresREP[0]
                fid = feature_to_update.id()  # ID del feature a modificar

                updates = {}
                # Analizar valores únicos para 'clase2', 'clase3', 'clase4'
                nuevo_clase = fet['clase1']
                for clase_field in ['clase2', 'clase3', 'clase4']:
                    if nuevo_clase and nuevo_clase != feature_to_update['clase1'] and nuevo_clase != feature_to_update['clase2'] and nuevo_clase != feature_to_update['clase3'] and nuevo_clase != feature_to_update['clase4']:
                        if feature_to_update[clase_field] == '':  # Si contiene ''
                            updates[self.layerRT.fields().indexOf(clase_field)] = nuevo_clase
                            comentarioNew = fet['comentario'] + ' - Ctra. con diferentes clases'
                            updates[self.layerRT.fields().indexOf('comentario')] = comentarioNew
                            break  # Solo se actualiza el primero vacío

                # Analizar valores únicos para 'titular2', 'titular3', 'titular4'
                nuevo_titular = fet['titular1']
                for titular_field in ['titular2', 'titular3', 'titular4']:
                    if nuevo_titular and nuevo_titular != feature_to_update['titular1'] and nuevo_titular != feature_to_update['titular2'] and nuevo_titular != feature_to_update['titular3'] and nuevo_titular != feature_to_update['titular4']:
                        if feature_to_update[titular_field] == '':  # Si contiene ''
                            updates[self.layerRT.fields().indexOf(titular_field)] = nuevo_titular
                            comentarioNew = fet['comentario'] + ' - Ctra. con diferentes Titulares'
                            updates[self.layerRT.fields().indexOf('comentario')] = comentarioNew
                            break  # Solo se actualiza el primero vacío

                # Analizar valores únicos para 'orden2'
                nuevo_orden = fet['orden1']
                if nuevo_orden and nuevo_orden != feature_to_update['orden1'] and nuevo_orden != feature_to_update['orden2']:
                    if feature_to_update['orden2'] == '':  # Si contiene ''
                        updates[self.layerRT.fields().indexOf('orden2')] = nuevo_orden

                # Aplicar los cambios al feature si hay actualizaciones
                if updates:
                    self.layerRT.dataProvider().changeAttributeValues({fid: updates})

            self.layerRT.updateExtents()
            self.layerRT.commitChanges()

        ### Analisis de datos de catálogo RT que ya no existen
        if RevRTdatErroneos:
            # Se revisan los datos erroneos del Catálogo RT que no existen en el CATALOGO OFICIAL DE CARRETERAS (GDB DGC)
            #   Todos los elementos del titular autonómico y no incluidos en el catálogo oficial GDB DGC, se incluirán en
            #   el listado

            # Revisando los datos erroneos del Catálogo RT
            self.iface.mainWindow().statusBar().showMessage("Revisando los datos erroneos del Catálogo RT...")

            ###########   TODO REVISAR ESTO ###########
            # Se debe controlar que se trabaja sobre todo el catálogo sin filtros
            ###########   TODO REVISAR ESTO ###########
            
            fetERRlist = [] # Listado de elementos erroneos

            # Buscamos todos los elemento del catálogo RT con prefijoIDVIAL id_Vial = '608xxxxxxxxx' y titular = 2 (Caso RED Autonómica)
            expression_idvial = QgsExpression(f'"id_vial" LIKE \'{prefijoIDVIAL}%\' AND ("titular1" = \'{clasePPAL}\' OR "titular2" = \'{clasePPAL}\' OR "titular3" = \'{clasePPAL}\' OR "titular4" = \'{clasePPAL}\')')

            # Preparar solicitudes
            request_idvial = QgsFeatureRequest(expression_idvial)

            features = list(capaRT.getFeatures(request_idvial))

            noFeatures = len(features)
            # count =0
            resCartociudad = ''
            for feature in features:
                # #################   TODO BORRAR CONTROL LIMITADOR BUCLE #################
                # count +=1
                # noFeatures = 50
                # if count > noFeatures: break
                # #################   TODO BORRAR CONTROL LIMITADOR BUCLE   #################
                
                progress.setValue(50+int(count/noFeatures*25))

                nombreFeat = feature['nombre']
                expression_nombre = QgsExpression(f'"nombre" = \'{nombreFeat}\'')
                # Preparar solicitudes
                request_nombre = QgsFeatureRequest(expression_nombre)
                featuresREP = list(self.layerRT.getFeatures(request_nombre))
                if len(featuresREP) == 0:
                    # Al no estar el elemento en el listado, y ser de tipo id_vial = 608, se añade al listado
                    #### Asignamos atributos al nuevo elemento
                    fetERR = {}
                    for key in feature.fields().names():  # Se obtienen los nombres de los campos del QgsFeature
                        fetERR[key] = feature[key]
                    fetERRlist.append(fetERR)
                    

            if len(fetERRlist) > 0:
                ### TODO Aquí se debe ordenar la lista fetERRlist
                fetERRlist_sorted = sorted(fetERRlist, key=lambda x: x['nombre'])
                self.layerRT.startEditing()

                for fetERR in fetERRlist_sorted:
                    progress.setValue(75+int(count/noFeatures*25))

                    ####   TODO CARGA DE CARRETERAS ERRÓNEAS DESDE CARTOCIUDAD    ####
                    nombreFeat = fetERR['nombre']
                    if CarTraRTErro: # Se carga el elemento desde el buscador de Cartociudad
                        resCartociudad = self.CargaCtraCartociudad(nombreFeat, self.cartocLayer)
                        if resCartociudad == '':
                            print ('nombreFeat: ', nombreFeat, ' OK', )
                        else:
                            print ('nombreFeat: ', nombreFeat, ' NO SE ENCUENTRA', )
                    ####   TODO CARGA DE CARRETERAS ERRÓNEAS DESDE CARTOCIUDAD    ####

                    fet = QgsFeature(self.layerRT.fields()) # Añade un elemento
                    #### Asignamos atributos al nuevo elemento
                    for key in fetERR.keys():  # Se obtienen los nombres de los keys del fetERR
                        try:
                            fet.setAttribute(key, fetERR[key])
                            # print (key)
                        except:
                            # print (f'No se puede asignar el key {key}')
                            pass

                    comentario = 'ELIMINAR. NO FIGURA YA EN CATÁLOGO DE CARRETERAS'
                    if resCartociudad != '':
                        comentario += '. ' + resCartociudad
                    fet.setAttribute("comentario",      comentario)
                    pr.addFeatures( [ fet ] )

                self.layerRT.updateExtents()
                self.layerRT.commitChanges()

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = name        # Nombre de la capa dentro del GeoPackage
        error = QgsVectorFileWriter.writeAsVectorFormatV2(
            self.layerRT, uri, QgsCoordinateTransformContext(), options)

        if error[0] == QgsVectorFileWriter.NoError:
            print(f"La capa {name} se ha creado correctamente en {uri}.")
        else:
            print(f"Error al crear la capa: {error[1]}")

        # Cargar la capa desde el GeoPackage y añadirla a la TOC
        uriGPKG = f"{uri}|layername={name}"
        gpkg_layer = QgsVectorLayer(uriGPKG, name, "ogr")
        if gpkg_layer.isValid():
            QgsProject.instance().addMapLayer(gpkg_layer)
        else:
            print("Error al cargar la capa desde el GeoPackage.")

        ### Se comprueba si se debe crear un EXCEL
        if GenHojaCalc:
            # Generando un EXCEL
            self.iface.mainWindow().statusBar().showMessage("Generando un EXCEL...")

            # Se crea el excel
            excel_path = uri.replace('.gpkg', '.xls')
            self.exportLayerToEXCEL(gpkg_layer, capaRT, name, excel_path, 'CATALOGO', IncCamposGDB, CompGDBorig)

        # return self.layerRT
        return self.layerRT


    def analisisCatRT(self, Matricula, capaRT, prefijoIDVIAL):
        # Se busca el dato 'Matrícula' en la 'capaRT', y se crea el elemento resultante
        # Argumentos:
        #       Matricula, valor alfanumérico de la Matrícula
        #       capaRT, capa con el Catálogo RT cargada en la TOC

        elementoRT = {}
        fields = []
        for field in self.listaCamposDataRT:
            fields.append(field['campo'])

        # Expresiones para buscar en los campos 'nombre' y 'nombre_alt'
        expression_nombre = QgsExpression(f'"nombre" = \'{Matricula}\'')

        # Preparar solicitudes
        request_nombre = QgsFeatureRequest(expression_nombre)

        features = list(capaRT.getFeatures(request_nombre))

        for feature in features:
            if feature['id_vial'][:3] == prefijoIDVIAL:
                featureCorr = feature
                break
            else:
                featureCorr = feature
            pass

        if len(features)>0:
            no_nombre = len(features)
            for field in self.listaCamposDataRT:
                try:
                    elementoRT[field['campo']] = featureCorr[field['campo']]
                except:
                    pass

            elementoRT['no_nombre']     = no_nombre # Número de elementos encontrados

            # Se incorporan los id_vial de los elementos encontrados (si múltiples)
            listaId_Vial = []
            if len(features)>1:
                for f in features:
                    listaId_Vial.append(f['id_vial'])
                elementoRT['id_vial_encont'] = ', '.join(listaId_Vial)
            else:
                elementoRT['id_vial_encont'] = ''
        else:
            elementoRT = {key: None for key in fields}
            elementoRT['no_nombre'] = 0 # Número de elementos encontrados

        return elementoRT


    def traduccionDatosRT(self, attributes, campoRT):
        # Se analiza el dato a meter en cada campo de la BD RT, dependiendo de los atributos del elemento en la BTAcalibrada
        result = {}

        # Análisis de los datos de clase: 'clase1','clase2','clase3','clase4'
                # 1001=Autopista
                # 1002=Autovía
                # 1003=Carretera convencional
                # 1005=Carretera multicarril
        if campoRT == 'clase1':
            if   attributes['Tipologia_DobleC'] == 'ATP' and attributes['Funcionalidad'] == 'Básica alta capacidad':
                result['clase1']        = '1001'
            elif attributes['Tipologia_DobleC'] == 'ATV' and attributes['Funcionalidad'] == 'Básica alta capacidad':
                result['clase1']        = '1002'
            elif attributes['Tipologia_DobleC'] == 'ATV' and attributes['Funcionalidad'] != 'Básica alta capacidad':
                result['clase1']        = '1005'
            elif attributes['Tipologia_DobleC'] == 'MTC':
                result['clase1']        = '1005'
                ### TODO. SE DEBE ANALIZAR QUÉ PASA CON EL CASO DE LAS 
                ###     CM-10,CM-45 (PARTE) 'Básicas alta capacidad', PERO MULTICARRIL 1005
            else:
                result['clase1']        = '1003'

        # Análisis de los datos de titular: 'titular1','titular2','titular','titular'
                # 1 = Administración General del Estado
                # 2 = Comunicad Autónoma
                # 3 = Diputación Provincial
                # 4 = Cabildo o Consell Insular
                # 5 = Ayuntamiento
                # 6 = Confederación hidrográfica
                # 7 = Autoridad portuaria
                # 8 = Militar
                # 9 = Empresa minera
                # 10 = Ciudad Autónoma
                # 99 = Otros
        if campoRT == 'titular1':
            if   attributes['Titularidad'] == 'Estatal':
                result['titular1']      = '1'
            elif attributes['Titularidad'] == 'JCCM':
                result['titular1']      = '2'
            elif attributes['Titularidad'] == 'Diputación':
                result['titular1']      = '3'
            elif attributes['Titularidad'] == 'Ayuntamiento':
                result['titular1']      = '5'
            else:
                result['titular1']      = '99'


        # Análisis de los datos de orden: 'orden1','orden2'
                # P = Principal (RIGE, autopistas y autovías nacionales y autonómicas)
                # 1 = I
                # 2 = II
                # 3 = III
        if campoRT == 'orden1':
            if  attributes['Funcionalidad'] == 'Básica alta capacidad':
                if   attributes['Tipologia_DobleC'] == 'ATP':
                    result['orden1']        = 'P'
                elif attributes['Tipologia_DobleC'] == 'ATV':
                    result['orden1']        = 'P'
                else:
                    result['orden1']        = '1'
            elif attributes['Funcionalidad'] == 'Básica':
                result['orden1']        = '1'
            elif attributes['Funcionalidad'] == 'Comarcal':
                result['orden1']        = '2'
            else:
                result['orden1']        = '3'

        # Análisis de los datos de fuente
                # Instituto Geográfico Nacional       1
                # Dirección General del Catastro      2
                # Inventario de la Red de Carreteras de Fomento   3
                # Instituto Nacional de Estadística   4
                # Sociedad Estatal de Correos y Telégrafos        5
                # Aragón                              6
                # Andalucía                           7
                # Canarias                            8
                # Cantabria                           9
                # Castilla - La Mancha                10
                # Castilla y León                     11
                # Cataluña/Catalunya                  12
                # Ciudad de Ceuta                     13
                # Comunidad Foral de Navarra          14
                # Comunidad de Madrid                 15
                # Comunitat Valenciana                16
                # Extremadura                         17
                # Galicia                             18
                # Illes Balears                       19
                # La Rioja                            20
                # Ciudad de Melilla                   21
                # Principado de Asturias              22
                # Región de Murcia                    23
                # País Vasco/Euskadi                  24
                # UNECE                               25
                # DGT                                 26
        if campoRT == 'fuente':
            if   attributes['Titularidad'] == 'JCCM':
                result['fuente']        = '10'
            else:
                result['fuente']        = '1'

        # Análisis de los datos de comentario
                # Administración General del Estado
                # JCCM;   Dato de Catalogo de Carreteras 2024
                # 3 = Diputación Provincial
                # 4 = Cabildo o Consell Insular
                # 5 = Ayuntamiento
                # 6 = Confederación hidrográfica
                # 7 = Autoridad portuaria
                # 8 = Militar
                # 9 = Empresa minera
                # 10 = Ciudad Autónoma
                # 99 = Otros
        if campoRT == 'comentario':
            if   attributes['Titularidad'] == 'Estatal':
                result['comentario']      = 'Catálogo en la Web del MTyMS a 31 de diciembre de 2023'
            elif attributes['Titularidad'] == 'JCCM':
                result['comentario']      = 'Catalogo de Carreteras 2024. Dec. 18/2024, de 2/4'
            elif attributes['Titularidad'] == 'Diputacion' and attributes['Provincia'] == 'Albacete':
                result['comentario']      = 'DIPUALBA. Relación de carreteras de la provincia de Albacete. Abril 2014'
            elif attributes['Titularidad'] == 'Diputacion' and attributes['Provincia'] == 'Ciudad Real':
                result['comentario']      = 'Relación de carreteras de la provincia de Ciudad Real'
            elif attributes['Titularidad'] == 'Diputacion' and attributes['Provincia'] == 'Cuenca':
                result['comentario']      = 'Relación de carreteras de la provincia de Cuenca'
            elif attributes['Titularidad'] == 'Diputacion' and attributes['Provincia'] == 'Guadalajara':
                result['comentario']      = 'Relación de carreteras de la provincia de Guadalajara'
            elif attributes['Titularidad'] == 'Diputacion' and attributes['Provincia'] == 'Toledo':
                result['comentario']      = 'Relación de carreteras de la provincia de Toledo'
            else:
                result['comentario']      = 'Distintas fuentes'

        return result


    def exportLayerToEXCEL(self, csv_lyr, capaRT, layer_name, excel_path, sheet_name='CATALOGO', IncCamposGDB = False, CompGDBorig = False):
        '''
        Exporta una tabla alfanumérica de un GeoPackage a Excel utilizando xlrd y xlwt.

        Args:
            csv_lyr    (QgsVectorLayer): CAPA CON DATOS NUEVOS RT A EXPORTAR AL EXCEL.
            capaRT     (QgsVectorLayer): Capa original con datos RT
            layer_name (str): Nombre de la capa dentro del GeoPackage.
            excel_path (str): Ruta y nombre del archivo Excel de salida.
            sheet_name (str optional): Nombre de la hoja en el Excel. Default 'CATALOGO'.
            IncCamposGDB (bool optional): Flag para incluir en el excel los campos de la GDB DGC
            CompGDBorig  (bool optional): Flag para comprobar y marcar valores distintos entre la RT original y resultado
        '''

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        # Datos del fichero de salida excel
        archivoXCL = excel_path
        hojaXCL = sheet_name

        # Renombrar fichero
        srcFilName, srcExt = os.path.splitext(archivoXCL)
        nombre_nuevo = srcFilName+'_'+srcExt.replace('.','')+'.bak'
        if os.path.exists(nombre_nuevo):
            os.remove(nombre_nuevo)

        ######################################################################
        #               Preparacion de TITULOS
        ######################################################################
        prov = self.cbxProvincia.currentText()
        if prov == 'Todo':
            prov = 'JCCM'

        title = u'CATÁLOGO DE CARRETERAS   -'+prov+'-'
        abstract = 'CATALOGO DE CARRETERAS -RT-'

        # FECHA DE CREACIÓN
        locale.setlocale(locale.LC_TIME,'')
        if hasattr(locale, 'nl_langinfo'):
            date_format = locale.nl_langinfo(locale.D_T_FMT)
        else:
            date_format = "%x %X"
        today = datetime.datetime.today()
        date = today.strftime(date_format)
        dt_date = u'JCCM. Dirección General de Carreteras '


        #########################################################
        #       Escritura del fichero EXCEL
        #########################################################
        # Se crea el workbook
        wb = xlwt.Workbook()
        wb = xlwt.Workbook(style_compression=2)

        # Se añade una HOJA  al WORKBOOK
        sheetWB = wb.add_sheet(hojaXCL)

        # Se añaden títulos
        styleTITLE = self.estiloExcelCell('white', 'left', 'bold', 300)
        sheetWB.write(0,1, title, styleTITLE)
        styleDATA = self.estiloExcelCell('white', 'left', 'bold', 240)
        sheetWB.write(1,1, 'Datos:', styleDATA)
        sheetWB.write(1,2, abstract, styleDATA)
        styleDATA = self.estiloExcelCell('white', 'left', 'bold', 200)
        sheetWB.write(2,1, 'Fecha:', styleDATA)
        sheetWB.write(2,2, date, styleDATA)
        row = 5


        # Obtenemos los tipos de cada campo en una lista
        fields = csv_lyr.fields()

        tipoCampos = []
        for field in fields:
            tipoCampos.append(field.typeName())

        ###### LINEAS DE ENCABEZADOS ######
        poslistCampos = []
        col = 0
        ColorCellFORE = 'black'
        ColorCellTXT  = 'white'
        styleCAB = self.estiloExcelCell(ColorCellFORE, 'text', 'bold', 220, True, ColorCellTXT)
        styleCABgdbDGC = self.estiloExcelCell('blue', 'text', 'bold', 220, True, ColorCellTXT)

        # Encabezados previos
        sheetWB.write_merge(row, row, 0, 4,  '- CAMPOS DE CAPA DE RED DE TRANSPORTES -', styleCAB)
        sheetWB.write_merge(row, row, 5, 8,  'CLASES',  styleCAB)
        sheetWB.write_merge(row, row, 9, 12, 'TITULAR', styleCAB)
        sheetWB.write_merge(row, row, 13,14, 'ORDEN', styleCAB)
        sheetWB.write_merge(row, row, 15,21, '', styleCAB)
        if IncCamposGDB:    # Encabezados previos de GDB DGC
            sheetWB.write_merge(row, row, 22,40, '- CAMPOS DE CAPA GEODATABASE DE LA D.G.C. DE CASTILLA - LA MANCHA -', styleCABgdbDGC)
        row += 1

        # Encabezados de campos
        for field in self.listaCamposDataRT:
            poslistCampos.append(self.listaCamposDataRT.index(field))
            # Establecemos los anchos desde el listado de campos de self.listaCamposDataRT
            ancho = field['anchocol']
            sheetWB.col(col).width = ancho
            sheetWB.write(row, col, field["alias"].capitalize(), styleCAB)
            col += 1
        if IncCamposGDB:    # Encabezados de campos de GDB DGC
            for field in self.listaCamposData:
                poslistCampos.append(self.listaCamposData.index(field))
                # Establecemos los anchos desde el listado de campos de self.listaCamposData
                ancho = field['anchocol']
                sheetWB.col(col).width = ancho
                sheetWB.write(row, col, field["alias"].capitalize(), styleCABgdbDGC)
                col += 1
        row += 1


        ###### Escribimos la tabla de contenido como EXCEL ######
        # Se mapean nombres de campo a índices
        field_indices = {field.name(): idx for idx, field in enumerate(csv_lyr.fields())}

        # Iteración sobre los features
        features = csv_lyr.getFeatures()
        for feat in features:               # Cada feature de la capa
            if CompGDBorig:
                featERR, featRT = self.CompRTorigRTdest(feat, capaRT)
            col = 0                         # Reinicia contador de columnas al inicio de cada fila
            attr = feat.attributes()        # Lista de valores de atributos para este feature
            for field in self.listaCamposDataRT:  # Cada campo de la lista
                styleDATA = self.estiloExcelCell('white', field["tipo"], '', 0, True, 'black', True)
                campo = field["campo"]      # Nombre del campo
                if CompGDBorig:
                    if featRT:
                        if featERR[campo] == 'MAL':
                            # Se detecta diferencia entre RT original y RT propuesta; se pone el texto rojo
                            styleDATA = self.estiloExcelCell('white', field["tipo"], '', 0, True, 'red', True)

                if campo in field_indices:  # Asegúramos que el campo existe
                    idx = field_indices[campo]      # Se obtiene el índice del campo
                    valueTD = attr[idx]     # Se accede al valor usando el índice
                else:
                    valueTD = ''            # Si el campo no existe, se asigna un valor por defecto ''

                if not valueTD:             # Si el valor es NULL, se asigna un valor por defecto ''
                    valueTD = ''
                try:
                    # Aseguramos que `row` y `col` se están gestionando correctamente
                    sheetWB.write(row, col, valueTD, styleDATA)  # Escribe en Excel
                except Exception as e:
                    print(f"Error escribiendo en Excel: {e}, fila {row}, columna {col}")
                col += 1                    # Incrementa la columna

            if IncCamposGDB:    # Datos en excel de GDB DGC
                for field in self.listaCamposData:  # Cada campo de la lista
                    styleDATA = self.estiloExcelCell('white', field["tipo"], '', 0, True, 'black', True)
                    campo = field["campo"]      # Nombre del campo
                    if campo in field_indices:  # Asegúrate de que el campo existe
                        idx = field_indices[campo]      # Obtén el índice del campo
                        valueTD = attr[idx]     # Accede al valor usando el índice
                    else:                       # Si el campo no existe, asigna un valor por defecto ''
                        valueTD = ''
                    if not valueTD:             # Si el valor es NULL, asigna un valor por defecto ''
                        valueTD = ''
                    try:
                        # Aseguramos que `row` y `col` se están gestionando correctamente
                        sheetWB.write(row, col, valueTD, styleDATA)  # Escribe en Excel
                    except Exception as e:
                        print(f"Error escribiendo en Excel: {e}, fila {row}, columna {col}")
                    col += 1                    # Incrementa la columna

            row += 1            # Incrementa la fila fuera del bucle de columnas


        # Guardamos el nuevo fichero si es posible
        try:
            wb.save(archivoXCL)
            os.startfile(archivoXCL)
            return ('OK')

        except:
            text = ' NO SE PUEDE ESCRIBIR POR ESTAR ABIERTA LA HOJA\n\n-%s-\n\n'%(archivoXCL)
            text+= '- Se debe cerrar para volver a grabar -'
            self.fun.showMessageERR(text)
            QApplication.restoreOverrideCursor()
            return ('ERROR EXCEL')

        QApplication.restoreOverrideCursor()


    def estiloExcelCell(self, colorFORE, tipoDATA, tipoFONT, sizeFONT, bordes = False, colorFONT = 'black', ajuste = False):
        '''
        Generador de estilos para una excel
        https://github.com/python-excel/xlwt/blob/master/xlwt/Style.py
        '''
        # colorFORE : Color de fondo
        # tipoDATA  : Alineación de texto text, justified = justified, double,int = right,
        # tipoFONT  : bold
        # sizeFONT  : Valor entero
        # bordes    : DEFAULT False = sin bordes
        # colorFONT : DEFAULT 'black'
        # ajuste    : DEFAULT False = Sin ajustar dentro de la celda

        if tipoFONT == 'bold':
            tipoFONTbold = 'bold 1'
        else:
            tipoFONTbold = 'bold 0'

        if sizeFONT != 0:
            tipoFONTbold += ',height %s'%(str(sizeFONT))

        if tipoDATA == 'right' or tipoDATA == 'double' or tipoDATA == 'int':
            alignFONT = 'right'
        elif tipoDATA == 'text' or tipoDATA == 'justified':
            alignFONT = 'justified'
        elif tipoDATA == 'center':
            alignFONT = 'center'
        else:
            alignFONT = 'left'     # left, center, right, filled, justified ...

        if ajuste:
            styleCELL = xlwt.easyxf('font: %s, color %s; align: horiz %s; align: vert top; alignment: wrap on'%(tipoFONTbold, colorFONT, alignFONT))
        else:
            styleCELL = xlwt.easyxf('font: %s, color %s; align: horiz %s; align: vert top'%(tipoFONTbold, colorFONT, alignFONT))

        pattern = xlwt.Pattern()
        pattern.pattern = xlwt.Pattern.SOLID_PATTERN
        pattern.pattern_fore_colour = xlwt.Style.colour_map[colorFORE]
        styleCELL.pattern = pattern

        if bordes == True:
            borders = xlwt.Borders()
            borders.left = xlwt.Borders.THIN
            borders.right = xlwt.Borders.THIN
            borders.top = xlwt.Borders.THIN
            borders.bottom = xlwt.Borders.THIN
            styleCELL.borders = borders

        return styleCELL


    def CompRTorigRTdest(self, feat, capaRT):
        """
        Compara un QgsFeature con una capa y devuelve un diccionario con las diferencias y el elemento encontrado.

        Args:
            feat (QgsFeature): Elemento a comparar.
            capaRT (QgsVectorLayer): Capa original con datos RT.

        Returns:
            tuple:
                - featERR (dict): Diccionario con los nombres de los campos y su comparación ('OK' o 'MAL').
                - featRT (QgsFeature or None): Elemento encontrado en capaRT o None si no se encuentra.
        """
        # Inicializar el diccionario de errores
        featERR = {}
        featRT = None

        # Obtener el valor de 'id_vial' del elemento feat
        id_vial = feat['id_vial']

        # Crear una expresión para buscar en capaRT
        expression = QgsExpression(f'"id_vial" = \'{id_vial}\'')
        request = QgsFeatureRequest(expression)

        # Buscar el elemento en capaRT
        featuresRT = list(capaRT.getFeatures(request))

        # Verificar si se encontró un elemento
        if len(featuresRT) >= 1:
            featRT = featuresRT[0]

            # Comparar los campos de feat con los de featRT
            for field_name in feat.fields().names():
                if field_name in featRT.fields().names():
                    # Comparar valores
                    if feat[field_name] == featRT[field_name]:
                        featERR[field_name] = 'OK'
                    else:
                        featERR[field_name] = 'MAL'
                else:
                    featERR[field_name] = 'NO_EXISTE_EN_RT'
        else:
            # Si no se encuentra ningún elemento, todos los campos de feat están marcados como 'NO_EXISTE_EN_RT'
            for field_name in feat.fields().names():
                featERR[field_name] = 'NO_EXISTE_EN_RT'

        return featERR, featRT


    def CargaCtraCartociudad(self, nombre, capaCartoc):
        #   Busca en la web de cartociudad una cerretera por el valor 'nombre'
        #
        # ARGUMENTOS
        #   nombre, (string) MATRICULA DE CARRETREA A BUSCAR EN CARTOCIUDAD
        #   capaCartoc, (Qgslayer) CAPA DONDE SE CARGA EL ELEMENTO
        listDIRECCION, lstCANDIDATOS_DIRECC = self.cartoc.getDireccionCARTOCIUDAD(nombre)
        # print ('Ctra. Buscada: ', nombre)
        # print('listDIRECCION: ', listDIRECCION, 'lstCANDIDATOS_DIRECC: ', lstCANDIDATOS_DIRECC)
        
        tipoList = ['carretera', 'callejero']  # Separamos las carreteras o calles localizadas con ese 'nombre'
        carreteras = [d for d in listDIRECCION if isinstance(d, dict) and d.get('type') in tipoList]
        # print ('Carreteras LOC:')
        # print (carreteras)
        
        # Cargar el elemento en la capaCartoc
        for carretera in carreteras:
            address = carretera['address']
            id = carretera['id']
            tipo = carretera['type']
            portalNumber = carretera['portalNumber']

            # Expresión para buscar el id en el campo 'id_vial'
            expression = QgsExpression(f'"id_vial" = \'{id}\'')
            
            # Solicitar los features que cumplan con la expresión
            request = QgsFeatureRequest(expression)
            feature = next(self.layerRT.getFeatures(request), None)  # Obtiene el primer elemento que cumpla la condición
            
            if feature is None:
                geomDIRECCION, atributosDICT = self.cartoc.IrURLDireccionCARTOCIUDAD(address, id, tipo, portalNumber)
                # print (atributosDICT)
                self.cartoc.zoomCreaGeometry(self.iface, address, geomDIRECCION, atributosDICT, capaCartoc, Nomark='NO', zoomGeom = False, cargaTodo = True)
                
        # Análisis del dato localizado
        resCartociudad = ''
        if listDIRECCION == 'error':
            resCartociudad = f'No se localiza {nombre} en cartociudad'
        
        return resCartociudad
        

