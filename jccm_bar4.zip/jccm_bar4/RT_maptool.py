# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           RT_maptool.py
Purpose:
    RT_maptool.py basada en PK_maptool.py
                                 A QGIS4 plugin
    --------------------------------------------------------------------
        begin                : 2019-09-03
        validacion transfQG4 : 2026-10-20
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import QIcon, QColor, QCursor
from qgis.PyQt.QtCore import QVariant, Qt, QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtWidgets import (QAction, QApplication, QWidget, QPushButton, QMessageBox, QToolButton, QMenu, QListView, 
                        QFileDialog, QDialog)

from qgis.PyQt import QtGui, QtCore, uic

from qgis.gui import QgsMapTool,QgsVertexMarker
from qgis.core import (QgsProject, QgsVectorLayer, QgsField, QgsFeature, QgsGeometry, QgsExpression, QgsFeatureRequest, 
                        QgsCoordinateReferenceSystem, QgsFeedback, QgsRectangle)

from qgis.utils import iface

import os, glob, io, codecs
from osgeo import gdal, osr, ogr
import time

import xml.etree.ElementTree as ET

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
# from .PK_info_panel import info_panel


QT_VERSION=5
os.environ['QT_API'] = 'pyqt5'


nombre_plugin = os.path.basename(os.path.dirname(__file__))
# VARIABLES
srcVal = QSettings().value(f"{nombre_plugin}/GENERAL/EPSG")
if srcVal is None:
    srcVal = configuration.general['EPSG']
    QSettings().setValue(f"{nombre_plugin}/GENERAL/EPSG", srcVal)

# Obtener el sistema de referencia espacial
srs = QgsCoordinateReferenceSystem(srcVal)
#######################################################
######     TODO VER TEMA SRC       ####################
# Establecer el SRS en el lienzo del mapa
# iface.mapCanvas().setDestinationCrs(srs)
#######################################################


dest_path = 'en memoria'


class IdCtraRtTool(QgsMapTool):
    '''
    # Herramienta para identificar el dato en RT mediante un punto pinchado en la vista
    '''

    def __init__(self,canvas,iface,action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.fun = Functions()
        self.qs = QSettings()

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        cursor = QCursor()
        cursor.setShape(Qt.CursorShape.CrossCursor)
        iface.mapCanvas().setCursor(cursor)

        QApplication.restoreOverrideCursor()

       
        self.iface = iface
        self.setAction(action)
        self.action = action

        self.urlWmsRT = 'https://servicios.idee.es/wms-inspire/transportes?'
        self.urlWmsRTLayer='TN.RoadTransportNetwork.RoadLink'
        self.listWmsRTLayer=['TN.RoadTransportNetwork.RoadLink',
                             'TN.RailTransportNetwork.RailwayLink',
                             'TN.AirTransportNetwork.RunwayArea',
                             'TN.AirTransportNetwork.TaxiwayArea',
                             'TN.AirTransportNetwork.ApronArea',
                             'TN.RoadTransportNetwork.RoadServiceArea',
                             'TN.RailTransportNetwork.RailwayStationArea',
                             'TN.AirTransportNetwork.AerodromeArea',
                             'TN.WaterTransportNetwork.PortArea'
                             ]
        

    def canvasReleaseEvent(self, event):
        #Get the click
        x = event.pos().x()
        y = event.pos().y()

        # srs =  self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        # print ('Punto pinchado: ', point )
        # print ('srs = ',srs)
        self.getPointRT(point,self.iface)
        

    def getPointRT(self, point, iface):
        # Obtener datos del elemento pinchado en la GDB

        pintar='NO'
        tipo = 'text/xml'
        for urlWmsRTLayer in self.listWmsRTLayer:
            result = self.fun.WMSgetFeatureInfo(point, iface, pintar, self.urlWmsRT, tipo, urlWmsRTLayer)
            print (result)
            if not result:
                txt = f'En esta posición no se encuentra nada en {urlWmsRTLayer}'
                self.fun.showJCCMessage(txt)
            else:
                break

        def parse_xml_to_dict(xml_content):
            """
            Convierte un XML en un diccionario.
            :param xml_content: str, contenido XML en formato string.
            :return: dict, diccionario con los datos del XML.
            """
            tree = ET.ElementTree(ET.fromstring(xml_content))
            root = tree.getroot()

            def element_to_dict(element):
                """
                Convierte un elemento XML y sus hijos en un diccionario.
                """
                return {
                    child.tag: element_to_dict(child) if list(child) else child.text
                    for child in element
                }

            return element_to_dict(root)

        result_dict = parse_xml_to_dict(result[1])

        xml_data = result[1]

        # Parsear el XML
        tree = ET.fromstring(xml_data)

        # Lista de claves deseadas sin prefijo en dato RT
        desired_keys = [
            'id_unique', 'id_tramo', 'id_vial', 'rotulo', 'tipo_viald', 'clased',
            'ordend', 'titulard', 'tipo_tramod', 'calzadad', 'accesod', 'firmed',
            'ncarrilesd', 'sentidod', 'situaciond', 'estadofisd', 'tipovehicd',
            'geometry',
        ]

        # Lista para almacenar los resultados
        features_list = []

        # Iterar sobre cada featureMember
        listFeatureCombo = []
        for feature_member in tree.findall('.//{*}featureMember'):
            feature_dict = {}
            for key in desired_keys:
                # Buscar las subclaves dentro de featureMember
                element = feature_member.find(f'.//{{*}}{key}')
                if element is not None:
                    feature_dict[key] = element.text
                else:
                    feature_dict[key] = None  # Si no existe, lo dejamos como None
            f_rotulo = feature_dict['rotulo']
            f_tipo_viald = feature_dict['tipo_viald']
            f_tipo_tramod = feature_dict['tipo_tramod']
            textLista = f'{f_rotulo}  {f_tipo_viald}  {f_tipo_tramod}'
            listFeatureCombo.append(textLista)
            
            # 'id_unique': '20030138479608000000284', 
            # 'id_tramo': '20030138479', 
            # 'id_vial': '608000000284', 
            # 'rotulo': 'CM-3203', 
            # 'tipo_viald': 'Carretera', 
            # 'clased': 'Carretera convencional', 
            # 'ordend': 'Segundo orden', 
            # 'titulard': 'Comunidad Autónoma', 
            # 'tipo_tramod': 'Troncal', 
            # 'calzadad': 'Duplicada o superior', 
            # 'accesod': 'Libre', 
            # 'firmed': 'Pavimentado', 
            # 'ncarrilesd': '2', 
            # 'sentidod': 'Único', 
            # 'situaciond': 'En superficie', 
            # 'estadofisd': 'En servicio', 
            # 'tipovehicd': 'Peatón+bici+vehículo', 
            # '{http://192.168.192.39:8080/geoserver/geoserver/transportes}
            # geometry': LineString': {'{http://www.opengis.net/gml}
            # coordinates': '597564.85575002,4313908.26880028 597570.95814424,4313990.67427626'}}}
            
            # Añadir el diccionario del feature a la lista
            features_list.append(feature_dict)

        # Mostrar resultados en ventana
        ####  TODO ESTO ES PROVISIONAL Y SE DEBE QUITAR  ####
        text = 'ELEMENTO SELECCIONADO\n\n'
        for carreteraRT in features_list:
            # print("carreteraRT:")
            for key, value in carreteraRT.items():  # Usar .items() para iterar sobre clave y valor
                text += f"  {key}: {value}\n"

            # self.fun.showJCCMessage('DATOS RT', text)
        ####  TODO ESTO ES PROVISIONAL Y SE DEBE QUITAR  ####
        
        # Mostrar resultados en menú con selector
        if len(listFeatureCombo) >0:
            self.RT_info = Form_RT_info(self, self.iface.mapCanvas(), features_list, listFeatureCombo)
            
            # Se arranca el menu
            result = self.RT_info.exec()
        else:
            text = 'PULSA MÁS CERCA DE UN VIAL (Carretera, calle, camino, etc.)'
            self.fun.showMessageERR(u'CONSULTA INFORMACIÓN VIALES RT (RED de TRANSPORTES IGN)', text)

        return



FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/RT_info.ui'))

class Form_RT_info(QDialog, FORM_CLASS):
    def __init__(self, canvas, iface, features_list, listFeatureCombo, parent=None):
        super(Form_RT_info, self).__init__(parent)
        # super(Form_PK_info(geometria), self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.fun = Functions()
        self.qs = QSettings()

        carreteraRT = features_list[0]
        self.current_configuration = configuration()
        geometry = carreteraRT['geometry']
        # atributos = carretera_pk[4]
        ctra = carreteraRT['rotulo']

        self.setFixedSize(540, 265)
        self.setWindowIcon(QIcon(':/plugins/jccm_bar4/iconos/IGN_RT.jpg'))

        self.botonDcha = 'R'
        self.botonAbajo = 'D'
        self.pkProx = 0
        self.intervalo = 10.00

        self.lbl_PK.hide()          ####  TODO INHABILITADAS  ####
        self.pk_pinchado.hide()
        
        # Botones de acciones       ####  TODO INHABILITADAS  ####
        self.btnAbrirDcha.hide()
        self.btnVerCota.hide()
        self.btnDescargaEje.hide()
        self.btnLISTCOORD.hide()
        self.btnAbrirAbajo.hide()

        # Se añaden valores al Combo slectro de la via
        self.cbxSELECT_VIA.clear()
        self.cbxSELECT_VIA.addItems(listFeatureCombo)
        self.cbxSELECT_VIA.setCurrentIndex(0)
        
        # Control de cambio de  Combo slectro de la via
        self.cbxSELECT_VIA.currentIndexChanged.connect(lambda: self.actualizaMenu(features_list))

        # Se asignan valores al menú
        self.setDataMenu(carreteraRT)
        

    def actualizaMenu(self, features_list):
        # Al seleccionar otro item del combo desplegabe, se actualizan los datos del Menú
        
        idx = self.cbxSELECT_VIA.currentIndex()
        # self.cbxSELECT_VIA.setCurrentIndex(idx)
        carreteraRT = features_list[idx]
        self.setDataMenu(carreteraRT)
        pass


    def setDataMenu(self, carreteraRT):
        # Se actualizan los datos del Menú
        
        # Se colocan los distintos labels del menu
        self.lbl_numFenomenos.setText(f'({self.cbxSELECT_VIA.count()} items)')
        self.lblFuenteDatos.setText('Fuente:  WMS RT')
        
        # Se colocan los atributos
        if carreteraRT['rotulo']:
            self.txt_rotulo.setText(carreteraRT['rotulo'])
        else:
            self.txt_rotulo.setText('Sin Nombre')
        self.txt_id_unique.setText(carreteraRT['id_unique'])
        self.txt_id_tramo.setText(carreteraRT['id_tramo'])
        self.txt_id_vial.setText(carreteraRT['id_vial'])
        self.txt_tipo_viald.setText(carreteraRT['tipo_viald'])

        self.txt_titulard.setText(carreteraRT['titulard'])
        self.txt_ordend.setText(carreteraRT['ordend'])
        self.txt_clased.setText(carreteraRT['clased'])
        self.txt_tipo_tramod.setText(carreteraRT['tipo_tramod'])
        self.txt_calzadad.setText(carreteraRT['calzadad'])
        self.txt_accesod.setText(carreteraRT['accesod'])
        self.txt_tipovehicd.setText(carreteraRT['tipovehicd'])

        self.txt_firmed.setText(carreteraRT['firmed'])
        self.txt_ncarrilesd.setText(carreteraRT['ncarrilesd'])
        self.txt_sentidod.setText(carreteraRT['sentidod'])
        self.txt_situaciond.setText(carreteraRT['situaciond'])
        self.txt_estadofisd.setText(carreteraRT['estadofisd'])
        
        '''
        'id_unique': '20030138479608000000284', 
        'id_tramo': '20030138479', 
        'id_vial': '608000000284', 
        'rotulo': 'CM-3203', 
        'tipo_viald': 'Carretera', 
        'clased': 'Carretera convencional', 
        'ordend': 'Segundo orden', 
        'titulard': 'Comunidad Autónoma', 
        'tipo_tramod': 'Troncal', 
        'calzadad': 'Duplicada o superior', 
        'accesod': 'Libre', 
        'firmed': 'Pavimentado', 
        'ncarrilesd': '2', 
        'sentidod': 'Único', 
        'situaciond': 'En superficie', 
        'estadofisd': 'En servicio', 
        'tipovehicd': 'Peatón+bici+vehículo', 
        '{http://192.168.192.39:8080/geoserver/geoserver/transportes}
        geometry': LineString': {'{http://www.opengis.net/gml}
        coordinates': '597564.85575002,4313908.26880028 597570.95814424,4313990.67427626'}}}
        '''
        

        # COLORES CARRETERAS
        color_morado  = '255,0,255'
        color_naranja = '255,127,0'
        color_verde   = '0,255,0'
        color_amarillo= '255,255,0'
        color_blanco  = '255,255,255'
        color_azul  = '1,103,200'
        color_rojo  = '255,50,50'
        color_negro = '0,0,0'

        # COLORES CAMPO RÓTULO SEGÚN ORDEN Y CLASE
        colorF = color_blanco
        colorT = color_negro
        if carreteraRT['titulard'] == 'Comunidad Autónoma' and carreteraRT['ordend'] == 'Principal' :
            colorF = color_morado
            colorT = color_blanco
        elif carreteraRT['titulard'] == 'Comunidad Autónoma' and carreteraRT['ordend'] == 'Primer orden' :
            colorF = color_naranja
            colorT = color_negro
        elif carreteraRT['titulard'] == 'Comunidad Autónoma' and carreteraRT['ordend'] == 'Segundo orden' :
            colorF = color_verde
            colorT = color_negro
        elif carreteraRT['titulard'] == 'Comunidad Autónoma' and carreteraRT['ordend'] == 'Tercer orden' :
            colorF = color_amarillo
            colorT = color_negro
        elif carreteraRT['titulard'] == 'Administración General del Estado' and carreteraRT['clased'] == 'Autopista libre / autovía' :
            colorF = color_azul
            colorT = color_blanco
        elif carreteraRT['titulard'] == 'Administración General del Estado' and carreteraRT['clased'] == 'Carretera convencional' :
            colorF = color_rojo
            colorT = color_blanco
        else:
            colorF = color_blanco
            colorT = color_negro
            
        self.txt_rotulo.setStyleSheet("background: rgb(" +colorF+ " );border: 2px solid black ; color: rgb(" +colorT+ " );border-radius:7px;")
        
        # COLORES CAMPO TITULAR
        colorF = color_blanco
        colorT = color_negro
        if carreteraRT['titulard'] == 'Comunidad Autónoma':
            colorF = color_morado
            colorT = color_negro
        elif carreteraRT['titulard'] == 'Administración General del Estado':
            colorF = color_azul
            colorT = color_blanco
        elif carreteraRT['titulard'] == 'Diputación Provincial':
            colorF = color_amarillo
            colorT = color_negro
        else:
            colorF = color_blanco
            colorT = color_negro
        # self.txt_titulard.setStyleSheet("background: rgb(" +colorF+ " );border: 2px solid black ; color: rgb(" +colorT+ " );border-radius:7px;")
        self.txt_titulard.setStyleSheet("background: rgb(" +colorF+ " );border: 2px solid black ; color: rgb(" +colorT+ " )")


    # def botonAmpliarAbajo(self):
        # XE =  float(self.XE.text())
        # YE =  float(self.YE.text())

        # if self.botonAbajo == 'D':
            # # self.setHistoricoCTRA(XE, YE)
            # self.setFixedSize(540, 400)
            # self.btnAbrirAbajo.setArrowType(Qt.ArrowType.UpArrow)
            # self.botonAbajo = 'U'
        # elif self.botonAbajo == 'U':
            # self.setFixedSize(540, 170)
            # self.btnAbrirAbajo.setArrowType(QtCore.Qt.ArrowType.DownArrow)
            # self.botonAbajo = 'D'
            # # self.btnAbrirDcha.setArrowType(QtCore.Qt.ArrowType.RightArrow)
            # # self.botonDcha = 'R'


    # def botonLISTCOORD(self, geometry):
        # self.txbLISTGEOM.setHtml(self.fun.makeHtmlListCoord(geometry))
        # self.setFixedSize(860, 400)
        # self.btnAbrirAbajo.setArrowType(Qt.ArrowType.UpArrow)
        # self.botonAbajo = 'U'


    # def botonGuardaCSV(self, geometry, ctra):
        # nom_fich_csv = u"C:/temp/" + ctra.replace('-','')+'_geom'
        # ext = "*.csv"
        # dirfile, tipofile = QFileDialog.getSaveFileName(self, "Fichero CSV de salida", nom_fich_csv, ext)
        # if dirfile == None or dirfile == "":
            # dirfile = nom_fich_csv
            # self.fun.showJCCMessage(u"No se guarda el fichero CSV")
            # return
        # # Comprobamos que existe el directorio y si no se crea
        # if not os.path.exists(os.path.dirname(dirfile)):
            # os.makedirs(os.path.dirname(dirfile))

        # target  = open(dirfile, 'w+',encoding='utf-8')
        # if self.chkGuardarM.isChecked():
            # encabezado = u'"num";"x";"y";"pk";"dif"'
        # else:
            # encabezado = u'"num";"x";"y";"pk"'

        # target.write(encabezado+"\n")

        # paths = geometry["paths"]
        # listCoord =''
        # punto = 1
        # pathNum=1
        # Mant = None
        # for path in paths:
            # datoPath = 'TRAMO %s/%s (%s puntos)\n'%(str(pathNum),len(paths),len(path))
            # target.write(datoPath)
            # for point in path:
                # if point[2] is not None:
                    # if Mant is not None:
                        # if self.chkGuardarM.isChecked():
                            # listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+','+" %0.5f"%(point[2]-Mant)+'\n'
                        # else:
                            # listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+'\n'
                        # target.write(listCoord)
                    # else:
                        # if self.chkGuardarM.isChecked():
                            # listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+', 0.0'+'\n'
                        # else:
                            # listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+'\n'

                        # target.write(listCoord)
                    # Mant = point[2]
                # else:
                    # listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" None"+'\n'
                    # target.write(listCoord)
                # punto += 1
            # pathNum +=1

        # target.close()
        # textInfo = u"GUARDADO CSV\n\n"+dirfile
        # self.fun.showJCCMessage(textInfo)

    # def botonGuardaSHP(self, geometry):
        # self.fun.showJCCMessage(u"GUARDAMOS UN SHP")
        # pass

    # def botonVerCota(self):
        # # Zmdt = self.fun.Zmdt((float(self.XE),float(self.YE)), self.iface, pintar='NO')
        # XE = float(self.XE.text())
        # YE = float(self.YE.text())
        # Zmdt = self.fun.Zmdt((XE,YE), self.iface, pintar='NO')
        # # self.cotaEje.setText(str(round(Zmdt,3)))
        # # self.ZE.setText(str(round(Zmdt,3)))
        # if Zmdt == 'Error':
            # self.cotaEje.setText('Error')
            # self.ZE.setText('Error')
        # else:
            # self.cotaEje.setText(str(round(Zmdt,3)))
            # self.ZE.setText(str(round(Zmdt,3)))


    # def botonDescargaEje(self):
        # # Descarga de EJE pinchado
        # from .herrCTRAS_descargas import herrCTRAS_descargas
        
        # QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        
        # herrCTRAS_descargas = herrCTRAS_descargas(self.iface)
        # valcbxTitularidad = '%'
        # valcbxFuncionalidad = '%'
        # valcbxProvincia = '%'
        # valcbxMatricula = self.Matricula_plan.text()
        # valMatr9000 = True
        # SOLO2D = False 
        # messLblINFO = False
        # NOMcapa = u'CTRA %s EJE'%(valcbxMatricula)
        # fichEstilo = '/Carreteras_CLM_WFS.qml'
        # estiloCAPA = os.path.join(os.path.dirname(__file__), self.current_configuration.general["carpeta_estilos"] + fichEstilo)
        # # nomFich = u'C:/TEMP/%s_EJE.gpkg'%(valcbxMatricula)
        # nomFich = u'C:/TEMP/%s.gpkg'%(valcbxMatricula)
        # nomLayerPKS = u'CTRA %s PKS'%(valcbxMatricula)
        # fichEstiloPKS = '/GEO_PKS_WFS.qml'
        # nomFichPKS = 'C:/TEMP/%s_PKS.gpkg'%(valcbxMatricula)
        # estiloCAPAPKS = os.path.join(os.path.dirname(__file__), self.current_configuration.general["carpeta_estilos"] + fichEstiloPKS)

        # # Descargamos el eje
        # layerEJES2D = herrCTRAS_descargas.lecturaEJES(valcbxTitularidad, valcbxFuncionalidad,
                        # valcbxProvincia, valcbxMatricula, valMatr9000, SOLO2D,
                        # messLblINFO, NOMcapa, estiloCAPA, nomFich)

        # # ## TODO priueba de ver si carga la M del eje
        # # QgsProject.instance().addMapLayer(layerEJES2D) 
        # # print ('AQUI SE CARGA LA CAPA PREVIAMENTE')
        # # ## TODO priueba de ver si carga la M del eje

        # # Escribimos en un fichero GPKG los ejes
        # self.fun.cargaGPKGjson(layerEJES2D, nomFich, NOMcapa, NOMcapa, estiloCAPA, cargaVISTA=True)

        # # Descargamos los Pks
        # layerPKS = herrCTRAS_descargas.lecturaPKS(valcbxProvincia, valcbxMatricula,
                        # messLblINFO, nomLayerPKS, nomFichPKS, estiloCAPAPKS)
                        # # messLblINFO, nomLayerPKS, nomFich, estiloCAPAPKS)
                        
        # # Escribimos en un fichero GPKG los pks
        # self.fun.cargaGPKGjson(layerPKS, nomFichPKS, nomLayerPKS, nomLayerPKS, estiloCAPAPKS, cargaVISTA=True)
        # # self.fun.cargaGPKGjson(layerPKS, nomFich, nomLayerPKS, nomLayerPKS, estiloCAPAPKS, cargaVISTA=True)


        # QApplication.restoreOverrideCursor()
        # text = u'FINALIZADA DESCARGA EJE %s'%(valcbxMatricula)
        # self.fun.showJCCMessage(text)
        
        # return


    # def cancel(self):
        # self.reject()


    # def setLabelColors(window, base):
        # t = '<property name="palette"><palette><active>'
        # t+= '<colorrole role="Base">  <brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>255</green><blue>255</blue></color></brush></colorrole>'
        # t+= '<colorrole role="Window"><brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        # t+= '</active><inactive>'
        # t+= '<colorrole role="Base">  <brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>255</green><blue>255</blue></color></brush></colorrole>'
        # t+= '<colorrole role="Window"><brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        # t+= '</inactive><disabled>'
        # t+= '<colorrole role="Base">  <brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        # t+= '<colorrole role="Window"><brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        # t+= '</disabled></palette></property>'
        # return t

