# herrCalib_exportaCapaM.py
## 20/12/24

## COPIA CAPA CON M  V 1.07.03


from qgis.core import (QgsProject, QgsVectorLayer, QgsFeature, QgsVectorFileWriter, QgsCoordinateReferenceSystem, QgsWkbTypes,
                        QgsField)
from qgis.utils import iface
import os

from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES


class herrCalib_exportaCapaM():
    def __init__(self, iface, parent=None):

        self.fun = Functions()

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        capa_activa = iface.activeLayer()  # Obtener la capa activa correctamente

        try:
            self.exportaCapaM(capa_activa)
        except Exception as e:
            print(f"Error: {e}")

        
    def exportaCapaM(self, capa_activa):
        """ Exporta la capa activa de multipolilíneaM a un GeoPackage manteniendo los valores M y la carga en QGIS. """
        
        if not capa_activa:
            raise ValueError("No hay una capa activa seleccionada.")
        
        # Validar que la capa sea de tipo MultiLineStringM
        if QgsWkbTypes.hasM(capa_activa.wkbType()) == False:
            raise ValueError("La capa activa no es de tipo MultiLineStringM.")
        
        # Obtener el nombre de la capa activa
        nombre_capa = capa_activa.name()
        
        # Definir la ruta de exportación
        ruta_exportacion = os.path.join("C:\\TEMP", f"{nombre_capa}_copy.gpkg")
        nombre_capa_exportada = f"{nombre_capa}_copy"
        
        if os.path.exists(ruta_exportacion):
            os.remove(ruta_exportacion)  # Eliminar el archivo si ya existe para evitar errores
        
        # Crear la capa de destino con el mismo tipo de geometría y CRS
        crs = capa_activa.crs()
        tipo_geometria = QgsWkbTypes.displayString(QgsWkbTypes.multiType(capa_activa.wkbType()))
        
        capa_destino = QgsVectorLayer(f"MultiLineStringM?crs={crs.authid()}", nombre_capa_exportada, "memory")
        if not capa_destino.isValid():
            raise ValueError("No se pudo crear la capa de destino en memoria.")

        # Agregar los mismos campos que la capa original
        
        # Copiar campos respetando el formato original
        fields_originales = [QgsField(field.name(), field.type(), field.typeName(), field.length(), field.precision()) for field in capa_activa.fields()]
        capa_destino.dataProvider().addAttributes(fields_originales)
        capa_destino.updateFields()

        capa_destino.updateFields()

        #############    TODO BORRAR    #############
        # print ('-CAMPOS DESTINO-')
        # for campoDestino in capa_activa.fields():
            # print (campoDestino.name())
        #############    TODO BORRAR    #############
        
        # Copiar las entidades de la capa original a la capa de destino
        total_features = capa_activa.featureCount()
        
        for i, feature in enumerate(capa_activa.getFeatures()):
            nueva_geometria = feature.geometry()
            nueva_feature = QgsFeature(feature)
            nueva_feature.setGeometry(nueva_geometria)
            capa_destino.dataProvider().addFeature(nueva_feature)
            
            # Mostrar progreso en la barra de estado de QGIS
            porcentaje = int((i + 1) / total_features * 100)
            iface.mainWindow().statusBar().showMessage(f"Exportando capa {nombre_capa}... {porcentaje}% completado")
        
        # Guardar la capa de destino en un GeoPackage
        ### TODO revisar campos con mayusculas ###
        error = QgsVectorFileWriter.writeAsVectorFormat(
            capa_destino, 
            ruta_exportacion, 
            "GPKG", 
            crs, 
            layerOptions=["GEOMETRY_NAME=geometry", "CREATE_IF_NEEDED=YES", "LAUNDER=YES"]
        )
        iface.mainWindow().statusBar().showMessage("Exportación completada con éxito.")

        capa_exportada = QgsVectorLayer(ruta_exportacion, nombre_capa_exportada, "ogr")
        if capa_exportada.isValid():
            QgsProject.instance().addMapLayer(capa_exportada)
            text = "Capa Exportada y cargada con M"
            iface.mainWindow().statusBar().showMessage(text)
            self.fun.showMessage(text,text2="",tittle="JCCM",)

        else:
            raise ValueError("No se pudo cargar la capa exportada en QGIS.")
