'''
# MACRO_INICIO.py
### QGIS 3.34 Plugin jccm_bar4 2.07

MACRO PARA AUTOINSTALACIÓN DE PLUGIN
'''

from qgis.core import QgsProject, QgsApplication, Qgis
from qgis.utils import qgsfunction, reloadPlugin, iface
from qgis.gui import QgsMessageBar

from qgis.PyQt.QtWidgets import QMessageBox
 
import os, zipfile, io
import configparser
from xml.etree import ElementTree as ET 
from time import gmtime, localtime, strftime

dirOS = os.getcwd()
Proj = QgsProject.instance().fileName()
uniProj = Proj[:2]
uniRepo= u'Z:'
listUnd = ['z:', 'u:', 'c:']
dirRepo = u'/cartografia/datos_Q/INSTALACION SIG_CLM_QGIS/jccm_bar4/'
FichRepo = dirRepo + u'jccmctrasrepo.xml'

def openProject():
    # Datos plugin carreteras
    pluginCTRAS = u'python/plugins/jccm_bar4/metadata.txt'
    # fichREPOJCCM = uniProj + FichRepo

    # La rutina permite buscar el fichero 'fichREPOJCCM' en las diferentes unidades 'listUnd' en el orden de la lista de unidadesº
    FileNotFind = True
    it =0
    while FileNotFind and it < len(listUnd):
        uniRepo = listUnd[it]
        path = uniRepo + FichRepo
        result = os.path.exists(path)
        if result == True:
            FileNotFind = False
            print (it, ' ENCONTRADO : ', path)
            fichREPOJCCM = uniRepo + FichRepo
            break
        print (it, ' No se encuentra : ', path)
        it += 1
    if FileNotFind == True:
        print (u'NO EXISTE REPOSITORIO\n'+ fichREPOJCCM+ '\n    en  z:, u:, c:')
        fichREPOJCCM = uniRepo + FichRepo
        

    # Obtención de datos del Plugin 'JCCM Carreteras' instalado
    dirPYTJCCM = QgsApplication.qgisSettingsDirPath()
    fichPYTJCCM = os.path.normpath(os.path.join(os.path.dirname(dirPYTJCCM), pluginCTRAS))
    cfg = configparser.ConfigParser()
    cfg.read(fichPYTJCCM)
    version = cfg.get('general', 'version')
    fechaPlugin = strftime("%d %b %Y %H:%M ", localtime(os.path.getmtime(fichPYTJCCM)))
    print ('Plugin actual: '+version + ' - '+fechaPlugin)


    # Obtención de datos del Plugin 'JCCM Carreteras' en repositorio
    versionREPO = u's/d'
    fechaPluginREPO = u'Sin Repositorio'
    if os.path.exists(fichREPOJCCM):
        with open(fichREPOJCCM, 'r') as f:
            tree  = ET.parse(f)
            for elem in tree.findall('pyqgis_plugin'):
                if elem.attrib["name"] == u'JCCM Carreteras':
                    versionREPO = elem.attrib["version"].lower()
                    fechaPluginREPO = strftime("%d %b %Y %H:%M ", localtime(os.path.getmtime(fichREPOJCCM)))
        print ('Plugin en Repo: '+versionREPO + ' - '+fechaPluginREPO)


    # Se actualiza el plugin si es necesario
    print ('ACTUALIZAMOS versionREPO='+versionREPO, 'version='+version)
    if (versionREPO != u's/d' and float(versionREPO) > float(version)):
        plugin = 'jccm_bar4'
        zip_dir = uniRepo + dirRepo
        zip_file_base = 'jccm_bar4.zip'
        zip_file = zip_dir+zip_file_base
        dest = dirPYTJCCM + u'python/plugins/'
        if not os.path.exists(dest):
            os.makedirs(dest)
        zf = zipfile.ZipFile(zip_file)
        zf.extractall(dest)
        reloadPlugin(plugin)
        
        text = u'- SIG REGIONAL DE CARRETERAS -' + '\n' + u'Actualizada Versión- '+ versionREPO +' ('+fechaPluginREPO+')'

    else:
        text = u'- SIG REGIONAL DE CARRETERAS -' + '\n' + u'Vers.  Instalada- '+ version +u' ('+fechaPlugin+u')'


    # Datos en Barra de Mensajes
    text2 = u''
    tittle = u'JCCM Carreteras'
    iface.messageBar().pushMessage(text, tittle,  level=Qgis.Info, duration=10)
        
        

def saveProject():
    pass

def closeProject():
    pass

@qgsfunction(args="auto", group='SIG_REG_CTRAS')
def quitapar(value1, feature, parent):
    
    pos1= value1.find('(', 0)
    pos2= value1.find(')', 0)
    if pos1==-1:
        result = value1
    else:
        result = value1[pos1+1: pos2] +" "+ value1[:pos1]
    return result
    
@qgsfunction(args="auto", group='SIG_REG_CTRAS')
def mostrarPK(val, num, factor, feature, parent):
    '''
    <h2>FUNCIÓN de presentación de un valor kilométrico (numero) KK.MMMmmm en formato (string) KK+MMM.mmm
       return texto</h2>
    <ul>
    <li>mostrarPK(val, num, factor)</li>
            <ul>
            <li>val = (DECIMAL) Valor numérico a convertir en PK</li>
            <li>num = (ENTERO) número de decimals del resultado de la fracción de PK</li>
            <li>factor = 1 caso de entrada en KM. / factor = 1000 caso de entrada en M. (ENTERO)</li>
            </ul>
    <li>EJEMPLO: mostrarPK('12345.678,2) --> '12+345.68'</li>
    </ul>
    
    Creada ASS (2021)
    '''
    if ((val != None) and (str(val) != 'nan')):
        km = int(val/factor)
        m = round((val/factor - km)*1000,num)
        texto = str(km) + "+" + "{:0{}.{}f}".format( m, 4+num, num )
        return texto
    else:
        return 'None'
    
@qgsfunction(args="auto", group='SIG_REG_CTRAS')
def geomGetLista(geometry, prec, feature, parent):
    """ 
    <h2>Función que permite listar un poligono ajustando los decimales de salida 
        geomGetLista(polygon, prec)</h2>
    <ul>
    <li>geomGetLista(geometry, prec)</li>
        <ul>
        <li>polygon = Polygono WKT</li>
        <li>prec = decimales de precisión (ENTERO)</li>
        </ul>
    <h2>Llamada en texto desde diseñador:
    geomGetLista(geometry( get_feature( [NOMBRE CAPA], [CAMPO],  [VALOR] )),[PRECISION])</h2>
    <li>EJEMPLO: geomGetLista(geometry( get_feature( 'Informes de Expropiaciones', 'EX_NUM',  @VAR_INFEXPR )),2)</li>
    </ul>
    
    Creada ASS (2021)
    """

    cadena =''
    if geometry.isMultipart():
        polygon = geometry.asMultiPolygon()
        for listPartes in polygon:
            cadena += 'Poligono '+str(polygon.index(listPartes)+1)+'\n'
            for parte in listPartes:
                i=1
                for pto in parte:
                    cadena += " ".join([str(i),' - ',u'{:.{}f}'.format(pto[0], prec),' - ',u'{:.{}f}'.format(pto[1], prec),'\n'])
                    i += 1
            cadena += '\n'
    else:
        polygon = geometry.asPolygon()
        for parte in polygon:
            i=1
            for pto in parte:
                cadena += " ".join([str(i),' - ',u'{:.{}f}'.format(pto[0], prec),' - ',u'{:.{}f}'.format(pto[1], prec),'\n'])
                i += 1
    return cadena