# -*- coding: utf-8 -*-
"""
/***************************************************************************
 herrCTRAS_descargasAPI_RT
                                 A QGIS4 plugin
                             -------------------
        begin                : 2024-12-24
        git sha              : $Format:%H$
        copyright            : (C) 2016 by ASS
        email                : asolabre@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.
 *
 *   Based in 'Quick Export' pluggin
 *                                                                         *
 ***************************************************************************/

 EN PRUEBAS (TODO)
 ----------
 - BORRAR CONTROL DE BUCLE
 - Habría que compobar si las capas del GRUPO APIREST existen dentro
 - REVISAR widgets inactivos e inexistentes del MENU
 - SOLO FUNCIONA LA DESCARGA PARA EJES
 - Desaparecerán los combos de selección de PROVINCIA, FUNCIONALIDAD, TITULARIDAD y MATRICULA

"""

from qgis.PyQt.QtGui import QIcon, QPixmap
from qgis.PyQt.QtCore import QSettings, QCoreApplication, QTranslator, qVersion, Qt
from qgis.PyQt.QtWidgets import QApplication, QMessageBox, QToolButton, QMenu, QAction, QDialog, QCheckBox, QFileDialog
from qgis.PyQt import uic

from qgis.gui import QgsMessageBar
from qgis.core import (QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsApplication, QgsFeature,
                        QgsGeometry, QgsVectorFileWriter, QgsVectorDataProvider, QgsLayerDefinition, QgsLayerTreeGroup,
                        QgsWkbTypes, QgsField, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsCoordinateTransformContext)

from qgis.utils import iface
from qgis.PyQt.QtPrintSupport import QPrinter

from qgis import processing

import os
from osgeo import ogr, osr
import urllib
import json
from time import sleep
import glob, codecs
from functools import partial
import shutil
import datetime
import locale
import tempfile
import sys
import subprocess
import csv
import timeit
import io
import configparser


from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .settings import Settings           # CLASE DE CONFIGURACIÓN DE VARIABLES GLOBALES
conf = configuration()
conf = configuration()


# VARIABLES
srcVal = conf.general["EPSG"]
conf = configuration()

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrCTRAS_descargasAPI_RT.ui'))


class herrCTRAS_descargasAPI_RT(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(herrCTRAS_descargasAPI_RT, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface;
        self.fun = Functions()
        
        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))
        
        self.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/jccm_DESCAPI.jpg'))
        self.logo.setPixmap(QPixmap(f":/plugins/jccm_bar4/iconos/jccm.jpg"))

        self.fun = Functions()
        self.conf = configuration()

        self.plugin_dir = os.path.dirname(__file__)
        self.QgisVersion = Qgis.QGIS_VERSION_INT

        # Comprobamos la versión máxima en METADATA.TXT. La funcionalidad descargas no funciona en diferentes versiones modernas
        ###  (10/12/22 v. 3.26 no funciona)  ###
        mtdt = configparser.ConfigParser()
        fileMetadata = os.path.join(os.path.dirname(__file__), 'metadata.txt')
        mtdt.read(fileMetadata)
        qgisMaximumVersion= mtdt.get('general', 'qgisMaximumVersion')

        qversionmax = int(qgisMaximumVersion.replace('.',''))  ## VERSION MÁXIMA DE FUNCIONAMIENTO PARA LAS DESCARGAS

        # if self.QgisVersion > qversionmax:
            # # La versión instalada de QGIS es más moderna que la desarrollada para la DESCARGA
            # msg = u'Versión instalada - QGIS %s -. PUEDE DAR PROBLEMAS EN ESTA FUNCIONALIDAD.\n Maxima versión válida v. %s'%(Qgis.QGIS_VERSION, qgisMaximumVersion)
            # self.fun.showMessageERR(msg)

        ## Variables
        self.grpCtrasAPIREST = self.plugin_dir + '/GRUPOS_CAPAS/01 CARRETERAS SIGCLM _RT(APIREST).qlr'
        self.nomgrpCtrasAPIREST = 'Carreteras CLM RT (APIREST)'
        self.nomgrpCtrasFichero = 'SIG REGIONAL CARRETERAS'             # Nombre del grupo donde se cargan las capas destino
        self.nomFichDest = u'C:/TEMP/SIG_REGIONAL_CARRETERAS_RT.gpkg'   # Dirección y nombre del fichero GPKG destino

        self.nomcapa_EJES =     'Ctras_CLM EJES RT'                     # Nombre de la capa de ejes del grupo 'Carreteras CLM (APIREST)'
        self.nomcapaDES_EJES =  'RT_carreteras_Tramovial'               # Nombre de la capa de ejes destino en la TOC
        self.nomcapa_EJES_TOC = 'Ctras_CLM EJES RT'                     # Nombre de la capa de ejes destino en la TOC
        self.estilocapa_EJES =  '/RT_TRAMOVIAL.qml'                     # Estilo para capa EJES

        self.nomcapa_PKS =      'Ctras_CLM PKS RT'                      # Nombre de la capa de PKS del grupo 'Carreteras CLM (APIREST)'
        self.nomcapaDES_PKS =   'RT_Carreteras_PKS'                     # Nombre de la capa de PKS en el GPKG destino
        self.nomcapa_PKS_TOC =  'Ctras_CLM PKS RT'                      # Nombre de la capa de PKS destino en la TOC
        self.estilocapa_PKS =   '/RT_PKS.qml'                           # Estilo para capa PKS

        self.porcentaje = 0

        self.chbMaxFeat.clicked.connect(self.cambiaMaxFeat)
        self.chbMaxFeat.setChecked(True)
        self.lneMaxFeat.setEnabled(True)
        self.lneMaxFeat.setText('200')

        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)
        self.progressBar.setValue(0)
        self.lblINFO.setText('INFO:')

        self.chbGeoBtaCalibrada.setChecked(True)
        self.chbGeoPks.setChecked(True)

        self.chbCargaCapas.setChecked(True)
        self.chbCargaBorraAPI.setChecked(False)

        self.lneFICHsalida.setText(self.nomFichDest)

        self.btnSeleccionfich.clicked.connect(self.salida_file_click)
        self.buttonBoxOK.clicked.connect(self.DescargaFicheros)

        self.lblPRECISION.hide()
        self.spnPRECISION.hide()
        self.strPrecision = "{:."+str(self.spnPRECISION.value())+"f}"


    def closeEvent(self, event):
        pass


    def encode(self,text):
        """
        For printing unicode characters to the console.
        """
        # return text.encode('utf-8')
        return text.encode('ISO-8859-14')


    def cambiaMaxFeat(self):
        if self.chbMaxFeat.isChecked():
            self.lneMaxFeat.setEnabled(True)
        else:
            self.lneMaxFeat.setEnabled(False)
        pass


    def salida_file_click(self):
        dirFile = self.lneFICHsalida.text()
        fileTipe = '.gpkg'

        ext = "*.gpkg"
        if fileTipe == 'gpkg':
            filename, tipofile = QFileDialog.getSaveFileName(self, "Fichero GEOPACKAGE de salida", dirFile, ext)
            if filename != None and filename != "":
                self.lneFICHsalida.setText(filename)
            else:
                filename = dirFile

            # Comprobamos que existe el directorio y si no se crea
            self.fun.comprobarDirectorio(filename)

        else:
            text = 'NO ES POSIBLE GUARDAR FICHEROS DE TIPO '+fileTipe+' \n'
            self.fun.showMessage('',text)


    def DescargaFicheros(self):
        # Se advierte si no se ha establecido limite de elementos
        if not self.chbMaxFeat.isChecked():
            text =  'OJO. NO SE HA LIMITADO LA DESCARGA\n\n'
            text += 'LA TAREA PUEDE TARDAR VARIOS MINUTOS\n\n'
            text += '     ¿QUIERE CONTINUAR?'
            resp = self.fun.showMessageYESNO(text)
            if resp == 4194304:
                # resp == 1024:       # Se ha pulsado ACEPTAR
                # resp == 4194304:    # Se ha pulsado CANCELAR
                return


        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        start = timeit.default_timer()

        # Verificar si el grupo self.nomgrpCtrasAPIREST ya existe
        root = QgsProject.instance().layerTreeRoot()
        grupo_existente = root.findGroup(self.nomgrpCtrasAPIREST)

        # PASO 1. Descarga del grupo de Carreteras CLM (APIREST)
        if grupo_existente and len(QgsProject.instance().mapLayersByName(self.nomcapa_EJES))>0:
            grpCtrasFichero = grupo_existente
            #################################################################################
            #### TODO Habría que comprobar si las capas del GRUPO APIREST existen dentro ####
            #################################################################################
        else:
            # Crear el grupo si no existe

            self.lblINFO.setText('INFO: PASO 1. Descarga del grupo de Carreteras CLM (APIREST)...')
            uniProj = QgsProject.instance().fileName()[:2]
            listUnd = [uniProj,  'v:', 'u:', 'z:', 'w:']
            fichGrupoAPI = self.fun.buscaFichUnd(listUnd, self.grpCtrasAPIREST)
            print ('uniProj: ', uniProj, 'fichGrupoAPI: ', fichGrupoAPI)

            if os.path.isfile(fichGrupoAPI[0]) and fichGrupoAPI is not None:
                nomGRUPO = self.nomgrpCtrasAPIREST.replace(u' -Grupo-', '')
                result=QgsLayerDefinition().loadLayerDefinition(fichGrupoAPI[0], QgsProject.instance(), root)
                if result[0]=='False':
                    QgsMessageLog.logMessage( "Fallo al cargar la capa: " + data["nombre"],self.nombre_plugin)
                    return
                # print ('Cargado: '+ fichGrupoAPI[0])

                # Asumimos que el último grupo añadido es el grupo recién cargado
                ultimo_grupo = root.children()[-1]
                ultimo_grupoName = ultimo_grupo.name()

                # Verificar si es un grupo de capas
                if isinstance(ultimo_grupo, QgsLayerTreeGroup):
                    # Mover el grupo al inicio de la TOC
                    root.insertChildNode(0, ultimo_grupo.clone())
                    root.removeChildNode(ultimo_grupo)
                    # print(f"El grupo recién cargado '{ultimo_grupoName}' se ha movido a la parte superior de la TOC.")
            else:
                text = f"No se ha encontrado el grupo {self.nomgrpCtrasAPIREST}"
                text += '\n'+ fichGrupoAPI[0]

                # print(text)
                QApplication.restoreOverrideCursor()
                self.fun.showMessageERR(text)
                return

        iface.mainWindow().statusBar().showMessage('INFO: Cargado grupo de Carreteras CLM (APIREST)')
        self.lblINFO.setText('INFO: Cargado grupo de Carreteras CLM (APIREST)')
        self.porcentaje += 12.5
        self.progressBar.setValue(int(self.porcentaje))       # PASO 1. Cargado grupo. TERMINADO
        iface.mainWindow().statusBar().showMessage(f"PASO 1. Cargado grupo {self.nomgrpCtrasAPIREST}")

        # PASO 2. Se crea fichero GPKG y grupo
        # Definir la ruta de exportación
        ruta_exportacion = self.nomFichDest
        self.lblINFO.setText('INFO: PASO 2. Se crea fichero GPKG y grupo de capas...')


        # Eliminar las posibles capas existentes de la ruta del GPKG
        QApplication.restoreOverrideCursor()
        resp = self.eliminar_capas_por_ruta(ruta_exportacion)
        if resp != 'OK':
            text = f'SE DEBEN BORRAR LAS CAPAS CARGADAS DEL FICHERO \n\n    {ruta_exportacion}'
            text += '\n\n PARA CONTINUAR'
            self.fun.showMessageERR(text)
            return

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        # if os.path.exists(ruta_exportacion):
            # os.remove(ruta_exportacion)  # Eliminar el archivo si ya existe para evitar errores
        ####################################################################
        #### TODO AUN NO HEMOS CREADO NADA                              ####
        ####################################################################

        # Crear en la vista nuevo grupo de Carreteras
        root = QgsProject.instance().layerTreeRoot()

        # # Verificar si el grupo ya existe
        grupo_existente = root.findGroup(self.nomgrpCtrasFichero)
        if grupo_existente:
            grpCtrasFichero = grupo_existente
        else:
            # Crear el grupo si no existe
            grpCtrasFichero = root.addGroup(self.nomgrpCtrasFichero)

        # Mover el grupo existente a la parte superior
        grupo_existente = root.findGroup(self.nomgrpCtrasFichero)
        root.insertChildNode(0, grupo_existente.clone())
        root.removeChildNode(grupo_existente)
        iface.mainWindow().statusBar().showMessage('INFO: Creado fichero GPKG y grupo de capas')
        self.lblINFO.setText('INFO: Creado fichero GPKG y grupo de capas')
        self.porcentaje += 12.5
        self.progressBar.setValue(int(self.porcentaje))       # PASO 2. TERMINADO


        # PASO 3. Exporta capa ejes
        if self.chbGeoBtaCalibrada.isChecked():
            self.lblINFO.setText('INFO: PASO 3. Creando capa de EJES con M...')
            if len(QgsProject.instance().mapLayersByName(self.nomcapa_EJES))>0:
                capa_EJES = QgsProject.instance().mapLayersByName(self.nomcapa_EJES)[0]
            else:
                txt = f'No existe ninguna capa de nombre {self.nomcapa_EJES}'
                QApplication.restoreOverrideCursor()
                self.fun.showMessageERR(txt)
                return

            try:
                capa_destino = self.exportaCapaM(capa_EJES, self.nomcapaDES_EJES)
            except Exception as e:
                QApplication.restoreOverrideCursor()
                # print(f"Error: {e}")
                self.fun.showMessageERR(f"Error: {e}")
                return

            # Configura las opciones para guardar la capa en un GeoPackage
            opciones = QgsVectorFileWriter.SaveVectorOptions()
            opciones.driverName = "GPKG"  # Especifica el formato GeoPackage
            opciones.layerName = self.nomcapaDES_EJES  # Nombre de la capa dentro del GeoPackage
            opciones.fileEncoding = capa_destino.dataProvider().encoding()  # Usa la misma codificación que la capa de origen
            
            if os.path.exists(ruta_exportacion):
                opciones.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

            # Guarda la capa en el GeoPackage
            error = QgsVectorFileWriter.writeAsVectorFormatV3(
                capa_destino,
                self.nomFichDest,
                QgsProject.instance().transformContext(),
                opciones
            )

            iface.mainWindow().statusBar().showMessage('INFO: Creada la capa de EJES con M')
            self.lblINFO.setText('INFO: Creada la capa de EJES con M')

            # Cargar la capa desde el GeoPackage a la TOC
            uri = f"{self.nomFichDest}|layername={self.nomcapaDES_EJES}"
            capa_destinoEJES = QgsVectorLayer(uri, self.nomcapa_EJES_TOC, "ogr")

            # Ponemos el estilo a la capa
            estiloCAPA = os.path.join(os.path.dirname(__file__), self.conf.general["carpeta_estilos"] + self.estilocapa_EJES)
            capa_destinoEJES.loadNamedStyle(estiloCAPA)

            if capa_destinoEJES.isValid():
                # Obtener la raíz de la TOC
                root = QgsProject.instance().layerTreeRoot()

                # Buscar el grupo existente o crearlo si no existe
                grupo = root.findGroup(self.nomgrpCtrasFichero)
                if not grupo:
                    grupo = root.addGroup(self.nomgrpCtrasFichero)

                # Añadir la capa al grupo
                QgsProject.instance().addMapLayer(capa_destinoEJES, False)
                grupo.addLayer(capa_destinoEJES)
                
                # Contraer el nodo de la leyenda de la capa
                capa_tree_node = root.findLayer(capa_destinoEJES.id())
                if capa_tree_node:
                    capa_tree_node.setExpanded(False)  # Contraer el nodo de la capa en el árbol


            iface.mainWindow().statusBar().showMessage(f"PASO 3. Capa Exportada y cargada con M")
            self.porcentaje += 12.5
            self.progressBar.setValue(int(self.porcentaje))       # PASO 3. TERMINADO


        # PASO 4. Exporta capa PKS
        if self.chbGeoPks.isChecked():

            self.lblINFO.setText('INFO: PASO 4. Exportando capa de PKS...')

            self.copiaCargaCAPA(self.nomcapa_PKS, self.nomFichDest, self.nomcapaDES_PKS, self.nomcapa_PKS_TOC,
                    self.estilocapa_PKS, self.nomgrpCtrasFichero)

            iface.mainWindow().statusBar().showMessage(f"PASO 4. Capa de PKS exportada")
            self.progressBar.setValue(50)       # PASO 4. TERMINADO


        # Se eliminan las capas desde API salvo que esté seleccionadp
        if not self.chbCargaBorraAPI.isChecked():
            # # Obtén el proyecto actual
            # project = QgsProject.instance()

            # Nombre del grupo a borrar
            nombre_grupo = self.nomgrpCtrasAPIREST

            # Se busca el grupo en el proyecto
            root = QgsProject.instance().layerTreeRoot()
            grupo = root.findGroup(nombre_grupo)

            # Si el grupo existe, se borra
            if grupo:
                root.removeChildNode(grupo)
                print(f"El grupo '{nombre_grupo}' ha sido eliminado.")
            # else:
                # print(f"El grupo '{nombre_grupo}' no existe en el proyecto.")
        self.porcentaje += 12.5
        self.progressBar.setValue(int(self.porcentaje))       # PASO 7. TERMINADO

        stop = timeit.default_timer()
        QApplication.restoreOverrideCursor()

        self.progressBar.setValue(100)
        self.lblINFO.setText('INFO: TERMINADA LA CARGA')

        # Tiempo en segundos
        elapsed_time = stop - start

        text = 'Guardado fichero DESCARGADO \n'
        # Convertir a minutos y segundos si es necesario
        if elapsed_time >= 60:
            minutes = int(elapsed_time // 60)
            seconds = elapsed_time % 60
            text += f'Tiempo: {minutes} min {"%0.2f" % seconds} seg.'
        else:
            text += f'Tiempo: {"%0.2f" % elapsed_time} seg.'
        
        # text += 'Tiempo: '+"%0.2f"%(stop - start)+' seg.'
        self.fun.showMessage('DESCARGA DE FICHEROS DE CARRETERAS',text)


    def exportaCapaM(self, capaOrigen, nombre_capa_exportada):
        """ Exporta la capa activa de multipolilíneaM a un GeoPackage manteniendo los valores M y la carga en QGIS. """

        # Validar que la capa sea de tipo MultiLineStringM
        if QgsWkbTypes.hasM(capaOrigen.wkbType()) == False:
            raise ValueError("La capa activa no es de tipo MultiLineStringM.")

        # Crear la capa de destino con el mismo tipo de geometría y CRS
        tipo_geometria = QgsWkbTypes.displayString(QgsWkbTypes.multiType(capaOrigen.wkbType()))
        crs = capaOrigen.crs()

        capa_destino = QgsVectorLayer(f"MultiLineStringM?crs={crs.authid()}", nombre_capa_exportada, "memory")
        if not capa_destino.isValid():
            raise ValueError("No se pudo crear la capa de destino en memoria.")

        # Agregar los mismos campos que la capa original

        # Copiar campos respetando el formato original
        fields_originales = [QgsField(field.name(), field.type(), field.typeName(), field.length(), field.precision()) for field in capaOrigen.fields()]
        capa_destino.dataProvider().addAttributes(fields_originales)
        capa_destino.updateFields()

        capa_destino.updateFields()


        # Copiar las entidades de la capa original a la capa de destino
        total_features = capaOrigen.featureCount()

        if self.chbMaxFeat.isChecked():
            maxfeat = int(self.lneMaxFeat.text())
        else:
            maxfeat = 999999999

        for i, feature in enumerate(capaOrigen.getFeatures()):
            if i > maxfeat:     # Control de cálculo limitado
                break
                
            nueva_geometria = feature.geometry()
            nueva_feature = QgsFeature(feature)
            nueva_feature.setGeometry(nueva_geometria)
            capa_destino.dataProvider().addFeature(nueva_feature)

            # Mostrar progreso en la barra de estado de QGIS
            self.porcentaje += int((i + 1) / total_features * 15)
            self.progressBar.setValue(int(self.porcentaje))
            iface.mainWindow().statusBar().showMessage(f"Exportando capa {nombre_capa_exportada}... {self.porcentaje}% completado")

        return capa_destino


    def eliminar_capas_por_ruta(self, ruta_exportacion):
        """
        Identifica y elimina las capas de la TOC que tengan como fuente la ruta 'ruta_exportacion'.

        :param ruta_exportacion: Ruta del archivo que se desea buscar.
        """
        # Lista para almacenar las capas que coinciden
        capas_a_eliminar = []

        # Recorrer las capas del proyecto
        for capa in QgsProject.instance().mapLayers().values():
            # Verificar si la fuente de datos de la capa coincide con la ruta dada
            if capa.dataProvider().dataSourceUri().startswith(ruta_exportacion):
                capas_a_eliminar.append(capa)

        # Si no hay capas coincidentes, salir de la función
        if not capas_a_eliminar:
            iface.messageBar().pushMessage("Información", "No se encontraron capas con la ruta especificada.", level=Qgis.Info)
            return 'OK'

        # Mostrar un cuadro de diálogo de confirmación con los nombres de las capas
        nombres_capas = "\n    ".join([capa.name() for capa in capas_a_eliminar])
        mensaje = f"Se encontraron las siguientes capas con la ruta \n\n'{ruta_exportacion}':\n\n    {nombres_capas}\n\n¿Desea eliminarlas?"
        respuesta = QMessageBox.question(
            iface.mainWindow(),
            "Eliminar capas",
            mensaje,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        # Si el usuario selecciona "Sí", eliminar las capas
        if respuesta == QMessageBox.StandardButton.Yes:
            for capa in capas_a_eliminar:
                QgsProject.instance().removeMapLayer(capa)
            iface.messageBar().pushMessage("Éxito", "Capas eliminadas correctamente.", level=Qgis.Success)
            return 'OK'


    def copiaCargaCAPA(self, capaOrigen, nomFichDest, nomcapaDES, nomcapa_TOC, estilocapaFich, nomgrpCtrasFichero):
        ### VARIABLES ###
        # capaOrigen,           # Nombre de la capa en el grupo de capas ORIGEN
        # nomFichDest,          # Dirección y nombre del fichero GPKG destino
        # nomcapaDES,           # Nombre de la capa en el fichero GPKG destino
        # nomcapa_TOC,          # Nombre de la capa destino en la TOC
        # estilocapaFich,       # Estilo para la nueva capa
        # nomgrpCtrasFichero,   # Nombre del grupo donde se cargan las capas destino

        # Obtener la capa de puntos de la TOC
        capa_origen = QgsProject.instance().mapLayersByName(capaOrigen)[0]

        # Copiar la capa a un fichero GeoPackage
        opciones = QgsVectorFileWriter.SaveVectorOptions()
        opciones.driverName = "GPKG"
        opciones.layerName = nomcapaDES
        opciones.fileEncoding = capa_origen.dataProvider().encoding()
        if os.path.exists(nomFichDest):
            opciones.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

        QgsVectorFileWriter.writeAsVectorFormatV3(capa_origen, nomFichDest, QgsProject.instance().transformContext(), opciones)

        iface.mainWindow().statusBar().showMessage(f"Exportación de {nomcapaDES} completada con éxito.")

        # Cargar la capa desde el GeoPackage a la TOC
        uri = f"{nomFichDest}|layername={nomcapaDES}"
        capa_destino = QgsVectorLayer(uri, nomcapa_TOC, "ogr")

        # Ponemos el estilo a la capa
        estiloCAPA = os.path.join(os.path.dirname(__file__), self.conf.general["carpeta_estilos"] + estilocapaFich)
        capa_destino.loadNamedStyle(estiloCAPA)

        if capa_destino.isValid():
            # Obtener la raíz de la TOC
            root = QgsProject.instance().layerTreeRoot()

            # Buscar el grupo existente o crearlo si no existe
            grupo = root.findGroup(nomgrpCtrasFichero)
            if not grupo:
                grupo = root.addGroup(nomgrpCtrasFichero)

            # Añadir la capa al grupo
            QgsProject.instance().addMapLayer(capa_destino, False)
            grupo.addLayer(capa_destino)

            # Mover el grupo al inicio de la TOC
            root.insertChildNode(0, grupo.clone())
            root.removeChildNode(grupo)
            
            # Contraer el nodo de la leyenda de la capa
            capa_tree_node = root.findLayer(capa_destino.id())
            if capa_tree_node:
                capa_tree_node.setExpanded(False)  # Contraer el nodo de la capa en el árbol

        else:
            # print("Error: No se pudo cargar la capa desde el GeoPackage.")
            self.fun.showMessageERR("Error: No se pudo cargar la capa desde el GeoPackage")

