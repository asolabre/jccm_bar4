# -*- coding: utf-8 -*-
"""
/***************************************************************************
catastroParcelaINFO.py
                                 A QGIS4 plugin
Plugin:     catastroesp - Catastro de España
Purpose:    Carga el menú de información de parcela
        --------------------------------------------------------------------
        begin                : 2016-06-06
        validacion transfQG4 : 2026-10-22
        git sha              : $Format:%H$
        Codigo Corregido     : Agustín Solabre
        email                : agusass@hotmail.com
 ***************************************************************************/
"""
from qgis.PyQt.QtWidgets import QApplication, QDialog
from qgis.PyQt import uic, QtCore, QtGui

import os
import sys
import builtins
import types

from .functions4 import Functions

# --- Registro del promoted widget ANTES de uic.loadUiType ---
# uic.loadUiType necesita que 'ZoomableGraphicsView' exista en builtins
# en el momento de parsear el .ui (import-time), no en el __init__.
_fun_module = Functions()
builtins.ZoomableGraphicsView = _fun_module.crearZoomableGraphicsView()

# Módulo "zoomableview" falso por compatibilidad con .ui que lo referencien así
_zoom_mod = types.ModuleType('zoomableview')
_zoom_mod.ZoomableGraphicsView = builtins.ZoomableGraphicsView
sys.modules['zoomableview'] = _zoom_mod
del _fun_module

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/catastroParcelaINFO.ui'))


class catastroParcelaINFODialog(QDialog, FORM_CLASS):
    def __init__(self, iface, parent=None):
        """Constructor."""
        super(catastroParcelaINFODialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface

    def encode(self, text):
        return text.encode('utf-8')