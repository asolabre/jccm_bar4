<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis hasScaleBasedVisibilityFlag="0" readOnly="0" simplifyAlgorithm="0" maxScale="0" simplifyLocal="1" simplifyMaxScale="1" simplifyDrawingTol="1" version="3.10.6-A Coruña" minScale="1e+08" labelsEnabled="1" simplifyDrawingHints="0" styleCategories="AllStyleCategories">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
  </flags>
  <renderer-v2 forceraster="0" enableorderby="0" type="singleSymbol" symbollevels="0">
    <symbols>
      <symbol alpha="1" name="0" clip_to_extent="1" type="marker" force_rhr="0">
        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
          <prop v="0" k="angle"/>
          <prop v="244,251,142,255" k="color"/>
          <prop v="1" k="horizontal_anchor_point"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="circle" k="name"/>
          <prop v="0,0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0,0,0,255" k="outline_color"/>
          <prop v="solid" k="outline_style"/>
          <prop v="0" k="outline_width"/>
          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
          <prop v="MM" k="outline_width_unit"/>
          <prop v="area" k="scale_method"/>
          <prop v="2.4" k="size"/>
          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
          <prop v="MM" k="size_unit"/>
          <prop v="1" k="vertical_anchor_point"/>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
          <prop v="0" k="angle"/>
          <prop v="0,0,0,255" k="color"/>
          <prop v="1" k="horizontal_anchor_point"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="circle" k="name"/>
          <prop v="0,0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0,0,0,255" k="outline_color"/>
          <prop v="solid" k="outline_style"/>
          <prop v="0" k="outline_width"/>
          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
          <prop v="MM" k="outline_width_unit"/>
          <prop v="area" k="scale_method"/>
          <prop v="0.5" k="size"/>
          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
          <prop v="MM" k="size_unit"/>
          <prop v="1" k="vertical_anchor_point"/>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style blendMode="0" fontUnderline="0" fontSize="8" fieldName="'Pk:' ||  format_number(  &quot;pk_ini&quot; ,0) || '+'  || format_number(  &quot;pk_iniDist&quot; ,0)" previewBkgrdColor="255,255,255,255" multilineHeight="1" fontWeight="50" fontWordSpacing="0" textOrientation="horizontal" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textOpacity="1" fontFamily="MS Shell Dlg 2" fontSizeUnit="Point" isExpression="1" namedStyle="Normal" fontLetterSpacing="0" fontCapitals="0" fontKerning="1" useSubstitutions="0" fontItalic="0" fontStrikeout="0" textColor="0,0,0,255">
        <text-buffer bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferBlendMode="0" bufferSize="1" bufferNoFill="1" bufferSizeUnits="MM" bufferOpacity="1" bufferJoinStyle="128" bufferDraw="0" bufferColor="255,255,255,255"/>
        <background shapeDraw="1" shapeSizeType="0" shapeFillColor="255,255,255,255" shapeSizeX="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeRotation="0" shapeOffsetX="0" shapeOffsetUnit="MM" shapeBorderWidthUnit="MM" shapeBorderColor="128,128,128,255" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRotationType="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0" shapeSizeY="0" shapeRadiiY="0" shapeSVGFile="" shapeBlendMode="0" shapeType="0" shapeOpacity="1" shapeSizeUnit="MM" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeOffsetY="0">
          <symbol alpha="1" name="markerSymbol" clip_to_extent="1" type="marker" force_rhr="0">
            <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
              <prop v="0" k="angle"/>
              <prop v="114,155,111,255" k="color"/>
              <prop v="1" k="horizontal_anchor_point"/>
              <prop v="bevel" k="joinstyle"/>
              <prop v="circle" k="name"/>
              <prop v="0,0" k="offset"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="35,35,35,255" k="outline_color"/>
              <prop v="solid" k="outline_style"/>
              <prop v="0" k="outline_width"/>
              <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
              <prop v="MM" k="outline_width_unit"/>
              <prop v="diameter" k="scale_method"/>
              <prop v="2" k="size"/>
              <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
              <prop v="MM" k="size_unit"/>
              <prop v="1" k="vertical_anchor_point"/>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowOffsetGlobal="1" shadowOffsetUnit="MM" shadowDraw="0" shadowRadiusAlphaOnly="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOpacity="0" shadowBlendMode="6" shadowUnder="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowRadius="0"/>
        <dd_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format reverseDirectionSymbol="0" rightDirectionSymbol=">" addDirectionSymbol="0" plussign="0" multilineAlign="3" leftDirectionSymbol="&lt;" wrapChar="" autoWrapLength="0" decimals="3" useMaxLineLengthForAutoWrap="1" placeDirectionSymbol="0" formatNumbers="0"/>
      <placement labelOffsetMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" layerType="PointGeometry" geometryGeneratorType="PointGeometry" distUnits="MM" quadOffset="4" offsetType="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" centroidWhole="0" preserveRotation="1" offsetUnits="MM" overrunDistanceUnit="MM" overrunDistance="0" placement="1" rotationAngle="0" repeatDistanceUnits="MM" fitInPolygonOnly="0" xOffset="0" maxCurvedCharAngleOut="-25" repeatDistance="0" geometryGenerator="" dist="0" priority="5" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" geometryGeneratorEnabled="0"/>
      <rendering mergeLines="0" fontMaxPixelSize="10000" drawLabels="1" fontMinPixelSize="3" obstacleType="0" scaleMin="0" scaleVisibility="0" limitNumLabels="0" fontLimitPixelSize="0" zIndex="0" displayAll="0" scaleMax="0" obstacle="1" obstacleFactor="1" upsidedownLabels="0" maxNumLabels="2000" minFeatureSize="0" labelPerPart="0"/>
      <dd_properties>
        <Option type="Map">
          <Option name="name" type="QString" value=""/>
          <Option name="properties" type="Map">
            <Option name="LabelRotation" type="Map">
              <Option name="active" type="bool" value="true"/>
              <Option name="expression" type="QString" value="360 - (CASE &#xd;&#xa;WHEN   ( &quot;acimut&quot; &lt;= 90 OR   &quot;acimut&quot;  >270) THEN (360- &quot;acimut&quot; )&#xd;&#xa;&#xd;&#xa;ELSE (180- &quot;acimut&quot; ) &#xd;&#xa;END)"/>
              <Option name="type" type="int" value="3"/>
            </Option>
            <Option name="OffsetQuad" type="Map">
              <Option name="active" type="bool" value="true"/>
              <Option name="expression" type="QString" value="CASE &#xd;&#xa;WHEN  ( &quot;acimut&quot; > 90 AND  &quot;acimut&quot; &lt;= 270) THEN if ( &quot;distancia&quot; >=  0, 0, 2)&#xd;&#xa;&#x9;ELSE  if( &quot;distancia&quot;  >=  0, 2, 0)&#xd;&#xa;END"/>
              <Option name="type" type="int" value="3"/>
            </Option>
          </Option>
          <Option name="type" type="QString" value="collection"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
          <Option name="ddProperties" type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
          <Option name="drawToAllParts" type="bool" value="false"/>
          <Option name="enabled" type="QString" value="0"/>
          <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot;>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
          <Option name="minLength" type="double" value="0"/>
          <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="minLengthUnit" type="QString" value="MM"/>
          <Option name="offsetFromAnchor" type="double" value="0"/>
          <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
          <Option name="offsetFromLabel" type="double" value="0"/>
          <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <property key="embeddedWidgets/count" value="0"/>
    <property key="variableNames"/>
    <property key="variableValues"/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory width="15" lineSizeScale="3x:0,0,0,0,0,0" diagramOrientation="Up" penColor="#000000" height="15" backgroundColor="#ffffff" barWidth="5" enabled="0" penWidth="0" penAlpha="255" scaleBasedVisibility="0" maxScaleDenominator="1e+08" sizeType="MM" scaleDependency="Area" backgroundAlpha="255" minScaleDenominator="0" labelPlacementMethod="XHeight" minimumSize="0" opacity="1" lineSizeType="MM" sizeScale="3x:0,0,0,0,0,0" rotationOffset="270">
      <fontProperties style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0"/>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings priority="0" dist="0" obstacle="0" linePlacementFlags="18" showAll="1" placement="0" zIndex="0">
    <properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <fieldConfiguration>
    <field name="carretera">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="pk_ini">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="pk_iniDist">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="pk_fin">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="pk_finDist">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="acimut">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="distancia">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CTRA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PKHITO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PKDIST">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DATO1">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="carretera" name=""/>
    <alias index="1" field="pk_ini" name=""/>
    <alias index="2" field="pk_iniDist" name=""/>
    <alias index="3" field="pk_fin" name=""/>
    <alias index="4" field="pk_finDist" name=""/>
    <alias index="5" field="acimut" name=""/>
    <alias index="6" field="distancia" name=""/>
    <alias index="7" field="CTRA" name=""/>
    <alias index="8" field="PKHITO" name=""/>
    <alias index="9" field="PKDIST" name=""/>
    <alias index="10" field="DATO1" name=""/>
  </aliases>
  <excludeAttributesWMS/>
  <excludeAttributesWFS/>
  <defaults>
    <default field="carretera" applyOnUpdate="0" expression=""/>
    <default field="pk_ini" applyOnUpdate="0" expression=""/>
    <default field="pk_iniDist" applyOnUpdate="0" expression=""/>
    <default field="pk_fin" applyOnUpdate="0" expression=""/>
    <default field="pk_finDist" applyOnUpdate="0" expression=""/>
    <default field="acimut" applyOnUpdate="0" expression=""/>
    <default field="distancia" applyOnUpdate="0" expression=""/>
    <default field="CTRA" applyOnUpdate="0" expression=""/>
    <default field="PKHITO" applyOnUpdate="0" expression=""/>
    <default field="PKDIST" applyOnUpdate="0" expression=""/>
    <default field="DATO1" applyOnUpdate="0" expression=""/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="carretera" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="pk_ini" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="pk_iniDist" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="pk_fin" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="pk_finDist" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="acimut" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="distancia" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="CTRA" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="PKHITO" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="PKDIST" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="DATO1" unique_strength="0" constraints="0" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="carretera" desc="" exp=""/>
    <constraint field="pk_ini" desc="" exp=""/>
    <constraint field="pk_iniDist" desc="" exp=""/>
    <constraint field="pk_fin" desc="" exp=""/>
    <constraint field="pk_finDist" desc="" exp=""/>
    <constraint field="acimut" desc="" exp=""/>
    <constraint field="distancia" desc="" exp=""/>
    <constraint field="CTRA" desc="" exp=""/>
    <constraint field="PKHITO" desc="" exp=""/>
    <constraint field="PKDIST" desc="" exp=""/>
    <constraint field="DATO1" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" sortExpression="" actionWidgetStyle="dropDown">
    <columns>
      <column name="carretera" hidden="0" width="-1" type="field"/>
      <column name="pk_ini" hidden="0" width="-1" type="field"/>
      <column name="pk_fin" hidden="0" width="-1" type="field"/>
      <column name="acimut" hidden="0" width="-1" type="field"/>
      <column name="distancia" hidden="0" width="-1" type="field"/>
      <column name="CTRA" hidden="0" width="-1" type="field"/>
      <column name="PKHITO" hidden="0" width="-1" type="field"/>
      <column name="PKDIST" hidden="0" width="-1" type="field"/>
      <column name="DATO1" hidden="0" width="-1" type="field"/>
      <column hidden="1" width="-1" type="actions"/>
      <column name="pk_iniDist" hidden="0" width="-1" type="field"/>
      <column name="pk_finDist" hidden="0" width="-1" type="field"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- codificación: utf-8 -*-
"""
Los formularios de QGIS pueden tener una función de Python que
es llamada cuando se abre el formulario.

Use esta función para añadir lógica extra a sus formularios.

Introduzca el nombre de la función en el campo
"Python Init function".
Sigue un ejemplo:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="CTRA"/>
    <field editable="1" name="DATO1"/>
    <field editable="1" name="PKDIST"/>
    <field editable="1" name="PKHITO"/>
    <field editable="1" name="acimut"/>
    <field editable="1" name="carretera"/>
    <field editable="1" name="distancia"/>
    <field editable="1" name="pk_fin"/>
    <field editable="1" name="pk_finDist"/>
    <field editable="1" name="pk_ini"/>
    <field editable="1" name="pk_iniDist"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="CTRA"/>
    <field labelOnTop="0" name="DATO1"/>
    <field labelOnTop="0" name="PKDIST"/>
    <field labelOnTop="0" name="PKHITO"/>
    <field labelOnTop="0" name="acimut"/>
    <field labelOnTop="0" name="carretera"/>
    <field labelOnTop="0" name="distancia"/>
    <field labelOnTop="0" name="pk_fin"/>
    <field labelOnTop="0" name="pk_finDist"/>
    <field labelOnTop="0" name="pk_ini"/>
    <field labelOnTop="0" name="pk_iniDist"/>
  </labelOnTop>
  <widgets/>
  <previewExpression>carretera</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
