<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="2.14.6-Essen" minimumScale="0" maximumScale="1e+08" simplifyDrawingHints="1" minLabelScale="0" maxLabelScale="1e+08" simplifyDrawingTol="1" simplifyMaxScale="1" hasScaleBasedVisibilityFlag="0" simplifyLocal="1" scaleBasedLabelVisibilityFlag="0">
  <edittypes>
    <edittype widgetv2type="TextEdit" name="OBJECTID">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="idMatricula">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="Matricula">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="Longitud">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="PkINI">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="PkFin">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="Matricula_Plan">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="Titularidad">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="Funcionalidad">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="Tipologia_DobleC">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="Tipologia_UnaC">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="Denominacion">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="Long_Km">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="idOrdenCtra">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="Origen">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="Destino">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="Provincia">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="Shape.STLength__">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
  </edittypes>
  <renderer-v2 forceraster="0" symbollevels="0" type="RuleRenderer" enableorderby="0">
    <rules key="{45bed473-7b44-438e-b544-e7b1d2bc6af0}">
      <rule filter="((&quot;Titularidad&quot;  =  'JCCM' OR  &quot;Titularidad&quot;  =  'CAM' OR  &quot;Titularidad&quot;  =  'JEX' )) and (&quot;Matricula&quot;  &lt;> '9000')" key="{91464e02-0dab-44cd-bdec-cbba3c9a37e9}" symbol="0" label="Rot CTRAS. Regionales"/>
      <rule filter=" (&quot;Titularidad&quot;  =   'Estatal') and  (&quot;Matricula&quot; &lt;> '9000')" key="{91464e02-0dab-44cd-bdec-cbba3c9a37e9}" symbol="1" label="Rot CTRAS. Estatales"/>
      <rule filter=" (&quot;Titularidad&quot;  =  'Diputación') and  (&quot;Matricula&quot; &lt;> '9000')" key="{6e8f1bfb-2c03-4227-810d-1b3da25272cc}" symbol="2" label="Rot CTRAS. Diputación"/>
    </rules>
    <symbols>
      <symbol alpha="0" clip_to_extent="1" type="line" name="0">
        <layer pass="0" class="SimpleLine" locked="0">
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="138,138,138,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="0,0,0,0,0,0"/>
        </layer>
      </symbol>
      <symbol alpha="0" clip_to_extent="1" type="line" name="1">
        <layer pass="0" class="SimpleLine" locked="0">
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="138,138,138,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="0,0,0,0,0,0"/>
        </layer>
      </symbol>
      <symbol alpha="0" clip_to_extent="1" type="line" name="2">
        <layer pass="0" class="SimpleLine" locked="0">
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="138,138,138,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="0,0,0,0,0,0"/>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <labeling type="simple"/>
  <customproperties>
    <property key="labeling" value="pal"/>
    <property key="labeling/addDirectionSymbol" value="false"/>
    <property key="labeling/angleOffset" value="0"/>
    <property key="labeling/blendMode" value="0"/>
    <property key="labeling/bufferBlendMode" value="0"/>
    <property key="labeling/bufferColorA" value="255"/>
    <property key="labeling/bufferColorB" value="255"/>
    <property key="labeling/bufferColorG" value="255"/>
    <property key="labeling/bufferColorR" value="255"/>
    <property key="labeling/bufferDraw" value="false"/>
    <property key="labeling/bufferJoinStyle" value="64"/>
    <property key="labeling/bufferNoFill" value="false"/>
    <property key="labeling/bufferSize" value="1"/>
    <property key="labeling/bufferSizeInMapUnits" value="false"/>
    <property key="labeling/bufferSizeMapUnitMaxScale" value="0"/>
    <property key="labeling/bufferSizeMapUnitMinScale" value="0"/>
    <property key="labeling/bufferSizeMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/bufferTransp" value="0"/>
    <property key="labeling/centroidInside" value="false"/>
    <property key="labeling/centroidWhole" value="false"/>
    <property key="labeling/dataDefined/Color" value="1~~1~~CASE WHEN    &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;  =    'Básica alta capacidad'    THEN  color_rgb(255,255,255)&#xd;&#xa;ELSE &#xd;&#xa;    CASE WHEN   &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;    =   'Básica'   THEN  color_rgb( 0,0,0)&#xd;&#xa;    ELSE &#xd;&#xa;        CASE WHEN   &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;   =   'Comarcal'   THEN  color_rgb(255,255,255)&#xd;&#xa;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;CASE WHEN   &quot;Titularidad&quot;  =   'Estatal' THEN  color_rgb(255,255,255)&#xd;&#xa;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;CASE WHEN   &quot;Titularidad&quot;  =   'Estatal' THEN  color_rgb(255,255,255)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;color_rgb( 0,0,0)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;END&#xd;&#xa;        END&#xd;&#xa;    END&#xd;&#xa;END~~"/>
    <property key="labeling/dataDefined/MaxScale" value="1~~1~~CASE WHEN    &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;  =    'Básica alta capacidad'    THEN  2000000&#xd;&#xa;ELSE &#xd;&#xa;    CASE WHEN   &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;    =   'Básica'   THEN  2000000&#xd;&#xa;    ELSE &#xd;&#xa;        CASE WHEN   &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;   =   'Comarcal'   THEN  750000&#xd;&#xa;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;CASE WHEN   &quot;Titularidad&quot;  =   'Estatal' THEN  2000000&#xd;&#xa;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;CASE WHEN   &quot;Titularidad&quot;  =   'Estatal' THEN  2000000&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;600000&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;END&#xd;&#xa;        END&#xd;&#xa;    END&#xd;&#xa;END~~"/>
    <property key="labeling/dataDefined/ShapeBorderColor" value="1~~1~~CASE WHEN    &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;  =    'Básica alta capacidad'    THEN  color_rgb(255,255,255)&#xd;&#xa;ELSE &#xd;&#xa;    CASE WHEN   &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;    =   'Básica'   THEN  color_rgb( 0,0,0)&#xd;&#xa;    ELSE &#xd;&#xa;        CASE WHEN   &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;   =   'Comarcal'   THEN  color_rgb(255,255,255)&#xd;&#xa;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;CASE WHEN   &quot;Titularidad&quot;  =   'Estatal' THEN  color_rgb(255,255,255)&#xd;&#xa;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;CASE WHEN   &quot;Titularidad&quot;  =   'Estatal' THEN  color_rgb(255,255,255)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;color_rgb( 0,0,0)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;END&#xd;&#xa;        END&#xd;&#xa;    END&#xd;&#xa;END~~"/>
    <property key="labeling/dataDefined/ShapeFillColor" value="1~~1~~CASE WHEN    &quot;Titularidad&quot; =  'JCCM' AND &quot;Funcionalidad&quot;  =    'Básica alta capacidad'    THEN  color_rgb( 184,0,204)&#xd;&#xa;&#x9;ELSE&#xd;&#xa;&#x9;CASE WHEN    &quot;Titularidad&quot; =  'JCCM' AND &quot;Funcionalidad&quot;    =   'Básica'   THEN  color_rgb( 255,127,0) &#x9;&#xd;&#xa;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;CASE WHEN   &quot;Titularidad&quot; =  'JCCM' AND &quot;Funcionalidad&quot;   =   'Comarcal'   THEN  color_rgb( 51,140,41)&#xd;&#xa;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;CASE WHEN   &quot;Titularidad&quot; =  'JCCM' AND (&quot;Funcionalidad&quot;   =  'Local'  OR  &quot;Funcionalidad&quot;  =  'Travesía'  OR  &quot;Funcionalidad&quot;  =  'Ramal' )   THEN  color_rgb( 255,255,0)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;CASE WHEN &quot;Titularidad&quot; =  'Estatal' AND ((  &quot;Tipologia_DobleC&quot;   =   'ATP' )  OR (   &quot;Tipologia_DobleC&quot;  =   'ATV' ))  THEN  color_rgb( 1,120,255) &#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;CASE WHEN &quot;Titularidad&quot; =  'Estatal' AND  ((   &quot;Tipologia_UnaC&quot;    =   'CON' )  OR (  &quot;Tipologia_UnaC&quot;    =   'ATN' )) &#x9;THEN  color_rgb( 255,0,0)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;color_rgb(255,255,255)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;END&#xd;&#xa;&#x9;END&#xd;&#xa;END~~"/>
    <property key="labeling/dataDefined/Size" value="1~~1~~CASE WHEN    &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;  =    'Básica alta capacidad'    THEN  7&#xd;&#xa;ELSE &#xd;&#xa;    CASE WHEN   &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;    =   'Básica'   THEN  7&#xd;&#xa;    ELSE &#xd;&#xa;        CASE WHEN   &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;   =   'Comarcal'   THEN  7&#xd;&#xa;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;CASE WHEN   &quot;Titularidad&quot;  =   'Estatal' THEN  7&#xd;&#xa;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;CASE WHEN   &quot;Titularidad&quot;  =   'Estatal' THEN  7&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;6&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;END&#xd;&#xa;        END&#xd;&#xa;    END&#xd;&#xa;END~~"/>
    <property key="labeling/decimals" value="3"/>
    <property key="labeling/displayAll" value="false"/>
    <property key="labeling/dist" value="0"/>
    <property key="labeling/distInMapUnits" value="false"/>
    <property key="labeling/distMapUnitMaxScale" value="0"/>
    <property key="labeling/distMapUnitMinScale" value="0"/>
    <property key="labeling/distMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/drawLabels" value="true"/>
    <property key="labeling/enabled" value="true"/>
    <property key="labeling/fieldName" value="Matricula"/>
    <property key="labeling/fitInPolygonOnly" value="false"/>
    <property key="labeling/fontBold" value="false"/>
    <property key="labeling/fontCapitals" value="0"/>
    <property key="labeling/fontFamily" value="Arial"/>
    <property key="labeling/fontItalic" value="false"/>
    <property key="labeling/fontLetterSpacing" value="0"/>
    <property key="labeling/fontLimitPixelSize" value="false"/>
    <property key="labeling/fontMaxPixelSize" value="10000"/>
    <property key="labeling/fontMinPixelSize" value="3"/>
    <property key="labeling/fontSize" value="7"/>
    <property key="labeling/fontSizeInMapUnits" value="false"/>
    <property key="labeling/fontSizeMapUnitMaxScale" value="0"/>
    <property key="labeling/fontSizeMapUnitMinScale" value="0"/>
    <property key="labeling/fontSizeMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/fontStrikeout" value="false"/>
    <property key="labeling/fontUnderline" value="false"/>
    <property key="labeling/fontWeight" value="50"/>
    <property key="labeling/fontWordSpacing" value="0"/>
    <property key="labeling/formatNumbers" value="false"/>
    <property key="labeling/isExpression" value="false"/>
    <property key="labeling/labelOffsetInMapUnits" value="true"/>
    <property key="labeling/labelOffsetMapUnitMaxScale" value="0"/>
    <property key="labeling/labelOffsetMapUnitMinScale" value="0"/>
    <property key="labeling/labelOffsetMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/labelPerPart" value="false"/>
    <property key="labeling/leftDirectionSymbol" value="&lt;"/>
    <property key="labeling/limitNumLabels" value="false"/>
    <property key="labeling/maxCurvedCharAngleIn" value="20"/>
    <property key="labeling/maxCurvedCharAngleOut" value="-20"/>
    <property key="labeling/maxNumLabels" value="2000"/>
    <property key="labeling/mergeLines" value="true"/>
    <property key="labeling/minFeatureSize" value="10"/>
    <property key="labeling/multilineAlign" value="0"/>
    <property key="labeling/multilineHeight" value="1"/>
    <property key="labeling/namedStyle" value="Normal"/>
    <property key="labeling/obstacle" value="true"/>
    <property key="labeling/obstacleFactor" value="1"/>
    <property key="labeling/obstacleType" value="0"/>
    <property key="labeling/offsetType" value="0"/>
    <property key="labeling/placeDirectionSymbol" value="0"/>
    <property key="labeling/placement" value="4"/>
    <property key="labeling/placementFlags" value="10"/>
    <property key="labeling/plussign" value="false"/>
    <property key="labeling/predefinedPositionOrder" value="TR,TL,BR,BL,R,L,TSR,BSR"/>
    <property key="labeling/preserveRotation" value="true"/>
    <property key="labeling/previewBkgrdColor" value="#ffffff"/>
    <property key="labeling/priority" value="5"/>
    <property key="labeling/quadOffset" value="4"/>
    <property key="labeling/repeatDistance" value="50"/>
    <property key="labeling/repeatDistanceMapUnitMaxScale" value="0"/>
    <property key="labeling/repeatDistanceMapUnitMinScale" value="0"/>
    <property key="labeling/repeatDistanceMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/repeatDistanceUnit" value="1"/>
    <property key="labeling/reverseDirectionSymbol" value="false"/>
    <property key="labeling/rightDirectionSymbol" value=">"/>
    <property key="labeling/scaleMax" value="10000000"/>
    <property key="labeling/scaleMin" value="1"/>
    <property key="labeling/scaleVisibility" value="true"/>
    <property key="labeling/shadowBlendMode" value="6"/>
    <property key="labeling/shadowColorB" value="0"/>
    <property key="labeling/shadowColorG" value="0"/>
    <property key="labeling/shadowColorR" value="0"/>
    <property key="labeling/shadowDraw" value="false"/>
    <property key="labeling/shadowOffsetAngle" value="135"/>
    <property key="labeling/shadowOffsetDist" value="1"/>
    <property key="labeling/shadowOffsetGlobal" value="true"/>
    <property key="labeling/shadowOffsetMapUnitMaxScale" value="0"/>
    <property key="labeling/shadowOffsetMapUnitMinScale" value="0"/>
    <property key="labeling/shadowOffsetMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/shadowOffsetUnits" value="1"/>
    <property key="labeling/shadowRadius" value="1.5"/>
    <property key="labeling/shadowRadiusAlphaOnly" value="false"/>
    <property key="labeling/shadowRadiusMapUnitMaxScale" value="0"/>
    <property key="labeling/shadowRadiusMapUnitMinScale" value="0"/>
    <property key="labeling/shadowRadiusMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/shadowRadiusUnits" value="1"/>
    <property key="labeling/shadowScale" value="100"/>
    <property key="labeling/shadowTransparency" value="30"/>
    <property key="labeling/shadowUnder" value="0"/>
    <property key="labeling/shapeBlendMode" value="0"/>
    <property key="labeling/shapeBorderColorA" value="255"/>
    <property key="labeling/shapeBorderColorB" value="0"/>
    <property key="labeling/shapeBorderColorG" value="0"/>
    <property key="labeling/shapeBorderColorR" value="0"/>
    <property key="labeling/shapeBorderWidth" value="0.1"/>
    <property key="labeling/shapeBorderWidthMapUnitMaxScale" value="0"/>
    <property key="labeling/shapeBorderWidthMapUnitMinScale" value="0"/>
    <property key="labeling/shapeBorderWidthMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/shapeBorderWidthUnits" value="1"/>
    <property key="labeling/shapeDraw" value="true"/>
    <property key="labeling/shapeFillColorA" value="255"/>
    <property key="labeling/shapeFillColorB" value="255"/>
    <property key="labeling/shapeFillColorG" value="255"/>
    <property key="labeling/shapeFillColorR" value="255"/>
    <property key="labeling/shapeJoinStyle" value="64"/>
    <property key="labeling/shapeOffsetMapUnitMaxScale" value="0"/>
    <property key="labeling/shapeOffsetMapUnitMinScale" value="0"/>
    <property key="labeling/shapeOffsetMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/shapeOffsetUnits" value="1"/>
    <property key="labeling/shapeOffsetX" value="0"/>
    <property key="labeling/shapeOffsetY" value="0"/>
    <property key="labeling/shapeRadiiMapUnitMaxScale" value="0"/>
    <property key="labeling/shapeRadiiMapUnitMinScale" value="0"/>
    <property key="labeling/shapeRadiiMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/shapeRadiiUnits" value="1"/>
    <property key="labeling/shapeRadiiX" value="0"/>
    <property key="labeling/shapeRadiiY" value="0"/>
    <property key="labeling/shapeRotation" value="0"/>
    <property key="labeling/shapeRotationType" value="0"/>
    <property key="labeling/shapeSVGFile" value=""/>
    <property key="labeling/shapeSizeMapUnitMaxScale" value="0"/>
    <property key="labeling/shapeSizeMapUnitMinScale" value="0"/>
    <property key="labeling/shapeSizeMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/shapeSizeType" value="0"/>
    <property key="labeling/shapeSizeUnits" value="1"/>
    <property key="labeling/shapeSizeX" value="0.5"/>
    <property key="labeling/shapeSizeY" value="0.03"/>
    <property key="labeling/shapeTransparency" value="0"/>
    <property key="labeling/shapeType" value="0"/>
    <property key="labeling/textColorA" value="255"/>
    <property key="labeling/textColorB" value="0"/>
    <property key="labeling/textColorG" value="0"/>
    <property key="labeling/textColorR" value="0"/>
    <property key="labeling/textTransp" value="0"/>
    <property key="labeling/upsidedownLabels" value="0"/>
    <property key="labeling/wrapChar" value=""/>
    <property key="labeling/xOffset" value="0"/>
    <property key="labeling/yOffset" value="0"/>
    <property key="labeling/zIndex" value="0"/>
    <property key="variableNames" value="_fields_"/>
    <property key="variableValues" value=""/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerTransparency>0</layerTransparency>
  <displayfield>CARRETERA  [% "Matricula" %]</displayfield>
  <label>0</label>
  <labelattributes>
    <label fieldname="" text="Etiqueta"/>
    <family fieldname="" name="MS Shell Dlg 2"/>
    <size fieldname="" units="pt" value="12"/>
    <bold fieldname="" on="0"/>
    <italic fieldname="" on="0"/>
    <underline fieldname="" on="0"/>
    <strikeout fieldname="" on="0"/>
    <color fieldname="" red="0" blue="0" green="0"/>
    <x fieldname=""/>
    <y fieldname=""/>
    <offset x="0" y="0" units="pt" yfieldname="" xfieldname=""/>
    <angle fieldname="" value="0" auto="0"/>
    <alignment fieldname="" value="center"/>
    <buffercolor fieldname="" red="255" blue="255" green="255"/>
    <buffersize fieldname="" units="pt" value="1"/>
    <bufferenabled fieldname="" on=""/>
    <multilineenabled fieldname="" on=""/>
    <selectedonly on=""/>
  </labelattributes>
  <SingleCategoryDiagramRenderer diagramType="Pie">
    <DiagramCategory penColor="#000000" labelPlacementMethod="XHeight" penWidth="0" diagramOrientation="Up" minimumSize="0" barWidth="5" penAlpha="255" maxScaleDenominator="1e+08" backgroundColor="#ffffff" transparency="0" width="15" scaleDependency="Area" backgroundAlpha="255" angleOffset="1440" scaleBasedVisibility="0" enabled="0" height="15" sizeType="MM" minScaleDenominator="0">
      <fontProperties description="MS Shell Dlg 2,7.8,-1,5,50,0,0,0,0,0" style=""/>
      <attribute field="" color="#000000" label=""/>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings yPosColumn="-1" linePlacementFlags="10" placement="2" dist="0" xPosColumn="-1" priority="0" obstacle="0" zIndex="0" showAll="1"/>
  <annotationform>P:/permisos/Documentacion/Exptes_Varios/Año_2013/datos/QSIG</annotationform>
  <excludeAttributesWMS/>
  <excludeAttributesWFS/>
  <attributeactions>
    <actionsetting action="## IDENTIFICA CARRETERA&#xa;TITULO=&quot;IDENTIFICAR CARRETERA&quot;;&#xa;MENSAJE=&quot;Carretera -  [% &quot;Matricula&quot; %]\n\nRED:[% &quot;Titularida&quot; %]  FUNCIONALIDAD:[% &quot;Funcionali&quot; %]\nPK Ini:[%format_number( &quot;PkINI&quot; ,1)%] -  PK Fin:[%format_number( &quot;PkFIN&quot; ,1)%]  LONG= [% format_number($length,2) %]m.\nDenominacion -  [% &quot;Denominaci&quot; %]&quot;;&#xa;QtGui.QMessageBox.information(None, TITULO, MENSAJE)&#xa;" icon="" capture="1" type="1" name="IDENTIFICA CARRETERA"/>
    <actionsetting action="QtGui.QMessageBox.information(None, &quot;Coordenadas&quot;, &quot;Capa: [% $layerid %]\n&quot;,&quot;Coords: X= [% format_number($clickx,2) %] , Y= [% format_number($clicky,2) %]&quot;)" icon="" capture="0" type="1" name="Coordenadas pinchadas (Herramienta ejecutar acciones de objetos espaciales)"/>
    <actionsetting action="QtGui.QMessageBox.information(None, &quot;Coordenadas&quot;,&quot;Coords: X= [% format_number($clickx,2) %] , Y= [% format_number($clicky,2) %]&quot;)" icon="" capture="0" type="1" name="OBTENER DISTANCIA EN LA RUTA"/>
    <actionsetting action="QString text = QInputDialog::getText(this, tr(&quot;QInputDialog::getText()&quot;),&#xa;                                         tr(&quot;User name:&quot;), QLineEdit::Normal,&#xa;                                         QDir::home().dirName(), &amp;ok);&#xa;&#xa;&#xa;" icon="" capture="0" type="1" name="PRUEBA MENSAJE TEXTO"/>
    <actionsetting action="QtGui.QMessageBox.Information([parent=None[, f=0]],&quot;Carretera&quot;,&quot;Carretera -  [% &quot;Matricula&quot; %]\n\nRED:[% &quot;Titularida&quot; %]  FUNCIONALIDAD:[% &quot;Funcionali&quot; %]\nPK Ini:[%format_number( &quot;PkINI&quot; ,1)%] -  PK Fin:[%format_number( &quot;PkFIN&quot; ,1)%]  LONG= [% format_number($length,2) %]m.\nDenominacion -  [% &quot;Denominaci&quot; %]&quot;,&quot;OK&quot;)&#xa;" icon="" capture="0" type="1" name="PRUEBA MENSAJE TEXTO 2"/>
  </attributeactions>
  <editform>P:/permisos/Documentacion/Exptes_Varios/Año_2013/datos/QSIG</editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from PyQt4.QtGui import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <widgets/>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <layerGeometryType>1</layerGeometryType>
</qgis>
