<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis labelsEnabled="1" maxScale="0" simplifyAlgorithm="0" hasScaleBasedVisibilityFlag="0" readOnly="0" simplifyLocal="1" minScale="100000000" simplifyDrawingHints="1" styleCategories="AllStyleCategories" simplifyDrawingTol="1" version="3.34.10-Prizren" simplifyMaxScale="1" symbologyReferenceScale="-1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endExpression="" fixedDuration="0" endField="" enabled="0" startField="" mode="0" durationField="supcat" startExpression="" limitMode="0" durationUnit="min" accumulate="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation zscale="1" respectLayerSymbol="1" zoffset="0" binding="Centroid" type="IndividualFeatures" extrusion="0" symbology="Line" clamping="Terrain" showMarkerSymbolInSurfacePlots="0" extrusionEnabled="0">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol type="line" clip_to_extent="1" frame_rate="10" alpha="1" force_rhr="0" name="" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{ef0fd0da-66fa-40aa-b437-07ae9d3ca058}" locked="0" pass="0" class="SimpleLine">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="196,60,57,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.6" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol type="fill" clip_to_extent="1" frame_rate="10" alpha="1" force_rhr="0" name="" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{0f3f8b96-3aac-497f-91c5-ee3bb130859a}" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="196,60,57,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="140,43,41,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol type="marker" clip_to_extent="1" frame_rate="10" alpha="1" force_rhr="0" name="" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{beabd8f4-dd69-4a14-bc9b-cde21ffed3fa}" locked="0" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="square" name="cap_style"/>
            <Option type="QString" value="196,60,57,255" name="color"/>
            <Option type="QString" value="1" name="horizontal_anchor_point"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="diamond" name="name"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="140,43,41,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="diameter" name="scale_method"/>
            <Option type="QString" value="3" name="size"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
            <Option type="QString" value="MM" name="size_unit"/>
            <Option type="QString" value="1" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 type="RuleRenderer" symbollevels="1" enableorderby="0" referencescale="-1" forceraster="0">
    <rules key="{b724590d-289f-4eb1-9be7-45fdf99ffbc3}">
      <rule filter="&quot;TIPORES&quot; =  'EXPRO' " symbol="0" label="Parte EXPROPIADA" key="{fb2e639a-eb25-4858-881e-6f36d945d65c}"/>
      <rule filter="&quot;TIPORES&quot; = 'RESTO'" symbol="1" label="RESTO PARCELA" key="{21b256f5-d7dd-428e-bd37-c413e1b874c8}"/>
      <rule filter="ELSE" symbol="2" key="{bdf13054-715f-46b4-a216-2269145b5da6}"/>
    </rules>
    <symbols>
      <symbol type="fill" clip_to_extent="1" frame_rate="10" alpha="1" force_rhr="0" name="0" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{d914137b-574a-409b-8e9b-158bad8e7e58}" locked="0" pass="1" class="SimpleFill">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="72,255,0,51" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="1,13,255,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.4" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="fill" clip_to_extent="1" frame_rate="10" alpha="1" force_rhr="0" name="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{a65f0054-0ea2-4924-90e4-9eff8be44721}" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="255,249,124,51" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="255,149,1,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.4" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="fill" clip_to_extent="1" frame_rate="10" alpha="1" force_rhr="0" name="2" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{8d196ccb-4651-4d65-9c25-bb7d6f16343d}" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="243,166,178,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="35,35,35,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.26" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol type="fill" clip_to_extent="1" frame_rate="10" alpha="1" force_rhr="0" name="" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{eac64f5b-f77b-4006-bbcf-2ad50657066c}" locked="0" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="0,0,255,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="35,35,35,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.26" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style previewBkgrdColor="0,0,0,255" useSubstitutions="0" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" fontStrikeout="0" isExpression="0" allowHtml="0" fontSize="7" capitalization="0" forcedBold="0" fontKerning="1" multilineHeightUnit="Percentage" fontItalic="0" namedStyle="Normal" fontLetterSpacing="0" fontUnderline="0" fieldName="RC14" blendMode="0" forcedItalic="0" fontWeight="50" multilineHeight="1" legendString="Aa" textOpacity="1" textColor="31,120,180,255" fontWordSpacing="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="Point">
        <families/>
        <text-buffer bufferNoFill="0" bufferJoinStyle="64" bufferDraw="1" bufferSize="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferColor="255,255,255,255" bufferBlendMode="0" bufferOpacity="1"/>
        <text-mask maskSize="1.5" maskedSymbolLayers="" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskJoinStyle="128" maskSize2="1.5" maskSizeUnits="MM" maskOpacity="1" maskType="0"/>
        <background shapeBlendMode="0" shapeSVGFile="" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="Point" shapeFillColor="255,255,255,255" shapeOffsetX="0" shapeBorderWidth="0" shapeRadiiX="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeRotation="0" shapeRadiiY="0" shapeOffsetUnit="MM" shapeBorderColor="31,120,180,255" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeType="0" shapeSizeY="0" shapeDraw="1" shapeOpacity="1">
          <symbol type="marker" clip_to_extent="1" frame_rate="10" alpha="1" force_rhr="0" name="markerSymbol" is_animated="0">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name"/>
                <Option name="properties"/>
                <Option type="QString" value="collection" name="type"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" id="" locked="0" pass="0" class="SimpleMarker">
              <Option type="Map">
                <Option type="QString" value="0" name="angle"/>
                <Option type="QString" value="square" name="cap_style"/>
                <Option type="QString" value="231,113,72,255" name="color"/>
                <Option type="QString" value="1" name="horizontal_anchor_point"/>
                <Option type="QString" value="bevel" name="joinstyle"/>
                <Option type="QString" value="circle" name="name"/>
                <Option type="QString" value="0,0" name="offset"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="35,35,35,255" name="outline_color"/>
                <Option type="QString" value="solid" name="outline_style"/>
                <Option type="QString" value="0" name="outline_width"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                <Option type="QString" value="MM" name="outline_width_unit"/>
                <Option type="QString" value="diameter" name="scale_method"/>
                <Option type="QString" value="2" name="size"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                <Option type="QString" value="MM" name="size_unit"/>
                <Option type="QString" value="1" name="vertical_anchor_point"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name"/>
                  <Option name="properties"/>
                  <Option type="QString" value="collection" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol type="fill" clip_to_extent="1" frame_rate="10" alpha="1" force_rhr="0" name="fillSymbol" is_animated="0">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name"/>
                <Option name="properties"/>
                <Option type="QString" value="collection" name="type"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" id="" locked="0" pass="0" class="SimpleFill">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                <Option type="QString" value="255,255,255,255" name="color"/>
                <Option type="QString" value="bevel" name="joinstyle"/>
                <Option type="QString" value="0,0" name="offset"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="31,120,180,255" name="outline_color"/>
                <Option type="QString" value="no" name="outline_style"/>
                <Option type="QString" value="0" name="outline_width"/>
                <Option type="QString" value="MM" name="outline_width_unit"/>
                <Option type="QString" value="solid" name="style"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name"/>
                  <Option name="properties"/>
                  <Option type="QString" value="collection" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowRadiusAlphaOnly="0" shadowOffsetDist="1" shadowOffsetUnit="MM" shadowRadiusUnit="MM" shadowOffsetAngle="135" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowRadius="0" shadowColor="0,0,0,255" shadowUnder="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOpacity="0" shadowScale="100" shadowBlendMode="6" shadowOffsetGlobal="1"/>
        <dd_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format placeDirectionSymbol="0" addDirectionSymbol="0" leftDirectionSymbol="&lt;" reverseDirectionSymbol="0" wrapChar="" autoWrapLength="0" useMaxLineLengthForAutoWrap="1" decimals="3" rightDirectionSymbol=">" plussign="0" multilineAlign="1" formatNumbers="0"/>
      <placement xOffset="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" priority="3" fitInPolygonOnly="0" placement="1" preserveRotation="1" placementFlags="10" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" geometryGeneratorType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" centroidInside="0" layerType="PolygonGeometry" overrunDistanceUnit="MM" offsetType="0" repeatDistance="0" distUnits="MM" yOffset="0" quadOffset="4" lineAnchorClipping="0" rotationUnit="AngleDegrees" centroidWhole="0" overlapHandling="PreventOverlap" repeatDistanceUnits="MM" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="0" geometryGenerator="" allowDegraded="0" offsetUnits="MapUnit" lineAnchorType="0" geometryGeneratorEnabled="0" lineAnchorTextPoint="CenterOfText" polygonPlacementFlags="2" maxCurvedCharAngleIn="20" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-20" rotationAngle="0" overrunDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
      <rendering obstacleFactor="1" fontMaxPixelSize="10000" upsidedownLabels="0" scaleVisibility="1" mergeLines="0" limitNumLabels="0" fontLimitPixelSize="0" fontMinPixelSize="3" scaleMax="5001" obstacleType="0" scaleMin="1" zIndex="-2" obstacle="1" unplacedVisibility="0" maxNumLabels="2000" minFeatureSize="0" labelPerPart="0" drawLabels="1"/>
      <dd_properties>
        <Option type="Map">
          <Option type="QString" value="" name="name"/>
          <Option type="Map" name="properties">
            <Option type="Map" name="Color">
              <Option type="bool" value="true" name="active"/>
              <Option type="QString" value="if(  &quot;TIPORES&quot; = 'RESTO' , color_rgb(255,158,23) , color_rgb (0,0,255))" name="expression"/>
              <Option type="int" value="3" name="type"/>
            </Option>
            <Option type="Map" name="Hali">
              <Option type="bool" value="true" name="active"/>
              <Option type="QString" value="'Center'" name="expression"/>
              <Option type="int" value="3" name="type"/>
            </Option>
            <Option type="Map" name="PositionX">
              <Option type="bool" value="false" name="active"/>
              <Option type="int" value="1" name="type"/>
              <Option type="QString" value="" name="val"/>
            </Option>
            <Option type="Map" name="PositionY">
              <Option type="bool" value="false" name="active"/>
              <Option type="int" value="1" name="type"/>
              <Option type="QString" value="" name="val"/>
            </Option>
            <Option type="Map" name="ShapeFillColor">
              <Option type="bool" value="true" name="active"/>
              <Option type="QString" value="if(  ( &quot;TIPORES&quot;  = 'EXPRO'), color_rgb( 255,255,255),color_rgb( 255,255,150))" name="expression"/>
              <Option type="int" value="3" name="type"/>
            </Option>
            <Option type="Map" name="Vali">
              <Option type="bool" value="true" name="active"/>
              <Option type="QString" value="'Center'" name="expression"/>
              <Option type="int" value="3" name="type"/>
            </Option>
          </Option>
          <Option type="QString" value="collection" name="type"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
          <Option type="int" value="0" name="blendMode"/>
          <Option type="Map" name="ddProperties">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
          <Option type="bool" value="true" name="drawToAllParts"/>
          <Option type="QString" value="0" name="enabled"/>
          <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
          <Option type="QString" value="&lt;symbol type=&quot;line&quot; clip_to_extent=&quot;1&quot; frame_rate=&quot;10&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; id=&quot;{4d0d1bd0-c4bb-4e23-9808-3397adca6f97}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
          <Option type="double" value="0" name="minLength"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
          <Option type="QString" value="MM" name="minLengthUnit"/>
          <Option type="double" value="0" name="offsetFromAnchor"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
          <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
          <Option type="double" value="0" name="offsetFromLabel"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
          <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option type="bool" value="false" name="OnConvertFormatRegeneratePrimaryKey"/>
      <Option type="QString" value="no_action" name="QFieldSync/action"/>
      <Option type="QString" value="{}" name="QFieldSync/attachment_naming"/>
      <Option type="QString" value="offline" name="QFieldSync/cloud_action"/>
      <Option type="QString" value="" name="QFieldSync/geometry_locked_expression"/>
      <Option type="QString" value="{}" name="QFieldSync/photo_naming"/>
      <Option type="QString" value="{}" name="QFieldSync/relationship_maximum_visible"/>
      <Option type="int" value="30" name="QFieldSync/tracking_distance_requirement_minimum_meters"/>
      <Option type="int" value="1" name="QFieldSync/tracking_erroneous_distance_safeguard_maximum_meters"/>
      <Option type="int" value="0" name="QFieldSync/tracking_measurement_type"/>
      <Option type="int" value="30" name="QFieldSync/tracking_time_requirement_interval_seconds"/>
      <Option type="int" value="0" name="QFieldSync/value_map_button_interface_threshold"/>
      <Option type="List" name="dualview/previewExpressions">
        <Option type="QString" value="&quot;RC14&quot;"/>
      </Option>
      <Option type="int" value="0" name="embeddedWidgets/count"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory maxScaleDenominator="1e+08" sizeType="MM" width="15" minimumSize="0" rotationOffset="270" spacingUnitScale="3x:0,0,0,0,0,0" enabled="0" height="15" lineSizeScale="3x:0,0,0,0,0,0" penWidth="0" barWidth="5" lineSizeType="MM" backgroundAlpha="255" scaleDependency="Area" spacing="5" penAlpha="255" minScaleDenominator="0" labelPlacementMethod="XHeight" spacingUnit="MM" direction="0" backgroundColor="#ffffff" sizeScale="3x:0,0,0,0,0,0" showAxis="1" opacity="1" scaleBasedVisibility="0" diagramOrientation="Up" penColor="#000000">
      <fontProperties italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      <attribute field="" color="#000000" colorOpacity="1" label=""/>
      <axisSymbol>
        <symbol type="line" clip_to_extent="1" frame_rate="10" alpha="1" force_rhr="0" name="" is_animated="0">
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
          <layer enabled="1" id="{712fa802-cc08-430d-97cb-9ace9258504e}" locked="0" pass="0" class="SimpleLine">
            <Option type="Map">
              <Option type="QString" value="0" name="align_dash_pattern"/>
              <Option type="QString" value="square" name="capstyle"/>
              <Option type="QString" value="5;2" name="customdash"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
              <Option type="QString" value="MM" name="customdash_unit"/>
              <Option type="QString" value="0" name="dash_pattern_offset"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
              <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
              <Option type="QString" value="0" name="draw_inside_polygon"/>
              <Option type="QString" value="bevel" name="joinstyle"/>
              <Option type="QString" value="35,35,35,255" name="line_color"/>
              <Option type="QString" value="solid" name="line_style"/>
              <Option type="QString" value="0.26" name="line_width"/>
              <Option type="QString" value="MM" name="line_width_unit"/>
              <Option type="QString" value="0" name="offset"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
              <Option type="QString" value="MM" name="offset_unit"/>
              <Option type="QString" value="0" name="ring_filter"/>
              <Option type="QString" value="0" name="trim_distance_end"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
              <Option type="QString" value="MM" name="trim_distance_end_unit"/>
              <Option type="QString" value="0" name="trim_distance_start"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
              <Option type="QString" value="MM" name="trim_distance_start_unit"/>
              <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
              <Option type="QString" value="0" name="use_custom_dash"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name"/>
                <Option name="properties"/>
                <Option type="QString" value="collection" name="type"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings placement="1" obstacle="0" showAll="1" zIndex="0" dist="0" priority="0" linePlacementFlags="18">
    <properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option type="Map" name="QgsGeometryGapCheck">
        <Option type="double" value="0" name="allowedGapsBuffer"/>
        <Option type="bool" value="false" name="allowedGapsEnabled"/>
        <Option type="QString" value="" name="allowedGapsLayer"/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="no_orden" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="EXPEDIENTE" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="term_munic" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="cod_term_m" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="pedanía" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="pol" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="par" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="subpar" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="RC14" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dirfinca" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="paraje" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="uso" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="concepto" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="tipopropi" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="supcat" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="calificacion" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="superfpd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="valorunitpd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="importepd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="superfot" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="valorunitot" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="importeot" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="superfsp" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="valorunitsp" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="importesp" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="superfsv" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="valorunitsv" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="importesv" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="TIPORES" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CAT_NMSPC" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="AREA_PARTE" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" value="false" name="IsMultiline"/>
            <Option type="bool" value="false" name="UseHtml"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="X_LABEL" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Y_LABEL" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="AREA" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="no_orden" name="" index="0"/>
    <alias field="EXPEDIENTE" name="" index="1"/>
    <alias field="term_munic" name="" index="2"/>
    <alias field="cod_term_m" name="" index="3"/>
    <alias field="pedanía" name="" index="4"/>
    <alias field="pol" name="" index="5"/>
    <alias field="par" name="" index="6"/>
    <alias field="subpar" name="" index="7"/>
    <alias field="RC14" name="" index="8"/>
    <alias field="dirfinca" name="" index="9"/>
    <alias field="paraje" name="" index="10"/>
    <alias field="uso" name="" index="11"/>
    <alias field="concepto" name="" index="12"/>
    <alias field="tipopropi" name="" index="13"/>
    <alias field="supcat" name="" index="14"/>
    <alias field="calificacion" name="" index="15"/>
    <alias field="superfpd" name="" index="16"/>
    <alias field="valorunitpd" name="" index="17"/>
    <alias field="importepd" name="" index="18"/>
    <alias field="superfot" name="" index="19"/>
    <alias field="valorunitot" name="" index="20"/>
    <alias field="importeot" name="" index="21"/>
    <alias field="superfsp" name="" index="22"/>
    <alias field="valorunitsp" name="" index="23"/>
    <alias field="importesp" name="" index="24"/>
    <alias field="superfsv" name="" index="25"/>
    <alias field="valorunitsv" name="" index="26"/>
    <alias field="importesv" name="" index="27"/>
    <alias field="TIPORES" name="" index="28"/>
    <alias field="CAT_NMSPC" name="" index="29"/>
    <alias field="AREA_PARTE" name="" index="30"/>
    <alias field="X_LABEL" name="" index="31"/>
    <alias field="Y_LABEL" name="" index="32"/>
    <alias field="AREA" name="" index="33"/>
  </aliases>
  <splitPolicies>
    <policy field="no_orden" policy="Duplicate"/>
    <policy field="EXPEDIENTE" policy="Duplicate"/>
    <policy field="term_munic" policy="Duplicate"/>
    <policy field="cod_term_m" policy="Duplicate"/>
    <policy field="pedanía" policy="Duplicate"/>
    <policy field="pol" policy="Duplicate"/>
    <policy field="par" policy="Duplicate"/>
    <policy field="subpar" policy="Duplicate"/>
    <policy field="RC14" policy="Duplicate"/>
    <policy field="dirfinca" policy="Duplicate"/>
    <policy field="paraje" policy="Duplicate"/>
    <policy field="uso" policy="Duplicate"/>
    <policy field="concepto" policy="Duplicate"/>
    <policy field="tipopropi" policy="Duplicate"/>
    <policy field="supcat" policy="Duplicate"/>
    <policy field="calificacion" policy="Duplicate"/>
    <policy field="superfpd" policy="Duplicate"/>
    <policy field="valorunitpd" policy="Duplicate"/>
    <policy field="importepd" policy="Duplicate"/>
    <policy field="superfot" policy="Duplicate"/>
    <policy field="valorunitot" policy="Duplicate"/>
    <policy field="importeot" policy="Duplicate"/>
    <policy field="superfsp" policy="Duplicate"/>
    <policy field="valorunitsp" policy="Duplicate"/>
    <policy field="importesp" policy="Duplicate"/>
    <policy field="superfsv" policy="Duplicate"/>
    <policy field="valorunitsv" policy="Duplicate"/>
    <policy field="importesv" policy="Duplicate"/>
    <policy field="TIPORES" policy="Duplicate"/>
    <policy field="CAT_NMSPC" policy="Duplicate"/>
    <policy field="AREA_PARTE" policy="Duplicate"/>
    <policy field="X_LABEL" policy="Duplicate"/>
    <policy field="Y_LABEL" policy="Duplicate"/>
    <policy field="AREA" policy="Duplicate"/>
  </splitPolicies>
  <defaults>
    <default expression="" field="no_orden" applyOnUpdate="0"/>
    <default expression="" field="EXPEDIENTE" applyOnUpdate="0"/>
    <default expression="" field="term_munic" applyOnUpdate="0"/>
    <default expression="" field="cod_term_m" applyOnUpdate="0"/>
    <default expression="" field="pedanía" applyOnUpdate="0"/>
    <default expression="" field="pol" applyOnUpdate="0"/>
    <default expression="" field="par" applyOnUpdate="0"/>
    <default expression="" field="subpar" applyOnUpdate="0"/>
    <default expression="" field="RC14" applyOnUpdate="0"/>
    <default expression="" field="dirfinca" applyOnUpdate="0"/>
    <default expression="" field="paraje" applyOnUpdate="0"/>
    <default expression="" field="uso" applyOnUpdate="0"/>
    <default expression="" field="concepto" applyOnUpdate="0"/>
    <default expression="" field="tipopropi" applyOnUpdate="0"/>
    <default expression="" field="supcat" applyOnUpdate="0"/>
    <default expression="" field="calificacion" applyOnUpdate="0"/>
    <default expression="" field="superfpd" applyOnUpdate="0"/>
    <default expression="" field="valorunitpd" applyOnUpdate="0"/>
    <default expression="" field="importepd" applyOnUpdate="0"/>
    <default expression="" field="superfot" applyOnUpdate="0"/>
    <default expression="" field="valorunitot" applyOnUpdate="0"/>
    <default expression="" field="importeot" applyOnUpdate="0"/>
    <default expression="" field="superfsp" applyOnUpdate="0"/>
    <default expression="" field="valorunitsp" applyOnUpdate="0"/>
    <default expression="" field="importesp" applyOnUpdate="0"/>
    <default expression="" field="superfsv" applyOnUpdate="0"/>
    <default expression="" field="valorunitsv" applyOnUpdate="0"/>
    <default expression="" field="importesv" applyOnUpdate="0"/>
    <default expression="" field="TIPORES" applyOnUpdate="0"/>
    <default expression="" field="CAT_NMSPC" applyOnUpdate="0"/>
    <default expression="" field="AREA_PARTE" applyOnUpdate="0"/>
    <default expression="" field="X_LABEL" applyOnUpdate="0"/>
    <default expression="" field="Y_LABEL" applyOnUpdate="0"/>
    <default expression="" field="AREA" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="no_orden" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="EXPEDIENTE" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="term_munic" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="cod_term_m" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="pedanía" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="pol" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="par" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="subpar" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="RC14" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="dirfinca" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="paraje" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="uso" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="concepto" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="tipopropi" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="supcat" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="calificacion" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="superfpd" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="valorunitpd" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="importepd" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="superfot" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="valorunitot" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="importeot" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="superfsp" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="valorunitsp" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="importesp" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="superfsv" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="valorunitsv" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="importesv" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="TIPORES" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="CAT_NMSPC" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="AREA_PARTE" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="X_LABEL" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="Y_LABEL" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint field="AREA" constraints="0" notnull_strength="0" unique_strength="0" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="no_orden" desc="" exp=""/>
    <constraint field="EXPEDIENTE" desc="" exp=""/>
    <constraint field="term_munic" desc="" exp=""/>
    <constraint field="cod_term_m" desc="" exp=""/>
    <constraint field="pedanía" desc="" exp=""/>
    <constraint field="pol" desc="" exp=""/>
    <constraint field="par" desc="" exp=""/>
    <constraint field="subpar" desc="" exp=""/>
    <constraint field="RC14" desc="" exp=""/>
    <constraint field="dirfinca" desc="" exp=""/>
    <constraint field="paraje" desc="" exp=""/>
    <constraint field="uso" desc="" exp=""/>
    <constraint field="concepto" desc="" exp=""/>
    <constraint field="tipopropi" desc="" exp=""/>
    <constraint field="supcat" desc="" exp=""/>
    <constraint field="calificacion" desc="" exp=""/>
    <constraint field="superfpd" desc="" exp=""/>
    <constraint field="valorunitpd" desc="" exp=""/>
    <constraint field="importepd" desc="" exp=""/>
    <constraint field="superfot" desc="" exp=""/>
    <constraint field="valorunitot" desc="" exp=""/>
    <constraint field="importeot" desc="" exp=""/>
    <constraint field="superfsp" desc="" exp=""/>
    <constraint field="valorunitsp" desc="" exp=""/>
    <constraint field="importesp" desc="" exp=""/>
    <constraint field="superfsv" desc="" exp=""/>
    <constraint field="valorunitsv" desc="" exp=""/>
    <constraint field="importesv" desc="" exp=""/>
    <constraint field="TIPORES" desc="" exp=""/>
    <constraint field="CAT_NMSPC" desc="" exp=""/>
    <constraint field="AREA_PARTE" desc="" exp=""/>
    <constraint field="X_LABEL" desc="" exp=""/>
    <constraint field="Y_LABEL" desc="" exp=""/>
    <constraint field="AREA" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="&quot;AREA_PARTE&quot;" sortOrder="0">
    <columns>
      <column type="field" hidden="0" name="RC14" width="164"/>
      <column type="field" hidden="0" name="CAT_NMSPC" width="121"/>
      <column type="field" hidden="0" name="TIPORES" width="-1"/>
      <column type="field" hidden="0" name="AREA" width="-1"/>
      <column type="field" hidden="0" name="supcat" width="-1"/>
      <column type="field" hidden="0" name="AREA_PARTE" width="100"/>
      <column type="field" hidden="0" name="term_munic" width="-1"/>
      <column type="field" hidden="0" name="no_orden" width="-1"/>
      <column type="field" hidden="0" name="EXPEDIENTE" width="-1"/>
      <column type="field" hidden="0" name="cod_term_m" width="-1"/>
      <column type="field" hidden="0" name="pedanía" width="-1"/>
      <column type="field" hidden="0" name="pol" width="-1"/>
      <column type="field" hidden="0" name="par" width="-1"/>
      <column type="field" hidden="0" name="subpar" width="-1"/>
      <column type="field" hidden="0" name="dirfinca" width="-1"/>
      <column type="field" hidden="0" name="paraje" width="-1"/>
      <column type="field" hidden="0" name="uso" width="-1"/>
      <column type="field" hidden="0" name="concepto" width="-1"/>
      <column type="field" hidden="0" name="tipopropi" width="-1"/>
      <column type="field" hidden="0" name="calificacion" width="-1"/>
      <column type="field" hidden="0" name="superfpd" width="-1"/>
      <column type="field" hidden="0" name="valorunitpd" width="-1"/>
      <column type="field" hidden="0" name="importepd" width="-1"/>
      <column type="field" hidden="0" name="superfot" width="-1"/>
      <column type="field" hidden="0" name="valorunitot" width="-1"/>
      <column type="field" hidden="0" name="importeot" width="-1"/>
      <column type="field" hidden="0" name="superfsp" width="-1"/>
      <column type="field" hidden="0" name="valorunitsp" width="-1"/>
      <column type="field" hidden="0" name="importesp" width="-1"/>
      <column type="field" hidden="0" name="superfsv" width="-1"/>
      <column type="field" hidden="0" name="valorunitsv" width="-1"/>
      <column type="field" hidden="0" name="importesv" width="-1"/>
      <column type="field" hidden="0" name="X_LABEL" width="-1"/>
      <column type="field" hidden="0" name="Y_LABEL" width="-1"/>
      <column type="actions" hidden="1" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- codificación: utf-8 -*-
"""
Los formularios de QGIS pueden tener una función de Python que
es llamada cuando se abre el formulario.

Use esta función para añadir lógica extra a sus formularios.

Introduzca el nombre de la función en el campo
"Python Init function".
Sigue un ejemplo:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
    </labelStyle>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="fid" index="-1">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="no_orden" index="0">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="EXPEDIENTE" index="1">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="term_munic" index="2">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="cod_term_m" index="3">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="pedanía" index="4">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="pol" index="5">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="par" index="6">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="subpar" index="7">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="uso" index="11">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="superfpd" index="16">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="SIGPAC_CULT" index="-1">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="TIPORES" index="28">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="RC14" index="8">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="calificacion" index="15">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="dirfinca" index="9">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="paraje" index="10">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField showLabel="1" verticalStretch="0" horizontalStretch="0" name="concepto" index="12">
      <labelStyle labelColor="0,0,0,255" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont italic="0" underline="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" strikethrough="0" style=""/>
      </labelStyle>
    </attributeEditorField>
  </attributeEditorForm>
  <editable>
    <field editable="1" name="AREA"/>
    <field editable="1" name="AREA_CALC"/>
    <field editable="1" name="AREA_PARTE"/>
    <field editable="1" name="BORRAR"/>
    <field editable="1" name="CAT_NMSPC"/>
    <field editable="1" name="COD_INE"/>
    <field editable="1" name="CONTROL"/>
    <field editable="1" name="COORX"/>
    <field editable="1" name="COORY"/>
    <field editable="1" name="DELEGACIO"/>
    <field editable="1" name="DIRECCION"/>
    <field editable="1" name="EJERCICIO"/>
    <field editable="1" name="EXPEDIENTE"/>
    <field editable="1" name="FECHAALTA"/>
    <field editable="1" name="FECHABAJA"/>
    <field editable="1" name="HOJA"/>
    <field editable="1" name="LEE_ACTAS PREVIAS"/>
    <field editable="1" name="LEE_CLAVE PROYECTO"/>
    <field editable="1" name="LEE_CORRECCION PLANOS"/>
    <field editable="1" name="LEE_CTRA"/>
    <field editable="1" name="LEE_CTRA ANT"/>
    <field editable="1" name="LEE_DECR_ACUE_RESO"/>
    <field editable="1" name="LEE_DIGITALIZADO"/>
    <field editable="1" name="LEE_DIRECTORIO PLANOS"/>
    <field editable="1" name="LEE_EMPRESA LEVANTAMIENTO"/>
    <field editable="1" name="LEE_FECHA_SERVCART"/>
    <field editable="1" name="LEE_GEORREFER"/>
    <field editable="1" name="LEE_LISTADOS"/>
    <field editable="1" name="LEE_METADATOS"/>
    <field editable="1" name="LEE_NOMBRE TRAMO"/>
    <field editable="1" name="LEE_NOM_REVISOR"/>
    <field editable="1" name="LEE_Nẃ ARCHIVO DATOS CAMPO"/>
    <field editable="1" name="LEE_Nẃ PROYECTO ARCH DELEG"/>
    <field editable="1" name="LEE_OBSERVACIONES"/>
    <field editable="1" name="LEE_P K FIN"/>
    <field editable="1" name="LEE_P K FIN ANT"/>
    <field editable="1" name="LEE_P K INI"/>
    <field editable="1" name="LEE_P K INI ANT"/>
    <field editable="1" name="LEE_PLANERO"/>
    <field editable="1" name="LEE_PLANOS PDF"/>
    <field editable="1" name="LEE_REMISION CATASTRO"/>
    <field editable="1" name="LEE_REVISADO EN SERVIDOR"/>
    <field editable="1" name="LEE_REV_DATOSCAD"/>
    <field editable="1" name="LEE_REV_DATOSCAMPO"/>
    <field editable="1" name="LEE_REV_DIRECTORIO"/>
    <field editable="1" name="LEE_SUST_SERVCART"/>
    <field editable="1" name="LEE_TERMINO_MUNICIPAL"/>
    <field editable="1" name="LEE_TIPO PROYECTO"/>
    <field editable="1" name="LEE_TITULO_EXPROPIACION"/>
    <field editable="1" name="LEE_fid"/>
    <field editable="1" name="LEE_nẃ ORDEN"/>
    <field editable="1" name="MAPA"/>
    <field editable="1" name="MASA"/>
    <field editable="1" name="MUNICIPIO"/>
    <field editable="1" name="NOM_MUNI"/>
    <field editable="1" name="NUMERO"/>
    <field editable="1" name="NUMERODUP"/>
    <field editable="1" name="NUMSYMBOL"/>
    <field editable="1" name="NUM_EXP"/>
    <field editable="1" name="NUM_VERT"/>
    <field editable="1" name="PARCELA"/>
    <field editable="1" name="PCAT1"/>
    <field editable="1" name="PCAT2"/>
    <field editable="1" name="PLANOS_ETRS89"/>
    <field editable="1" name="PROVINCIA"/>
    <field editable="1" name="RC14"/>
    <field editable="1" name="REF_CAT"/>
    <field editable="1" name="TIPO"/>
    <field editable="1" name="TIPORES"/>
    <field editable="1" name="VIA"/>
    <field editable="1" name="X_LABEL"/>
    <field editable="1" name="Y_LABEL"/>
    <field editable="1" name="acad_rev"/>
    <field editable="1" name="calificacion"/>
    <field editable="1" name="cat-remisi"/>
    <field editable="1" name="cat_RC"/>
    <field editable="1" name="cat_estado"/>
    <field editable="1" name="cat_nmspc_2"/>
    <field editable="1" name="cat_observ"/>
    <field editable="1" name="cod_term_m"/>
    <field editable="1" name="concepto"/>
    <field editable="1" name="ctra"/>
    <field editable="1" name="ctra_ant"/>
    <field editable="1" name="dir_doc"/>
    <field editable="1" name="dir_doc_b"/>
    <field editable="1" name="dirfinca"/>
    <field editable="1" name="expte1"/>
    <field editable="1" name="expte2"/>
    <field editable="1" name="expte3"/>
    <field editable="1" name="fid"/>
    <field editable="1" name="fid_2"/>
    <field editable="1" name="funcionali"/>
    <field editable="1" name="id_reg"/>
    <field editable="1" name="importeot"/>
    <field editable="1" name="importepd"/>
    <field editable="1" name="importesp"/>
    <field editable="1" name="importesv"/>
    <field editable="1" name="layer"/>
    <field editable="1" name="no_orden"/>
    <field editable="1" name="nom_proyec"/>
    <field editable="1" name="nom_tramo"/>
    <field editable="1" name="par"/>
    <field editable="1" name="paraje"/>
    <field editable="1" name="path"/>
    <field editable="1" name="pedanía"/>
    <field editable="1" name="pkfin"/>
    <field editable="1" name="pkfin_ant"/>
    <field editable="1" name="pkini"/>
    <field editable="1" name="pkini_ant"/>
    <field editable="1" name="pol"/>
    <field editable="1" name="provincia"/>
    <field editable="1" name="provincia_2"/>
    <field editable="1" name="provis"/>
    <field editable="1" name="rev_expte"/>
    <field editable="1" name="subpar"/>
    <field editable="1" name="supcat"/>
    <field editable="1" name="superficie"/>
    <field editable="1" name="superfot"/>
    <field editable="1" name="superfpd"/>
    <field editable="1" name="superfsp"/>
    <field editable="1" name="superfsv"/>
    <field editable="1" name="term_mucod"/>
    <field editable="1" name="term_munic"/>
    <field editable="1" name="tipopropi"/>
    <field editable="1" name="titularida"/>
    <field editable="1" name="uso"/>
    <field editable="1" name="valorunitot"/>
    <field editable="1" name="valorunitpd"/>
    <field editable="1" name="valorunitsp"/>
    <field editable="1" name="valorunitsv"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="AREA"/>
    <field labelOnTop="0" name="AREA_CALC"/>
    <field labelOnTop="0" name="AREA_PARTE"/>
    <field labelOnTop="0" name="BORRAR"/>
    <field labelOnTop="0" name="CAT_NMSPC"/>
    <field labelOnTop="0" name="COD_INE"/>
    <field labelOnTop="0" name="CONTROL"/>
    <field labelOnTop="0" name="COORX"/>
    <field labelOnTop="0" name="COORY"/>
    <field labelOnTop="0" name="DELEGACIO"/>
    <field labelOnTop="0" name="DIRECCION"/>
    <field labelOnTop="0" name="EJERCICIO"/>
    <field labelOnTop="0" name="EXPEDIENTE"/>
    <field labelOnTop="0" name="FECHAALTA"/>
    <field labelOnTop="0" name="FECHABAJA"/>
    <field labelOnTop="0" name="HOJA"/>
    <field labelOnTop="0" name="LEE_ACTAS PREVIAS"/>
    <field labelOnTop="0" name="LEE_CLAVE PROYECTO"/>
    <field labelOnTop="0" name="LEE_CORRECCION PLANOS"/>
    <field labelOnTop="0" name="LEE_CTRA"/>
    <field labelOnTop="0" name="LEE_CTRA ANT"/>
    <field labelOnTop="0" name="LEE_DECR_ACUE_RESO"/>
    <field labelOnTop="0" name="LEE_DIGITALIZADO"/>
    <field labelOnTop="0" name="LEE_DIRECTORIO PLANOS"/>
    <field labelOnTop="0" name="LEE_EMPRESA LEVANTAMIENTO"/>
    <field labelOnTop="0" name="LEE_FECHA_SERVCART"/>
    <field labelOnTop="0" name="LEE_GEORREFER"/>
    <field labelOnTop="0" name="LEE_LISTADOS"/>
    <field labelOnTop="0" name="LEE_METADATOS"/>
    <field labelOnTop="0" name="LEE_NOMBRE TRAMO"/>
    <field labelOnTop="0" name="LEE_NOM_REVISOR"/>
    <field labelOnTop="0" name="LEE_Nẃ ARCHIVO DATOS CAMPO"/>
    <field labelOnTop="0" name="LEE_Nẃ PROYECTO ARCH DELEG"/>
    <field labelOnTop="0" name="LEE_OBSERVACIONES"/>
    <field labelOnTop="0" name="LEE_P K FIN"/>
    <field labelOnTop="0" name="LEE_P K FIN ANT"/>
    <field labelOnTop="0" name="LEE_P K INI"/>
    <field labelOnTop="0" name="LEE_P K INI ANT"/>
    <field labelOnTop="0" name="LEE_PLANERO"/>
    <field labelOnTop="0" name="LEE_PLANOS PDF"/>
    <field labelOnTop="0" name="LEE_REMISION CATASTRO"/>
    <field labelOnTop="0" name="LEE_REVISADO EN SERVIDOR"/>
    <field labelOnTop="0" name="LEE_REV_DATOSCAD"/>
    <field labelOnTop="0" name="LEE_REV_DATOSCAMPO"/>
    <field labelOnTop="0" name="LEE_REV_DIRECTORIO"/>
    <field labelOnTop="0" name="LEE_SUST_SERVCART"/>
    <field labelOnTop="0" name="LEE_TERMINO_MUNICIPAL"/>
    <field labelOnTop="0" name="LEE_TIPO PROYECTO"/>
    <field labelOnTop="0" name="LEE_TITULO_EXPROPIACION"/>
    <field labelOnTop="0" name="LEE_fid"/>
    <field labelOnTop="0" name="LEE_nẃ ORDEN"/>
    <field labelOnTop="0" name="MAPA"/>
    <field labelOnTop="0" name="MASA"/>
    <field labelOnTop="0" name="MUNICIPIO"/>
    <field labelOnTop="0" name="NOM_MUNI"/>
    <field labelOnTop="0" name="NUMERO"/>
    <field labelOnTop="0" name="NUMERODUP"/>
    <field labelOnTop="0" name="NUMSYMBOL"/>
    <field labelOnTop="0" name="NUM_EXP"/>
    <field labelOnTop="0" name="NUM_VERT"/>
    <field labelOnTop="0" name="PARCELA"/>
    <field labelOnTop="0" name="PCAT1"/>
    <field labelOnTop="0" name="PCAT2"/>
    <field labelOnTop="0" name="PLANOS_ETRS89"/>
    <field labelOnTop="0" name="PROVINCIA"/>
    <field labelOnTop="0" name="RC14"/>
    <field labelOnTop="0" name="REF_CAT"/>
    <field labelOnTop="0" name="TIPO"/>
    <field labelOnTop="0" name="TIPORES"/>
    <field labelOnTop="0" name="VIA"/>
    <field labelOnTop="0" name="X_LABEL"/>
    <field labelOnTop="0" name="Y_LABEL"/>
    <field labelOnTop="0" name="acad_rev"/>
    <field labelOnTop="0" name="calificacion"/>
    <field labelOnTop="0" name="cat-remisi"/>
    <field labelOnTop="0" name="cat_RC"/>
    <field labelOnTop="0" name="cat_estado"/>
    <field labelOnTop="0" name="cat_nmspc_2"/>
    <field labelOnTop="0" name="cat_observ"/>
    <field labelOnTop="0" name="cod_term_m"/>
    <field labelOnTop="0" name="concepto"/>
    <field labelOnTop="0" name="ctra"/>
    <field labelOnTop="0" name="ctra_ant"/>
    <field labelOnTop="0" name="dir_doc"/>
    <field labelOnTop="0" name="dir_doc_b"/>
    <field labelOnTop="0" name="dirfinca"/>
    <field labelOnTop="0" name="expte1"/>
    <field labelOnTop="0" name="expte2"/>
    <field labelOnTop="0" name="expte3"/>
    <field labelOnTop="0" name="fid"/>
    <field labelOnTop="0" name="fid_2"/>
    <field labelOnTop="0" name="funcionali"/>
    <field labelOnTop="0" name="id_reg"/>
    <field labelOnTop="0" name="importeot"/>
    <field labelOnTop="0" name="importepd"/>
    <field labelOnTop="0" name="importesp"/>
    <field labelOnTop="0" name="importesv"/>
    <field labelOnTop="0" name="layer"/>
    <field labelOnTop="0" name="no_orden"/>
    <field labelOnTop="0" name="nom_proyec"/>
    <field labelOnTop="0" name="nom_tramo"/>
    <field labelOnTop="0" name="par"/>
    <field labelOnTop="0" name="paraje"/>
    <field labelOnTop="0" name="path"/>
    <field labelOnTop="0" name="pedanía"/>
    <field labelOnTop="0" name="pkfin"/>
    <field labelOnTop="0" name="pkfin_ant"/>
    <field labelOnTop="0" name="pkini"/>
    <field labelOnTop="0" name="pkini_ant"/>
    <field labelOnTop="0" name="pol"/>
    <field labelOnTop="0" name="provincia"/>
    <field labelOnTop="0" name="provincia_2"/>
    <field labelOnTop="0" name="provis"/>
    <field labelOnTop="0" name="rev_expte"/>
    <field labelOnTop="0" name="subpar"/>
    <field labelOnTop="0" name="supcat"/>
    <field labelOnTop="0" name="superficie"/>
    <field labelOnTop="0" name="superfot"/>
    <field labelOnTop="0" name="superfpd"/>
    <field labelOnTop="0" name="superfsp"/>
    <field labelOnTop="0" name="superfsv"/>
    <field labelOnTop="0" name="term_mucod"/>
    <field labelOnTop="0" name="term_munic"/>
    <field labelOnTop="0" name="tipopropi"/>
    <field labelOnTop="0" name="titularida"/>
    <field labelOnTop="0" name="uso"/>
    <field labelOnTop="0" name="valorunitot"/>
    <field labelOnTop="0" name="valorunitpd"/>
    <field labelOnTop="0" name="valorunitsp"/>
    <field labelOnTop="0" name="valorunitsv"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="AREA" reuseLastValue="0"/>
    <field name="AREA_CALC" reuseLastValue="0"/>
    <field name="AREA_PARTE" reuseLastValue="0"/>
    <field name="BORRAR" reuseLastValue="0"/>
    <field name="CAT_NMSPC" reuseLastValue="0"/>
    <field name="COD_INE" reuseLastValue="0"/>
    <field name="CONTROL" reuseLastValue="0"/>
    <field name="COORX" reuseLastValue="0"/>
    <field name="COORY" reuseLastValue="0"/>
    <field name="DELEGACIO" reuseLastValue="0"/>
    <field name="DIRECCION" reuseLastValue="0"/>
    <field name="EJERCICIO" reuseLastValue="0"/>
    <field name="EXPEDIENTE" reuseLastValue="0"/>
    <field name="FECHAALTA" reuseLastValue="0"/>
    <field name="FECHABAJA" reuseLastValue="0"/>
    <field name="HOJA" reuseLastValue="0"/>
    <field name="LEE_ACTAS PREVIAS" reuseLastValue="0"/>
    <field name="LEE_CLAVE PROYECTO" reuseLastValue="0"/>
    <field name="LEE_CORRECCION PLANOS" reuseLastValue="0"/>
    <field name="LEE_CTRA" reuseLastValue="0"/>
    <field name="LEE_CTRA ANT" reuseLastValue="0"/>
    <field name="LEE_DECR_ACUE_RESO" reuseLastValue="0"/>
    <field name="LEE_DIGITALIZADO" reuseLastValue="0"/>
    <field name="LEE_DIRECTORIO PLANOS" reuseLastValue="0"/>
    <field name="LEE_EMPRESA LEVANTAMIENTO" reuseLastValue="0"/>
    <field name="LEE_FECHA_SERVCART" reuseLastValue="0"/>
    <field name="LEE_GEORREFER" reuseLastValue="0"/>
    <field name="LEE_LISTADOS" reuseLastValue="0"/>
    <field name="LEE_METADATOS" reuseLastValue="0"/>
    <field name="LEE_NOMBRE TRAMO" reuseLastValue="0"/>
    <field name="LEE_NOM_REVISOR" reuseLastValue="0"/>
    <field name="LEE_Nẃ ARCHIVO DATOS CAMPO" reuseLastValue="0"/>
    <field name="LEE_Nẃ PROYECTO ARCH DELEG" reuseLastValue="0"/>
    <field name="LEE_OBSERVACIONES" reuseLastValue="0"/>
    <field name="LEE_P K FIN" reuseLastValue="0"/>
    <field name="LEE_P K FIN ANT" reuseLastValue="0"/>
    <field name="LEE_P K INI" reuseLastValue="0"/>
    <field name="LEE_P K INI ANT" reuseLastValue="0"/>
    <field name="LEE_PLANERO" reuseLastValue="0"/>
    <field name="LEE_PLANOS PDF" reuseLastValue="0"/>
    <field name="LEE_REMISION CATASTRO" reuseLastValue="0"/>
    <field name="LEE_REVISADO EN SERVIDOR" reuseLastValue="0"/>
    <field name="LEE_REV_DATOSCAD" reuseLastValue="0"/>
    <field name="LEE_REV_DATOSCAMPO" reuseLastValue="0"/>
    <field name="LEE_REV_DIRECTORIO" reuseLastValue="0"/>
    <field name="LEE_SUST_SERVCART" reuseLastValue="0"/>
    <field name="LEE_TERMINO_MUNICIPAL" reuseLastValue="0"/>
    <field name="LEE_TIPO PROYECTO" reuseLastValue="0"/>
    <field name="LEE_TITULO_EXPROPIACION" reuseLastValue="0"/>
    <field name="LEE_fid" reuseLastValue="0"/>
    <field name="LEE_nẃ ORDEN" reuseLastValue="0"/>
    <field name="MAPA" reuseLastValue="0"/>
    <field name="MASA" reuseLastValue="0"/>
    <field name="MUNICIPIO" reuseLastValue="0"/>
    <field name="NOM_MUNI" reuseLastValue="0"/>
    <field name="NUMERO" reuseLastValue="0"/>
    <field name="NUMERODUP" reuseLastValue="0"/>
    <field name="NUMSYMBOL" reuseLastValue="0"/>
    <field name="NUM_EXP" reuseLastValue="0"/>
    <field name="NUM_VERT" reuseLastValue="0"/>
    <field name="PARCELA" reuseLastValue="0"/>
    <field name="PCAT1" reuseLastValue="0"/>
    <field name="PCAT2" reuseLastValue="0"/>
    <field name="PLANOS_ETRS89" reuseLastValue="0"/>
    <field name="PROVINCIA" reuseLastValue="0"/>
    <field name="RC14" reuseLastValue="0"/>
    <field name="REF_CAT" reuseLastValue="0"/>
    <field name="TIPO" reuseLastValue="0"/>
    <field name="TIPORES" reuseLastValue="0"/>
    <field name="VIA" reuseLastValue="0"/>
    <field name="X_LABEL" reuseLastValue="0"/>
    <field name="Y_LABEL" reuseLastValue="0"/>
    <field name="acad_rev" reuseLastValue="0"/>
    <field name="calificacion" reuseLastValue="0"/>
    <field name="cat-remisi" reuseLastValue="0"/>
    <field name="cat_RC" reuseLastValue="0"/>
    <field name="cat_estado" reuseLastValue="0"/>
    <field name="cat_nmspc_2" reuseLastValue="0"/>
    <field name="cat_observ" reuseLastValue="0"/>
    <field name="cod_term_m" reuseLastValue="0"/>
    <field name="concepto" reuseLastValue="0"/>
    <field name="ctra" reuseLastValue="0"/>
    <field name="ctra_ant" reuseLastValue="0"/>
    <field name="dir_doc" reuseLastValue="0"/>
    <field name="dir_doc_b" reuseLastValue="0"/>
    <field name="dirfinca" reuseLastValue="0"/>
    <field name="expte1" reuseLastValue="0"/>
    <field name="expte2" reuseLastValue="0"/>
    <field name="expte3" reuseLastValue="0"/>
    <field name="fid" reuseLastValue="0"/>
    <field name="fid_2" reuseLastValue="0"/>
    <field name="funcionali" reuseLastValue="0"/>
    <field name="id_reg" reuseLastValue="0"/>
    <field name="importeot" reuseLastValue="0"/>
    <field name="importepd" reuseLastValue="0"/>
    <field name="importesp" reuseLastValue="0"/>
    <field name="importesv" reuseLastValue="0"/>
    <field name="layer" reuseLastValue="0"/>
    <field name="no_orden" reuseLastValue="0"/>
    <field name="nom_proyec" reuseLastValue="0"/>
    <field name="nom_tramo" reuseLastValue="0"/>
    <field name="par" reuseLastValue="0"/>
    <field name="paraje" reuseLastValue="0"/>
    <field name="path" reuseLastValue="0"/>
    <field name="pedanía" reuseLastValue="0"/>
    <field name="pkfin" reuseLastValue="0"/>
    <field name="pkfin_ant" reuseLastValue="0"/>
    <field name="pkini" reuseLastValue="0"/>
    <field name="pkini_ant" reuseLastValue="0"/>
    <field name="pol" reuseLastValue="0"/>
    <field name="provincia" reuseLastValue="0"/>
    <field name="provincia_2" reuseLastValue="0"/>
    <field name="provis" reuseLastValue="0"/>
    <field name="rev_expte" reuseLastValue="0"/>
    <field name="subpar" reuseLastValue="0"/>
    <field name="supcat" reuseLastValue="0"/>
    <field name="superficie" reuseLastValue="0"/>
    <field name="superfot" reuseLastValue="0"/>
    <field name="superfpd" reuseLastValue="0"/>
    <field name="superfsp" reuseLastValue="0"/>
    <field name="superfsv" reuseLastValue="0"/>
    <field name="term_mucod" reuseLastValue="0"/>
    <field name="term_munic" reuseLastValue="0"/>
    <field name="tipopropi" reuseLastValue="0"/>
    <field name="titularida" reuseLastValue="0"/>
    <field name="uso" reuseLastValue="0"/>
    <field name="valorunitot" reuseLastValue="0"/>
    <field name="valorunitpd" reuseLastValue="0"/>
    <field name="valorunitsp" reuseLastValue="0"/>
    <field name="valorunitsv" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_Apellidos">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_Cultivo/1">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_Cultivo/2">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_Cultivo/3">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_D P">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_J P">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_Jurado">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_Justiprecio">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_Nombre">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_Parcela">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_Pol">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_Total Pts">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_Total m2">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_m2/1">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_m2/2">
      <config/>
    </widget>
    <widget name="98-054 Elche de la Sierra - Letur (Almazarán)_m2/3">
      <config/>
    </widget>
    <widget name="BDEXP_APEL">
      <config/>
    </widget>
    <widget name="BDEXP_APEL_C">
      <config/>
    </widget>
    <widget name="BDEXP_APEL_R">
      <config/>
    </widget>
    <widget name="BDEXP_CARTA">
      <config/>
    </widget>
    <widget name="BDEXP_CITA">
      <config/>
    </widget>
    <widget name="BDEXP_CLAVE">
      <config/>
    </widget>
    <widget name="BDEXP_CP">
      <config/>
    </widget>
    <widget name="BDEXP_CTA">
      <config/>
    </widget>
    <widget name="BDEXP_CULT1">
      <config/>
    </widget>
    <widget name="BDEXP_CULT2">
      <config/>
    </widget>
    <widget name="BDEXP_CULT3">
      <config/>
    </widget>
    <widget name="BDEXP_DEPOSITO">
      <config/>
    </widget>
    <widget name="BDEXP_DG">
      <config/>
    </widget>
    <widget name="BDEXP_DIA_PAGO">
      <config/>
    </widget>
    <widget name="BDEXP_DOMI">
      <config/>
    </widget>
    <widget name="BDEXP_E">
      <config/>
    </widget>
    <widget name="BDEXP_ENTI">
      <config/>
    </widget>
    <widget name="BDEXP_FECHA1">
      <config/>
    </widget>
    <widget name="BDEXP_FICHERO">
      <config/>
    </widget>
    <widget name="BDEXP_FINCA">
      <config/>
    </widget>
    <widget name="BDEXP_FOLIO">
      <config/>
    </widget>
    <widget name="BDEXP_HORA">
      <config/>
    </widget>
    <widget name="BDEXP_INS">
      <config/>
    </widget>
    <widget name="BDEXP_JURADO">
      <config/>
    </widget>
    <widget name="BDEXP_JUSTIPRECI">
      <config/>
    </widget>
    <widget name="BDEXP_LIBRO">
      <config/>
    </widget>
    <widget name="BDEXP_LOC">
      <config/>
    </widget>
    <widget name="BDEXP_M2_1">
      <config/>
    </widget>
    <widget name="BDEXP_M2_2">
      <config/>
    </widget>
    <widget name="BDEXP_M2_3">
      <config/>
    </widget>
    <widget name="BDEXP_N">
      <config/>
    </widget>
    <widget name="BDEXP_NIF">
      <config/>
    </widget>
    <widget name="BDEXP_NIF_C">
      <config/>
    </widget>
    <widget name="BDEXP_NIF_R">
      <config/>
    </widget>
    <widget name="BDEXP_NO">
      <config/>
    </widget>
    <widget name="BDEXP_NOM">
      <config/>
    </widget>
    <widget name="BDEXP_NOM_C">
      <config/>
    </widget>
    <widget name="BDEXP_NOM_R">
      <config/>
    </widget>
    <widget name="BDEXP_O">
      <config/>
    </widget>
    <widget name="BDEXP_OBS">
      <config/>
    </widget>
    <widget name="BDEXP_OFIC">
      <config/>
    </widget>
    <widget name="BDEXP_P1">
      <config/>
    </widget>
    <widget name="BDEXP_P2">
      <config/>
    </widget>
    <widget name="BDEXP_P3">
      <config/>
    </widget>
    <widget name="BDEXP_PAGO">
      <config/>
    </widget>
    <widget name="BDEXP_PAR">
      <config/>
    </widget>
    <widget name="BDEXP_POL">
      <config/>
    </widget>
    <widget name="BDEXP_PRV">
      <config/>
    </widget>
    <widget name="BDEXP_PTSM2_1">
      <config/>
    </widget>
    <widget name="BDEXP_PTSM2_2">
      <config/>
    </widget>
    <widget name="BDEXP_PTSM2_3">
      <config/>
    </widget>
    <widget name="BDEXP_PTSUND_1">
      <config/>
    </widget>
    <widget name="BDEXP_PTSUND_2">
      <config/>
    </widget>
    <widget name="BDEXP_PTSUND_3">
      <config/>
    </widget>
    <widget name="BDEXP_RG">
      <config/>
    </widget>
    <widget name="BDEXP_S">
      <config/>
    </widget>
    <widget name="BDEXP_TIT">
      <config/>
    </widget>
    <widget name="BDEXP_TM">
      <config/>
    </widget>
    <widget name="BDEXP_TOMO">
      <config/>
    </widget>
    <widget name="BDEXP_TOTAL_M2">
      <config/>
    </widget>
    <widget name="BDEXP_TOTAL_PTS">
      <config/>
    </widget>
    <widget name="BDEXP_UND_1">
      <config/>
    </widget>
    <widget name="BDEXP_UND_2">
      <config/>
    </widget>
    <widget name="BDEXP_UND_3">
      <config/>
    </widget>
    <widget name="BD_EXPRAPEL">
      <config/>
    </widget>
    <widget name="BD_EXPRAPEL_C">
      <config/>
    </widget>
    <widget name="BD_EXPRAPEL_R">
      <config/>
    </widget>
    <widget name="BD_EXPRCARTA">
      <config/>
    </widget>
    <widget name="BD_EXPRCITA">
      <config/>
    </widget>
    <widget name="BD_EXPRCLAVE">
      <config/>
    </widget>
    <widget name="BD_EXPRCP">
      <config/>
    </widget>
    <widget name="BD_EXPRCTA">
      <config/>
    </widget>
    <widget name="BD_EXPRCULT1">
      <config/>
    </widget>
    <widget name="BD_EXPRCULT2">
      <config/>
    </widget>
    <widget name="BD_EXPRCULT3">
      <config/>
    </widget>
    <widget name="BD_EXPRDEPOSITO">
      <config/>
    </widget>
    <widget name="BD_EXPRDG">
      <config/>
    </widget>
    <widget name="BD_EXPRDIA_PAGO">
      <config/>
    </widget>
    <widget name="BD_EXPRDOMI">
      <config/>
    </widget>
    <widget name="BD_EXPRE">
      <config/>
    </widget>
    <widget name="BD_EXPRENTI">
      <config/>
    </widget>
    <widget name="BD_EXPRFECHA1">
      <config/>
    </widget>
    <widget name="BD_EXPRFICHERO">
      <config/>
    </widget>
    <widget name="BD_EXPRFINCA">
      <config/>
    </widget>
    <widget name="BD_EXPRFOLIO">
      <config/>
    </widget>
    <widget name="BD_EXPRField66">
      <config/>
    </widget>
    <widget name="BD_EXPRField67">
      <config/>
    </widget>
    <widget name="BD_EXPRField68">
      <config/>
    </widget>
    <widget name="BD_EXPRField69">
      <config/>
    </widget>
    <widget name="BD_EXPRField70">
      <config/>
    </widget>
    <widget name="BD_EXPRField71">
      <config/>
    </widget>
    <widget name="BD_EXPRField72">
      <config/>
    </widget>
    <widget name="BD_EXPRField73">
      <config/>
    </widget>
    <widget name="BD_EXPRField74">
      <config/>
    </widget>
    <widget name="BD_EXPRField75">
      <config/>
    </widget>
    <widget name="BD_EXPRField76">
      <config/>
    </widget>
    <widget name="BD_EXPRField77">
      <config/>
    </widget>
    <widget name="BD_EXPRField78">
      <config/>
    </widget>
    <widget name="BD_EXPRField79">
      <config/>
    </widget>
    <widget name="BD_EXPRField80">
      <config/>
    </widget>
    <widget name="BD_EXPRHORA">
      <config/>
    </widget>
    <widget name="BD_EXPRINS">
      <config/>
    </widget>
    <widget name="BD_EXPRJURADO">
      <config/>
    </widget>
    <widget name="BD_EXPRJUSTIPRECI">
      <config/>
    </widget>
    <widget name="BD_EXPRLIBRO">
      <config/>
    </widget>
    <widget name="BD_EXPRLOC">
      <config/>
    </widget>
    <widget name="BD_EXPRM2_1">
      <config/>
    </widget>
    <widget name="BD_EXPRM2_2">
      <config/>
    </widget>
    <widget name="BD_EXPRM2_3">
      <config/>
    </widget>
    <widget name="BD_EXPRN">
      <config/>
    </widget>
    <widget name="BD_EXPRNIF">
      <config/>
    </widget>
    <widget name="BD_EXPRNIF_C">
      <config/>
    </widget>
    <widget name="BD_EXPRNIF_R">
      <config/>
    </widget>
    <widget name="BD_EXPRNO">
      <config/>
    </widget>
    <widget name="BD_EXPRNOM">
      <config/>
    </widget>
    <widget name="BD_EXPRNOM_C">
      <config/>
    </widget>
    <widget name="BD_EXPRNOM_R">
      <config/>
    </widget>
    <widget name="BD_EXPRO">
      <config/>
    </widget>
    <widget name="BD_EXPROBS">
      <config/>
    </widget>
    <widget name="BD_EXPROFIC">
      <config/>
    </widget>
    <widget name="BD_EXPRP1">
      <config/>
    </widget>
    <widget name="BD_EXPRP2">
      <config/>
    </widget>
    <widget name="BD_EXPRP3">
      <config/>
    </widget>
    <widget name="BD_EXPRPAGO">
      <config/>
    </widget>
    <widget name="BD_EXPRPAR">
      <config/>
    </widget>
    <widget name="BD_EXPRPOL">
      <config/>
    </widget>
    <widget name="BD_EXPRPRV">
      <config/>
    </widget>
    <widget name="BD_EXPRPTSM2_1">
      <config/>
    </widget>
    <widget name="BD_EXPRPTSM2_2">
      <config/>
    </widget>
    <widget name="BD_EXPRPTSM2_3">
      <config/>
    </widget>
    <widget name="BD_EXPRPTSUND_1">
      <config/>
    </widget>
    <widget name="BD_EXPRPTSUND_2">
      <config/>
    </widget>
    <widget name="BD_EXPRPTSUND_3">
      <config/>
    </widget>
    <widget name="BD_EXPRRG">
      <config/>
    </widget>
    <widget name="BD_EXPRS">
      <config/>
    </widget>
    <widget name="BD_EXPRTIT">
      <config/>
    </widget>
    <widget name="BD_EXPRTM">
      <config/>
    </widget>
    <widget name="BD_EXPRTOMO">
      <config/>
    </widget>
    <widget name="BD_EXPRTOTAL_M2">
      <config/>
    </widget>
    <widget name="BD_EXPRTOTAL_PTS">
      <config/>
    </widget>
    <widget name="BD_EXPRUND_1">
      <config/>
    </widget>
    <widget name="BD_EXPRUND_2">
      <config/>
    </widget>
    <widget name="BD_EXPRUND_3">
      <config/>
    </widget>
  </widgets>
  <previewExpression>"RC14"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
