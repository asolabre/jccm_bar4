<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="2.14.6-Essen" minimumScale="2500" maximumScale="1e+08" simplifyDrawingHints="1" minLabelScale="0" maxLabelScale="1e+08" simplifyDrawingTol="1" simplifyMaxScale="1" hasScaleBasedVisibilityFlag="1" simplifyLocal="0" scaleBasedLabelVisibilityFlag="0">
  <edittypes>
    <edittype widgetv2type="TextEdit" name="EXPTE1">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="UniqueValues" name="TITULARIDA">
      <widgetv2config fieldEditable="1" labelOnTop="0" Editable="1"/>
    </edittype>
    <edittype widgetv2type="UniqueValues" name="FUNCIONALI">
      <widgetv2config fieldEditable="1" labelOnTop="0" Editable="1"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="CTRA">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="PKINI">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="PKFIN">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="CTRA_ANT">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="PKINI_ANT">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="PKFIN_ANT">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="EXPTE2">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="EXPTE3">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="NOM_TRAMO">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="NOM_PROYEC">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="DIR_DOC">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="Layer">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="SUPERFICIE">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="PROVINCIA">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="TERM_MUNIC">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="TERM_MUCOD">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="ACAD_REV">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="ID_REG">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="REV_EXPTE">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="DIR_DOC_B">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="CAT-REMISI">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="CAT_ESTADO">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
    <edittype widgetv2type="TextEdit" name="CAT_OBSERV">
      <widgetv2config IsMultiline="0" fieldEditable="1" UseHtml="0" labelOnTop="0"/>
    </edittype>
  </edittypes>
  <renderer-v2 forceraster="0" symbollevels="0" type="RuleRenderer" enableorderby="0">
    <rules key="{1393d949-8352-4021-a245-50fc11885a53}">
      <rule filter=" &quot;CAT-REMISI&quot;  &lt;> 's/d' AND  &quot;CAT_ESTADO&quot;  &lt;>  'ACTUALIZADO' AND  (&quot;CAT_ESTADO&quot;  LIKE  'ACTUALIZADO%' OR &quot;CAT_ESTADO&quot;  LIKE  'MAL ACTUALIZADO%')" key="{ee8e21f0-e666-4c74-9c5c-725b8cb5f116}" symbol="0" label="REMIT / MAL ACTUALIZADO"/>
      <rule filter=" &quot;CAT-REMISI&quot;  &lt;> 's/d' AND  &quot;CAT_ESTADO&quot;  =  'ACTUALIZADO' " key="{83ac3be0-b59d-413d-bbf7-39b87b808bbc}" symbol="1" label="REMIT / CORR EN CATASTRO"/>
      <rule filter=" &quot;CAT-REMISI&quot;  &lt;> 's/d' AND  &quot;CAT_ESTADO&quot;  &lt;>  'ACTUALIZADO' " key="{abcc16b2-6274-45f7-8097-0ae063ef0f59}" symbol="2" label="REMIT. NO ACTUALIZADO"/>
      <rule filter="&quot;CAT-REMISI&quot; = 'S/D' OR &quot;CAT-REMISI&quot; = 's/d' OR  &quot;CAT-REMISI&quot; IS  NULL " key="{5c4f721d-76df-4d46-b90a-c46617750e68}" symbol="3" label="NO REMITIDO"/>
    </rules>
    <symbols>
      <symbol alpha="1" clip_to_extent="1" type="fill" name="0">
        <layer pass="4" class="SimpleLine" locked="0">
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="0;1;8;1"/>
          <prop k="customdash_map_unit_scale" v="0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="1,255,234,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="5"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="0,0,0,0,0,0"/>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" type="fill" name="1">
        <layer pass="4" class="SimpleLine" locked="0">
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="0;1;8;1"/>
          <prop k="customdash_map_unit_scale" v="0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="0,255,30,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="5"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="0,0,0,0,0,0"/>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" type="fill" name="2">
        <layer pass="1" class="SimpleLine" locked="0">
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="0;1;8;1"/>
          <prop k="customdash_map_unit_scale" v="0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="230,3,26,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="5"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="0,0,0,0,0,0"/>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" type="fill" name="3">
        <layer pass="0" class="SimpleLine" locked="0">
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="0,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="5"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="0,0,0,0,0,0"/>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <labeling type="simple"/>
  <customproperties>
    <property key="labeling" value="pal"/>
    <property key="labeling/addDirectionSymbol" value="false"/>
    <property key="labeling/angleOffset" value="0"/>
    <property key="labeling/blendMode" value="0"/>
    <property key="labeling/bufferBlendMode" value="0"/>
    <property key="labeling/bufferColorA" value="255"/>
    <property key="labeling/bufferColorB" value="255"/>
    <property key="labeling/bufferColorG" value="255"/>
    <property key="labeling/bufferColorR" value="255"/>
    <property key="labeling/bufferDraw" value="false"/>
    <property key="labeling/bufferJoinStyle" value="64"/>
    <property key="labeling/bufferNoFill" value="false"/>
    <property key="labeling/bufferSize" value="1"/>
    <property key="labeling/bufferSizeInMapUnits" value="false"/>
    <property key="labeling/bufferSizeMapUnitMaxScale" value="0"/>
    <property key="labeling/bufferSizeMapUnitMinScale" value="0"/>
    <property key="labeling/bufferSizeMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/bufferTransp" value="0"/>
    <property key="labeling/centroidInside" value="false"/>
    <property key="labeling/centroidWhole" value="false"/>
    <property key="labeling/decimals" value="3"/>
    <property key="labeling/displayAll" value="false"/>
    <property key="labeling/dist" value="0"/>
    <property key="labeling/distInMapUnits" value="false"/>
    <property key="labeling/distMapUnitMaxScale" value="0"/>
    <property key="labeling/distMapUnitMinScale" value="0"/>
    <property key="labeling/distMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/drawLabels" value="false"/>
    <property key="labeling/enabled" value="false"/>
    <property key="labeling/fieldName" value=""/>
    <property key="labeling/fitInPolygonOnly" value="false"/>
    <property key="labeling/fontCapitals" value="0"/>
    <property key="labeling/fontFamily" value="MS Shell Dlg 2"/>
    <property key="labeling/fontItalic" value="false"/>
    <property key="labeling/fontLetterSpacing" value="0"/>
    <property key="labeling/fontLimitPixelSize" value="false"/>
    <property key="labeling/fontMaxPixelSize" value="10000"/>
    <property key="labeling/fontMinPixelSize" value="3"/>
    <property key="labeling/fontSize" value="7.8"/>
    <property key="labeling/fontSizeInMapUnits" value="false"/>
    <property key="labeling/fontSizeMapUnitMaxScale" value="0"/>
    <property key="labeling/fontSizeMapUnitMinScale" value="0"/>
    <property key="labeling/fontSizeMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/fontStrikeout" value="false"/>
    <property key="labeling/fontUnderline" value="false"/>
    <property key="labeling/fontWeight" value="50"/>
    <property key="labeling/fontWordSpacing" value="0"/>
    <property key="labeling/formatNumbers" value="false"/>
    <property key="labeling/isExpression" value="true"/>
    <property key="labeling/labelOffsetInMapUnits" value="true"/>
    <property key="labeling/labelOffsetMapUnitMaxScale" value="0"/>
    <property key="labeling/labelOffsetMapUnitMinScale" value="0"/>
    <property key="labeling/labelOffsetMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/labelPerPart" value="false"/>
    <property key="labeling/leftDirectionSymbol" value="&lt;"/>
    <property key="labeling/limitNumLabels" value="false"/>
    <property key="labeling/maxCurvedCharAngleIn" value="20"/>
    <property key="labeling/maxCurvedCharAngleOut" value="-20"/>
    <property key="labeling/maxNumLabels" value="2000"/>
    <property key="labeling/mergeLines" value="false"/>
    <property key="labeling/minFeatureSize" value="0"/>
    <property key="labeling/multilineAlign" value="0"/>
    <property key="labeling/multilineHeight" value="1"/>
    <property key="labeling/namedStyle" value="Normal"/>
    <property key="labeling/obstacle" value="true"/>
    <property key="labeling/obstacleFactor" value="1"/>
    <property key="labeling/obstacleType" value="0"/>
    <property key="labeling/offsetType" value="0"/>
    <property key="labeling/placeDirectionSymbol" value="0"/>
    <property key="labeling/placement" value="1"/>
    <property key="labeling/placementFlags" value="10"/>
    <property key="labeling/plussign" value="false"/>
    <property key="labeling/predefinedPositionOrder" value="TR,TL,BR,BL,R,L,TSR,BSR"/>
    <property key="labeling/preserveRotation" value="true"/>
    <property key="labeling/previewBkgrdColor" value="#ffffff"/>
    <property key="labeling/priority" value="5"/>
    <property key="labeling/quadOffset" value="4"/>
    <property key="labeling/repeatDistance" value="0"/>
    <property key="labeling/repeatDistanceMapUnitMaxScale" value="0"/>
    <property key="labeling/repeatDistanceMapUnitMinScale" value="0"/>
    <property key="labeling/repeatDistanceMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/repeatDistanceUnit" value="1"/>
    <property key="labeling/reverseDirectionSymbol" value="false"/>
    <property key="labeling/rightDirectionSymbol" value=">"/>
    <property key="labeling/scaleMax" value="10000000"/>
    <property key="labeling/scaleMin" value="1"/>
    <property key="labeling/scaleVisibility" value="false"/>
    <property key="labeling/shadowBlendMode" value="6"/>
    <property key="labeling/shadowColorB" value="0"/>
    <property key="labeling/shadowColorG" value="0"/>
    <property key="labeling/shadowColorR" value="0"/>
    <property key="labeling/shadowDraw" value="false"/>
    <property key="labeling/shadowOffsetAngle" value="135"/>
    <property key="labeling/shadowOffsetDist" value="1"/>
    <property key="labeling/shadowOffsetGlobal" value="true"/>
    <property key="labeling/shadowOffsetMapUnitMaxScale" value="0"/>
    <property key="labeling/shadowOffsetMapUnitMinScale" value="0"/>
    <property key="labeling/shadowOffsetMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/shadowOffsetUnits" value="1"/>
    <property key="labeling/shadowRadius" value="1.5"/>
    <property key="labeling/shadowRadiusAlphaOnly" value="false"/>
    <property key="labeling/shadowRadiusMapUnitMaxScale" value="0"/>
    <property key="labeling/shadowRadiusMapUnitMinScale" value="0"/>
    <property key="labeling/shadowRadiusMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/shadowRadiusUnits" value="1"/>
    <property key="labeling/shadowScale" value="100"/>
    <property key="labeling/shadowTransparency" value="30"/>
    <property key="labeling/shadowUnder" value="0"/>
    <property key="labeling/shapeBlendMode" value="0"/>
    <property key="labeling/shapeBorderColorA" value="255"/>
    <property key="labeling/shapeBorderColorB" value="128"/>
    <property key="labeling/shapeBorderColorG" value="128"/>
    <property key="labeling/shapeBorderColorR" value="128"/>
    <property key="labeling/shapeBorderWidth" value="0"/>
    <property key="labeling/shapeBorderWidthMapUnitMaxScale" value="0"/>
    <property key="labeling/shapeBorderWidthMapUnitMinScale" value="0"/>
    <property key="labeling/shapeBorderWidthMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/shapeBorderWidthUnits" value="1"/>
    <property key="labeling/shapeDraw" value="false"/>
    <property key="labeling/shapeFillColorA" value="255"/>
    <property key="labeling/shapeFillColorB" value="255"/>
    <property key="labeling/shapeFillColorG" value="255"/>
    <property key="labeling/shapeFillColorR" value="255"/>
    <property key="labeling/shapeJoinStyle" value="64"/>
    <property key="labeling/shapeOffsetMapUnitMaxScale" value="0"/>
    <property key="labeling/shapeOffsetMapUnitMinScale" value="0"/>
    <property key="labeling/shapeOffsetMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/shapeOffsetUnits" value="1"/>
    <property key="labeling/shapeOffsetX" value="0"/>
    <property key="labeling/shapeOffsetY" value="0"/>
    <property key="labeling/shapeRadiiMapUnitMaxScale" value="0"/>
    <property key="labeling/shapeRadiiMapUnitMinScale" value="0"/>
    <property key="labeling/shapeRadiiMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/shapeRadiiUnits" value="1"/>
    <property key="labeling/shapeRadiiX" value="0"/>
    <property key="labeling/shapeRadiiY" value="0"/>
    <property key="labeling/shapeRotation" value="0"/>
    <property key="labeling/shapeRotationType" value="0"/>
    <property key="labeling/shapeSVGFile" value=""/>
    <property key="labeling/shapeSizeMapUnitMaxScale" value="0"/>
    <property key="labeling/shapeSizeMapUnitMinScale" value="0"/>
    <property key="labeling/shapeSizeMapUnitScale" value="0,0,0,0,0,0"/>
    <property key="labeling/shapeSizeType" value="0"/>
    <property key="labeling/shapeSizeUnits" value="1"/>
    <property key="labeling/shapeSizeX" value="0"/>
    <property key="labeling/shapeSizeY" value="0"/>
    <property key="labeling/shapeTransparency" value="0"/>
    <property key="labeling/shapeType" value="0"/>
    <property key="labeling/textColorA" value="255"/>
    <property key="labeling/textColorB" value="0"/>
    <property key="labeling/textColorG" value="0"/>
    <property key="labeling/textColorR" value="0"/>
    <property key="labeling/textTransp" value="0"/>
    <property key="labeling/upsidedownLabels" value="0"/>
    <property key="labeling/wrapChar" value=""/>
    <property key="labeling/xOffset" value="0"/>
    <property key="labeling/yOffset" value="0"/>
    <property key="labeling/zIndex" value="0"/>
    <property key="variableNames" value="_fields_"/>
    <property key="variableValues" value=""/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerTransparency>50</layerTransparency>
  <displayfield>Layer</displayfield>
  <label>0</label>
  <labelattributes>
    <label fieldname="" text="Etiqueta"/>
    <family fieldname="" name="MS Shell Dlg 2"/>
    <size fieldname="" units="pt" value="12"/>
    <bold fieldname="" on="0"/>
    <italic fieldname="" on="0"/>
    <underline fieldname="" on="0"/>
    <strikeout fieldname="" on="0"/>
    <color fieldname="" red="0" blue="0" green="0"/>
    <x fieldname=""/>
    <y fieldname=""/>
    <offset x="0" y="0" units="pt" yfieldname="" xfieldname=""/>
    <angle fieldname="" value="0" auto="0"/>
    <alignment fieldname="" value="center"/>
    <buffercolor fieldname="" red="255" blue="255" green="255"/>
    <buffersize fieldname="" units="pt" value="1"/>
    <bufferenabled fieldname="" on=""/>
    <multilineenabled fieldname="" on=""/>
    <selectedonly on=""/>
  </labelattributes>
  <SingleCategoryDiagramRenderer diagramType="Pie">
    <DiagramCategory penColor="#000000" labelPlacementMethod="XHeight" penWidth="0" diagramOrientation="Up" minimumSize="0" barWidth="5" penAlpha="255" maxScaleDenominator="1e+08" backgroundColor="#ffffff" transparency="0" width="15" scaleDependency="Area" backgroundAlpha="255" angleOffset="1440" scaleBasedVisibility="0" enabled="0" height="15" sizeType="MM" minScaleDenominator="25000">
      <fontProperties description="MS Shell Dlg 2,7.8,-1,5,50,0,0,0,0,0" style=""/>
      <attribute field="" color="#000000" label=""/>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings yPosColumn="-1" linePlacementFlags="10" placement="0" dist="0" xPosColumn="-1" priority="0" obstacle="0" zIndex="0" showAll="1"/>
  <annotationform>.</annotationform>
  <excludeAttributesWMS/>
  <excludeAttributesWFS/>
  <attributeactions>
    <actionsetting action="##SUPERFICIE DE POLÍGONO&#xa;#Calcula la superficie del polígono pinchado&#xa;&#xa;QtGui.QMessageBox.information(None, &quot;SUPERFICIE DE POLÍGONO&quot;, &quot;Superficie = [% format_number($area ,2)%] m2&quot;)&#xa;&#xa;&#xa;&#xa;" icon="" capture="0" type="1" name="SUPERFICIE DE POLÍGONO"/>
  </attributeactions>
  <editform>.</editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from PyQt4.QtGui import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <widgets>
    <widget name="LISTADO_EXPTES_EXPROPIACION_ACTAS PREVIAS">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_CLAVE PROYECTO">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_CORRECCION PLANOS">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_CTRA">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_CTRA ANT">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_DECR_ACUE_RESO">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_DIGITALIZADO">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_DIRECTORIO PLANOS">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_EMPRESA LEVANTAMIENTO">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_FECHA_SERVCART">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_GEORREFER">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_LAYER">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_LISTADOS">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_METADATOS">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_NOMBRE TRAMO">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_NOM_REVISOR">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_Nº ARCHIVO DATOS CAMPO">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_Nº PROYECTO ARCH DELEG">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_OBSERVACIONES">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_P K FIN">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_P K FIN ANT">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_P K INI">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_P K INI ANT">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_PLANERO">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_PLANOS PDF">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_PROV">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_REMISION CATASTRO">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_REVISADO EN SERVIDOR">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_REV_DATOSCAD">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_REV_DATOSCAMPO">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_REV_DIRECTORIO">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_SUST_SERVCART">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_TERMINO_MUNICIPAL">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_TIPO PROYECTO">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_TITULO_EXPROPIACION">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_generated">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_idTRAMOEXP1">
      <config/>
    </widget>
    <widget name="LISTADO_EXPTES_EXPROPIACION_nº ORDEN">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_ACTAS PREVIAS">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_CLAVE PROYECTO">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_CORRECCION PLANOS">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_CTRA">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_CTRA ANT">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_DECR_ACUE_RESO">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_DIGITALIZADO">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_DIRECTORIO PLANOS">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_EMPRESA LEVANTAMIENTO">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_EXPTE_EXPROPIACION">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_FECHA_SERVCART">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_GEORREFER">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_LISTADOS">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_METADATOS">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_NOMBRE TRAMO">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_NOM_REVISOR">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_Nº ARCHIVO DATOS CAMPO">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_Nº PROYECTO ARCH DELEG">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_OBSERVACIONES">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_P K FIN">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_P K FIN ANT">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_P K INI">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_P K INI ANT">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_PLANERO">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_PLANOS PDF">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_PROV">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_REMISION CATASTRO">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_REVISADO EN SERVIDOR">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_REV_DATOSCAD">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_REV_DATOSCAMPO">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_REV_DIRECTORIO">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_SUST_SERVCART">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_TERMINO_MUNICIPAL">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_TIPO PROYECTO">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_TITULO_EXPROPIACION">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_generated">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_idTRAMOEXP1">
      <config/>
    </widget>
    <widget name="LIST_EXPTES_nº ORDEN">
      <config/>
    </widget>
  </widgets>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <layerGeometryType>2</layerGeometryType>
</qgis>
