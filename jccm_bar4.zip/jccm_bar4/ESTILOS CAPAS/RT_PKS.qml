<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis autoRefreshMode="Disabled" autoRefreshTime="0" hasScaleBasedVisibilityFlag="1" labelsEnabled="1" layerType="Vector" maxScale="-4.6566128730773926e-10" minScale="900000" readOnly="0" simplifyAlgorithm="0" simplifyDrawingHints="0" simplifyDrawingTol="1" simplifyLocal="1" simplifyMaxScale="1" styleCategories="AllStyleCategories" symbologyReferenceScale="-1" version="4.2.3-Belém do Pará">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal accumulate="0" durationField="fid" durationUnit="min" enabled="0" endExpression="" endField="" fixedDuration="0" limitMode="0" mode="0" startExpression="" startField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation binding="Centroid" clamping="Relative" customToleranceEnabled="0" extrusion="0" extrusionEnabled="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" symbology="Line" type="IndividualFeatures" zoffset="0" zscale="1">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="line">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{fd249587-d1d8-4094-a7c1-2c7ad7a04637}" locked="0" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="141,90,153,255,rgb:0.5529412,0.3529412,0.6,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{3436e906-e8bc-4e45-978c-bcbc4c68bad4}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="141,90,153,255,rgb:0.5529412,0.3529412,0.6,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="101,64,109,255,rgb:0.3960784,0.2509804,0.427451,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" id="{a77bc021-3fc1-423a-a369-8413b6b9ec44}" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="141,90,153,255,rgb:0.5529412,0.3529412,0.6,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="101,64,109,255,rgb:0.3960784,0.2509804,0.427451,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" forceraster="0" referencescale="-1" symbollevels="0" type="RuleRenderer">
    <rules key="{67e74a66-ebdd-457f-ac37-89e4340537bc}">
      <rule filter=" &quot;tipo_porpk&quot;  =  2 and&#xd;&#xa; ( floor( to_int(  &quot;numero&quot;)/10)=to_int(  &quot;numero&quot;)/10) and ( &quot;numero&quot; &lt;> 0)" key="{b3638f36-a05f-4845-9cfd-ce90276a8260}" label="PK (x10)" scalemaxdenom="1000000" scalemindenom="200001" symbol="0"/>
      <rule filter=" &quot;tipo_porpk&quot;  =  2" key="{2cadc2e2-bf69-432d-9dbb-9f83e23b4bad}" label="PK" scalemaxdenom="200000" symbol="1"/>
      <rule checkstate="0" filter=" &quot;tipo_porpk&quot;  =  1" key="{6e548995-5dfa-4a2d-9dd8-5cd087dd0c97}" label="Portal" scalemaxdenom="10000" symbol="2"/>
    </rules>
    <symbols>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="0" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" id="{d3eab1c3-d93c-415c-8d63-0e35f3aa05e5}" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="12,40,254,255,rgb:0.0470588,0.1568628,0.9960784,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="0,0,0,0,rgb:0,0,0,0"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="1"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="1" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" id="{d3eab1c3-d93c-415c-8d63-0e35f3aa05e5}" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="12,40,254,255,rgb:0.0470588,0.1568628,0.9960784,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="0,0,0,0,rgb:0,0,0,0"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="1"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="2" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" id="{ec0b40ec-253d-443a-95cf-7d4a5f8ab43f}" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="0,0,0,255,rgb:0,0,0,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="0,0,0,0,rgb:0,0,0,0"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="0.5"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" id="{fbd11cc6-f78b-4f34-b455-d7e5191499ed}" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="255,0,0,255,rgb:1,0,0,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="2"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style allowHtml="0" blendMode="0" capitalization="0" fieldName="numero" fontFamily="Arial" fontItalic="0" fontKerning="1" fontLetterSpacing="0" fontSize="8" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontSizeUnit="Point" fontStrikeout="0" fontUnderline="0" fontWeight="400" fontWordSpacing="0" forcedBold="0" forcedItalic="0" isExpression="0" legendString="Aa" multilineHeight="1" multilineHeightUnit="Percentage" namedStyle="Regular" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" stretchFactor="100" tabStopDistance="80" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" tabStopDistanceUnit="Point" textColor="0,0,0,255,hsv:0.99730557203292847,0.40755322575569153,0,1" textOpacity="1" textOrientation="horizontal" useSubstitutions="0">
        <families/>
        <text-buffer bufferBlendMode="0" bufferColor="255,255,255,255,rgb:1,1,1,1" bufferDraw="1" bufferJoinStyle="64" bufferNoFill="0" bufferOpacity="1" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM"/>
        <text-mask maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSize="1.5" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskType="0" maskedSymbolLayers=""/>
        <background shapeBlendMode="0" shapeBorderColor="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1" shapeBorderWidth="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthUnit="MM" shapeDraw="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeJoinStyle="64" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetX="0" shapeOffsetY="0" shapeOpacity="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRadiiX="0" shapeRadiiY="0" shapeRotation="0" shapeRotationType="0" shapeSVGFile="" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeUnit="MM" shapeSizeX="0" shapeSizeY="0" shapeType="0">
          <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="markerSymbol" type="marker">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer class="SimpleMarker" enabled="1" id="" locked="0" pass="0">
              <Option type="Map">
                <Option name="angle" type="QString" value="0"/>
                <Option name="cap_style" type="QString" value="square"/>
                <Option name="color" type="QString" value="152,125,183,255,rgb:0.5960785,0.4901961,0.7176471,1"/>
                <Option name="horizontal_anchor_point" type="QString" value="1"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="name" type="QString" value="circle"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
                <Option name="outline_style" type="QString" value="solid"/>
                <Option name="outline_width" type="QString" value="0"/>
                <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="outline_width_unit" type="QString" value="MM"/>
                <Option name="scale_method" type="QString" value="diameter"/>
                <Option name="size" type="QString" value="2"/>
                <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="size_unit" type="QString" value="MM"/>
                <Option name="vertical_anchor_point" type="QString" value="1"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="fillSymbol" type="fill">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
              <Option type="Map">
                <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="color" type="QString" value="255,255,255,255,rgb:1,1,1,1"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="128,128,128,255,rgb:0.5019608,0.5019608,0.5019608,1"/>
                <Option name="outline_style" type="QString" value="no"/>
                <Option name="outline_width" type="QString" value="0"/>
                <Option name="outline_width_unit" type="QString" value="MM"/>
                <Option name="style" type="QString" value="solid"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowBlendMode="6" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowDraw="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowOffsetGlobal="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetUnit="MM" shadowOpacity="0" shadowRadius="0" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowScale="100" shadowUnder="0"/>
        <dd_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format addDirectionSymbol="0" autoWrapLength="0" decimals="3" formatNumbers="0" leftDirectionSymbol="&lt;" multilineAlign="0" placeDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" rightDirectionSymbol=">" useMaxLineLengthForAutoWrap="1" wrapChar=""/>
      <placement allowDegraded="0" centroidInside="0" centroidWhole="0" dist="0" distMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" fitInPolygonOnly="0" geometryGenerator="" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" lineAnchorClipping="0" lineAnchorPercent="0.5" lineAnchorTextPoint="CenterOfText" lineAnchorType="0" maxCurvedCharAngleIn="20" maxCurvedCharAngleOut="-20" maximumDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" maximumDistanceUnit="MM" multipartBehavior="LabelLargestPartOnly" offsetType="0" offsetUnits="MapUnit" overlapHandling="PreventOverlap" overrunDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" placement="0" placementFlags="10" polygonPlacementFlags="2" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" prioritization="PreferCloser" priority="5" quadOffset="4" repeatDistance="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM" rotationAngle="0" rotationUnit="AngleDegrees" xOffset="0" yOffset="0"/>
      <rendering drawLabels="1" fontLimitPixelSize="0" fontMaxPixelSize="10000" fontMinPixelSize="3" limitNumLabels="0" maxNumLabels="2000" mergeLines="0" minFeatureSize="0" obstacle="1" obstacleFactor="1" obstacleType="0" scaleMax="10000000" scaleMin="1" scaleVisibility="0" unplacedVisibility="0" upsidedownLabels="0" zIndex="0"/>
      <dd_properties>
        <Option type="Map">
          <Option name="name" type="QString" value=""/>
          <Option name="properties"/>
          <Option name="type" type="QString" value="collection"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
          <Option name="blendMode" type="int" value="0"/>
          <Option name="ddProperties" type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
          <Option name="drawToAllParts" type="bool" value="false"/>
          <Option name="enabled" type="QString" value="0"/>
          <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
          <Option name="lineSymbol" type="QString" value="&lt;symbol alpha=&quot;1&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{13e9729e-e8cc-4fb0-bc04-08463afef099}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.2352941,0.2352941,0.2352941,1&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
          <Option name="minLength" type="double" value="0"/>
          <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="minLengthUnit" type="QString" value="MM"/>
          <Option name="offsetFromAnchor" type="double" value="0"/>
          <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
          <Option name="offsetFromLabel" type="double" value="0"/>
          <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option name="QFieldSync/action" type="QString" value="copy"/>
      <Option name="QFieldSync/attachment_naming" type="QString" value="{}"/>
      <Option name="QFieldSync/cloud_action" type="QString" value="offline"/>
      <Option name="QFieldSync/geometry_locked_expression" type="invalid"/>
      <Option name="QFieldSync/photo_naming" type="QString" value="{}"/>
      <Option name="QFieldSync/relationship_maximum_visible" type="QString" value="{}"/>
      <Option name="QFieldSync/tracking_distance_requirement_minimum_meters" type="int" value="30"/>
      <Option name="QFieldSync/tracking_erroneous_distance_safeguard_maximum_meters" type="bool" value="false"/>
      <Option name="QFieldSync/tracking_measurement_type" type="int" value="0"/>
      <Option name="QFieldSync/tracking_time_requirement_interval_seconds" type="int" value="30"/>
      <Option name="QFieldSync/value_map_button_interface_threshold" type="int" value="0"/>
      <Option name="dualview/previewExpressions" type="List">
        <Option type="QString" value="COALESCE( &quot;id_vial&quot;, '&lt;NULL>' )"/>
        <Option type="QString" value="id_vial"/>
        <Option type="invalid"/>
      </Option>
      <Option name="embeddedWidgets/count" type="QString" value="0"/>
      <Option name="labeling/addDirectionSymbol" type="QString" value="false"/>
      <Option name="labeling/angleOffset" type="QString" value="0"/>
      <Option name="labeling/blendMode" type="QString" value="0"/>
      <Option name="labeling/bufferBlendMode" type="QString" value="0"/>
      <Option name="labeling/bufferColorA" type="QString" value="255"/>
      <Option name="labeling/bufferColorB" type="QString" value="255"/>
      <Option name="labeling/bufferColorG" type="QString" value="255"/>
      <Option name="labeling/bufferColorR" type="QString" value="255"/>
      <Option name="labeling/bufferDraw" type="QString" value="true"/>
      <Option name="labeling/bufferJoinStyle" type="QString" value="64"/>
      <Option name="labeling/bufferNoFill" type="QString" value="false"/>
      <Option name="labeling/bufferSize" type="QString" value="1"/>
      <Option name="labeling/bufferSizeInMapUnits" type="QString" value="false"/>
      <Option name="labeling/bufferSizeMapUnitScale" type="QString" value="0,0,0,0,0,0"/>
      <Option name="labeling/bufferTransp" type="QString" value="0"/>
      <Option name="labeling/centroidInside" type="QString" value="false"/>
      <Option name="labeling/centroidWhole" type="QString" value="false"/>
      <Option name="labeling/decimals" type="QString" value="3"/>
      <Option name="labeling/displayAll" type="QString" value="false"/>
      <Option name="labeling/dist" type="QString" value="0"/>
      <Option name="labeling/distInMapUnits" type="QString" value="false"/>
      <Option name="labeling/distMapUnitScale" type="QString" value="0,0,0,0,0,0"/>
      <Option name="labeling/drawLabels" type="QString" value="true"/>
      <Option name="labeling/enabled" type="QString" value="true"/>
      <Option name="labeling/fieldName" type="QString" value="numero"/>
      <Option name="labeling/fitInPolygonOnly" type="QString" value="false"/>
      <Option name="labeling/fontCapitals" type="QString" value="0"/>
      <Option name="labeling/fontFamily" type="QString" value="MS Shell Dlg 2"/>
      <Option name="labeling/fontItalic" type="QString" value="false"/>
      <Option name="labeling/fontLetterSpacing" type="QString" value="0"/>
      <Option name="labeling/fontLimitPixelSize" type="QString" value="false"/>
      <Option name="labeling/fontMaxPixelSize" type="QString" value="10000"/>
      <Option name="labeling/fontMinPixelSize" type="QString" value="3"/>
      <Option name="labeling/fontSize" type="QString" value="7.8"/>
      <Option name="labeling/fontSizeInMapUnits" type="QString" value="false"/>
      <Option name="labeling/fontSizeMapUnitScale" type="QString" value="0,0,0,0,0,0"/>
      <Option name="labeling/fontStrikeout" type="QString" value="false"/>
      <Option name="labeling/fontUnderline" type="QString" value="false"/>
      <Option name="labeling/fontWeight" type="QString" value="50"/>
      <Option name="labeling/fontWordSpacing" type="QString" value="0"/>
      <Option name="labeling/formatNumbers" type="QString" value="false"/>
      <Option name="labeling/isExpression" type="QString" value="false"/>
      <Option name="labeling/labelOffsetInMapUnits" type="QString" value="true"/>
      <Option name="labeling/labelOffsetMapUnitScale" type="QString" value="0,0,0,0,0,0"/>
      <Option name="labeling/labelPerPart" type="QString" value="false"/>
      <Option name="labeling/leftDirectionSymbol" type="QString" value="&lt;"/>
      <Option name="labeling/limitNumLabels" type="QString" value="false"/>
      <Option name="labeling/maxCurvedCharAngleIn" type="QString" value="20"/>
      <Option name="labeling/maxCurvedCharAngleOut" type="QString" value="-20"/>
      <Option name="labeling/maxNumLabels" type="QString" value="2000"/>
      <Option name="labeling/mergeLines" type="QString" value="false"/>
      <Option name="labeling/minFeatureSize" type="QString" value="0"/>
      <Option name="labeling/multilineAlign" type="QString" value="0"/>
      <Option name="labeling/multilineHeight" type="QString" value="1"/>
      <Option name="labeling/namedStyle" type="QString" value="Normal"/>
      <Option name="labeling/obstacle" type="QString" value="true"/>
      <Option name="labeling/obstacleFactor" type="QString" value="1"/>
      <Option name="labeling/obstacleType" type="QString" value="0"/>
      <Option name="labeling/offsetType" type="QString" value="0"/>
      <Option name="labeling/placeDirectionSymbol" type="QString" value="0"/>
      <Option name="labeling/placement" type="QString" value="0"/>
      <Option name="labeling/placementFlags" type="QString" value="10"/>
      <Option name="labeling/plussign" type="QString" value="false"/>
      <Option name="labeling/predefinedPositionOrder" type="QString" value="TR,TL,BR,BL,R,L,TSR,BSR"/>
      <Option name="labeling/preserveRotation" type="QString" value="true"/>
      <Option name="labeling/previewBkgrdColor" type="QString" value="#ffffff"/>
      <Option name="labeling/priority" type="QString" value="5"/>
      <Option name="labeling/quadOffset" type="QString" value="4"/>
      <Option name="labeling/repeatDistance" type="QString" value="0"/>
      <Option name="labeling/repeatDistanceMapUnitScale" type="QString" value="0,0,0,0,0,0"/>
      <Option name="labeling/repeatDistanceUnit" type="QString" value="1"/>
      <Option name="labeling/reverseDirectionSymbol" type="QString" value="false"/>
      <Option name="labeling/rightDirectionSymbol" type="QString" value=">"/>
      <Option name="labeling/scaleMax" type="QString" value="10000000"/>
      <Option name="labeling/scaleMin" type="QString" value="1"/>
      <Option name="labeling/scaleVisibility" type="QString" value="false"/>
      <Option name="labeling/shadowBlendMode" type="QString" value="6"/>
      <Option name="labeling/shadowColorB" type="QString" value="0"/>
      <Option name="labeling/shadowColorG" type="QString" value="0"/>
      <Option name="labeling/shadowColorR" type="QString" value="0"/>
      <Option name="labeling/shadowDraw" type="QString" value="false"/>
      <Option name="labeling/shadowOffsetAngle" type="QString" value="135"/>
      <Option name="labeling/shadowOffsetDist" type="QString" value="1"/>
      <Option name="labeling/shadowOffsetGlobal" type="QString" value="true"/>
      <Option name="labeling/shadowOffsetMapUnitScale" type="QString" value="0,0,0,0,0,0"/>
      <Option name="labeling/shadowOffsetUnits" type="QString" value="1"/>
      <Option name="labeling/shadowRadius" type="QString" value="1.5"/>
      <Option name="labeling/shadowRadiusAlphaOnly" type="QString" value="false"/>
      <Option name="labeling/shadowRadiusMapUnitScale" type="QString" value="0,0,0,0,0,0"/>
      <Option name="labeling/shadowRadiusUnits" type="QString" value="1"/>
      <Option name="labeling/shadowScale" type="QString" value="100"/>
      <Option name="labeling/shadowTransparency" type="QString" value="30"/>
      <Option name="labeling/shadowUnder" type="QString" value="0"/>
      <Option name="labeling/shapeBlendMode" type="QString" value="0"/>
      <Option name="labeling/shapeBorderColorA" type="QString" value="255"/>
      <Option name="labeling/shapeBorderColorB" type="QString" value="128"/>
      <Option name="labeling/shapeBorderColorG" type="QString" value="128"/>
      <Option name="labeling/shapeBorderColorR" type="QString" value="128"/>
      <Option name="labeling/shapeBorderWidth" type="QString" value="0"/>
      <Option name="labeling/shapeBorderWidthMapUnitScale" type="QString" value="0,0,0,0,0,0"/>
      <Option name="labeling/shapeBorderWidthUnits" type="QString" value="1"/>
      <Option name="labeling/shapeDraw" type="QString" value="false"/>
      <Option name="labeling/shapeFillColorA" type="QString" value="255"/>
      <Option name="labeling/shapeFillColorB" type="QString" value="255"/>
      <Option name="labeling/shapeFillColorG" type="QString" value="255"/>
      <Option name="labeling/shapeFillColorR" type="QString" value="255"/>
      <Option name="labeling/shapeJoinStyle" type="QString" value="64"/>
      <Option name="labeling/shapeOffsetMapUnitScale" type="QString" value="0,0,0,0,0,0"/>
      <Option name="labeling/shapeOffsetUnits" type="QString" value="1"/>
      <Option name="labeling/shapeOffsetX" type="QString" value="0"/>
      <Option name="labeling/shapeOffsetY" type="QString" value="0"/>
      <Option name="labeling/shapeRadiiMapUnitScale" type="QString" value="0,0,0,0,0,0"/>
      <Option name="labeling/shapeRadiiUnits" type="QString" value="1"/>
      <Option name="labeling/shapeRadiiX" type="QString" value="0"/>
      <Option name="labeling/shapeRadiiY" type="QString" value="0"/>
      <Option name="labeling/shapeRotation" type="QString" value="0"/>
      <Option name="labeling/shapeRotationType" type="QString" value="0"/>
      <Option name="labeling/shapeSVGFile" type="invalid"/>
      <Option name="labeling/shapeSizeMapUnitScale" type="QString" value="0,0,0,0,0,0"/>
      <Option name="labeling/shapeSizeType" type="QString" value="0"/>
      <Option name="labeling/shapeSizeUnits" type="QString" value="1"/>
      <Option name="labeling/shapeSizeX" type="QString" value="0"/>
      <Option name="labeling/shapeSizeY" type="QString" value="0"/>
      <Option name="labeling/shapeTransparency" type="QString" value="0"/>
      <Option name="labeling/shapeType" type="QString" value="0"/>
      <Option name="labeling/textColorA" type="QString" value="255"/>
      <Option name="labeling/textColorB" type="QString" value="0"/>
      <Option name="labeling/textColorG" type="QString" value="0"/>
      <Option name="labeling/textColorR" type="QString" value="0"/>
      <Option name="labeling/textTransp" type="QString" value="0"/>
      <Option name="labeling/upsidedownLabels" type="QString" value="0"/>
      <Option name="labeling/wrapChar" type="invalid"/>
      <Option name="labeling/xOffset" type="QString" value="0"/>
      <Option name="labeling/yOffset" type="QString" value="0"/>
      <Option name="labeling/zIndex" type="QString" value="0"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Pie">
    <DiagramCategory backgroundAlpha="255" backgroundColor="#ffffff" barWidth="5" diagramOrientation="Up" direction="1" enabled="0" height="15" labelPlacementMethod="XHeight" lineSizeScale="3x:0,0,0,0,0,0" lineSizeType="MM" maxScaleDenominator="1e+08" minScaleDenominator="-4.65661e-10" minimumSize="0" opacity="1" penAlpha="255" penColor="#000000" penWidth="0" rotationOffset="270" scaleBasedVisibility="0" scaleDependency="Area" showAxis="0" sizeScale="3x:0,0,0,0,0,0" sizeType="MM" spacing="0" spacingUnit="MM" spacingUnitScale="3x:0,0,0,0,0,0" stackedDiagramMode="Horizontal" stackedDiagramSpacing="0" stackedDiagramSpacingUnit="MM" stackedDiagramSpacingUnitScale="3x:0,0,0,0,0,0" width="15">
      <fontProperties bold="0" description="MS Shell Dlg 2,7.8,-1,5,400,0,0,0,0,0,0,0,0,0,0,1,,0,0" italic="0" strikethrough="0" style="" underline="0"/>
      <attribute color="#000000" colorOpacity="1" field="" label=""/>
      <axisSymbol>
        <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="line">
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
          <layer class="SimpleLine" enabled="1" id="{d0f59652-8cb0-4f9a-a509-6c3a360fad01}" locked="0" pass="0">
            <Option type="Map">
              <Option name="align_dash_pattern" type="QString" value="0"/>
              <Option name="capstyle" type="QString" value="square"/>
              <Option name="customdash" type="QString" value="5;2"/>
              <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="customdash_unit" type="QString" value="MM"/>
              <Option name="dash_pattern_offset" type="QString" value="0"/>
              <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
              <Option name="draw_inside_polygon" type="QString" value="0"/>
              <Option name="joinstyle" type="QString" value="bevel"/>
              <Option name="line_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
              <Option name="line_style" type="QString" value="solid"/>
              <Option name="line_width" type="QString" value="0.26"/>
              <Option name="line_width_unit" type="QString" value="MM"/>
              <Option name="offset" type="QString" value="0"/>
              <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offset_unit" type="QString" value="MM"/>
              <Option name="ring_filter" type="QString" value="0"/>
              <Option name="trim_distance_end" type="QString" value="0"/>
              <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="trim_distance_end_unit" type="QString" value="MM"/>
              <Option name="trim_distance_start" type="QString" value="0"/>
              <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="trim_distance_start_unit" type="QString" value="MM"/>
              <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
              <Option name="use_custom_dash" type="QString" value="0"/>
              <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings dist="0" linePlacementFlags="2" obstacle="0" placement="0" priority="0" showAll="1" zIndex="0">
    <properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field configurationFlags="0" name="fid">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="id_porpk">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="id_tramo">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="id_vial">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="tvia">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="nombre">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="numero">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="extension">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="tipo_porpk">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="tipoporpkd">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="sentidopk">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="sentidopkd">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="fuente">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="fuented">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="alta_db">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="Provincia">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="0" name="OBJECTID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" index="0" name=""/>
    <alias field="id_porpk" index="1" name=""/>
    <alias field="id_tramo" index="2" name=""/>
    <alias field="id_vial" index="3" name=""/>
    <alias field="tvia" index="4" name=""/>
    <alias field="nombre" index="5" name=""/>
    <alias field="numero" index="6" name=""/>
    <alias field="extension" index="7" name=""/>
    <alias field="tipo_porpk" index="8" name=""/>
    <alias field="tipoporpkd" index="9" name=""/>
    <alias field="sentidopk" index="10" name=""/>
    <alias field="sentidopkd" index="11" name=""/>
    <alias field="fuente" index="12" name=""/>
    <alias field="fuented" index="13" name=""/>
    <alias field="alta_db" index="14" name=""/>
    <alias field="Provincia" index="15" name=""/>
    <alias field="OBJECTID" index="16" name=""/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" expression="" field="fid"/>
    <default applyOnUpdate="0" expression="" field="id_porpk"/>
    <default applyOnUpdate="0" expression="" field="id_tramo"/>
    <default applyOnUpdate="0" expression="" field="id_vial"/>
    <default applyOnUpdate="0" expression="" field="tvia"/>
    <default applyOnUpdate="0" expression="" field="nombre"/>
    <default applyOnUpdate="0" expression="" field="numero"/>
    <default applyOnUpdate="0" expression="" field="extension"/>
    <default applyOnUpdate="0" expression="" field="tipo_porpk"/>
    <default applyOnUpdate="0" expression="" field="tipoporpkd"/>
    <default applyOnUpdate="0" expression="" field="sentidopk"/>
    <default applyOnUpdate="0" expression="" field="sentidopkd"/>
    <default applyOnUpdate="0" expression="" field="fuente"/>
    <default applyOnUpdate="0" expression="" field="fuented"/>
    <default applyOnUpdate="0" expression="" field="alta_db"/>
    <default applyOnUpdate="0" expression="" field="Provincia"/>
    <default applyOnUpdate="0" expression="" field="OBJECTID"/>
  </defaults>
  <constraints>
    <constraint constraints="3" exp_strength="0" field="fid" notnull_strength="1" unique_strength="1"/>
    <constraint constraints="0" exp_strength="0" field="id_porpk" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="id_tramo" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="id_vial" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="tvia" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="nombre" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="numero" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="extension" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="tipo_porpk" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="tipoporpkd" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="sentidopk" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="sentidopkd" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="fuente" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="fuented" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="alta_db" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Provincia" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="OBJECTID" notnull_strength="0" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="fid"/>
    <constraint desc="" exp="" field="id_porpk"/>
    <constraint desc="" exp="" field="id_tramo"/>
    <constraint desc="" exp="" field="id_vial"/>
    <constraint desc="" exp="" field="tvia"/>
    <constraint desc="" exp="" field="nombre"/>
    <constraint desc="" exp="" field="numero"/>
    <constraint desc="" exp="" field="extension"/>
    <constraint desc="" exp="" field="tipo_porpk"/>
    <constraint desc="" exp="" field="tipoporpkd"/>
    <constraint desc="" exp="" field="sentidopk"/>
    <constraint desc="" exp="" field="sentidopkd"/>
    <constraint desc="" exp="" field="fuente"/>
    <constraint desc="" exp="" field="fuented"/>
    <constraint desc="" exp="" field="alta_db"/>
    <constraint desc="" exp="" field="Provincia"/>
    <constraint desc="" exp="" field="OBJECTID"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns>
      <column hidden="0" name="fid" type="field" width="-1"/>
      <column hidden="0" name="id_vial" type="field" width="108"/>
      <column hidden="0" name="id_tramo" type="field" width="-1"/>
      <column hidden="0" name="id_porpk" type="field" width="-1"/>
      <column hidden="0" name="numero" type="field" width="-1"/>
      <column hidden="0" name="extension" type="field" width="-1"/>
      <column hidden="0" name="tipo_porpk" type="field" width="-1"/>
      <column hidden="0" name="sentidopk" type="field" width="-1"/>
      <column hidden="0" name="fuente" type="field" width="-1"/>
      <column hidden="0" name="tipoporpkd" type="field" width="-1"/>
      <column hidden="0" name="sentidopkd" type="field" width="-1"/>
      <column hidden="0" name="fuented" type="field" width="-1"/>
      <column hidden="0" name="alta_db" type="field" width="-1"/>
      <column hidden="0" name="tvia" type="field" width="-1"/>
      <column hidden="0" name="nombre" type="field" width="-1"/>
      <column hidden="0" name="Provincia" type="field" width="-1"/>
      <column hidden="0" name="OBJECTID" type="field" width="-1"/>
      <column hidden="1" type="actions" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from PyQt4.QtGui import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="OBJECTID"/>
    <field editable="1" name="Provincia"/>
    <field editable="1" name="alta_db"/>
    <field editable="1" name="extension"/>
    <field editable="1" name="fecha_alta"/>
    <field editable="1" name="fid"/>
    <field editable="1" name="fuente"/>
    <field editable="1" name="fuenteD"/>
    <field editable="1" name="fuented"/>
    <field editable="1" name="id_porpk"/>
    <field editable="1" name="id_tramo"/>
    <field editable="1" name="id_vial"/>
    <field editable="1" name="nombre"/>
    <field editable="1" name="numero"/>
    <field editable="1" name="sentidopk"/>
    <field editable="1" name="sentidopkD"/>
    <field editable="1" name="sentidopkd"/>
    <field editable="1" name="tipo_porpk"/>
    <field editable="1" name="tipoporpkD"/>
    <field editable="1" name="tipoporpkd"/>
    <field editable="1" name="tvia"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="OBJECTID"/>
    <field labelOnTop="0" name="Provincia"/>
    <field labelOnTop="0" name="alta_db"/>
    <field labelOnTop="0" name="extension"/>
    <field labelOnTop="0" name="fecha_alta"/>
    <field labelOnTop="0" name="fid"/>
    <field labelOnTop="0" name="fuente"/>
    <field labelOnTop="0" name="fuenteD"/>
    <field labelOnTop="0" name="fuented"/>
    <field labelOnTop="0" name="id_porpk"/>
    <field labelOnTop="0" name="id_tramo"/>
    <field labelOnTop="0" name="id_vial"/>
    <field labelOnTop="0" name="nombre"/>
    <field labelOnTop="0" name="numero"/>
    <field labelOnTop="0" name="sentidopk"/>
    <field labelOnTop="0" name="sentidopkD"/>
    <field labelOnTop="0" name="sentidopkd"/>
    <field labelOnTop="0" name="tipo_porpk"/>
    <field labelOnTop="0" name="tipoporpkD"/>
    <field labelOnTop="0" name="tipoporpkd"/>
    <field labelOnTop="0" name="tvia"/>
  </labelOnTop>
  <reuseLastValuePolicy>
    <field name="OBJECTID" reuseLastValuePolicy="NotAllowed"/>
    <field name="Provincia" reuseLastValuePolicy="NotAllowed"/>
    <field name="alta_db" reuseLastValuePolicy="NotAllowed"/>
    <field name="extension" reuseLastValuePolicy="NotAllowed"/>
    <field name="fid" reuseLastValuePolicy="NotAllowed"/>
    <field name="fuente" reuseLastValuePolicy="NotAllowed"/>
    <field name="fuented" reuseLastValuePolicy="NotAllowed"/>
    <field name="id_porpk" reuseLastValuePolicy="NotAllowed"/>
    <field name="id_tramo" reuseLastValuePolicy="NotAllowed"/>
    <field name="id_vial" reuseLastValuePolicy="NotAllowed"/>
    <field name="nombre" reuseLastValuePolicy="NotAllowed"/>
    <field name="numero" reuseLastValuePolicy="NotAllowed"/>
    <field name="sentidopk" reuseLastValuePolicy="NotAllowed"/>
    <field name="sentidopkd" reuseLastValuePolicy="NotAllowed"/>
    <field name="tipo_porpk" reuseLastValuePolicy="NotAllowed"/>
    <field name="tipoporpkd" reuseLastValuePolicy="NotAllowed"/>
    <field name="tvia" reuseLastValuePolicy="NotAllowed"/>
  </reuseLastValuePolicy>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>COALESCE( "id_vial", '&lt;NULL>' )</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
