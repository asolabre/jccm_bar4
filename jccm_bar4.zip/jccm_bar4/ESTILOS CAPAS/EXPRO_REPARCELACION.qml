<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis hasScaleBasedVisibilityFlag="1" simplifyAlgorithm="0" minScale="100000" simplifyDrawingTol="1" symbologyReferenceScale="-1" version="3.34.10-Prizren" maxScale="0" styleCategories="AllStyleCategories" simplifyDrawingHints="1" simplifyLocal="1" labelsEnabled="1" simplifyMaxScale="1" readOnly="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal limitMode="0" durationField="fid" enabled="0" endField="" durationUnit="min" mode="0" accumulate="0" fixedDuration="0" endExpression="" startField="" startExpression="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation extrusionEnabled="0" extrusion="0" clamping="Terrain" respectLayerSymbol="1" zoffset="0" zscale="1" type="IndividualFeatures" binding="Centroid" symbology="Line" showMarkerSymbolInSurfacePlots="0">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" alpha="1" type="line" name="" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer id="{70438787-2af9-4e6e-b51d-6d32aa44b34a}" enabled="1" locked="0" class="SimpleLine" pass="0">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="243,166,178,255" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" alpha="1" type="fill" name="" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer id="{ebfe1c5d-98fe-4083-bc36-d2f0b7773a3d}" enabled="1" locked="0" class="SimpleFill" pass="0">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="243,166,178,255" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="174,119,127,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" alpha="1" type="marker" name="" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer id="{4995d206-56bf-497e-adf1-654c57e6e55e}" enabled="1" locked="0" class="SimpleMarker" pass="0">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="square" type="QString" name="cap_style"/>
            <Option value="243,166,178,255" type="QString" name="color"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="diamond" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="174,119,127,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="diameter" type="QString" name="scale_method"/>
            <Option value="3" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 forceraster="0" referencescale="-1" type="singleSymbol" enableorderby="0" symbollevels="0">
    <symbols>
      <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" alpha="1" type="fill" name="0" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer id="{a2b5a190-48ec-46b9-8e71-2f78e3835a94}" enabled="1" locked="0" class="SimpleFill" pass="0">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="224,87,32,0" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0,0,255,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.8" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" alpha="1" type="fill" name="" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer id="{b4a5c938-4680-4629-8e4e-17bef08dcdca}" enabled="1" locked="0" class="SimpleFill" pass="0">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="0,0,255,255" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.26" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style multilineHeight="1" textOrientation="horizontal" multilineHeightUnit="Percentage" capitalization="0" forcedItalic="0" textOpacity="1" previewBkgrdColor="255,255,255,255" fontItalic="0" fontUnderline="0" legendString="Aa" isExpression="1" fontStrikeout="0" blendMode="0" fieldName="&quot;RC14&quot; ||  '\n' ||   format_number(  area(  $geometry ) ,0 )" namedStyle="Normal" fontLetterSpacing="0" fontKerning="1" fontWordSpacing="0" fontSizeUnit="Point" fontFamily="Arial" fontWeight="50" fontSize="8" fontSizeMapUnitScale="3x:0,0,0,0,0,0" allowHtml="0" useSubstitutions="0" forcedBold="0" textColor="0,0,255,255">
        <families/>
        <text-buffer bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferSize="1" bufferColor="255,255,255,255" bufferJoinStyle="64" bufferSizeUnits="MM" bufferDraw="1" bufferNoFill="0"/>
        <text-mask maskType="0" maskEnabled="0" maskSize2="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskOpacity="1" maskedSymbolLayers="" maskSize="1.5" maskJoinStyle="128"/>
        <background shapeRotationType="0" shapeBorderWidthUnit="MM" shapeSizeType="0" shapeBorderWidth="0" shapeSizeUnit="MM" shapeType="0" shapeSizeX="0" shapeOpacity="1" shapeRotation="0" shapeFillColor="255,255,255,255" shapeRadiiX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRadiiY="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeY="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeOffsetUnit="MM" shapeSVGFile="" shapeOffsetX="0" shapeBorderColor="128,128,128,255">
          <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" alpha="1" type="marker" name="markerSymbol" is_animated="0">
            <data_defined_properties>
              <Option type="Map">
                <Option value="" type="QString" name="name"/>
                <Option name="properties"/>
                <Option value="collection" type="QString" name="type"/>
              </Option>
            </data_defined_properties>
            <layer id="" enabled="1" locked="0" class="SimpleMarker" pass="0">
              <Option type="Map">
                <Option value="0" type="QString" name="angle"/>
                <Option value="square" type="QString" name="cap_style"/>
                <Option value="196,60,57,255" type="QString" name="color"/>
                <Option value="1" type="QString" name="horizontal_anchor_point"/>
                <Option value="bevel" type="QString" name="joinstyle"/>
                <Option value="circle" type="QString" name="name"/>
                <Option value="0,0" type="QString" name="offset"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
                <Option value="MM" type="QString" name="offset_unit"/>
                <Option value="35,35,35,255" type="QString" name="outline_color"/>
                <Option value="solid" type="QString" name="outline_style"/>
                <Option value="0" type="QString" name="outline_width"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
                <Option value="MM" type="QString" name="outline_width_unit"/>
                <Option value="diameter" type="QString" name="scale_method"/>
                <Option value="2" type="QString" name="size"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
                <Option value="MM" type="QString" name="size_unit"/>
                <Option value="1" type="QString" name="vertical_anchor_point"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" type="QString" name="name"/>
                  <Option name="properties"/>
                  <Option value="collection" type="QString" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" alpha="1" type="fill" name="fillSymbol" is_animated="0">
            <data_defined_properties>
              <Option type="Map">
                <Option value="" type="QString" name="name"/>
                <Option name="properties"/>
                <Option value="collection" type="QString" name="type"/>
              </Option>
            </data_defined_properties>
            <layer id="" enabled="1" locked="0" class="SimpleFill" pass="0">
              <Option type="Map">
                <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
                <Option value="255,255,255,255" type="QString" name="color"/>
                <Option value="bevel" type="QString" name="joinstyle"/>
                <Option value="0,0" type="QString" name="offset"/>
                <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
                <Option value="MM" type="QString" name="offset_unit"/>
                <Option value="128,128,128,255" type="QString" name="outline_color"/>
                <Option value="no" type="QString" name="outline_style"/>
                <Option value="0" type="QString" name="outline_width"/>
                <Option value="MM" type="QString" name="outline_width_unit"/>
                <Option value="solid" type="QString" name="style"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" type="QString" name="name"/>
                  <Option name="properties"/>
                  <Option value="collection" type="QString" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowRadiusUnit="MM" shadowOpacity="0" shadowRadiusAlphaOnly="0" shadowUnder="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowBlendMode="6" shadowOffsetAngle="135" shadowColor="0,0,0,255" shadowScale="100" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetGlobal="1" shadowOffsetDist="1" shadowOffsetUnit="MM" shadowRadius="0"/>
        <dd_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format leftDirectionSymbol="&lt;" rightDirectionSymbol=">" formatNumbers="0" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" autoWrapLength="0" placeDirectionSymbol="0" addDirectionSymbol="0" reverseDirectionSymbol="0" plussign="0" decimals="3"/>
      <placement quadOffset="4" maxCurvedCharAngleIn="20" centroidInside="0" lineAnchorPercent="0.5" fitInPolygonOnly="0" centroidWhole="0" maxCurvedCharAngleOut="-20" geometryGeneratorEnabled="0" distMapUnitScale="3x:0,0,0,0,0,0" dist="0" lineAnchorTextPoint="CenterOfText" lineAnchorType="0" repeatDistanceUnits="MM" polygonPlacementFlags="2" allowDegraded="0" lineAnchorClipping="0" preserveRotation="1" offsetUnits="MapUnit" distUnits="MM" geometryGeneratorType="PointGeometry" priority="5" overrunDistanceUnit="MM" placement="1" overlapHandling="PreventOverlap" geometryGenerator="" overrunDistance="0" placementFlags="10" rotationAngle="0" offsetType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" rotationUnit="AngleDegrees" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" layerType="PolygonGeometry" yOffset="0" repeatDistance="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR"/>
      <rendering fontMinPixelSize="3" obstacle="1" scaleMax="10000000" scaleVisibility="0" minFeatureSize="0" unplacedVisibility="0" mergeLines="0" upsidedownLabels="0" obstacleType="0" obstacleFactor="1" fontMaxPixelSize="10000" scaleMin="1" labelPerPart="0" zIndex="0" fontLimitPixelSize="0" drawLabels="1" maxNumLabels="2000" limitNumLabels="0"/>
      <dd_properties>
        <Option type="Map">
          <Option value="" type="QString" name="name"/>
          <Option name="properties"/>
          <Option value="collection" type="QString" name="type"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option value="pole_of_inaccessibility" type="QString" name="anchorPoint"/>
          <Option value="0" type="int" name="blendMode"/>
          <Option type="Map" name="ddProperties">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
          <Option value="false" type="bool" name="drawToAllParts"/>
          <Option value="0" type="QString" name="enabled"/>
          <Option value="point_on_exterior" type="QString" name="labelAnchorPoint"/>
          <Option value="&lt;symbol force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; type=&quot;line&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; type=&quot;QString&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; type=&quot;QString&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{25260434-56a7-4b40-8452-75194c11154f}&quot; enabled=&quot;1&quot; locked=&quot;0&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option value=&quot;square&quot; type=&quot;QString&quot; name=&quot;capstyle&quot;/>&lt;Option value=&quot;5;2&quot; type=&quot;QString&quot; name=&quot;customdash&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;customdash_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option value=&quot;bevel&quot; type=&quot;QString&quot; name=&quot;joinstyle&quot;/>&lt;Option value=&quot;60,60,60,255&quot; type=&quot;QString&quot; name=&quot;line_color&quot;/>&lt;Option value=&quot;solid&quot; type=&quot;QString&quot; name=&quot;line_style&quot;/>&lt;Option value=&quot;0.3&quot; type=&quot;QString&quot; name=&quot;line_width&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;line_width_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;offset&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;offset_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;ring_filter&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;trim_distance_end&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;trim_distance_start&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option value=&quot;MM&quot; type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option value=&quot;0&quot; type=&quot;QString&quot; name=&quot;use_custom_dash&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; type=&quot;QString&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; type=&quot;QString&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString" name="lineSymbol"/>
          <Option value="0" type="double" name="minLength"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="minLengthMapUnitScale"/>
          <Option value="MM" type="QString" name="minLengthUnit"/>
          <Option value="0" type="double" name="offsetFromAnchor"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="offsetFromAnchorMapUnitScale"/>
          <Option value="MM" type="QString" name="offsetFromAnchorUnit"/>
          <Option value="0" type="double" name="offsetFromLabel"/>
          <Option value="3x:0,0,0,0,0,0" type="QString" name="offsetFromLabelMapUnitScale"/>
          <Option value="MM" type="QString" name="offsetFromLabelUnit"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option value="copy" type="QString" name="QFieldSync/action"/>
      <Option value="{}" type="QString" name="QFieldSync/attachment_naming"/>
      <Option value="offline" type="QString" name="QFieldSync/cloud_action"/>
      <Option value="" type="QString" name="QFieldSync/geometry_locked_expression"/>
      <Option value="{}" type="QString" name="QFieldSync/photo_naming"/>
      <Option value="{}" type="QString" name="QFieldSync/relationship_maximum_visible"/>
      <Option value="30" type="int" name="QFieldSync/tracking_distance_requirement_minimum_meters"/>
      <Option value="1" type="int" name="QFieldSync/tracking_erroneous_distance_safeguard_maximum_meters"/>
      <Option value="0" type="int" name="QFieldSync/tracking_measurement_type"/>
      <Option value="30" type="int" name="QFieldSync/tracking_time_requirement_interval_seconds"/>
      <Option value="0" type="int" name="QFieldSync/value_map_button_interface_threshold"/>
      <Option type="List" name="dualview/previewExpressions">
        <Option value="COALESCE(   &quot;RC14&quot; , '&lt;NULL>' ) ||  '\n'  ||  coalesce(   &quot;MUNICIPIO&quot;  , '&lt;NULL>' ) || ' ' ||  coalesce(    &quot;MUNI_nm&quot;   , '&lt;NULL>' )" type="QString"/>
      </Option>
      <Option value="0" type="QString" name="embeddedWidgets/count"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Pie" attributeLegend="1">
    <DiagramCategory scaleBasedVisibility="0" width="15" spacingUnit="MM" sizeType="MM" penWidth="0" opacity="1" labelPlacementMethod="XHeight" spacing="0" showAxis="0" lineSizeType="MM" minimumSize="0" diagramOrientation="Up" direction="1" maxScaleDenominator="1e+08" backgroundColor="#ffffff" rotationOffset="270" scaleDependency="Area" penColor="#000000" enabled="0" sizeScale="3x:0,0,0,0,0,0" lineSizeScale="3x:0,0,0,0,0,0" backgroundAlpha="255" barWidth="5" penAlpha="255" height="15" minScaleDenominator="0" spacingUnitScale="3x:0,0,0,0,0,0">
      <fontProperties strikethrough="0" italic="0" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0"/>
      <attribute color="#000000" colorOpacity="1" label="" field=""/>
      <axisSymbol>
        <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" alpha="1" type="line" name="" is_animated="0">
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
          <layer id="{6b9c8c25-a06b-4444-a68b-b1546016a091}" enabled="1" locked="0" class="SimpleLine" pass="0">
            <Option type="Map">
              <Option value="0" type="QString" name="align_dash_pattern"/>
              <Option value="square" type="QString" name="capstyle"/>
              <Option value="5;2" type="QString" name="customdash"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
              <Option value="MM" type="QString" name="customdash_unit"/>
              <Option value="0" type="QString" name="dash_pattern_offset"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
              <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
              <Option value="0" type="QString" name="draw_inside_polygon"/>
              <Option value="bevel" type="QString" name="joinstyle"/>
              <Option value="35,35,35,255" type="QString" name="line_color"/>
              <Option value="solid" type="QString" name="line_style"/>
              <Option value="0.26" type="QString" name="line_width"/>
              <Option value="MM" type="QString" name="line_width_unit"/>
              <Option value="0" type="QString" name="offset"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
              <Option value="MM" type="QString" name="offset_unit"/>
              <Option value="0" type="QString" name="ring_filter"/>
              <Option value="0" type="QString" name="trim_distance_end"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
              <Option value="MM" type="QString" name="trim_distance_end_unit"/>
              <Option value="0" type="QString" name="trim_distance_start"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
              <Option value="MM" type="QString" name="trim_distance_start_unit"/>
              <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
              <Option value="0" type="QString" name="use_custom_dash"/>
              <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option value="" type="QString" name="name"/>
                <Option name="properties"/>
                <Option value="collection" type="QString" name="type"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings zIndex="0" showAll="1" linePlacementFlags="2" priority="0" dist="0" placement="0" obstacle="0">
    <properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option type="Map" name="QgsGeometryGapCheck">
        <Option value="0" type="double" name="allowedGapsBuffer"/>
        <Option value="false" type="bool" name="allowedGapsEnabled"/>
        <Option value="" type="QString" name="allowedGapsLayer"/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="fid">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="RC14">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="PCAT1">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="PCAT2">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="EJERCICIO">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="NUM_EXP">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="CONTROL">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="COORY">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="VIA">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="NUMERO">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="NUMERODUP">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="NUMSYMBOL">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="AREA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="FECHAALTA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="FECHABAJA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="MAPA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="DELEGACIO">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="MUNICIPIO">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="MASA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="HOJA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="TIPO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="PARCELA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="COORX">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="NOM_MUNI">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="CAT_NMSPC">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="DIRECCION">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="PROVINCIA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="REF_CAT">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="COD_INE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="fid" name=""/>
    <alias index="1" field="RC14" name=""/>
    <alias index="2" field="PCAT1" name=""/>
    <alias index="3" field="PCAT2" name=""/>
    <alias index="4" field="EJERCICIO" name=""/>
    <alias index="5" field="NUM_EXP" name=""/>
    <alias index="6" field="CONTROL" name=""/>
    <alias index="7" field="COORY" name=""/>
    <alias index="8" field="VIA" name=""/>
    <alias index="9" field="NUMERO" name=""/>
    <alias index="10" field="NUMERODUP" name=""/>
    <alias index="11" field="NUMSYMBOL" name=""/>
    <alias index="12" field="AREA" name=""/>
    <alias index="13" field="FECHAALTA" name=""/>
    <alias index="14" field="FECHABAJA" name=""/>
    <alias index="15" field="MAPA" name=""/>
    <alias index="16" field="DELEGACIO" name=""/>
    <alias index="17" field="MUNICIPIO" name=""/>
    <alias index="18" field="MASA" name=""/>
    <alias index="19" field="HOJA" name=""/>
    <alias index="20" field="TIPO" name=""/>
    <alias index="21" field="PARCELA" name=""/>
    <alias index="22" field="COORX" name=""/>
    <alias index="23" field="NOM_MUNI" name=""/>
    <alias index="24" field="CAT_NMSPC" name=""/>
    <alias index="25" field="DIRECCION" name=""/>
    <alias index="26" field="PROVINCIA" name=""/>
    <alias index="27" field="REF_CAT" name=""/>
    <alias index="28" field="COD_INE" name=""/>
  </aliases>
  <splitPolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="RC14"/>
    <policy policy="Duplicate" field="PCAT1"/>
    <policy policy="Duplicate" field="PCAT2"/>
    <policy policy="Duplicate" field="EJERCICIO"/>
    <policy policy="Duplicate" field="NUM_EXP"/>
    <policy policy="Duplicate" field="CONTROL"/>
    <policy policy="Duplicate" field="COORY"/>
    <policy policy="Duplicate" field="VIA"/>
    <policy policy="Duplicate" field="NUMERO"/>
    <policy policy="Duplicate" field="NUMERODUP"/>
    <policy policy="Duplicate" field="NUMSYMBOL"/>
    <policy policy="Duplicate" field="AREA"/>
    <policy policy="Duplicate" field="FECHAALTA"/>
    <policy policy="Duplicate" field="FECHABAJA"/>
    <policy policy="Duplicate" field="MAPA"/>
    <policy policy="Duplicate" field="DELEGACIO"/>
    <policy policy="Duplicate" field="MUNICIPIO"/>
    <policy policy="Duplicate" field="MASA"/>
    <policy policy="Duplicate" field="HOJA"/>
    <policy policy="Duplicate" field="TIPO"/>
    <policy policy="Duplicate" field="PARCELA"/>
    <policy policy="Duplicate" field="COORX"/>
    <policy policy="Duplicate" field="NOM_MUNI"/>
    <policy policy="Duplicate" field="CAT_NMSPC"/>
    <policy policy="Duplicate" field="DIRECCION"/>
    <policy policy="Duplicate" field="PROVINCIA"/>
    <policy policy="Duplicate" field="REF_CAT"/>
    <policy policy="Duplicate" field="COD_INE"/>
  </splitPolicies>
  <defaults>
    <default expression="" applyOnUpdate="0" field="fid"/>
    <default expression="" applyOnUpdate="0" field="RC14"/>
    <default expression="" applyOnUpdate="0" field="PCAT1"/>
    <default expression="" applyOnUpdate="0" field="PCAT2"/>
    <default expression="" applyOnUpdate="0" field="EJERCICIO"/>
    <default expression="" applyOnUpdate="0" field="NUM_EXP"/>
    <default expression="" applyOnUpdate="0" field="CONTROL"/>
    <default expression="" applyOnUpdate="0" field="COORY"/>
    <default expression="" applyOnUpdate="0" field="VIA"/>
    <default expression="" applyOnUpdate="0" field="NUMERO"/>
    <default expression="" applyOnUpdate="0" field="NUMERODUP"/>
    <default expression="" applyOnUpdate="0" field="NUMSYMBOL"/>
    <default expression="" applyOnUpdate="0" field="AREA"/>
    <default expression="" applyOnUpdate="0" field="FECHAALTA"/>
    <default expression="" applyOnUpdate="0" field="FECHABAJA"/>
    <default expression="" applyOnUpdate="0" field="MAPA"/>
    <default expression="" applyOnUpdate="0" field="DELEGACIO"/>
    <default expression="" applyOnUpdate="0" field="MUNICIPIO"/>
    <default expression="" applyOnUpdate="0" field="MASA"/>
    <default expression="" applyOnUpdate="0" field="HOJA"/>
    <default expression="" applyOnUpdate="0" field="TIPO"/>
    <default expression="" applyOnUpdate="0" field="PARCELA"/>
    <default expression="" applyOnUpdate="0" field="COORX"/>
    <default expression="" applyOnUpdate="0" field="NOM_MUNI"/>
    <default expression="" applyOnUpdate="0" field="CAT_NMSPC"/>
    <default expression="" applyOnUpdate="0" field="DIRECCION"/>
    <default expression="" applyOnUpdate="0" field="PROVINCIA"/>
    <default expression="" applyOnUpdate="0" field="REF_CAT"/>
    <default expression="" applyOnUpdate="0" field="COD_INE"/>
  </defaults>
  <constraints>
    <constraint unique_strength="1" notnull_strength="1" constraints="3" exp_strength="0" field="fid"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="RC14"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="PCAT1"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="PCAT2"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="EJERCICIO"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="NUM_EXP"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="CONTROL"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="COORY"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="VIA"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="NUMERO"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="NUMERODUP"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="NUMSYMBOL"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="AREA"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="FECHAALTA"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="FECHABAJA"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="MAPA"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="DELEGACIO"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="MUNICIPIO"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="MASA"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="HOJA"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="TIPO"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="PARCELA"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="COORX"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="NOM_MUNI"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="CAT_NMSPC"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="DIRECCION"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="PROVINCIA"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="REF_CAT"/>
    <constraint unique_strength="0" notnull_strength="0" constraints="0" exp_strength="0" field="COD_INE"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="fid"/>
    <constraint desc="" exp="" field="RC14"/>
    <constraint desc="" exp="" field="PCAT1"/>
    <constraint desc="" exp="" field="PCAT2"/>
    <constraint desc="" exp="" field="EJERCICIO"/>
    <constraint desc="" exp="" field="NUM_EXP"/>
    <constraint desc="" exp="" field="CONTROL"/>
    <constraint desc="" exp="" field="COORY"/>
    <constraint desc="" exp="" field="VIA"/>
    <constraint desc="" exp="" field="NUMERO"/>
    <constraint desc="" exp="" field="NUMERODUP"/>
    <constraint desc="" exp="" field="NUMSYMBOL"/>
    <constraint desc="" exp="" field="AREA"/>
    <constraint desc="" exp="" field="FECHAALTA"/>
    <constraint desc="" exp="" field="FECHABAJA"/>
    <constraint desc="" exp="" field="MAPA"/>
    <constraint desc="" exp="" field="DELEGACIO"/>
    <constraint desc="" exp="" field="MUNICIPIO"/>
    <constraint desc="" exp="" field="MASA"/>
    <constraint desc="" exp="" field="HOJA"/>
    <constraint desc="" exp="" field="TIPO"/>
    <constraint desc="" exp="" field="PARCELA"/>
    <constraint desc="" exp="" field="COORX"/>
    <constraint desc="" exp="" field="NOM_MUNI"/>
    <constraint desc="" exp="" field="CAT_NMSPC"/>
    <constraint desc="" exp="" field="DIRECCION"/>
    <constraint desc="" exp="" field="PROVINCIA"/>
    <constraint desc="" exp="" field="REF_CAT"/>
    <constraint desc="" exp="" field="COD_INE"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" actionWidgetStyle="dropDown" sortExpression="">
    <columns>
      <column width="-1" type="field" hidden="0" name="RC14"/>
      <column width="-1" type="field" hidden="0" name="PCAT1"/>
      <column width="-1" type="field" hidden="0" name="PCAT2"/>
      <column width="-1" type="field" hidden="0" name="EJERCICIO"/>
      <column width="-1" type="field" hidden="0" name="NUM_EXP"/>
      <column width="-1" type="field" hidden="0" name="CONTROL"/>
      <column width="-1" type="field" hidden="0" name="COORY"/>
      <column width="-1" type="field" hidden="0" name="VIA"/>
      <column width="-1" type="field" hidden="0" name="NUMERO"/>
      <column width="-1" type="field" hidden="0" name="NUMERODUP"/>
      <column width="-1" type="field" hidden="0" name="NUMSYMBOL"/>
      <column width="-1" type="field" hidden="0" name="AREA"/>
      <column width="-1" type="field" hidden="0" name="FECHAALTA"/>
      <column width="-1" type="field" hidden="0" name="FECHABAJA"/>
      <column width="-1" type="field" hidden="0" name="MAPA"/>
      <column width="-1" type="field" hidden="0" name="DELEGACIO"/>
      <column width="-1" type="field" hidden="0" name="MUNICIPIO"/>
      <column width="-1" type="field" hidden="0" name="MASA"/>
      <column width="-1" type="field" hidden="0" name="HOJA"/>
      <column width="-1" type="field" hidden="0" name="TIPO"/>
      <column width="-1" type="field" hidden="0" name="PARCELA"/>
      <column width="-1" type="field" hidden="0" name="COORX"/>
      <column width="-1" type="field" hidden="0" name="fid"/>
      <column width="-1" type="field" hidden="0" name="NOM_MUNI"/>
      <column width="-1" type="field" hidden="0" name="CAT_NMSPC"/>
      <column width="-1" type="field" hidden="0" name="DIRECCION"/>
      <column width="-1" type="field" hidden="0" name="PROVINCIA"/>
      <column width="-1" type="field" hidden="0" name="REF_CAT"/>
      <column width="-1" type="field" hidden="0" name="COD_INE"/>
      <column width="-1" type="actions" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from PyQt4.QtGui import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="AREA"/>
    <field editable="1" name="CAT_NMSPC"/>
    <field editable="1" name="COD_INE"/>
    <field editable="1" name="CONTROL"/>
    <field editable="1" name="COORX"/>
    <field editable="1" name="COORY"/>
    <field editable="1" name="DELEGACIO"/>
    <field editable="1" name="DIRECCION"/>
    <field editable="1" name="EJERCICIO"/>
    <field editable="1" name="FECHAALTA"/>
    <field editable="1" name="FECHABAJA"/>
    <field editable="1" name="HOJA"/>
    <field editable="1" name="MAPA"/>
    <field editable="1" name="MASA"/>
    <field editable="1" name="MUNICIPIO"/>
    <field editable="0" name="MUNI_cd"/>
    <field editable="0" name="MUNI_cdcmc"/>
    <field editable="0" name="MUNI_cmc"/>
    <field editable="0" name="MUNI_codine"/>
    <field editable="0" name="MUNI_nm"/>
    <field editable="1" name="NOM_MUNI"/>
    <field editable="1" name="NUMERO"/>
    <field editable="1" name="NUMERODUP"/>
    <field editable="1" name="NUMSYMBOL"/>
    <field editable="1" name="NUM_EXP"/>
    <field editable="1" name="PARCELA"/>
    <field editable="1" name="PCAT1"/>
    <field editable="1" name="PCAT2"/>
    <field editable="1" name="PROVINCIA"/>
    <field editable="1" name="RC14"/>
    <field editable="1" name="REF_CAT"/>
    <field editable="1" name="TIPO"/>
    <field editable="1" name="VIA"/>
    <field editable="1" name="fid"/>
  </editable>
  <labelOnTop>
    <field name="AREA" labelOnTop="0"/>
    <field name="CAT_NMSPC" labelOnTop="0"/>
    <field name="COD_INE" labelOnTop="0"/>
    <field name="CONTROL" labelOnTop="0"/>
    <field name="COORX" labelOnTop="0"/>
    <field name="COORY" labelOnTop="0"/>
    <field name="DELEGACIO" labelOnTop="0"/>
    <field name="DIRECCION" labelOnTop="0"/>
    <field name="EJERCICIO" labelOnTop="0"/>
    <field name="FECHAALTA" labelOnTop="0"/>
    <field name="FECHABAJA" labelOnTop="0"/>
    <field name="HOJA" labelOnTop="0"/>
    <field name="MAPA" labelOnTop="0"/>
    <field name="MASA" labelOnTop="0"/>
    <field name="MUNICIPIO" labelOnTop="0"/>
    <field name="MUNI_cd" labelOnTop="0"/>
    <field name="MUNI_cdcmc" labelOnTop="0"/>
    <field name="MUNI_cmc" labelOnTop="0"/>
    <field name="MUNI_codine" labelOnTop="0"/>
    <field name="MUNI_nm" labelOnTop="0"/>
    <field name="NOM_MUNI" labelOnTop="0"/>
    <field name="NUMERO" labelOnTop="0"/>
    <field name="NUMERODUP" labelOnTop="0"/>
    <field name="NUMSYMBOL" labelOnTop="0"/>
    <field name="NUM_EXP" labelOnTop="0"/>
    <field name="PARCELA" labelOnTop="0"/>
    <field name="PCAT1" labelOnTop="0"/>
    <field name="PCAT2" labelOnTop="0"/>
    <field name="PROVINCIA" labelOnTop="0"/>
    <field name="RC14" labelOnTop="0"/>
    <field name="REF_CAT" labelOnTop="0"/>
    <field name="TIPO" labelOnTop="0"/>
    <field name="VIA" labelOnTop="0"/>
    <field name="fid" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="AREA"/>
    <field reuseLastValue="0" name="CAT_NMSPC"/>
    <field reuseLastValue="0" name="COD_INE"/>
    <field reuseLastValue="0" name="CONTROL"/>
    <field reuseLastValue="0" name="COORX"/>
    <field reuseLastValue="0" name="COORY"/>
    <field reuseLastValue="0" name="DELEGACIO"/>
    <field reuseLastValue="0" name="DIRECCION"/>
    <field reuseLastValue="0" name="EJERCICIO"/>
    <field reuseLastValue="0" name="FECHAALTA"/>
    <field reuseLastValue="0" name="FECHABAJA"/>
    <field reuseLastValue="0" name="HOJA"/>
    <field reuseLastValue="0" name="MAPA"/>
    <field reuseLastValue="0" name="MASA"/>
    <field reuseLastValue="0" name="MUNICIPIO"/>
    <field reuseLastValue="0" name="NOM_MUNI"/>
    <field reuseLastValue="0" name="NUMERO"/>
    <field reuseLastValue="0" name="NUMERODUP"/>
    <field reuseLastValue="0" name="NUMSYMBOL"/>
    <field reuseLastValue="0" name="NUM_EXP"/>
    <field reuseLastValue="0" name="PARCELA"/>
    <field reuseLastValue="0" name="PCAT1"/>
    <field reuseLastValue="0" name="PCAT2"/>
    <field reuseLastValue="0" name="PROVINCIA"/>
    <field reuseLastValue="0" name="RC14"/>
    <field reuseLastValue="0" name="REF_CAT"/>
    <field reuseLastValue="0" name="TIPO"/>
    <field reuseLastValue="0" name="VIA"/>
    <field reuseLastValue="0" name="fid"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>COALESCE(   "RC14" , '&lt;NULL>' ) ||  '\n'  ||  coalesce(   "MUNICIPIO"  , '&lt;NULL>' ) || ' ' ||  coalesce(    "MUNI_nm"   , '&lt;NULL>' )</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
