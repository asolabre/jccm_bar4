<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis maxScale="0" simplifyDrawingTol="1" simplifyAlgorithm="0" styleCategories="AllStyleCategories" minScale="50000" labelsEnabled="1" simplifyLocal="1" simplifyMaxScale="1" readOnly="0" version="3.8.2-Zanzibar" simplifyDrawingHints="1" hasScaleBasedVisibilityFlag="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
  </flags>
  <renderer-v2 type="singleSymbol" enableorderby="0" symbollevels="0" forceraster="0">
    <symbols>
      <symbol type="fill" clip_to_extent="1" name="0" alpha="1" force_rhr="0">
        <layer locked="0" class="SimpleFill" enabled="1" pass="0">
          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
          <prop v="207,255,239,255" k="color"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="0,0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="51,48,227,255" k="outline_color"/>
          <prop v="solid" k="outline_style"/>
          <prop v="0.8" k="outline_width"/>
          <prop v="MM" k="outline_width_unit"/>
          <prop v="solid" k="style"/>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <labeling type="rule-based">
    <rules key="{446ea266-9867-46f6-859f-a61e0edc1362}">
      <rule key="{9f8085be-c329-4736-82f4-c9015ad48c65}">
        <settings>
          <text-style namedStyle="Normal" fontItalic="0" blendMode="0" previewBkgrdColor="#ffffff" textOpacity="1" isExpression="0" fontFamily="MS Shell Dlg 2" fontUnderline="0" multilineHeight="1" fontSize="0" fontWordSpacing="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" useSubstitutions="0" textColor="51,48,227,255" fontCapitals="0" fontStrikeout="0" fontWeight="50" fontSizeUnit="Point" fieldName="EX_TIPOINV" fontLetterSpacing="0">
            <text-buffer bufferSizeUnits="MM" bufferBlendMode="0" bufferDraw="1" bufferSize="0,8" bufferNoFill="0" bufferColor="255,255,255,255" bufferJoinStyle="64" bufferOpacity="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0"/>
            <background shapeRadiiUnit="MM" shapeDraw="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeRotationType="0" shapeOffsetX="0" shapeJoinStyle="64" shapeSizeY="0" shapeFillColor="255,255,255,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSVGFile="" shapeRotation="0" shapeRadiiY="0" shapeBorderWidthUnit="MM" shapeOpacity="1" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeBorderWidth="0" shapeOffsetY="0" shapeRadiiX="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeType="0"/>
            <shadow shadowRadiusUnit="MM" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="0" shadowOffsetGlobal="1" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowOffsetDist="1" shadowScale="100" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOpacity="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowDraw="0" shadowUnder="0"/>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" reverseDirectionSymbol="0" plussign="0" autoWrapLength="0" rightDirectionSymbol=">" leftDirectionSymbol="&lt;" multilineAlign="0" formatNumbers="0" wrapChar="" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" decimals="3"/>
          <placement xOffset="0" maxCurvedCharAngleIn="20" dist="0" rotationAngle="0" geometryGeneratorType="PointGeometry" distUnits="MM" repeatDistanceUnits="MM" offsetUnits="MapUnit" repeatDistance="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" placement="1" geometryGeneratorEnabled="0" yOffset="0" fitInPolygonOnly="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" quadOffset="4" centroidWhole="0" priority="5" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" centroidInside="1" geometryGenerator="" distMapUnitScale="3x:0,0,0,0,0,0" offsetType="0" preserveRotation="1" maxCurvedCharAngleOut="-20" placementFlags="10"/>
          <rendering displayAll="0" fontMinPixelSize="3" scaleMin="1" obstacleType="0" fontLimitPixelSize="0" scaleMax="10000000" labelPerPart="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" zIndex="0" mergeLines="0" upsidedownLabels="0" maxNumLabels="2000" scaleVisibility="0" fontMaxPixelSize="10000" obstacle="1" limitNumLabels="0"/>
          <dd_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </dd_properties>
        </settings>
      </rule>
      <rule description="INVASION" key="{86e3b432-bb4a-47b4-b71b-23f536609f50}" filter=" &quot;EX_TIPOINV&quot;  =  'INVASION'">
        <settings>
          <text-style namedStyle="Normal" fontItalic="0" blendMode="0" previewBkgrdColor="#ffffff" textOpacity="1" isExpression="1" fontFamily="MS Shell Dlg 2" fontUnderline="0" multilineHeight="1" fontSize="8" fontWordSpacing="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" useSubstitutions="0" textColor="255,1,13,255" fontCapitals="0" fontStrikeout="0" fontWeight="50" fontSizeUnit="Point" fieldName="'INVASION' + '\n' + &quot;RC14&quot; + '\n' +format_number(   &quot;EX_SUPINF&quot;   ,1)  || ' m2'" fontLetterSpacing="0">
            <text-buffer bufferSizeUnits="MM" bufferBlendMode="0" bufferDraw="1" bufferSize="0,8" bufferNoFill="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferOpacity="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0"/>
            <background shapeRadiiUnit="MM" shapeDraw="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeRotationType="0" shapeOffsetX="0" shapeJoinStyle="64" shapeSizeY="0" shapeFillColor="255,255,255,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSVGFile="" shapeRotation="0" shapeRadiiY="0" shapeBorderWidthUnit="MM" shapeOpacity="1" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeBorderWidth="0" shapeOffsetY="0" shapeRadiiX="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeType="0"/>
            <shadow shadowRadiusUnit="MM" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="0" shadowOffsetGlobal="1" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowOffsetDist="1" shadowScale="100" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOpacity="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowDraw="0" shadowUnder="0"/>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" reverseDirectionSymbol="0" plussign="0" autoWrapLength="0" rightDirectionSymbol=">" leftDirectionSymbol="&lt;" multilineAlign="0" formatNumbers="0" wrapChar="" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" decimals="3"/>
          <placement xOffset="0" maxCurvedCharAngleIn="25" dist="0" rotationAngle="0" geometryGeneratorType="PointGeometry" distUnits="MM" repeatDistanceUnits="MM" offsetUnits="MM" repeatDistance="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" placement="0" geometryGeneratorEnabled="0" yOffset="0" fitInPolygonOnly="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" quadOffset="4" centroidWhole="0" priority="5" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" centroidInside="1" geometryGenerator="" distMapUnitScale="3x:0,0,0,0,0,0" offsetType="0" preserveRotation="1" maxCurvedCharAngleOut="-25" placementFlags="10"/>
          <rendering displayAll="0" fontMinPixelSize="3" scaleMin="0" obstacleType="0" fontLimitPixelSize="0" scaleMax="0" labelPerPart="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" zIndex="0" mergeLines="0" upsidedownLabels="0" maxNumLabels="2000" scaleVisibility="0" fontMaxPixelSize="10000" obstacle="1" limitNumLabels="0"/>
          <dd_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </dd_properties>
        </settings>
      </rule>
      <rule description="NO INVASION" key="{fbd4e39f-2091-4626-adb5-da5eb34432ba}" filter=" &quot;EX_TIPOINV&quot;  =  'NO INVASION'">
        <settings>
          <text-style namedStyle="Normal" fontItalic="0" blendMode="0" previewBkgrdColor="#ffffff" textOpacity="1" isExpression="1" fontFamily="MS Shell Dlg 2" fontUnderline="0" multilineHeight="1" fontSize="8" fontWordSpacing="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" useSubstitutions="0" textColor="1,13,255,255" fontCapitals="0" fontStrikeout="0" fontWeight="50" fontSizeUnit="Point" fieldName="'NO INVASION'" fontLetterSpacing="0">
            <text-buffer bufferSizeUnits="MM" bufferBlendMode="0" bufferDraw="1" bufferSize="0,8" bufferNoFill="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferOpacity="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0"/>
            <background shapeRadiiUnit="MM" shapeDraw="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeRotationType="0" shapeOffsetX="0" shapeJoinStyle="64" shapeSizeY="0" shapeFillColor="255,255,255,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSVGFile="" shapeRotation="0" shapeRadiiY="0" shapeBorderWidthUnit="MM" shapeOpacity="1" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeBorderWidth="0" shapeOffsetY="0" shapeRadiiX="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeType="0"/>
            <shadow shadowRadiusUnit="MM" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="0" shadowOffsetGlobal="1" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowOffsetDist="1" shadowScale="100" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOpacity="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowDraw="0" shadowUnder="0"/>
            <substitutions/>
          </text-style>
          <text-format addDirectionSymbol="0" reverseDirectionSymbol="0" plussign="0" autoWrapLength="0" rightDirectionSymbol=">" leftDirectionSymbol="&lt;" multilineAlign="0" formatNumbers="0" wrapChar="" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" decimals="3"/>
          <placement xOffset="0" maxCurvedCharAngleIn="25" dist="0" rotationAngle="0" geometryGeneratorType="PointGeometry" distUnits="MM" repeatDistanceUnits="MM" offsetUnits="MM" repeatDistance="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" placement="0" geometryGeneratorEnabled="0" yOffset="0" fitInPolygonOnly="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" quadOffset="4" centroidWhole="0" priority="5" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" centroidInside="1" geometryGenerator="" distMapUnitScale="3x:0,0,0,0,0,0" offsetType="0" preserveRotation="1" maxCurvedCharAngleOut="-25" placementFlags="10"/>
          <rendering displayAll="0" fontMinPixelSize="3" scaleMin="0" obstacleType="0" fontLimitPixelSize="0" scaleMax="0" labelPerPart="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" zIndex="0" mergeLines="0" upsidedownLabels="0" maxNumLabels="2000" scaleVisibility="0" fontMaxPixelSize="10000" obstacle="1" limitNumLabels="0"/>
          <dd_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </dd_properties>
        </settings>
      </rule>
    </rules>
  </labeling>
  <customproperties>
    <property value="NOM_MUNI" key="dualview/previewExpressions"/>
    <property value="0" key="embeddedWidgets/count"/>
    <property key="variableNames"/>
    <property key="variableValues"/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>0.6</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Pie">
    <DiagramCategory lineSizeScale="3x:0,0,0,0,0,0" minScaleDenominator="0" barWidth="5" width="15" penWidth="0" diagramOrientation="Up" enabled="0" lineSizeType="MM" penColor="#000000" scaleDependency="Area" height="15" sizeType="MM" sizeScale="3x:0,0,0,0,0,0" opacity="1" penAlpha="255" backgroundColor="#ffffff" labelPlacementMethod="XHeight" scaleBasedVisibility="0" rotationOffset="270" backgroundAlpha="255" maxScaleDenominator="1e+08" minimumSize="0">
      <fontProperties description="MS Shell Dlg 2,7.8,-1,5,50,0,0,0,0,0" style=""/>
      <attribute label="" field="" color="#000000"/>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings obstacle="0" dist="0" linePlacementFlags="2" showAll="1" priority="0" zIndex="0" placement="0">
    <properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <fieldConfiguration>
    <field name="EX_NUM">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="EX_TMUNIC">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="EX_TEXTINF">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="EX_SUPEXPR">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="EX_SUPINF">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="EX_TIPOINV">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CAT_NMSPC">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="RC14">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PCAT1">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PCAT2">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="EJERCICIO">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NUM_EXP">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CONTROL">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COORY">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="VIA">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NUMERO">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NUMERODUP">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NUMSYMBOL">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="AREA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="FECHAALTA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="FECHABAJA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="MAPA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DELEGACIO">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="MUNICIPIO">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="MASA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="HOJA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="TIPO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PARCELA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="COORX">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NOM_MUNI">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="EXPTE1">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="TITULARIDA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="FUNCIONALI">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CTRA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PKINI">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PKFIN">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CTRA_ANT">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PKINI_ANT">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PKFIN_ANT">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="EXPTE2">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="EXPTE3">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NOM_TRAMO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="NOM_PROYEC">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DIR_DOC">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Layer">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="SUPERFICIE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="PROVINCIA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="TERM_MUNIC">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="TERM_MUCOD">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ACAD_REV">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ID_REG">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="REV_EXPTE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="DIR_DOC_B">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CAT-REMISI">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CAT_ESTADO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="CAT_OBSERV">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" name="" field="EX_NUM"/>
    <alias index="1" name="" field="EX_TMUNIC"/>
    <alias index="2" name="" field="EX_TEXTINF"/>
    <alias index="3" name="" field="EX_SUPEXPR"/>
    <alias index="4" name="" field="EX_SUPINF"/>
    <alias index="5" name="" field="EX_TIPOINV"/>
    <alias index="6" name="" field="CAT_NMSPC"/>
    <alias index="7" name="" field="RC14"/>
    <alias index="8" name="" field="PCAT1"/>
    <alias index="9" name="" field="PCAT2"/>
    <alias index="10" name="" field="EJERCICIO"/>
    <alias index="11" name="" field="NUM_EXP"/>
    <alias index="12" name="" field="CONTROL"/>
    <alias index="13" name="" field="COORY"/>
    <alias index="14" name="" field="VIA"/>
    <alias index="15" name="" field="NUMERO"/>
    <alias index="16" name="" field="NUMERODUP"/>
    <alias index="17" name="" field="NUMSYMBOL"/>
    <alias index="18" name="" field="AREA"/>
    <alias index="19" name="" field="FECHAALTA"/>
    <alias index="20" name="" field="FECHABAJA"/>
    <alias index="21" name="" field="MAPA"/>
    <alias index="22" name="" field="DELEGACIO"/>
    <alias index="23" name="" field="MUNICIPIO"/>
    <alias index="24" name="" field="MASA"/>
    <alias index="25" name="" field="HOJA"/>
    <alias index="26" name="" field="TIPO"/>
    <alias index="27" name="" field="PARCELA"/>
    <alias index="28" name="" field="COORX"/>
    <alias index="29" name="" field="NOM_MUNI"/>
    <alias index="30" name="" field="EXPTE1"/>
    <alias index="31" name="" field="TITULARIDA"/>
    <alias index="32" name="" field="FUNCIONALI"/>
    <alias index="33" name="" field="CTRA"/>
    <alias index="34" name="" field="PKINI"/>
    <alias index="35" name="" field="PKFIN"/>
    <alias index="36" name="" field="CTRA_ANT"/>
    <alias index="37" name="" field="PKINI_ANT"/>
    <alias index="38" name="" field="PKFIN_ANT"/>
    <alias index="39" name="" field="EXPTE2"/>
    <alias index="40" name="" field="EXPTE3"/>
    <alias index="41" name="" field="NOM_TRAMO"/>
    <alias index="42" name="" field="NOM_PROYEC"/>
    <alias index="43" name="" field="DIR_DOC"/>
    <alias index="44" name="" field="Layer"/>
    <alias index="45" name="" field="SUPERFICIE"/>
    <alias index="46" name="" field="PROVINCIA"/>
    <alias index="47" name="" field="TERM_MUNIC"/>
    <alias index="48" name="" field="TERM_MUCOD"/>
    <alias index="49" name="" field="ACAD_REV"/>
    <alias index="50" name="" field="ID_REG"/>
    <alias index="51" name="" field="REV_EXPTE"/>
    <alias index="52" name="" field="DIR_DOC_B"/>
    <alias index="53" name="" field="CAT-REMISI"/>
    <alias index="54" name="" field="CAT_ESTADO"/>
    <alias index="55" name="" field="CAT_OBSERV"/>
  </aliases>
  <excludeAttributesWMS/>
  <excludeAttributesWFS/>
  <defaults>
    <default expression="" field="EX_NUM" applyOnUpdate="0"/>
    <default expression="" field="EX_TMUNIC" applyOnUpdate="0"/>
    <default expression="" field="EX_TEXTINF" applyOnUpdate="0"/>
    <default expression="" field="EX_SUPEXPR" applyOnUpdate="0"/>
    <default expression="" field="EX_SUPINF" applyOnUpdate="0"/>
    <default expression="" field="EX_TIPOINV" applyOnUpdate="0"/>
    <default expression="" field="CAT_NMSPC" applyOnUpdate="0"/>
    <default expression="" field="RC14" applyOnUpdate="0"/>
    <default expression="" field="PCAT1" applyOnUpdate="0"/>
    <default expression="" field="PCAT2" applyOnUpdate="0"/>
    <default expression="" field="EJERCICIO" applyOnUpdate="0"/>
    <default expression="" field="NUM_EXP" applyOnUpdate="0"/>
    <default expression="" field="CONTROL" applyOnUpdate="0"/>
    <default expression="" field="COORY" applyOnUpdate="0"/>
    <default expression="" field="VIA" applyOnUpdate="0"/>
    <default expression="" field="NUMERO" applyOnUpdate="0"/>
    <default expression="" field="NUMERODUP" applyOnUpdate="0"/>
    <default expression="" field="NUMSYMBOL" applyOnUpdate="0"/>
    <default expression="" field="AREA" applyOnUpdate="0"/>
    <default expression="" field="FECHAALTA" applyOnUpdate="0"/>
    <default expression="" field="FECHABAJA" applyOnUpdate="0"/>
    <default expression="" field="MAPA" applyOnUpdate="0"/>
    <default expression="" field="DELEGACIO" applyOnUpdate="0"/>
    <default expression="" field="MUNICIPIO" applyOnUpdate="0"/>
    <default expression="" field="MASA" applyOnUpdate="0"/>
    <default expression="" field="HOJA" applyOnUpdate="0"/>
    <default expression="" field="TIPO" applyOnUpdate="0"/>
    <default expression="" field="PARCELA" applyOnUpdate="0"/>
    <default expression="" field="COORX" applyOnUpdate="0"/>
    <default expression="" field="NOM_MUNI" applyOnUpdate="0"/>
    <default expression="" field="EXPTE1" applyOnUpdate="0"/>
    <default expression="" field="TITULARIDA" applyOnUpdate="0"/>
    <default expression="" field="FUNCIONALI" applyOnUpdate="0"/>
    <default expression="" field="CTRA" applyOnUpdate="0"/>
    <default expression="" field="PKINI" applyOnUpdate="0"/>
    <default expression="" field="PKFIN" applyOnUpdate="0"/>
    <default expression="" field="CTRA_ANT" applyOnUpdate="0"/>
    <default expression="" field="PKINI_ANT" applyOnUpdate="0"/>
    <default expression="" field="PKFIN_ANT" applyOnUpdate="0"/>
    <default expression="" field="EXPTE2" applyOnUpdate="0"/>
    <default expression="" field="EXPTE3" applyOnUpdate="0"/>
    <default expression="" field="NOM_TRAMO" applyOnUpdate="0"/>
    <default expression="" field="NOM_PROYEC" applyOnUpdate="0"/>
    <default expression="" field="DIR_DOC" applyOnUpdate="0"/>
    <default expression="" field="Layer" applyOnUpdate="0"/>
    <default expression="" field="SUPERFICIE" applyOnUpdate="0"/>
    <default expression="" field="PROVINCIA" applyOnUpdate="0"/>
    <default expression="" field="TERM_MUNIC" applyOnUpdate="0"/>
    <default expression="" field="TERM_MUCOD" applyOnUpdate="0"/>
    <default expression="" field="ACAD_REV" applyOnUpdate="0"/>
    <default expression="" field="ID_REG" applyOnUpdate="0"/>
    <default expression="" field="REV_EXPTE" applyOnUpdate="0"/>
    <default expression="" field="DIR_DOC_B" applyOnUpdate="0"/>
    <default expression="" field="CAT-REMISI" applyOnUpdate="0"/>
    <default expression="" field="CAT_ESTADO" applyOnUpdate="0"/>
    <default expression="" field="CAT_OBSERV" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint constraints="0" unique_strength="0" field="EX_NUM" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="EX_TMUNIC" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="EX_TEXTINF" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="EX_SUPEXPR" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="EX_SUPINF" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="EX_TIPOINV" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="CAT_NMSPC" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="RC14" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="PCAT1" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="PCAT2" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="EJERCICIO" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="NUM_EXP" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="CONTROL" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="COORY" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="VIA" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="NUMERO" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="NUMERODUP" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="NUMSYMBOL" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="AREA" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="FECHAALTA" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="FECHABAJA" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="MAPA" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="DELEGACIO" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="MUNICIPIO" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="MASA" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="HOJA" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="TIPO" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="PARCELA" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="COORX" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="NOM_MUNI" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="EXPTE1" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="TITULARIDA" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="FUNCIONALI" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="CTRA" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="PKINI" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="PKFIN" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="CTRA_ANT" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="PKINI_ANT" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="PKFIN_ANT" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="EXPTE2" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="EXPTE3" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="NOM_TRAMO" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="NOM_PROYEC" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="DIR_DOC" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="Layer" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="SUPERFICIE" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="PROVINCIA" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="TERM_MUNIC" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="TERM_MUCOD" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="ACAD_REV" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="ID_REG" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="REV_EXPTE" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="DIR_DOC_B" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="CAT-REMISI" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="CAT_ESTADO" exp_strength="0" notnull_strength="0"/>
    <constraint constraints="0" unique_strength="0" field="CAT_OBSERV" exp_strength="0" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="EX_NUM"/>
    <constraint desc="" exp="" field="EX_TMUNIC"/>
    <constraint desc="" exp="" field="EX_TEXTINF"/>
    <constraint desc="" exp="" field="EX_SUPEXPR"/>
    <constraint desc="" exp="" field="EX_SUPINF"/>
    <constraint desc="" exp="" field="EX_TIPOINV"/>
    <constraint desc="" exp="" field="CAT_NMSPC"/>
    <constraint desc="" exp="" field="RC14"/>
    <constraint desc="" exp="" field="PCAT1"/>
    <constraint desc="" exp="" field="PCAT2"/>
    <constraint desc="" exp="" field="EJERCICIO"/>
    <constraint desc="" exp="" field="NUM_EXP"/>
    <constraint desc="" exp="" field="CONTROL"/>
    <constraint desc="" exp="" field="COORY"/>
    <constraint desc="" exp="" field="VIA"/>
    <constraint desc="" exp="" field="NUMERO"/>
    <constraint desc="" exp="" field="NUMERODUP"/>
    <constraint desc="" exp="" field="NUMSYMBOL"/>
    <constraint desc="" exp="" field="AREA"/>
    <constraint desc="" exp="" field="FECHAALTA"/>
    <constraint desc="" exp="" field="FECHABAJA"/>
    <constraint desc="" exp="" field="MAPA"/>
    <constraint desc="" exp="" field="DELEGACIO"/>
    <constraint desc="" exp="" field="MUNICIPIO"/>
    <constraint desc="" exp="" field="MASA"/>
    <constraint desc="" exp="" field="HOJA"/>
    <constraint desc="" exp="" field="TIPO"/>
    <constraint desc="" exp="" field="PARCELA"/>
    <constraint desc="" exp="" field="COORX"/>
    <constraint desc="" exp="" field="NOM_MUNI"/>
    <constraint desc="" exp="" field="EXPTE1"/>
    <constraint desc="" exp="" field="TITULARIDA"/>
    <constraint desc="" exp="" field="FUNCIONALI"/>
    <constraint desc="" exp="" field="CTRA"/>
    <constraint desc="" exp="" field="PKINI"/>
    <constraint desc="" exp="" field="PKFIN"/>
    <constraint desc="" exp="" field="CTRA_ANT"/>
    <constraint desc="" exp="" field="PKINI_ANT"/>
    <constraint desc="" exp="" field="PKFIN_ANT"/>
    <constraint desc="" exp="" field="EXPTE2"/>
    <constraint desc="" exp="" field="EXPTE3"/>
    <constraint desc="" exp="" field="NOM_TRAMO"/>
    <constraint desc="" exp="" field="NOM_PROYEC"/>
    <constraint desc="" exp="" field="DIR_DOC"/>
    <constraint desc="" exp="" field="Layer"/>
    <constraint desc="" exp="" field="SUPERFICIE"/>
    <constraint desc="" exp="" field="PROVINCIA"/>
    <constraint desc="" exp="" field="TERM_MUNIC"/>
    <constraint desc="" exp="" field="TERM_MUCOD"/>
    <constraint desc="" exp="" field="ACAD_REV"/>
    <constraint desc="" exp="" field="ID_REG"/>
    <constraint desc="" exp="" field="REV_EXPTE"/>
    <constraint desc="" exp="" field="DIR_DOC_B"/>
    <constraint desc="" exp="" field="CAT-REMISI"/>
    <constraint desc="" exp="" field="CAT_ESTADO"/>
    <constraint desc="" exp="" field="CAT_OBSERV"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig sortExpression="" actionWidgetStyle="dropDown" sortOrder="0">
    <columns>
      <column type="field" width="-1" name="EX_NUM" hidden="0"/>
      <column type="field" width="-1" name="EX_TMUNIC" hidden="0"/>
      <column type="field" width="-1" name="EX_TEXTINF" hidden="0"/>
      <column type="field" width="-1" name="EX_SUPEXPR" hidden="0"/>
      <column type="field" width="-1" name="EX_SUPINF" hidden="0"/>
      <column type="field" width="-1" name="EX_TIPOINV" hidden="0"/>
      <column type="field" width="-1" name="CAT_NMSPC" hidden="0"/>
      <column type="field" width="-1" name="RC14" hidden="0"/>
      <column type="field" width="-1" name="PCAT1" hidden="0"/>
      <column type="field" width="-1" name="PCAT2" hidden="0"/>
      <column type="field" width="-1" name="EJERCICIO" hidden="0"/>
      <column type="field" width="-1" name="NUM_EXP" hidden="0"/>
      <column type="field" width="-1" name="CONTROL" hidden="0"/>
      <column type="field" width="-1" name="COORY" hidden="0"/>
      <column type="field" width="-1" name="VIA" hidden="0"/>
      <column type="field" width="-1" name="NUMERO" hidden="0"/>
      <column type="field" width="-1" name="NUMERODUP" hidden="0"/>
      <column type="field" width="-1" name="NUMSYMBOL" hidden="0"/>
      <column type="field" width="-1" name="AREA" hidden="0"/>
      <column type="field" width="-1" name="FECHAALTA" hidden="0"/>
      <column type="field" width="-1" name="FECHABAJA" hidden="0"/>
      <column type="field" width="-1" name="MAPA" hidden="0"/>
      <column type="field" width="-1" name="DELEGACIO" hidden="0"/>
      <column type="field" width="-1" name="MUNICIPIO" hidden="0"/>
      <column type="field" width="-1" name="MASA" hidden="0"/>
      <column type="field" width="-1" name="HOJA" hidden="0"/>
      <column type="field" width="-1" name="TIPO" hidden="0"/>
      <column type="field" width="-1" name="PARCELA" hidden="0"/>
      <column type="field" width="-1" name="COORX" hidden="0"/>
      <column type="field" width="-1" name="NOM_MUNI" hidden="0"/>
      <column type="field" width="-1" name="EXPTE1" hidden="0"/>
      <column type="field" width="-1" name="TITULARIDA" hidden="0"/>
      <column type="field" width="-1" name="FUNCIONALI" hidden="0"/>
      <column type="field" width="-1" name="CTRA" hidden="0"/>
      <column type="field" width="-1" name="PKINI" hidden="0"/>
      <column type="field" width="-1" name="PKFIN" hidden="0"/>
      <column type="field" width="-1" name="CTRA_ANT" hidden="0"/>
      <column type="field" width="-1" name="PKINI_ANT" hidden="0"/>
      <column type="field" width="-1" name="PKFIN_ANT" hidden="0"/>
      <column type="field" width="-1" name="EXPTE2" hidden="0"/>
      <column type="field" width="-1" name="EXPTE3" hidden="0"/>
      <column type="field" width="-1" name="NOM_TRAMO" hidden="0"/>
      <column type="field" width="-1" name="NOM_PROYEC" hidden="0"/>
      <column type="field" width="-1" name="DIR_DOC" hidden="0"/>
      <column type="field" width="-1" name="Layer" hidden="0"/>
      <column type="field" width="-1" name="SUPERFICIE" hidden="0"/>
      <column type="field" width="-1" name="PROVINCIA" hidden="0"/>
      <column type="field" width="-1" name="TERM_MUNIC" hidden="0"/>
      <column type="field" width="-1" name="TERM_MUCOD" hidden="0"/>
      <column type="field" width="-1" name="ACAD_REV" hidden="0"/>
      <column type="field" width="-1" name="ID_REG" hidden="0"/>
      <column type="field" width="-1" name="REV_EXPTE" hidden="0"/>
      <column type="field" width="-1" name="DIR_DOC_B" hidden="0"/>
      <column type="field" width="-1" name="CAT-REMISI" hidden="0"/>
      <column type="field" width="-1" name="CAT_ESTADO" hidden="0"/>
      <column type="field" width="-1" name="CAT_OBSERV" hidden="0"/>
      <column type="actions" width="-1" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <editform tolerant="1">U:/cartografia/datos_Q/QSIG/MENUS/INFORMES EXPROPIACIONES.ui</editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath>.</editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from PyQt4.QtGui import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>1</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="ACAD_REV" editable="1"/>
    <field name="AREA" editable="1"/>
    <field name="CAT-REMISI" editable="1"/>
    <field name="CAT_ESTADO" editable="1"/>
    <field name="CAT_NMSPC" editable="1"/>
    <field name="CAT_OBSERV" editable="1"/>
    <field name="CONTROL" editable="1"/>
    <field name="COORX" editable="1"/>
    <field name="COORY" editable="1"/>
    <field name="CTRA" editable="1"/>
    <field name="CTRA_ANT" editable="1"/>
    <field name="DELEGACIO" editable="1"/>
    <field name="DIR_DOC" editable="1"/>
    <field name="DIR_DOC_B" editable="1"/>
    <field name="EJERCICIO" editable="1"/>
    <field name="EXPTE1" editable="1"/>
    <field name="EXPTE2" editable="1"/>
    <field name="EXPTE3" editable="1"/>
    <field name="EX_NUM" editable="1"/>
    <field name="EX_SUPEXPR" editable="1"/>
    <field name="EX_SUPINF" editable="1"/>
    <field name="EX_TEXTINF" editable="1"/>
    <field name="EX_TIPOINV" editable="1"/>
    <field name="EX_TMUNIC" editable="1"/>
    <field name="FECHAALTA" editable="1"/>
    <field name="FECHABAJA" editable="1"/>
    <field name="FUNCIONALI" editable="1"/>
    <field name="HOJA" editable="1"/>
    <field name="ID_REG" editable="1"/>
    <field name="Layer" editable="1"/>
    <field name="MAPA" editable="1"/>
    <field name="MASA" editable="1"/>
    <field name="MUNICIPIO" editable="1"/>
    <field name="NOM_MUNI" editable="1"/>
    <field name="NOM_PROYEC" editable="1"/>
    <field name="NOM_TRAMO" editable="1"/>
    <field name="NUMERO" editable="1"/>
    <field name="NUMERODUP" editable="1"/>
    <field name="NUMSYMBOL" editable="1"/>
    <field name="NUM_EXP" editable="1"/>
    <field name="PARCELA" editable="1"/>
    <field name="PCAT1" editable="1"/>
    <field name="PCAT2" editable="1"/>
    <field name="PKFIN" editable="1"/>
    <field name="PKFIN_ANT" editable="1"/>
    <field name="PKINI" editable="1"/>
    <field name="PKINI_ANT" editable="1"/>
    <field name="PROVINCIA" editable="1"/>
    <field name="RC14" editable="1"/>
    <field name="REV_EXPTE" editable="1"/>
    <field name="SUPERFICIE" editable="1"/>
    <field name="TERM_MUCOD" editable="1"/>
    <field name="TERM_MUNIC" editable="1"/>
    <field name="TIPO" editable="1"/>
    <field name="TITULARIDA" editable="1"/>
    <field name="VIA" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="ACAD_REV" labelOnTop="0"/>
    <field name="AREA" labelOnTop="0"/>
    <field name="CAT-REMISI" labelOnTop="0"/>
    <field name="CAT_ESTADO" labelOnTop="0"/>
    <field name="CAT_NMSPC" labelOnTop="0"/>
    <field name="CAT_OBSERV" labelOnTop="0"/>
    <field name="CONTROL" labelOnTop="0"/>
    <field name="COORX" labelOnTop="0"/>
    <field name="COORY" labelOnTop="0"/>
    <field name="CTRA" labelOnTop="0"/>
    <field name="CTRA_ANT" labelOnTop="0"/>
    <field name="DELEGACIO" labelOnTop="0"/>
    <field name="DIR_DOC" labelOnTop="0"/>
    <field name="DIR_DOC_B" labelOnTop="0"/>
    <field name="EJERCICIO" labelOnTop="0"/>
    <field name="EXPTE1" labelOnTop="0"/>
    <field name="EXPTE2" labelOnTop="0"/>
    <field name="EXPTE3" labelOnTop="0"/>
    <field name="EX_NUM" labelOnTop="0"/>
    <field name="EX_SUPEXPR" labelOnTop="0"/>
    <field name="EX_SUPINF" labelOnTop="0"/>
    <field name="EX_TEXTINF" labelOnTop="0"/>
    <field name="EX_TIPOINV" labelOnTop="0"/>
    <field name="EX_TMUNIC" labelOnTop="0"/>
    <field name="FECHAALTA" labelOnTop="0"/>
    <field name="FECHABAJA" labelOnTop="0"/>
    <field name="FUNCIONALI" labelOnTop="0"/>
    <field name="HOJA" labelOnTop="0"/>
    <field name="ID_REG" labelOnTop="0"/>
    <field name="Layer" labelOnTop="0"/>
    <field name="MAPA" labelOnTop="0"/>
    <field name="MASA" labelOnTop="0"/>
    <field name="MUNICIPIO" labelOnTop="0"/>
    <field name="NOM_MUNI" labelOnTop="0"/>
    <field name="NOM_PROYEC" labelOnTop="0"/>
    <field name="NOM_TRAMO" labelOnTop="0"/>
    <field name="NUMERO" labelOnTop="0"/>
    <field name="NUMERODUP" labelOnTop="0"/>
    <field name="NUMSYMBOL" labelOnTop="0"/>
    <field name="NUM_EXP" labelOnTop="0"/>
    <field name="PARCELA" labelOnTop="0"/>
    <field name="PCAT1" labelOnTop="0"/>
    <field name="PCAT2" labelOnTop="0"/>
    <field name="PKFIN" labelOnTop="0"/>
    <field name="PKFIN_ANT" labelOnTop="0"/>
    <field name="PKINI" labelOnTop="0"/>
    <field name="PKINI_ANT" labelOnTop="0"/>
    <field name="PROVINCIA" labelOnTop="0"/>
    <field name="RC14" labelOnTop="0"/>
    <field name="REV_EXPTE" labelOnTop="0"/>
    <field name="SUPERFICIE" labelOnTop="0"/>
    <field name="TERM_MUCOD" labelOnTop="0"/>
    <field name="TERM_MUNIC" labelOnTop="0"/>
    <field name="TIPO" labelOnTop="0"/>
    <field name="TITULARIDA" labelOnTop="0"/>
    <field name="VIA" labelOnTop="0"/>
  </labelOnTop>
  <widgets/>
  <previewExpression>NOM_MUNI</previewExpression>
  <mapTip>TITULARIDA</mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
