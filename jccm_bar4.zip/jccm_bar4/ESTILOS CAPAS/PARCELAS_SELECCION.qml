<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis labelsEnabled="1" hasScaleBasedVisibilityFlag="1" readOnly="0" simplifyDrawingHints="1" minScale="100000" version="3.40.15-Bratislava" simplifyDrawingTol="1" autoRefreshTime="0" simplifyAlgorithm="0" symbologyReferenceScale="-1" simplifyMaxScale="1" maxScale="0" simplifyLocal="1" styleCategories="AllStyleCategories" autoRefreshMode="Disabled">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal startField="" durationField="DELEGACIO" enabled="0" startExpression="" mode="0" endField="" accumulate="0" endExpression="" fixedDuration="0" durationUnit="min" limitMode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation symbology="Line" showMarkerSymbolInSurfacePlots="0" type="IndividualFeatures" zoffset="0" extrusionEnabled="0" extrusion="0" respectLayerSymbol="1" zscale="1" binding="Centroid" clamping="Terrain">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol type="line" alpha="1" force_rhr="0" name="" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleLine" id="{d3e1344d-65c3-4f8e-83c0-bd9be5aae28b}" pass="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="196,60,57,255,rgb:0.7686274509803922,0.23529411764705882,0.22352941176470589,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.6"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol type="fill" alpha="1" force_rhr="0" name="" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleFill" id="{f91cde5c-5654-4d8a-bb7d-9b927b8298da}" pass="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="196,60,57,255,rgb:0.7686274509803922,0.23529411764705882,0.22352941176470589,1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="140,43,41,255,rgb:0.5490196078431373,0.16803234912642101,0.15967040512703135,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol type="marker" alpha="1" force_rhr="0" name="" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleMarker" id="{6058907c-e04b-47c8-a829-3171fb52fa4c}" pass="0">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="196,60,57,255,rgb:0.7686274509803922,0.23529411764705882,0.22352941176470589,1"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="diamond"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="140,43,41,255,rgb:0.5490196078431373,0.16803234912642101,0.15967040512703135,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="3"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 forceraster="0" enableorderby="0" symbollevels="0" type="singleSymbol" referencescale="-1">
    <symbols>
      <symbol type="fill" alpha="1" force_rhr="0" name="0" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleFill" id="{64c22657-aeac-4a14-8957-9285474540ce}" pass="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="116,212,164,0,hsv:0.41666666666666669,0.45098039215686275,0.83137254901960789,0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="255,0,25,255,rgb:1,0,0.09803921568627451,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.8"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option type="Map" name="properties">
                <Option type="Map" name="fillColor">
                  <Option type="bool" name="active" value="true"/>
                  <Option type="QString" name="expression" value="coalesce(&#xd;&#xa; if(  &quot;COORDINADA&quot; = true,color_rgba( 200,255,100,40),0 ),&#xd;&#xa;0&#xd;&#xa;)"/>
                  <Option type="int" name="type" value="3"/>
                </Option>
              </Option>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol type="fill" alpha="1" force_rhr="0" name="" is_animated="0" clip_to_extent="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" class="SimpleFill" id="{2239feca-40a8-42c9-af0d-a0288cb5d39f}" pass="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="0,0,255,255,rgb:0,0,1,1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.26"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style forcedBold="0" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" legendString="Aa" namedStyle="Normal" textColor="227,26,28,255,rgb:0.8901960784313725,0.10196078431372549,0.10980392156862745,1" fontKerning="1" fontSize="8" textOpacity="1" fontFamily="Arial" textOrientation="horizontal" fontItalic="0" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" allowHtml="0" fontStrikeout="0" stretchFactor="100" fieldName="coalesce(&#xd;&#xa;&quot;RC14&quot;+'\n'+ ( if(  &quot;COORDINADA&quot; = true,'Coordinada','' )),&#xd;&#xa;&quot;RC14&quot;)" fontUnderline="0" tabStopDistanceUnit="Point" capitalization="0" fontWeight="50" fontSizeUnit="Point" fontWordSpacing="0" tabStopDistance="80" useSubstitutions="0" blendMode="0" multilineHeight="1" fontLetterSpacing="0" isExpression="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" multilineHeightUnit="Percentage" forcedItalic="0">
        <families/>
        <text-buffer bufferColor="255,255,255,255,rgb:1,1,1,1" bufferJoinStyle="64" bufferOpacity="1" bufferSizeUnits="MM" bufferBlendMode="0" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="0" bufferDraw="1"/>
        <text-mask maskType="0" maskEnabled="0" maskSize="1.5" maskedSymbolLayers="" maskJoinStyle="128" maskSize2="1.5" maskOpacity="1" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0"/>
        <background shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeSizeX="0" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeOpacity="1" shapeBlendMode="0" shapeSizeY="0" shapeRotation="0" shapeBorderWidthUnit="MM" shapeSizeType="0" shapeSVGFile="" shapeOffsetY="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeType="0" shapeBorderColor="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" shapeRotationType="0" shapeDraw="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetX="0" shapeRadiiX="0">
          <symbol type="marker" alpha="1" force_rhr="0" name="markerSymbol" is_animated="0" clip_to_extent="1" frame_rate="10">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value=""/>
                <Option name="properties"/>
                <Option type="QString" name="type" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer locked="0" enabled="1" class="SimpleMarker" id="" pass="0">
              <Option type="Map">
                <Option type="QString" name="angle" value="0"/>
                <Option type="QString" name="cap_style" value="square"/>
                <Option type="QString" name="color" value="125,139,143,255,rgb:0.49019607843137253,0.54509803921568623,0.5607843137254902,1"/>
                <Option type="QString" name="horizontal_anchor_point" value="1"/>
                <Option type="QString" name="joinstyle" value="bevel"/>
                <Option type="QString" name="name" value="circle"/>
                <Option type="QString" name="offset" value="0,0"/>
                <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="outline_color" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1"/>
                <Option type="QString" name="outline_style" value="solid"/>
                <Option type="QString" name="outline_width" value="0"/>
                <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="outline_width_unit" value="MM"/>
                <Option type="QString" name="scale_method" value="diameter"/>
                <Option type="QString" name="size" value="2"/>
                <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="size_unit" value="MM"/>
                <Option type="QString" name="vertical_anchor_point" value="1"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value=""/>
                  <Option name="properties"/>
                  <Option type="QString" name="type" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol type="fill" alpha="1" force_rhr="0" name="fillSymbol" is_animated="0" clip_to_extent="1" frame_rate="10">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value=""/>
                <Option name="properties"/>
                <Option type="QString" name="type" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer locked="0" enabled="1" class="SimpleFill" id="" pass="0">
              <Option type="Map">
                <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="255,255,255,255,rgb:1,1,1,1"/>
                <Option type="QString" name="joinstyle" value="bevel"/>
                <Option type="QString" name="offset" value="0,0"/>
                <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="outline_color" value="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1"/>
                <Option type="QString" name="outline_style" value="no"/>
                <Option type="QString" name="outline_width" value="0"/>
                <Option type="QString" name="outline_width_unit" value="MM"/>
                <Option type="QString" name="style" value="solid"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value=""/>
                  <Option name="properties"/>
                  <Option type="QString" name="type" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowOffsetDist="1" shadowUnder="0" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowOpacity="0" shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowOffsetGlobal="1" shadowDraw="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="0" shadowRadiusAlphaOnly="0" shadowBlendMode="6" shadowScale="100"/>
        <dd_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format addDirectionSymbol="0" leftDirectionSymbol="&lt;" decimals="3" wrapChar="" multilineAlign="0" formatNumbers="0" autoWrapLength="0" useMaxLineLengthForAutoWrap="1" rightDirectionSymbol=">" plussign="0" placeDirectionSymbol="0" reverseDirectionSymbol="0"/>
      <placement geometryGenerator="" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PolygonGeometry" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" lineAnchorClipping="0" repeatDistanceUnits="MM" overlapHandling="PreventOverlap" offsetUnits="MapUnit" maxCurvedCharAngleIn="20" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" geometryGeneratorType="PointGeometry" rotationUnit="AngleDegrees" maximumDistanceUnit="MM" distUnits="MM" lineAnchorPercent="0.5" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" lineAnchorTextPoint="CenterOfText" placementFlags="10" allowDegraded="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" lineAnchorType="0" fitInPolygonOnly="0" dist="0" geometryGeneratorEnabled="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetType="0" maximumDistance="0" rotationAngle="0" repeatDistance="0" prioritization="PreferCloser" centroidWhole="0" overrunDistanceUnit="MM" quadOffset="4" maxCurvedCharAngleOut="-20" centroidInside="0" yOffset="0" preserveRotation="1" priority="5" polygonPlacementFlags="2" placement="1" xOffset="0"/>
      <rendering drawLabels="1" limitNumLabels="0" obstacleType="0" unplacedVisibility="0" obstacle="1" fontMinPixelSize="3" labelPerPart="0" upsidedownLabels="0" fontLimitPixelSize="0" fontMaxPixelSize="10000" zIndex="0" mergeLines="0" scaleMin="1" minFeatureSize="0" obstacleFactor="1" scaleMax="10000000" scaleVisibility="0" maxNumLabels="2000"/>
      <dd_properties>
        <Option type="Map">
          <Option type="QString" name="name" value=""/>
          <Option name="properties"/>
          <Option type="QString" name="type" value="collection"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
          <Option type="int" name="blendMode" value="0"/>
          <Option type="Map" name="ddProperties">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
          <Option type="bool" name="drawToAllParts" value="false"/>
          <Option type="QString" name="enabled" value="0"/>
          <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
          <Option type="QString" name="lineSymbol" value="&lt;symbol type=&quot;line&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; clip_to_extent=&quot;1&quot; frame_rate=&quot;10&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; enabled=&quot;1&quot; class=&quot;SimpleLine&quot; id=&quot;{a41d3882-d621-4ce4-9e0d-1fd05d81a079}&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255,rgb:0.23529411764705882,0.23529411764705882,0.23529411764705882,1&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
          <Option type="double" name="minLength" value="0"/>
          <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
          <Option type="QString" name="minLengthUnit" value="MM"/>
          <Option type="double" name="offsetFromAnchor" value="0"/>
          <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
          <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
          <Option type="double" name="offsetFromLabel" value="0"/>
          <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
          <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option type="List" name="dualview/previewExpressions">
        <Option type="QString" value="COALESCE(   &quot;RC14&quot; , '&lt;NULL>' ) ||  '\n'  ||  coalesce(   &quot;MUNICIPIO&quot;  , '&lt;NULL>' ) || ' ' ||  coalesce(    &quot;MUNI_nm&quot;   , '&lt;NULL>' )"/>
      </Option>
      <Option type="QString" name="embeddedWidgets/count" value="0"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Pie">
    <DiagramCategory scaleDependency="Area" showAxis="0" maxScaleDenominator="1e+08" height="15" lineSizeType="MM" spacingUnit="MM" lineSizeScale="3x:0,0,0,0,0,0" minScaleDenominator="0" minimumSize="0" penColor="#000000" sizeType="MM" stackedDiagramSpacingUnit="MM" enabled="0" width="15" penAlpha="255" scaleBasedVisibility="0" sizeScale="3x:0,0,0,0,0,0" spacingUnitScale="3x:0,0,0,0,0,0" stackedDiagramSpacing="0" backgroundColor="#ffffff" penWidth="0" barWidth="5" labelPlacementMethod="XHeight" opacity="1" spacing="0" diagramOrientation="Up" backgroundAlpha="255" direction="1" stackedDiagramSpacingUnitScale="3x:0,0,0,0,0,0" rotationOffset="270" stackedDiagramMode="Horizontal">
      <fontProperties italic="0" bold="0" strikethrough="0" underline="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0"/>
      <attribute colorOpacity="1" field="" label="" color="#000000"/>
      <axisSymbol>
        <symbol type="line" alpha="1" force_rhr="0" name="" is_animated="0" clip_to_extent="1" frame_rate="10">
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
          <layer locked="0" enabled="1" class="SimpleLine" id="{8f1cb1b2-bb96-4a74-bf76-8d0bfdcf7852}" pass="0">
            <Option type="Map">
              <Option type="QString" name="align_dash_pattern" value="0"/>
              <Option type="QString" name="capstyle" value="square"/>
              <Option type="QString" name="customdash" value="5;2"/>
              <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="customdash_unit" value="MM"/>
              <Option type="QString" name="dash_pattern_offset" value="0"/>
              <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
              <Option type="QString" name="draw_inside_polygon" value="0"/>
              <Option type="QString" name="joinstyle" value="bevel"/>
              <Option type="QString" name="line_color" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1"/>
              <Option type="QString" name="line_style" value="solid"/>
              <Option type="QString" name="line_width" value="0.26"/>
              <Option type="QString" name="line_width_unit" value="MM"/>
              <Option type="QString" name="offset" value="0"/>
              <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="offset_unit" value="MM"/>
              <Option type="QString" name="ring_filter" value="0"/>
              <Option type="QString" name="trim_distance_end" value="0"/>
              <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="trim_distance_end_unit" value="MM"/>
              <Option type="QString" name="trim_distance_start" value="0"/>
              <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="trim_distance_start_unit" value="MM"/>
              <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
              <Option type="QString" name="use_custom_dash" value="0"/>
              <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value=""/>
                <Option name="properties"/>
                <Option type="QString" name="type" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings dist="0" linePlacementFlags="2" obstacle="0" placement="0" zIndex="0" priority="0" showAll="1">
    <properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option type="Map" name="QgsGeometryGapCheck">
        <Option type="double" name="allowedGapsBuffer" value="0"/>
        <Option type="bool" name="allowedGapsEnabled" value="false"/>
        <Option type="QString" name="allowedGapsLayer" value=""/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="RC14">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="NOM_MUNI">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="DELEGACIO">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="MUNICIPIO">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="MASA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="PARCELA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="TIPO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="AREA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="CAT_NMSPC">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="PCAT1">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="PCAT2">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="PARAJE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="EJERCICIO">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="NUM_EXP">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="CONTROL">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="VIA">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="NUMERO">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="NUMERODUP">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="NUMSYMBOL">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="FECHAALTA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="FECHABAJA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="MAPA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="HOJA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="COORX">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="COORY">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="DIRECCION">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="PROVINCIA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="REF_CAT">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="COD_INE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="COORDINADA">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="REGFECOORD">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="REGPROP">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="REGCRU">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="RC14" name="" index="0"/>
    <alias field="NOM_MUNI" name="" index="1"/>
    <alias field="DELEGACIO" name="" index="2"/>
    <alias field="MUNICIPIO" name="" index="3"/>
    <alias field="MASA" name="" index="4"/>
    <alias field="PARCELA" name="" index="5"/>
    <alias field="TIPO" name="" index="6"/>
    <alias field="AREA" name="" index="7"/>
    <alias field="CAT_NMSPC" name="" index="8"/>
    <alias field="PCAT1" name="" index="9"/>
    <alias field="PCAT2" name="" index="10"/>
    <alias field="PARAJE" name="" index="11"/>
    <alias field="EJERCICIO" name="" index="12"/>
    <alias field="NUM_EXP" name="" index="13"/>
    <alias field="CONTROL" name="" index="14"/>
    <alias field="VIA" name="" index="15"/>
    <alias field="NUMERO" name="" index="16"/>
    <alias field="NUMERODUP" name="" index="17"/>
    <alias field="NUMSYMBOL" name="" index="18"/>
    <alias field="FECHAALTA" name="" index="19"/>
    <alias field="FECHABAJA" name="" index="20"/>
    <alias field="MAPA" name="" index="21"/>
    <alias field="HOJA" name="" index="22"/>
    <alias field="COORX" name="" index="23"/>
    <alias field="COORY" name="" index="24"/>
    <alias field="DIRECCION" name="" index="25"/>
    <alias field="PROVINCIA" name="" index="26"/>
    <alias field="REF_CAT" name="" index="27"/>
    <alias field="COD_INE" name="" index="28"/>
    <alias field="COORDINADA" name="" index="29"/>
    <alias field="REGFECOORD" name="" index="30"/>
    <alias field="REGPROP" name="" index="31"/>
    <alias field="REGCRU" name="" index="32"/>
  </aliases>
  <splitPolicies>
    <policy field="RC14" policy="Duplicate"/>
    <policy field="NOM_MUNI" policy="Duplicate"/>
    <policy field="DELEGACIO" policy="Duplicate"/>
    <policy field="MUNICIPIO" policy="Duplicate"/>
    <policy field="MASA" policy="Duplicate"/>
    <policy field="PARCELA" policy="Duplicate"/>
    <policy field="TIPO" policy="Duplicate"/>
    <policy field="AREA" policy="Duplicate"/>
    <policy field="CAT_NMSPC" policy="Duplicate"/>
    <policy field="PCAT1" policy="Duplicate"/>
    <policy field="PCAT2" policy="Duplicate"/>
    <policy field="PARAJE" policy="Duplicate"/>
    <policy field="EJERCICIO" policy="Duplicate"/>
    <policy field="NUM_EXP" policy="Duplicate"/>
    <policy field="CONTROL" policy="Duplicate"/>
    <policy field="VIA" policy="Duplicate"/>
    <policy field="NUMERO" policy="Duplicate"/>
    <policy field="NUMERODUP" policy="Duplicate"/>
    <policy field="NUMSYMBOL" policy="Duplicate"/>
    <policy field="FECHAALTA" policy="Duplicate"/>
    <policy field="FECHABAJA" policy="Duplicate"/>
    <policy field="MAPA" policy="Duplicate"/>
    <policy field="HOJA" policy="Duplicate"/>
    <policy field="COORX" policy="Duplicate"/>
    <policy field="COORY" policy="Duplicate"/>
    <policy field="DIRECCION" policy="Duplicate"/>
    <policy field="PROVINCIA" policy="Duplicate"/>
    <policy field="REF_CAT" policy="Duplicate"/>
    <policy field="COD_INE" policy="Duplicate"/>
    <policy field="COORDINADA" policy="Duplicate"/>
    <policy field="REGFECOORD" policy="Duplicate"/>
    <policy field="REGPROP" policy="Duplicate"/>
    <policy field="REGCRU" policy="Duplicate"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy field="RC14" policy="Duplicate"/>
    <policy field="NOM_MUNI" policy="Duplicate"/>
    <policy field="DELEGACIO" policy="Duplicate"/>
    <policy field="MUNICIPIO" policy="Duplicate"/>
    <policy field="MASA" policy="Duplicate"/>
    <policy field="PARCELA" policy="Duplicate"/>
    <policy field="TIPO" policy="Duplicate"/>
    <policy field="AREA" policy="Duplicate"/>
    <policy field="CAT_NMSPC" policy="Duplicate"/>
    <policy field="PCAT1" policy="Duplicate"/>
    <policy field="PCAT2" policy="Duplicate"/>
    <policy field="PARAJE" policy="Duplicate"/>
    <policy field="EJERCICIO" policy="Duplicate"/>
    <policy field="NUM_EXP" policy="Duplicate"/>
    <policy field="CONTROL" policy="Duplicate"/>
    <policy field="VIA" policy="Duplicate"/>
    <policy field="NUMERO" policy="Duplicate"/>
    <policy field="NUMERODUP" policy="Duplicate"/>
    <policy field="NUMSYMBOL" policy="Duplicate"/>
    <policy field="FECHAALTA" policy="Duplicate"/>
    <policy field="FECHABAJA" policy="Duplicate"/>
    <policy field="MAPA" policy="Duplicate"/>
    <policy field="HOJA" policy="Duplicate"/>
    <policy field="COORX" policy="Duplicate"/>
    <policy field="COORY" policy="Duplicate"/>
    <policy field="DIRECCION" policy="Duplicate"/>
    <policy field="PROVINCIA" policy="Duplicate"/>
    <policy field="REF_CAT" policy="Duplicate"/>
    <policy field="COD_INE" policy="Duplicate"/>
    <policy field="COORDINADA" policy="Duplicate"/>
    <policy field="REGFECOORD" policy="Duplicate"/>
    <policy field="REGPROP" policy="Duplicate"/>
    <policy field="REGCRU" policy="Duplicate"/>
  </duplicatePolicies>
  <defaults>
    <default applyOnUpdate="0" field="RC14" expression=""/>
    <default applyOnUpdate="0" field="NOM_MUNI" expression=""/>
    <default applyOnUpdate="0" field="DELEGACIO" expression=""/>
    <default applyOnUpdate="0" field="MUNICIPIO" expression=""/>
    <default applyOnUpdate="0" field="MASA" expression=""/>
    <default applyOnUpdate="0" field="PARCELA" expression=""/>
    <default applyOnUpdate="0" field="TIPO" expression=""/>
    <default applyOnUpdate="0" field="AREA" expression=""/>
    <default applyOnUpdate="0" field="CAT_NMSPC" expression=""/>
    <default applyOnUpdate="0" field="PCAT1" expression=""/>
    <default applyOnUpdate="0" field="PCAT2" expression=""/>
    <default applyOnUpdate="0" field="PARAJE" expression=""/>
    <default applyOnUpdate="0" field="EJERCICIO" expression=""/>
    <default applyOnUpdate="0" field="NUM_EXP" expression=""/>
    <default applyOnUpdate="0" field="CONTROL" expression=""/>
    <default applyOnUpdate="0" field="VIA" expression=""/>
    <default applyOnUpdate="0" field="NUMERO" expression=""/>
    <default applyOnUpdate="0" field="NUMERODUP" expression=""/>
    <default applyOnUpdate="0" field="NUMSYMBOL" expression=""/>
    <default applyOnUpdate="0" field="FECHAALTA" expression=""/>
    <default applyOnUpdate="0" field="FECHABAJA" expression=""/>
    <default applyOnUpdate="0" field="MAPA" expression=""/>
    <default applyOnUpdate="0" field="HOJA" expression=""/>
    <default applyOnUpdate="0" field="COORX" expression=""/>
    <default applyOnUpdate="0" field="COORY" expression=""/>
    <default applyOnUpdate="0" field="DIRECCION" expression=""/>
    <default applyOnUpdate="0" field="PROVINCIA" expression=""/>
    <default applyOnUpdate="0" field="REF_CAT" expression=""/>
    <default applyOnUpdate="0" field="COD_INE" expression=""/>
    <default applyOnUpdate="0" field="COORDINADA" expression=""/>
    <default applyOnUpdate="0" field="REGFECOORD" expression=""/>
    <default applyOnUpdate="0" field="REGPROP" expression=""/>
    <default applyOnUpdate="0" field="REGCRU" expression=""/>
  </defaults>
  <constraints>
    <constraint unique_strength="0" field="RC14" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="NOM_MUNI" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="DELEGACIO" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="MUNICIPIO" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="MASA" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="PARCELA" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="TIPO" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="AREA" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="CAT_NMSPC" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="PCAT1" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="PCAT2" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="PARAJE" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="EJERCICIO" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="NUM_EXP" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="CONTROL" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="VIA" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="NUMERO" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="NUMERODUP" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="NUMSYMBOL" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="FECHAALTA" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="FECHABAJA" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="MAPA" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="HOJA" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="COORX" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="COORY" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="DIRECCION" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="PROVINCIA" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="REF_CAT" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="COD_INE" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="COORDINADA" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="REGFECOORD" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="REGPROP" notnull_strength="0" exp_strength="0" constraints="0"/>
    <constraint unique_strength="0" field="REGCRU" notnull_strength="0" exp_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="RC14" exp="" desc=""/>
    <constraint field="NOM_MUNI" exp="" desc=""/>
    <constraint field="DELEGACIO" exp="" desc=""/>
    <constraint field="MUNICIPIO" exp="" desc=""/>
    <constraint field="MASA" exp="" desc=""/>
    <constraint field="PARCELA" exp="" desc=""/>
    <constraint field="TIPO" exp="" desc=""/>
    <constraint field="AREA" exp="" desc=""/>
    <constraint field="CAT_NMSPC" exp="" desc=""/>
    <constraint field="PCAT1" exp="" desc=""/>
    <constraint field="PCAT2" exp="" desc=""/>
    <constraint field="PARAJE" exp="" desc=""/>
    <constraint field="EJERCICIO" exp="" desc=""/>
    <constraint field="NUM_EXP" exp="" desc=""/>
    <constraint field="CONTROL" exp="" desc=""/>
    <constraint field="VIA" exp="" desc=""/>
    <constraint field="NUMERO" exp="" desc=""/>
    <constraint field="NUMERODUP" exp="" desc=""/>
    <constraint field="NUMSYMBOL" exp="" desc=""/>
    <constraint field="FECHAALTA" exp="" desc=""/>
    <constraint field="FECHABAJA" exp="" desc=""/>
    <constraint field="MAPA" exp="" desc=""/>
    <constraint field="HOJA" exp="" desc=""/>
    <constraint field="COORX" exp="" desc=""/>
    <constraint field="COORY" exp="" desc=""/>
    <constraint field="DIRECCION" exp="" desc=""/>
    <constraint field="PROVINCIA" exp="" desc=""/>
    <constraint field="REF_CAT" exp="" desc=""/>
    <constraint field="COD_INE" exp="" desc=""/>
    <constraint field="COORDINADA" exp="" desc=""/>
    <constraint field="REGFECOORD" exp="" desc=""/>
    <constraint field="REGPROP" exp="" desc=""/>
    <constraint field="REGCRU" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortExpression="" actionWidgetStyle="dropDown" sortOrder="0">
    <columns>
      <column width="-1" type="field" name="RC14" hidden="0"/>
      <column width="-1" type="field" name="PCAT1" hidden="0"/>
      <column width="-1" type="field" name="PCAT2" hidden="0"/>
      <column width="-1" type="field" name="EJERCICIO" hidden="0"/>
      <column width="-1" type="field" name="NUM_EXP" hidden="0"/>
      <column width="-1" type="field" name="CONTROL" hidden="0"/>
      <column width="-1" type="field" name="COORY" hidden="0"/>
      <column width="-1" type="field" name="VIA" hidden="0"/>
      <column width="-1" type="field" name="NUMERO" hidden="0"/>
      <column width="-1" type="field" name="NUMERODUP" hidden="0"/>
      <column width="-1" type="field" name="NUMSYMBOL" hidden="0"/>
      <column width="-1" type="field" name="AREA" hidden="0"/>
      <column width="-1" type="field" name="FECHAALTA" hidden="0"/>
      <column width="-1" type="field" name="FECHABAJA" hidden="0"/>
      <column width="-1" type="field" name="MAPA" hidden="0"/>
      <column width="-1" type="field" name="DELEGACIO" hidden="0"/>
      <column width="-1" type="field" name="MUNICIPIO" hidden="0"/>
      <column width="-1" type="field" name="MASA" hidden="0"/>
      <column width="-1" type="field" name="HOJA" hidden="0"/>
      <column width="-1" type="field" name="TIPO" hidden="0"/>
      <column width="-1" type="field" name="PARCELA" hidden="0"/>
      <column width="-1" type="field" name="COORX" hidden="0"/>
      <column width="-1" type="field" name="NOM_MUNI" hidden="0"/>
      <column width="-1" type="field" name="CAT_NMSPC" hidden="0"/>
      <column width="-1" type="field" name="PARAJE" hidden="0"/>
      <column width="-1" type="field" name="DIRECCION" hidden="0"/>
      <column width="-1" type="field" name="PROVINCIA" hidden="0"/>
      <column width="-1" type="field" name="REF_CAT" hidden="0"/>
      <column width="-1" type="field" name="COD_INE" hidden="0"/>
      <column width="-1" type="field" name="COORDINADA" hidden="0"/>
      <column width="-1" type="field" name="REGFECOORD" hidden="0"/>
      <column width="-1" type="field" name="REGPROP" hidden="0"/>
      <column width="-1" type="field" name="REGCRU" hidden="0"/>
      <column width="-1" type="actions" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from PyQt4.QtGui import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="AREA"/>
    <field editable="1" name="CAT_NMSPC"/>
    <field editable="1" name="COD_INE"/>
    <field editable="1" name="CONTROL"/>
    <field editable="1" name="COORDINADA"/>
    <field editable="1" name="COORX"/>
    <field editable="1" name="COORY"/>
    <field editable="1" name="DELEGACIO"/>
    <field editable="1" name="DIRECCION"/>
    <field editable="1" name="EJERCICIO"/>
    <field editable="1" name="FECHAALTA"/>
    <field editable="1" name="FECHABAJA"/>
    <field editable="1" name="HOJA"/>
    <field editable="1" name="MAPA"/>
    <field editable="1" name="MASA"/>
    <field editable="1" name="MUNICIPIO"/>
    <field editable="0" name="MUNI_cd"/>
    <field editable="0" name="MUNI_cdcmc"/>
    <field editable="0" name="MUNI_cmc"/>
    <field editable="0" name="MUNI_codine"/>
    <field editable="0" name="MUNI_nm"/>
    <field editable="1" name="NOM_MUNI"/>
    <field editable="1" name="NUMERO"/>
    <field editable="1" name="NUMERODUP"/>
    <field editable="1" name="NUMSYMBOL"/>
    <field editable="1" name="NUM_EXP"/>
    <field editable="1" name="PARAJE"/>
    <field editable="1" name="PARCELA"/>
    <field editable="1" name="PCAT1"/>
    <field editable="1" name="PCAT2"/>
    <field editable="1" name="PROVINCIA"/>
    <field editable="1" name="RC14"/>
    <field editable="1" name="REF_CAT"/>
    <field editable="1" name="REGCRU"/>
    <field editable="1" name="REGFECOORD"/>
    <field editable="1" name="REGPROP"/>
    <field editable="1" name="TIPO"/>
    <field editable="1" name="VIA"/>
  </editable>
  <labelOnTop>
    <field name="AREA" labelOnTop="0"/>
    <field name="CAT_NMSPC" labelOnTop="0"/>
    <field name="COD_INE" labelOnTop="0"/>
    <field name="CONTROL" labelOnTop="0"/>
    <field name="COORDINADA" labelOnTop="0"/>
    <field name="COORX" labelOnTop="0"/>
    <field name="COORY" labelOnTop="0"/>
    <field name="DELEGACIO" labelOnTop="0"/>
    <field name="DIRECCION" labelOnTop="0"/>
    <field name="EJERCICIO" labelOnTop="0"/>
    <field name="FECHAALTA" labelOnTop="0"/>
    <field name="FECHABAJA" labelOnTop="0"/>
    <field name="HOJA" labelOnTop="0"/>
    <field name="MAPA" labelOnTop="0"/>
    <field name="MASA" labelOnTop="0"/>
    <field name="MUNICIPIO" labelOnTop="0"/>
    <field name="MUNI_cd" labelOnTop="0"/>
    <field name="MUNI_cdcmc" labelOnTop="0"/>
    <field name="MUNI_cmc" labelOnTop="0"/>
    <field name="MUNI_codine" labelOnTop="0"/>
    <field name="MUNI_nm" labelOnTop="0"/>
    <field name="NOM_MUNI" labelOnTop="0"/>
    <field name="NUMERO" labelOnTop="0"/>
    <field name="NUMERODUP" labelOnTop="0"/>
    <field name="NUMSYMBOL" labelOnTop="0"/>
    <field name="NUM_EXP" labelOnTop="0"/>
    <field name="PARAJE" labelOnTop="0"/>
    <field name="PARCELA" labelOnTop="0"/>
    <field name="PCAT1" labelOnTop="0"/>
    <field name="PCAT2" labelOnTop="0"/>
    <field name="PROVINCIA" labelOnTop="0"/>
    <field name="RC14" labelOnTop="0"/>
    <field name="REF_CAT" labelOnTop="0"/>
    <field name="REGCRU" labelOnTop="0"/>
    <field name="REGFECOORD" labelOnTop="0"/>
    <field name="REGPROP" labelOnTop="0"/>
    <field name="TIPO" labelOnTop="0"/>
    <field name="VIA" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="AREA" reuseLastValue="0"/>
    <field name="CAT_NMSPC" reuseLastValue="0"/>
    <field name="COD_INE" reuseLastValue="0"/>
    <field name="CONTROL" reuseLastValue="0"/>
    <field name="COORDINADA" reuseLastValue="0"/>
    <field name="COORX" reuseLastValue="0"/>
    <field name="COORY" reuseLastValue="0"/>
    <field name="DELEGACIO" reuseLastValue="0"/>
    <field name="DIRECCION" reuseLastValue="0"/>
    <field name="EJERCICIO" reuseLastValue="0"/>
    <field name="FECHAALTA" reuseLastValue="0"/>
    <field name="FECHABAJA" reuseLastValue="0"/>
    <field name="HOJA" reuseLastValue="0"/>
    <field name="MAPA" reuseLastValue="0"/>
    <field name="MASA" reuseLastValue="0"/>
    <field name="MUNICIPIO" reuseLastValue="0"/>
    <field name="NOM_MUNI" reuseLastValue="0"/>
    <field name="NUMERO" reuseLastValue="0"/>
    <field name="NUMERODUP" reuseLastValue="0"/>
    <field name="NUMSYMBOL" reuseLastValue="0"/>
    <field name="NUM_EXP" reuseLastValue="0"/>
    <field name="PARAJE" reuseLastValue="0"/>
    <field name="PARCELA" reuseLastValue="0"/>
    <field name="PCAT1" reuseLastValue="0"/>
    <field name="PCAT2" reuseLastValue="0"/>
    <field name="PROVINCIA" reuseLastValue="0"/>
    <field name="RC14" reuseLastValue="0"/>
    <field name="REF_CAT" reuseLastValue="0"/>
    <field name="REGCRU" reuseLastValue="0"/>
    <field name="REGFECOORD" reuseLastValue="0"/>
    <field name="REGPROP" reuseLastValue="0"/>
    <field name="TIPO" reuseLastValue="0"/>
    <field name="VIA" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>COALESCE(   "RC14" , '&lt;NULL>' ) ||  '\n'  ||  coalesce(   "MUNICIPIO"  , '&lt;NULL>' ) || ' ' ||  coalesce(    "MUNI_nm"   , '&lt;NULL>' )</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
