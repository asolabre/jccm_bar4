<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis autoRefreshTime="0" simplifyDrawingHints="1" minScale="100000000" simplifyDrawingTol="1" simplifyAlgorithm="0" version="3.40.15-Bratislava" maxScale="-4.6566128730773926e-10" simplifyMaxScale="1" simplifyLocal="1" readOnly="0" hasScaleBasedVisibilityFlag="0" autoRefreshMode="Disabled" labelsEnabled="1" styleCategories="AllStyleCategories" symbologyReferenceScale="-1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal durationUnit="min" enabled="0" limitMode="0" startField="" mode="0" endExpression="" startExpression="" fixedDuration="0" durationField="fid" accumulate="0" endField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation clamping="Terrain" binding="Centroid" type="IndividualFeatures" symbology="Line" zoffset="0" extrusionEnabled="0" extrusion="0" zscale="1" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol type="line" name="" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{d3eb34c1-2dc2-45a5-bdf3-5afc0fa3cf0e}" locked="0" pass="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="196,60,57,255,rgb:0.7686274509803922,0.23529411764705882,0.22352941176470589,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.6"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol type="fill" name="" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{00b619b6-edb7-4e1b-af5a-4b27ade9b0b6}" locked="0" pass="0">
          <Option type="Map">
            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="color" value="196,60,57,255,rgb:0.7686274509803922,0.23529411764705882,0.22352941176470589,1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="140,43,41,255,rgb:0.5490196078431373,0.16803234912642101,0.15967040512703135,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="style" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol type="marker" name="" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" id="{bac90836-4e55-496d-9493-6ff5e869ce8d}" locked="0" pass="0">
          <Option type="Map">
            <Option type="QString" name="angle" value="0"/>
            <Option type="QString" name="cap_style" value="square"/>
            <Option type="QString" name="color" value="196,60,57,255,rgb:0.7686274509803922,0.23529411764705882,0.22352941176470589,1"/>
            <Option type="QString" name="horizontal_anchor_point" value="1"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="name" value="diamond"/>
            <Option type="QString" name="offset" value="0,0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="outline_color" value="140,43,41,255,rgb:0.5490196078431373,0.16803234912642101,0.15967040512703135,1"/>
            <Option type="QString" name="outline_style" value="solid"/>
            <Option type="QString" name="outline_width" value="0.2"/>
            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="outline_width_unit" value="MM"/>
            <Option type="QString" name="scale_method" value="diameter"/>
            <Option type="QString" name="size" value="3"/>
            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="size_unit" value="MM"/>
            <Option type="QString" name="vertical_anchor_point" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 type="RuleRenderer" referencescale="-1" enableorderby="0" symbollevels="0" forceraster="0">
    <rules key="{de4fd46e-898d-45ce-81ed-bd72967f42e9}">
      <rule filter=" &quot;titular&quot;  = 2 AND &quot;clase&quot; = 1002 AND  &quot;tipo_tramo&quot; = 1" symbol="0" key="{df88e1c9-93ce-4930-ac75-44a6d2b81e77}" label="Red Regional Basica A.C."/>
      <rule filter=" &quot;titular&quot;  = 2 AND &quot;clase&quot; in (1003,1005) AND  &quot;tipo_tramo&quot; = 1 and  &quot;orden&quot;  =  1 " symbol="1" key="{8980eb8c-69b6-4f4b-892f-11773c0081c7}" label="Red Regional BASICA"/>
      <rule filter=" &quot;titular&quot;  = 2 AND &quot;clase&quot; in (1003,1005) AND  &quot;tipo_tramo&quot; = 1 and  &quot;orden&quot;  =  2 " symbol="2" key="{0f18bebe-651a-4328-aa94-cfe8bdaf0d00}" label="Red Regional COMARCAL"/>
      <rule filter=" &quot;titular&quot;  = 2 AND &quot;clase&quot; in (1003,1005) AND  &quot;tipo_tramo&quot; = 1 and  &quot;orden&quot;  =  3 " symbol="3" key="{2ed5e273-2869-4d93-83c5-2615f77d6ce9}" label="Red Regional LOCAL"/>
      <rule scalemaxdenom="100000" filter=" &quot;titular&quot;  = 2 AND &quot;clase&quot; = 1002 AND  &quot;tipo_tramo&quot; &lt;> 1" symbol="4" key="{55223f13-ea24-4a6c-b5ce-81d2c0d930f9}" label="Red Reg. Enl.B.A.C."/>
      <rule scalemaxdenom="100000" filter="&quot;titular&quot;  = 2 AND &quot;clase&quot; = 1003 AND  &quot;tipo_tramo&quot; &lt;> 1  and  &quot;orden&quot;  = 1 " symbol="5" key="{6cba02bf-4b4f-477f-8dd7-d1e615d318a3}" label="Red Reg. Enl.BASICA"/>
      <rule scalemaxdenom="100000" filter="&quot;titular&quot;  = 2 AND &quot;clase&quot; = 1003 AND  &quot;tipo_tramo&quot; &lt;> 1  and  &quot;orden&quot;  =  2 " symbol="6" key="{8bfbfc78-b5bb-475c-93b0-32704cc883fd}" label="Red Reg. Enl.COMARCAL"/>
      <rule scalemaxdenom="100000" filter="&quot;titular&quot;  = 2 AND &quot;clase&quot; = 1003 AND  &quot;tipo_tramo&quot; &lt;> 1  and  &quot;orden&quot;  =  3 " symbol="7" key="{08ad980a-d271-4566-984b-33be15a26fba}" label="Red Reg. Enl.COMARCAL"/>
      <rule scalemaxdenom="100000" filter="&quot;titular&quot;  = 2  and  &quot;clase&quot; not in (1002, 1003,1005)" symbol="8" key="{0b460aa1-466e-4c69-bf32-f5d21c8f2315}" label="Red Regional Resto"/>
      <rule filter=" &quot;titular&quot;  = 1 AND &quot;clase&quot; = 1001 AND  &quot;tipo_tramo&quot; = 1" symbol="9" key="{d23867d1-ecb8-4633-a07f-c35a43b4761a}" label="Red Estatal Autop Peaje"/>
      <rule filter=" &quot;titular&quot;  = 1 AND &quot;clase&quot; = 1002 AND  &quot;tipo_tramo&quot; = 1" symbol="10" key="{a54f4ffc-4d88-4460-87d0-f2b8554b6170}" label="Red Estatal Autopistas"/>
      <rule filter=" &quot;titular&quot;  = 1 AND &quot;clase&quot; = 1003 AND  &quot;tipo_tramo&quot; = 1" symbol="11" key="{fdb1407a-af6b-45ef-b45e-6102bbd4d7f9}" label="Red Estatal Convencional"/>
      <rule scalemaxdenom="100000" filter=" &quot;titular&quot;  = 1 AND (&quot;clase&quot; = 1001 OR &quot;clase&quot; = 1002) AND  &quot;tipo_tramo&quot; &lt;> 1" symbol="12" key="{215fcfe9-ecc1-4c94-9f96-5df41602694f}" label="Red Estatal Enl Autovia"/>
      <rule scalemaxdenom="100000" filter=" &quot;titular&quot;  = 1 AND &quot;clase&quot; = 1003 AND  &quot;tipo_tramo&quot; &lt;> 1" symbol="13" key="{498c971a-edd9-431e-81c5-e37fc5480d77}" label="Red Estatal Enlace Conv"/>
      <rule scalemaxdenom="100000" filter=" &quot;titular&quot;  = 1 AND &quot;clase&quot; > 1003" symbol="14" key="{4144483b-4c0d-45e1-9892-f9894dbf00ca}" label="Red Estatal -Resto-"/>
      <rule scalemaxdenom="100000" filter=" &quot;titular&quot;  = 3" symbol="15" key="{61cbadf9-c8d0-44e0-b211-d2fa190241d7}" label="Red Diputación"/>
      <rule scalemaxdenom="100000" filter=" &quot;titular&quot;  = 5 AND (&quot;clase&quot; > 1000 AND &quot;clase&quot; &lt;1005)" symbol="16" key="{5f2b5582-c694-4744-9e50-d5418b80df3d}" label="Carreteras Municipales"/>
      <rule scalemaxdenom="50000" filter=" &quot;titular&quot;  = 5 AND &quot;clase&quot; = 3001" symbol="17" key="{1f1b41ac-ad65-427e-8e13-6167170fe006}" label="Caminos Municipales"/>
      <rule scalemaxdenom="50000" filter=" &quot;titular&quot;  = 5 AND &quot;clase&quot; = 2000" symbol="18" key="{49b53f42-5bbb-4979-9aec-0e22e9a48c89}" label="Viales Urbanos"/>
      <rule scalemaxdenom="25000" filter=" &quot;titular&quot;  = 5 AND &quot;clase&quot; > 3001" symbol="19" key="{5c481975-c32b-48a9-a7a9-ff53cb768f83}" label="Resto Viales Municipales"/>
      <rule scalemaxdenom="25000" filter="ELSE" symbol="20" key="{cbe4a1b9-1bd7-415d-bc08-6fd71021fcd6}" label="RESTO"/>
    </rules>
    <symbols>
      <symbol type="line" name="0" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="0.796078">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{9bfccbc1-93fe-4ad8-870c-4b5ae19cca40}" locked="0" pass="10">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="184,0,204,255,rgb:0.72156862745098038,0,0.80000000000000004,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.2"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" enabled="1" id="{2d4ec91e-39ac-4ca9-8a19-e278e930ee6c}" locked="0" pass="10">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="255,255,255,255,rgb:1,1,1,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.25"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="1" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="0.796078">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{b560b8e9-a92f-42fe-901f-ba72b248c678}" locked="1" pass="10">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="0,0,0,255,rgb:0,0,0,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.75"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" enabled="1" id="{a58b7c42-e14a-43ae-8b3c-538b91b53e15}" locked="0" pass="10">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="255,127,0,255,rgb:1,0.49803921568627452,0,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.75"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="10" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{043c3ee4-604f-49a2-b5c4-58b6fa7838f9}" locked="1" pass="6">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="1,103,255,255,rgb:0.00392156862745098,0.40392156862745099,1,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.2"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" enabled="1" id="{7d1ef23d-2319-4501-8f03-50be92308780}" locked="0" pass="6">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="255,255,255,255,rgb:1,1,1,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.5"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="11" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="0.784314">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{3deb96c7-326f-42da-a3fa-edcf81d3fa9b}" locked="0" pass="6">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="227,26,28,255,rgb:0.8901960784313725,0.10196078431372549,0.10980392156862745,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.8"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" enabled="1" id="{e369147a-8f6c-46f2-a122-353cdb0917b1}" locked="1" pass="6">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="20,50,50,255,rgb:0.07843137254901961,0.19607843137254902,0.19607843137254902,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.05"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0.4"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" enabled="1" id="{5fe69c3a-861c-4e50-b231-34655ff4927e}" locked="0" pass="6">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="0,0,0,255,rgb:0,0,0,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.05"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="-0.4"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="12" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{56742867-a0a2-451c-b4ec-9ff42cb81279}" locked="0" pass="2">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="1,103,255,255,rgb:0.00392156862745098,0.40392156862745099,1,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.5"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="13" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{f572ab12-e4dd-4a32-988b-e8a98aa21feb}" locked="0" pass="2">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="255,0,25,255,rgb:1,0,0.09803921568627451,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.5"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="14" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{3d405dbd-d518-47c6-9276-65abf4dbc5dd}" locked="0" pass="6">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="227,26,28,255,rgb:0.8901960784313725,0.10196078431372549,0.10980392156862745,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.6"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" enabled="1" id="{11407dad-6faa-4d42-84e8-52233b02b707}" locked="1" pass="6">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="20,50,50,255,rgb:0.07843137254901961,0.19607843137254902,0.19607843137254902,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.6"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" enabled="1" id="{d23b5559-c20d-4d1b-b426-3ad7cdef1419}" locked="0" pass="6">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="0,0,0,255,rgb:0,0,0,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.6"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="15" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{03042993-01a5-4953-b3ee-00702722fdd6}" locked="1" pass="5">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="0,0,0,255,rgb:0,0,0,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.5"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" enabled="1" id="{fb3563d7-6ca3-4171-b4d9-5ca64963c53f}" locked="0" pass="5">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="255,255,255,255,rgb:1,1,1,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.4"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="16" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{5ab328fc-ba66-4fe4-9cd8-79caa280f1aa}" locked="1" pass="5">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="0,0,0,255,rgb:0,0,0,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.6"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="17" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{ef8617da-adee-43da-b76b-4b12b2d24703}" locked="1" pass="5">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="0,0,0,255,rgb:0,0,0,1"/>
            <Option type="QString" name="line_style" value="dash"/>
            <Option type="QString" name="line_width" value="0.25"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="18" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{a1b52530-47f1-4ae2-bf4f-4e0dd0813d3c}" locked="1" pass="5">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="255,5,1,255,rgb:1,0.0196078431372549,0.00392156862745098,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.3"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="19" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{cf44c3fe-42b6-4eeb-8f9f-84231b3d73b1}" locked="1" pass="5">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="0,0,0,255,rgb:0,0,0,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.2"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="2" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="0.796078">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{95c99271-cf80-4e80-aa2e-f4e1dd5404c5}" locked="1" pass="9">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="0,0,0,255,rgb:0,0,0,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.75"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" enabled="1" id="{a79c040f-3d37-4ab6-8938-b029fe2df544}" locked="0" pass="9">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="51,160,44,255,rgb:0.20000000000000001,0.62745098039215685,0.17254901960784313,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.75"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="20" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{f4557b76-c280-4993-919a-05b4afedf5ba}" locked="0" pass="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="0,0,0,255,rgb:0,0,0,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.26"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="3" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="0.796078">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{429f292b-8dcc-447f-b17e-660c339ec0a0}" locked="1" pass="8">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="0,0,0,255,rgb:0,0,0,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.75"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" enabled="1" id="{5f9b72fe-0782-431a-870d-d3dba132bcf6}" locked="0" pass="8">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="255,255,0,255,rgb:1,1,0,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.75"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="4" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="0.796078">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{820f2816-968f-4c4f-88ba-415bb44ba54e}" locked="0" pass="2">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="255,0,230,255,rgb:1,0,0.90196078431372551,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.4"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="5" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="0.796078">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{29461cc5-d221-4ef6-b42f-3ba1a3c37483}" locked="0" pass="2">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="255,127,0,255,rgb:1,0.49803921568627452,0,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.4"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="6" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="0.796078">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{bb2a6738-3f9c-4ffc-8c38-7f9ec05effc5}" locked="0" pass="2">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="42,227,25,255,rgb:0.16470588235294117,0.8901960784313725,0.09803921568627451,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.4"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="7" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="0.796078">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{6f0e70ab-8bf3-41ca-9450-d71b0ff6a537}" locked="0" pass="2">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="255,255,2,255,rgb:1,1,0.00784313725490196,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.4"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="8" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{2c766695-c354-4a42-9a1a-2c3a0c7177c7}" locked="0" pass="2">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="255,0,25,255,rgb:1,0,0.09803921568627451,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.5"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol type="line" name="9" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{2581c614-808d-4f5d-b88a-84117250f3d9}" locked="1" pass="6">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="1,103,255,255,rgb:0.00392156862745098,0.40392156862745099,1,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.2"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" enabled="1" id="{e3fb3e20-e55a-4977-a99d-9cd6c4b9e6de}" locked="0" pass="6">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="215,221,34,255,rgb:0.84313725490196079,0.8666666666666667,0.13333333333333333,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.5"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol type="line" name="" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{1a68a074-6e3f-471e-b8b5-b7304934c00d}" locked="0" pass="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.26"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" forcedBold="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" forcedItalic="0" blendMode="0" allowHtml="0" fontFamily="Arial" fieldName=" if(   &quot;tipo_tramo&quot;  =  1&#xd;&#xa;&#x9;AND strpos( &quot;nombre&quot;,'-') &lt;> 0 &#xd;&#xa;&#x9;AND  &quot;nombre&quot; &lt;> -997&#xd;&#xa;&#x9;,   &quot;nombre&quot;  , &quot;&quot;)" tabStopDistanceUnit="Point" multilineHeightUnit="Percentage" fontItalic="0" fontSizeUnit="Point" textOpacity="1" namedStyle="Normal" stretchFactor="100" isExpression="1" textColor="0,0,0,255,rgb:0,0,0,1" multilineHeight="1" legendString="Aa" fontWordSpacing="0" fontUnderline="0" fontKerning="1" tabStopDistance="80" fontStrikeout="0" fontLetterSpacing="0" capitalization="0" fontWeight="50" useSubstitutions="0" fontSize="7" textOrientation="horizontal" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1">
        <families/>
        <text-buffer bufferBlendMode="0" bufferOpacity="1" bufferSizeUnits="MM" bufferNoFill="0" bufferDraw="0" bufferJoinStyle="64" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferColor="255,255,255,255,rgb:1,1,1,1"/>
        <text-mask maskEnabled="0" maskType="0" maskedSymbolLayers="" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskSizeUnits="MM" maskSize="1.5" maskSize2="1.5" maskJoinStyle="128"/>
        <background shapeRotationType="0" shapeBorderWidth="0" shapeBlendMode="0" shapeRadiiX="0" shapeJoinStyle="64" shapeBorderColor="0,0,0,255,rgb:0,0,0,1" shapeOffsetUnit="MM" shapeDraw="1" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeOpacity="1" shapeSizeY="0" shapeType="0" shapeOffsetY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidthUnit="MM" shapeRadiiY="0" shapeRotation="0" shapeOffsetX="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSVGFile="" shapeSizeX="1" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
          <symbol type="marker" name="markerSymbol" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value=""/>
                <Option name="properties"/>
                <Option type="QString" name="type" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer class="SimpleMarker" enabled="1" id="" locked="0" pass="0">
              <Option type="Map">
                <Option type="QString" name="angle" value="0"/>
                <Option type="QString" name="cap_style" value="square"/>
                <Option type="QString" name="color" value="141,90,153,255,rgb:0.55294117647058827,0.35294117647058826,0.59999999999999998,1"/>
                <Option type="QString" name="horizontal_anchor_point" value="1"/>
                <Option type="QString" name="joinstyle" value="bevel"/>
                <Option type="QString" name="name" value="circle"/>
                <Option type="QString" name="offset" value="0,0"/>
                <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="outline_color" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1"/>
                <Option type="QString" name="outline_style" value="solid"/>
                <Option type="QString" name="outline_width" value="0"/>
                <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="outline_width_unit" value="MM"/>
                <Option type="QString" name="scale_method" value="diameter"/>
                <Option type="QString" name="size" value="2"/>
                <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="size_unit" value="MM"/>
                <Option type="QString" name="vertical_anchor_point" value="1"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value=""/>
                  <Option name="properties"/>
                  <Option type="QString" name="type" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol type="fill" name="fillSymbol" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value=""/>
                <Option name="properties"/>
                <Option type="QString" name="type" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer class="SimpleFill" enabled="1" id="" locked="0" pass="0">
              <Option type="Map">
                <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="255,255,255,255,rgb:1,1,1,1"/>
                <Option type="QString" name="joinstyle" value="bevel"/>
                <Option type="QString" name="offset" value="0,0"/>
                <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="outline_color" value="0,0,0,255,rgb:0,0,0,1"/>
                <Option type="QString" name="outline_style" value="solid"/>
                <Option type="QString" name="outline_width" value="0"/>
                <Option type="QString" name="outline_width_unit" value="MM"/>
                <Option type="QString" name="style" value="solid"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value=""/>
                  <Option type="Map" name="properties">
                    <Option type="Map" name="fillColor">
                      <Option type="bool" name="active" value="true"/>
                      <Option type="QString" name="expression" value="CASE WHEN &quot;titular&quot;  = 2 AND  &quot;clase&quot;  = 1002 THEN  color_rgb( 184,0,204)&#xd;&#xa;&#x9;ELSE&#xd;&#xa;&#x9;CASE WHEN &quot;titular&quot;  = 2 AND  &quot;orden&quot; =  1 THEN  color_rgb( 255,127,0) &#x9;&#xd;&#xa;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;CASE WHEN &quot;titular&quot;  = 2 AND  &quot;orden&quot; =  2  THEN  color_rgb( 51,140,41)&#xd;&#xa;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;CASE WHEN  &quot;titular&quot;  = 2 AND  &quot;orden&quot; =  3 THEN  color_rgb( 255,255,0)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;CASE WHEN   &quot;titular&quot;  = 1 AND   (&quot;clase&quot;  =  1001 or &quot;clase&quot;  =  1002) THEN  color_rgb( 1,120,255) &#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;CASE WHEN &quot;titular&quot;  = 1 AND   &quot;clase&quot;  =  1003  THEN  color_rgb( 255,0,0)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;color_rgb(255,255,255)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;END&#xd;&#xa;&#x9;END&#xd;&#xa;END"/>
                      <Option type="int" name="type" value="3"/>
                    </Option>
                  </Option>
                  <Option type="QString" name="type" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowOpacity="0" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowBlendMode="6" shadowOffsetGlobal="1" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="0" shadowOffsetUnit="MM" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowScale="100" shadowRadiusAlphaOnly="0" shadowRadiusUnit="MM"/>
        <dd_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" addDirectionSymbol="0" decimals="3" plussign="0" wrapChar="" useMaxLineLengthForAutoWrap="1" reverseDirectionSymbol="0" formatNumbers="0" multilineAlign="0" placeDirectionSymbol="0" rightDirectionSymbol=">"/>
      <placement lineAnchorPercent="0.5" rotationAngle="0" maxCurvedCharAngleIn="20" prioritization="PreferCloser" maximumDistance="0" distUnits="MM" centroidInside="0" layerType="LineGeometry" lineAnchorClipping="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" dist="0" preserveRotation="1" fitInPolygonOnly="0" lineAnchorTextPoint="CenterOfText" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" placement="4" placementFlags="10" overlapHandling="PreventOverlap" lineAnchorType="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" repeatDistanceUnits="MM" maximumDistanceUnit="MM" offsetType="0" centroidWhole="0" polygonPlacementFlags="2" maxCurvedCharAngleOut="-20" offsetUnits="MapUnit" distMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" rotationUnit="AngleDegrees" repeatDistance="50" geometryGenerator="" quadOffset="4" geometryGeneratorEnabled="0" geometryGeneratorType="PointGeometry" yOffset="0" allowDegraded="0" priority="5" overrunDistance="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0"/>
      <rendering mergeLines="1" obstacleFactor="1" drawLabels="1" upsidedownLabels="0" maxNumLabels="2000" obstacleType="0" labelPerPart="0" zIndex="3" fontLimitPixelSize="0" minFeatureSize="5" fontMaxPixelSize="10000" scaleVisibility="1" limitNumLabels="0" obstacle="1" unplacedVisibility="0" scaleMin="1" fontMinPixelSize="3" scaleMax="10000000"/>
      <dd_properties>
        <Option type="Map">
          <Option type="QString" name="name" value=""/>
          <Option type="Map" name="properties">
            <Option type="Map" name="AlwaysShow">
              <Option type="bool" name="active" value="false"/>
              <Option type="QString" name="expression" value="&quot;Titularidad&quot;  =  'JCCM' and  &quot;Funcionalidad&quot;  =  'Ramal'"/>
              <Option type="int" name="type" value="3"/>
            </Option>
            <Option type="Map" name="Color">
              <Option type="bool" name="active" value="true"/>
              <Option type="QString" name="expression" value="CASE WHEN &quot;titular&quot;  = 1 AND ( &quot;clase&quot; = 1001 or &quot;clase&quot; = 1002) THEN  color_rgb(255,255,255)&#xd;&#xa;&#x9;ELSE&#xd;&#xa;&#x9;CASE WHEN &quot;titular&quot;  = 2 AND  &quot;orden&quot; = 1 THEN  color_rgb( 0,0,0)&#xd;&#xa;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;CASE WHEN &quot;titular&quot;  = 2 AND  &quot;orden&quot; = 2  THEN  color_rgb(255,255,255)&#xd;&#xa;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;CASE WHEN &quot;titular&quot;  = 2 AND  &quot;orden&quot; = 3 THEN  color_rgb( 0,0,0)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;CASE WHEN &quot;titular&quot;  = 1 AND ( &quot;clase&quot; = 1002 or &quot;clase&quot; = 1003)  THEN color_rgb(255,255,255)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;color_rgb( 0,0,0)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;END&#xd;&#xa;&#x9;END&#xd;&#xa;END"/>
              <Option type="int" name="type" value="3"/>
            </Option>
            <Option type="Map" name="MinimumScale">
              <Option type="bool" name="active" value="false"/>
              <Option type="QString" name="expression" value="CASE WHEN    &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;  =    'Básica alta capacidad'    THEN  2000000&#xd;&#xa;ELSE &#xd;&#xa;    CASE WHEN   &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;    =   'Básica'   THEN  2000000&#xd;&#xa;    ELSE &#xd;&#xa;        CASE WHEN   &quot;Titularidad&quot;  =  'JCCM' AND &quot;Funcionalidad&quot;   =   'Comarcal'   THEN  750000&#xd;&#xa;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;CASE WHEN   &quot;Titularidad&quot;  =  'JCCM' AND (&quot;Funcionalidad&quot;   =   'Local' OR &quot;Funcionalidad&quot;   =   'Ramal')   THEN  600000&#xd;&#xa;&#x9;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;&#x9;CASE WHEN   &quot;Titularidad&quot;  =   'Estatal' THEN  2000000&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;CASE WHEN   &quot;Titularidad&quot;  =   'Estatal' THEN  2000000&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;CASE WHEN   &quot;Titularidad&quot;  =   'Diputación' THEN  350000&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;400000&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;END&#xd;&#xa;        END&#xd;&#xa;    END&#xd;&#xa;END"/>
              <Option type="int" name="type" value="3"/>
            </Option>
            <Option type="Map" name="ShapeBorderColor">
              <Option type="bool" name="active" value="true"/>
              <Option type="QString" name="expression" value="CASE WHEN &quot;titularD&quot;  =   'Comunidad Autónoma' AND &quot;calzadaD&quot; ='Duplicada' THEN  color_rgb(255,255,255)&#xd;&#xa;&#x9;ELSE&#xd;&#xa;&#x9;CASE WHEN &quot;titularD&quot;  =   'Comunidad Autónoma' AND  &quot;ordenD&quot; =  'Primer orden' THEN  color_rgb( 0,0,0)&#xd;&#xa;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;CASE WHEN &quot;titularD&quot;  =   'Comunidad Autónoma' AND  &quot;ordenD&quot; =   'Segundo orden'  THEN  color_rgb( 0,0,0)&#xd;&#xa;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;CASE WHEN &quot;titularD&quot;  =   'Comunidad Autónoma' AND  &quot;ordenD&quot; =  'Tercer orden' THEN  color_rgb( 0,0,0)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;CASE WHEN &quot;titularD&quot;  =    'Administración General del Estado' AND &quot;calzadaD&quot; =  'Duplicada' THEN color_rgb(255,255,255)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;CASE WHEN &quot;titularD&quot;  =    'Administración General del Estado' AND &quot;calzadaD&quot; = 'Única'  THEN color_rgb(255,255,255)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;color_rgb( 0,0,0)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;END&#xd;&#xa;&#x9;END&#xd;&#xa;END"/>
              <Option type="int" name="type" value="3"/>
            </Option>
            <Option type="Map" name="ShapeFillColor">
              <Option type="bool" name="active" value="true"/>
              <Option type="QString" name="expression" value="CASE WHEN &quot;titularD&quot;  =   'Comunidad Autónoma' AND &quot;calzadaD&quot; ='Duplicada' THEN  color_rgb( 184,0,204)&#xd;&#xa;&#x9;ELSE&#xd;&#xa;&#x9;CASE WHEN &quot;titularD&quot;  =   'Comunidad Autónoma' AND  &quot;ordenD&quot; =  'Primer orden' THEN  color_rgb( 255,127,0) &#x9;&#xd;&#xa;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;CASE WHEN &quot;titularD&quot;  =   'Comunidad Autónoma' AND  &quot;ordenD&quot; =   'Segundo orden'  THEN  color_rgb( 51,140,41)&#xd;&#xa;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;CASE WHEN &quot;titularD&quot;  =   'Comunidad Autónoma' AND  &quot;ordenD&quot; =  'Tercer orden' THEN  color_rgb( 255,255,0)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;CASE WHEN &quot;titularD&quot;  =    'Administración General del Estado' AND &quot;calzadaD&quot; =  'Duplicada' THEN  color_rgb( 1,120,255) &#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;CASE WHEN &quot;titularD&quot;  =    'Administración General del Estado' AND &quot;calzadaD&quot; = 'Única'  THEN  color_rgb( 255,0,0)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;ELSE &#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;color_rgb(255,255,255)&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;&#x9;END&#xd;&#xa;&#x9;&#x9;END&#xd;&#xa;&#x9;END&#xd;&#xa;END"/>
              <Option type="int" name="type" value="3"/>
            </Option>
            <Option type="Map" name="Show">
              <Option type="bool" name="active" value="false"/>
              <Option type="QString" name="expression" value="&quot;Titularidad&quot;  =  'JCCM' and  &quot;Funcionalidad&quot;  =  'Ramal'"/>
              <Option type="int" name="type" value="3"/>
            </Option>
            <Option type="Map" name="Size">
              <Option type="bool" name="active" value="true"/>
              <Option type="QString" name="expression" value="CASE WHEN    &quot;titular&quot; = 1  THEN  7&#xd;&#xa;ELSE &#xd;&#xa;    CASE WHEN   &quot;titular&quot; = 2 THEN  7&#xd;&#xa;    ELSE &#xd;&#xa;        CASE WHEN  &quot;titular&quot; = 3 THEN  6&#xd;&#xa;&#x9;&#x9;&#x9;ELSE&#xd;&#xa;&#x9;&#x9;&#x9;6&#xd;&#xa;&#x9;&#x9;END&#xd;&#xa;&#x9;END&#xd;&#xa;END"/>
              <Option type="int" name="type" value="3"/>
            </Option>
          </Option>
          <Option type="QString" name="type" value="collection"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
          <Option type="int" name="blendMode" value="0"/>
          <Option type="Map" name="ddProperties">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
          <Option type="bool" name="drawToAllParts" value="false"/>
          <Option type="QString" name="enabled" value="0"/>
          <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
          <Option type="QString" name="lineSymbol" value="&lt;symbol type=&quot;line&quot; name=&quot;symbol&quot; frame_rate=&quot;10&quot; clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; is_animated=&quot;0&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; enabled=&quot;1&quot; id=&quot;{0df39462-f2fe-46f0-9584-4dfa2a451eb6}&quot; locked=&quot;0&quot; pass=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255,rgb:0.23529411764705882,0.23529411764705882,0.23529411764705882,1&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
          <Option type="double" name="minLength" value="0"/>
          <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
          <Option type="QString" name="minLengthUnit" value="MM"/>
          <Option type="double" name="offsetFromAnchor" value="0"/>
          <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
          <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
          <Option type="double" name="offsetFromLabel" value="0"/>
          <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
          <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option type="List" name="dualview/previewExpressions">
        <Option type="QString" value="&quot;rt_catcarreteras_a_nombre&quot;"/>
        <Option type="QString" value="&quot;nombre&quot;"/>
        <Option type="QString" value="&quot;rt_catcarreteras_a_nombre&quot;"/>
      </Option>
      <Option type="QString" name="embeddedWidgets/count" value="0"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Pie">
    <DiagramCategory diagramOrientation="Up" stackedDiagramSpacing="0" stackedDiagramSpacingUnitScale="3x:0,0,0,0,0,0" sizeType="MM" height="15" rotationOffset="270" lineSizeScale="3x:0,0,0,0,0,0" labelPlacementMethod="XHeight" minimumSize="0" stackedDiagramSpacingUnit="MM" enabled="0" maxScaleDenominator="1e+08" penWidth="0" width="15" penColor="#000000" sizeScale="3x:0,0,0,0,0,0" minScaleDenominator="-4.65661e-10" lineSizeType="MM" scaleDependency="Area" stackedDiagramMode="Horizontal" backgroundAlpha="255" direction="1" spacing="0" spacingUnitScale="3x:0,0,0,0,0,0" opacity="1" penAlpha="255" scaleBasedVisibility="0" barWidth="5" backgroundColor="#ffffff" spacingUnit="MM" showAxis="0">
      <fontProperties description="MS Shell Dlg 2,7.8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
      <attribute colorOpacity="1" field="" color="#000000" label=""/>
      <axisSymbol>
        <symbol type="line" name="" frame_rate="10" clip_to_extent="1" force_rhr="0" is_animated="0" alpha="1">
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
          <layer class="SimpleLine" enabled="1" id="{a240c153-3d9d-4a66-afe9-091636afd299}" locked="0" pass="0">
            <Option type="Map">
              <Option type="QString" name="align_dash_pattern" value="0"/>
              <Option type="QString" name="capstyle" value="square"/>
              <Option type="QString" name="customdash" value="5;2"/>
              <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="customdash_unit" value="MM"/>
              <Option type="QString" name="dash_pattern_offset" value="0"/>
              <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
              <Option type="QString" name="draw_inside_polygon" value="0"/>
              <Option type="QString" name="joinstyle" value="bevel"/>
              <Option type="QString" name="line_color" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1"/>
              <Option type="QString" name="line_style" value="solid"/>
              <Option type="QString" name="line_width" value="0.26"/>
              <Option type="QString" name="line_width_unit" value="MM"/>
              <Option type="QString" name="offset" value="0"/>
              <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="offset_unit" value="MM"/>
              <Option type="QString" name="ring_filter" value="0"/>
              <Option type="QString" name="trim_distance_end" value="0"/>
              <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="trim_distance_end_unit" value="MM"/>
              <Option type="QString" name="trim_distance_start" value="0"/>
              <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="trim_distance_start_unit" value="MM"/>
              <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
              <Option type="QString" name="use_custom_dash" value="0"/>
              <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value=""/>
                <Option name="properties"/>
                <Option type="QString" name="type" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings placement="2" dist="0" obstacle="0" priority="0" linePlacementFlags="2" zIndex="0" showAll="1">
    <properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field name="fid" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="id_vial" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="codigo" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="dgc_via" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="tipo_vial" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="tipo_viald" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="nombre" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="nombre_alt" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="nombre_red" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Denominacion" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="PkINI" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="PkFIN" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Origen" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Destino" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Provincia" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="idMatricula" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="fuente_t" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="fuente_td" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="alta_db" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="version" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="id_tramo" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="tipo_tramo" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="tipo_tramd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="calzada" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="calzadad" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="acceso" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="accesod" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="firme" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="firmed" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ncarriles" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="sentido" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sentidod" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="situacion" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="situaciond" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="estadofis" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="estadofisd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="tipovehic" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="tipovehicd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="titular" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="titulard" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="orden" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ordend" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="clase" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="clased" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="fuente_v" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="fuente_vd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Longitud" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="Long_KM" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option type="bool" name="IsMultiline" value="false"/>
            <Option type="bool" name="UseHtml" value="false"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" name="" index="0"/>
    <alias field="id_vial" name="" index="1"/>
    <alias field="codigo" name="" index="2"/>
    <alias field="dgc_via" name="" index="3"/>
    <alias field="tipo_vial" name="" index="4"/>
    <alias field="tipo_viald" name="" index="5"/>
    <alias field="nombre" name="" index="6"/>
    <alias field="nombre_alt" name="" index="7"/>
    <alias field="nombre_red" name="" index="8"/>
    <alias field="Denominacion" name="" index="9"/>
    <alias field="PkINI" name="" index="10"/>
    <alias field="PkFIN" name="" index="11"/>
    <alias field="Origen" name="" index="12"/>
    <alias field="Destino" name="" index="13"/>
    <alias field="Provincia" name="" index="14"/>
    <alias field="idMatricula" name="" index="15"/>
    <alias field="fuente_t" name="" index="16"/>
    <alias field="fuente_td" name="" index="17"/>
    <alias field="alta_db" name="" index="18"/>
    <alias field="version" name="" index="19"/>
    <alias field="id_tramo" name="" index="20"/>
    <alias field="tipo_tramo" name="" index="21"/>
    <alias field="tipo_tramd" name="" index="22"/>
    <alias field="calzada" name="" index="23"/>
    <alias field="calzadad" name="" index="24"/>
    <alias field="acceso" name="" index="25"/>
    <alias field="accesod" name="" index="26"/>
    <alias field="firme" name="" index="27"/>
    <alias field="firmed" name="" index="28"/>
    <alias field="ncarriles" name="" index="29"/>
    <alias field="sentido" name="" index="30"/>
    <alias field="sentidod" name="" index="31"/>
    <alias field="situacion" name="" index="32"/>
    <alias field="situaciond" name="" index="33"/>
    <alias field="estadofis" name="" index="34"/>
    <alias field="estadofisd" name="" index="35"/>
    <alias field="tipovehic" name="" index="36"/>
    <alias field="tipovehicd" name="" index="37"/>
    <alias field="titular" name="" index="38"/>
    <alias field="titulard" name="" index="39"/>
    <alias field="orden" name="" index="40"/>
    <alias field="ordend" name="" index="41"/>
    <alias field="clase" name="" index="42"/>
    <alias field="clased" name="" index="43"/>
    <alias field="fuente_v" name="" index="44"/>
    <alias field="fuente_vd" name="" index="45"/>
    <alias field="Longitud" name="" index="46"/>
    <alias field="Long_KM" name="" index="47"/>
  </aliases>
  <splitPolicies>
    <policy field="fid" policy="Duplicate"/>
    <policy field="id_vial" policy="Duplicate"/>
    <policy field="codigo" policy="Duplicate"/>
    <policy field="dgc_via" policy="Duplicate"/>
    <policy field="tipo_vial" policy="Duplicate"/>
    <policy field="tipo_viald" policy="Duplicate"/>
    <policy field="nombre" policy="Duplicate"/>
    <policy field="nombre_alt" policy="Duplicate"/>
    <policy field="nombre_red" policy="Duplicate"/>
    <policy field="Denominacion" policy="Duplicate"/>
    <policy field="PkINI" policy="Duplicate"/>
    <policy field="PkFIN" policy="Duplicate"/>
    <policy field="Origen" policy="Duplicate"/>
    <policy field="Destino" policy="Duplicate"/>
    <policy field="Provincia" policy="Duplicate"/>
    <policy field="idMatricula" policy="Duplicate"/>
    <policy field="fuente_t" policy="Duplicate"/>
    <policy field="fuente_td" policy="Duplicate"/>
    <policy field="alta_db" policy="Duplicate"/>
    <policy field="version" policy="Duplicate"/>
    <policy field="id_tramo" policy="Duplicate"/>
    <policy field="tipo_tramo" policy="Duplicate"/>
    <policy field="tipo_tramd" policy="Duplicate"/>
    <policy field="calzada" policy="Duplicate"/>
    <policy field="calzadad" policy="Duplicate"/>
    <policy field="acceso" policy="Duplicate"/>
    <policy field="accesod" policy="Duplicate"/>
    <policy field="firme" policy="Duplicate"/>
    <policy field="firmed" policy="Duplicate"/>
    <policy field="ncarriles" policy="Duplicate"/>
    <policy field="sentido" policy="Duplicate"/>
    <policy field="sentidod" policy="Duplicate"/>
    <policy field="situacion" policy="Duplicate"/>
    <policy field="situaciond" policy="Duplicate"/>
    <policy field="estadofis" policy="Duplicate"/>
    <policy field="estadofisd" policy="Duplicate"/>
    <policy field="tipovehic" policy="Duplicate"/>
    <policy field="tipovehicd" policy="Duplicate"/>
    <policy field="titular" policy="Duplicate"/>
    <policy field="titulard" policy="Duplicate"/>
    <policy field="orden" policy="Duplicate"/>
    <policy field="ordend" policy="Duplicate"/>
    <policy field="clase" policy="Duplicate"/>
    <policy field="clased" policy="Duplicate"/>
    <policy field="fuente_v" policy="Duplicate"/>
    <policy field="fuente_vd" policy="Duplicate"/>
    <policy field="Longitud" policy="Duplicate"/>
    <policy field="Long_KM" policy="Duplicate"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy field="fid" policy="Duplicate"/>
    <policy field="id_vial" policy="Duplicate"/>
    <policy field="codigo" policy="Duplicate"/>
    <policy field="dgc_via" policy="Duplicate"/>
    <policy field="tipo_vial" policy="Duplicate"/>
    <policy field="tipo_viald" policy="Duplicate"/>
    <policy field="nombre" policy="Duplicate"/>
    <policy field="nombre_alt" policy="Duplicate"/>
    <policy field="nombre_red" policy="Duplicate"/>
    <policy field="Denominacion" policy="Duplicate"/>
    <policy field="PkINI" policy="Duplicate"/>
    <policy field="PkFIN" policy="Duplicate"/>
    <policy field="Origen" policy="Duplicate"/>
    <policy field="Destino" policy="Duplicate"/>
    <policy field="Provincia" policy="Duplicate"/>
    <policy field="idMatricula" policy="Duplicate"/>
    <policy field="fuente_t" policy="Duplicate"/>
    <policy field="fuente_td" policy="Duplicate"/>
    <policy field="alta_db" policy="Duplicate"/>
    <policy field="version" policy="Duplicate"/>
    <policy field="id_tramo" policy="Duplicate"/>
    <policy field="tipo_tramo" policy="Duplicate"/>
    <policy field="tipo_tramd" policy="Duplicate"/>
    <policy field="calzada" policy="Duplicate"/>
    <policy field="calzadad" policy="Duplicate"/>
    <policy field="acceso" policy="Duplicate"/>
    <policy field="accesod" policy="Duplicate"/>
    <policy field="firme" policy="Duplicate"/>
    <policy field="firmed" policy="Duplicate"/>
    <policy field="ncarriles" policy="Duplicate"/>
    <policy field="sentido" policy="Duplicate"/>
    <policy field="sentidod" policy="Duplicate"/>
    <policy field="situacion" policy="Duplicate"/>
    <policy field="situaciond" policy="Duplicate"/>
    <policy field="estadofis" policy="Duplicate"/>
    <policy field="estadofisd" policy="Duplicate"/>
    <policy field="tipovehic" policy="Duplicate"/>
    <policy field="tipovehicd" policy="Duplicate"/>
    <policy field="titular" policy="Duplicate"/>
    <policy field="titulard" policy="Duplicate"/>
    <policy field="orden" policy="Duplicate"/>
    <policy field="ordend" policy="Duplicate"/>
    <policy field="clase" policy="Duplicate"/>
    <policy field="clased" policy="Duplicate"/>
    <policy field="fuente_v" policy="Duplicate"/>
    <policy field="fuente_vd" policy="Duplicate"/>
    <policy field="Longitud" policy="Duplicate"/>
    <policy field="Long_KM" policy="Duplicate"/>
  </duplicatePolicies>
  <defaults>
    <default field="fid" applyOnUpdate="0" expression=""/>
    <default field="id_vial" applyOnUpdate="0" expression=""/>
    <default field="codigo" applyOnUpdate="0" expression=""/>
    <default field="dgc_via" applyOnUpdate="0" expression=""/>
    <default field="tipo_vial" applyOnUpdate="0" expression=""/>
    <default field="tipo_viald" applyOnUpdate="0" expression=""/>
    <default field="nombre" applyOnUpdate="0" expression=""/>
    <default field="nombre_alt" applyOnUpdate="0" expression=""/>
    <default field="nombre_red" applyOnUpdate="0" expression=""/>
    <default field="Denominacion" applyOnUpdate="0" expression=""/>
    <default field="PkINI" applyOnUpdate="0" expression=""/>
    <default field="PkFIN" applyOnUpdate="0" expression=""/>
    <default field="Origen" applyOnUpdate="0" expression=""/>
    <default field="Destino" applyOnUpdate="0" expression=""/>
    <default field="Provincia" applyOnUpdate="0" expression=""/>
    <default field="idMatricula" applyOnUpdate="0" expression=""/>
    <default field="fuente_t" applyOnUpdate="0" expression=""/>
    <default field="fuente_td" applyOnUpdate="0" expression=""/>
    <default field="alta_db" applyOnUpdate="0" expression=""/>
    <default field="version" applyOnUpdate="0" expression=""/>
    <default field="id_tramo" applyOnUpdate="0" expression=""/>
    <default field="tipo_tramo" applyOnUpdate="0" expression=""/>
    <default field="tipo_tramd" applyOnUpdate="0" expression=""/>
    <default field="calzada" applyOnUpdate="0" expression=""/>
    <default field="calzadad" applyOnUpdate="0" expression=""/>
    <default field="acceso" applyOnUpdate="0" expression=""/>
    <default field="accesod" applyOnUpdate="0" expression=""/>
    <default field="firme" applyOnUpdate="0" expression=""/>
    <default field="firmed" applyOnUpdate="0" expression=""/>
    <default field="ncarriles" applyOnUpdate="0" expression=""/>
    <default field="sentido" applyOnUpdate="0" expression=""/>
    <default field="sentidod" applyOnUpdate="0" expression=""/>
    <default field="situacion" applyOnUpdate="0" expression=""/>
    <default field="situaciond" applyOnUpdate="0" expression=""/>
    <default field="estadofis" applyOnUpdate="0" expression=""/>
    <default field="estadofisd" applyOnUpdate="0" expression=""/>
    <default field="tipovehic" applyOnUpdate="0" expression=""/>
    <default field="tipovehicd" applyOnUpdate="0" expression=""/>
    <default field="titular" applyOnUpdate="0" expression=""/>
    <default field="titulard" applyOnUpdate="0" expression=""/>
    <default field="orden" applyOnUpdate="0" expression=""/>
    <default field="ordend" applyOnUpdate="0" expression=""/>
    <default field="clase" applyOnUpdate="0" expression=""/>
    <default field="clased" applyOnUpdate="0" expression=""/>
    <default field="fuente_v" applyOnUpdate="0" expression=""/>
    <default field="fuente_vd" applyOnUpdate="0" expression=""/>
    <default field="Longitud" applyOnUpdate="0" expression=""/>
    <default field="Long_KM" applyOnUpdate="0" expression=""/>
  </defaults>
  <constraints>
    <constraint field="fid" notnull_strength="1" unique_strength="1" exp_strength="0" constraints="3"/>
    <constraint field="id_vial" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="codigo" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="dgc_via" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="tipo_vial" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="tipo_viald" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="nombre" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="nombre_alt" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="nombre_red" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="Denominacion" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="PkINI" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="PkFIN" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="Origen" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="Destino" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="Provincia" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="idMatricula" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="fuente_t" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="fuente_td" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="alta_db" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="version" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="id_tramo" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="tipo_tramo" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="tipo_tramd" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="calzada" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="calzadad" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="acceso" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="accesod" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="firme" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="firmed" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="ncarriles" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="sentido" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="sentidod" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="situacion" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="situaciond" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="estadofis" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="estadofisd" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="tipovehic" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="tipovehicd" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="titular" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="titulard" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="orden" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="ordend" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="clase" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="clased" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="fuente_v" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="fuente_vd" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="Longitud" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
    <constraint field="Long_KM" notnull_strength="0" unique_strength="0" exp_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="fid" exp="" desc=""/>
    <constraint field="id_vial" exp="" desc=""/>
    <constraint field="codigo" exp="" desc=""/>
    <constraint field="dgc_via" exp="" desc=""/>
    <constraint field="tipo_vial" exp="" desc=""/>
    <constraint field="tipo_viald" exp="" desc=""/>
    <constraint field="nombre" exp="" desc=""/>
    <constraint field="nombre_alt" exp="" desc=""/>
    <constraint field="nombre_red" exp="" desc=""/>
    <constraint field="Denominacion" exp="" desc=""/>
    <constraint field="PkINI" exp="" desc=""/>
    <constraint field="PkFIN" exp="" desc=""/>
    <constraint field="Origen" exp="" desc=""/>
    <constraint field="Destino" exp="" desc=""/>
    <constraint field="Provincia" exp="" desc=""/>
    <constraint field="idMatricula" exp="" desc=""/>
    <constraint field="fuente_t" exp="" desc=""/>
    <constraint field="fuente_td" exp="" desc=""/>
    <constraint field="alta_db" exp="" desc=""/>
    <constraint field="version" exp="" desc=""/>
    <constraint field="id_tramo" exp="" desc=""/>
    <constraint field="tipo_tramo" exp="" desc=""/>
    <constraint field="tipo_tramd" exp="" desc=""/>
    <constraint field="calzada" exp="" desc=""/>
    <constraint field="calzadad" exp="" desc=""/>
    <constraint field="acceso" exp="" desc=""/>
    <constraint field="accesod" exp="" desc=""/>
    <constraint field="firme" exp="" desc=""/>
    <constraint field="firmed" exp="" desc=""/>
    <constraint field="ncarriles" exp="" desc=""/>
    <constraint field="sentido" exp="" desc=""/>
    <constraint field="sentidod" exp="" desc=""/>
    <constraint field="situacion" exp="" desc=""/>
    <constraint field="situaciond" exp="" desc=""/>
    <constraint field="estadofis" exp="" desc=""/>
    <constraint field="estadofisd" exp="" desc=""/>
    <constraint field="tipovehic" exp="" desc=""/>
    <constraint field="tipovehicd" exp="" desc=""/>
    <constraint field="titular" exp="" desc=""/>
    <constraint field="titulard" exp="" desc=""/>
    <constraint field="orden" exp="" desc=""/>
    <constraint field="ordend" exp="" desc=""/>
    <constraint field="clase" exp="" desc=""/>
    <constraint field="clased" exp="" desc=""/>
    <constraint field="fuente_v" exp="" desc=""/>
    <constraint field="fuente_vd" exp="" desc=""/>
    <constraint field="Longitud" exp="" desc=""/>
    <constraint field="Long_KM" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
    <actionsetting type="1" capture="1" name="IDENTIFICA CARRETERA" action="## IDENTIFICA CARRETERA&#xa;TITULO=&quot;IDENTIFICAR CARRETERA&quot;;&#xa;MENSAJE=&quot;Carretera -  [% &quot;Matricula_Plan&quot; %]   PK - XX+XXX              (id:[% &quot;idMatricula&quot; %])\n\n&quot;;&#xa;&#xa;MENSAJE=MENSAJE+&quot;RED:[% &quot;Titularidad&quot; %]  FUNCIONALIDAD:[% &quot;Funcionalidad&quot; %]\nPK Ini:[%format_number( &quot;PkINI&quot; ,1)%] -  PK Fin:[%format_number( &quot;PkFIN&quot; ,1)%] ([% &quot;Long_Km&quot; %])  LONG(real)= [% format_number($length,2) %]m.\nDenominacion -  [% &quot;Denominacion&quot; %]  -[% &quot;Provincia&quot; %]-\n\n(DobleC-[% &quot;Tipologia_DobleC&quot; %], UnaC-[% &quot;Tipologia_UnaC&quot; %],)&quot;;&#xa;&#xa;QtGui.QMessageBox.information(None, TITULO, MENSAJE)&#xa;" notificationMessage="" icon="" shortTitle="" isEnabledOnlyWhenEditable="0" id="{65d7677c-3473-454a-ad68-f4145ed24f73}">
      <actionScope id="Canvas"/>
      <actionScope id="Field"/>
      <actionScope id="Feature"/>
    </actionsetting>
    <actionsetting type="1" capture="0" name="Coordenadas pinchadas (Herramienta ejecutar acciones de objetos espaciales)" action="QtGui.QMessageBox.information(None, &quot;Coordenadas&quot;, &quot;Capa: [% $layerid %]\n&quot;,&quot;Coords: X= [% format_number($clickx,2) %] , Y= [% format_number($clicky,2) %]&quot;)" notificationMessage="" icon="" shortTitle="" isEnabledOnlyWhenEditable="0" id="{b96ae8ed-48ca-4b04-b014-b4f87fa26ba3}">
      <actionScope id="Canvas"/>
      <actionScope id="Field"/>
      <actionScope id="Feature"/>
    </actionsetting>
    <actionsetting type="1" capture="0" name="OBTENER DISTANCIA EN LA RUTA" action="QtGui.QMessageBox.information(None, &quot;Coordenadas&quot;,&quot;Coords: X= [% format_number($clickx,2) %] , Y= [% format_number($clicky,2) %]&quot;)" notificationMessage="" icon="" shortTitle="" isEnabledOnlyWhenEditable="0" id="{c6377250-9183-475e-b4fc-de7bb3afc280}">
      <actionScope id="Canvas"/>
      <actionScope id="Field"/>
      <actionScope id="Feature"/>
    </actionsetting>
    <actionsetting type="1" capture="0" name="PRUEBA MENSAJE TEXTO" action="QString text = QInputDialog::getText(this, tr(&quot;QInputDialog::getText()&quot;),&#xa;                                         tr(&quot;User name:&quot;), QLineEdit::Normal,&#xa;                                         QDir::home().dirName(), &amp;ok);&#xa;&#xa;&#xa;" notificationMessage="" icon="" shortTitle="" isEnabledOnlyWhenEditable="0" id="{7b5db5fa-a745-44de-8cfd-dd9ea14084ea}">
      <actionScope id="Canvas"/>
      <actionScope id="Field"/>
      <actionScope id="Feature"/>
    </actionsetting>
    <actionsetting type="1" capture="0" name="PRUEBA MENSAJE TEXTO 2" action="QtGui.QMessageBox.Information([parent=None[, f=0]],&quot;Carretera&quot;,&quot;Carretera -  [% &quot;Matricula&quot; %]\n\nRED:[% &quot;Titularida&quot; %]  FUNCIONALIDAD:[% &quot;Funcionali&quot; %]\nPK Ini:[%format_number( &quot;PkINI&quot; ,1)%] -  PK Fin:[%format_number( &quot;PkFIN&quot; ,1)%]  LONG= [% format_number($length,2) %]m.\nDenominacion -  [% &quot;Denominaci&quot; %]&quot;,&quot;OK&quot;)&#xa;" notificationMessage="" icon="" shortTitle="" isEnabledOnlyWhenEditable="0" id="{30f55b43-6b11-4986-a823-eb8e5aca6d34}">
      <actionScope id="Canvas"/>
      <actionScope id="Field"/>
      <actionScope id="Feature"/>
    </actionsetting>
  </attributeactions>
  <attributetableconfig sortExpression="" sortOrder="0" actionWidgetStyle="dropDown">
    <columns>
      <column type="field" name="fid" width="-1" hidden="0"/>
      <column type="field" name="id_vial" width="-1" hidden="0"/>
      <column type="field" name="codigo" width="-1" hidden="0"/>
      <column type="field" name="dgc_via" width="-1" hidden="0"/>
      <column type="field" name="tipo_vial" width="-1" hidden="0"/>
      <column type="field" name="tipo_viald" width="-1" hidden="0"/>
      <column type="field" name="nombre" width="-1" hidden="0"/>
      <column type="field" name="nombre_alt" width="-1" hidden="0"/>
      <column type="field" name="nombre_red" width="-1" hidden="0"/>
      <column type="field" name="Denominacion" width="-1" hidden="0"/>
      <column type="field" name="PkINI" width="-1" hidden="0"/>
      <column type="field" name="PkFIN" width="-1" hidden="0"/>
      <column type="field" name="Origen" width="-1" hidden="0"/>
      <column type="field" name="Destino" width="-1" hidden="0"/>
      <column type="field" name="Provincia" width="-1" hidden="0"/>
      <column type="field" name="idMatricula" width="-1" hidden="0"/>
      <column type="field" name="fuente_t" width="-1" hidden="0"/>
      <column type="field" name="fuente_td" width="-1" hidden="0"/>
      <column type="field" name="alta_db" width="-1" hidden="0"/>
      <column type="field" name="version" width="-1" hidden="0"/>
      <column type="field" name="id_tramo" width="-1" hidden="0"/>
      <column type="field" name="tipo_tramo" width="-1" hidden="0"/>
      <column type="field" name="tipo_tramd" width="-1" hidden="0"/>
      <column type="field" name="calzada" width="-1" hidden="0"/>
      <column type="field" name="calzadad" width="-1" hidden="0"/>
      <column type="field" name="acceso" width="-1" hidden="0"/>
      <column type="field" name="accesod" width="-1" hidden="0"/>
      <column type="field" name="firme" width="-1" hidden="0"/>
      <column type="field" name="firmed" width="-1" hidden="0"/>
      <column type="field" name="ncarriles" width="-1" hidden="0"/>
      <column type="field" name="sentido" width="-1" hidden="0"/>
      <column type="field" name="sentidod" width="-1" hidden="0"/>
      <column type="field" name="situacion" width="-1" hidden="0"/>
      <column type="field" name="situaciond" width="-1" hidden="0"/>
      <column type="field" name="estadofis" width="-1" hidden="0"/>
      <column type="field" name="estadofisd" width="-1" hidden="0"/>
      <column type="field" name="tipovehic" width="-1" hidden="0"/>
      <column type="field" name="tipovehicd" width="-1" hidden="0"/>
      <column type="field" name="titular" width="-1" hidden="0"/>
      <column type="field" name="titulard" width="-1" hidden="0"/>
      <column type="field" name="orden" width="-1" hidden="0"/>
      <column type="field" name="ordend" width="-1" hidden="0"/>
      <column type="field" name="clase" width="-1" hidden="0"/>
      <column type="field" name="clased" width="168" hidden="0"/>
      <column type="field" name="fuente_v" width="-1" hidden="0"/>
      <column type="field" name="fuente_vd" width="-1" hidden="0"/>
      <column type="field" name="Longitud" width="-1" hidden="0"/>
      <column type="field" name="Long_KM" width="-1" hidden="0"/>
      <column type="actions" width="-1" hidden="1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1">Z:/cartografia/datos_Q/QSIG/MENUS/identificadorCTRAS.ui</editform>
  <editforminit/>
  <editforminitcodesource>1</editforminitcodesource>
  <editforminitfilepath>Z:/cartografia/datos_Q/QSIG/PLUGGIN PRUEBA/jccm_bar_CTRAS/pkmaptool.py</editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from PyQt4.QtGui import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
      <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
    </labelStyle>
    <attributeEditorContainer groupBox="1" type="GroupBox" name="DATOS GENERALES" visibilityExpressionEnabled="0" verticalStretch="0" collapsed="0" visibilityExpression="" columnCount="4" collapsedExpression="" collapsedExpressionEnabled="0" showLabel="1" horizontalStretch="0">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
        <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
      </labelStyle>
      <attributeEditorField name="nombre" verticalStretch="0" showLabel="1" horizontalStretch="0" index="6">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="nombre_alt" verticalStretch="0" showLabel="1" horizontalStretch="0" index="7">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="nombre_red" verticalStretch="0" showLabel="1" horizontalStretch="0" index="8">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="id_vial" verticalStretch="0" showLabel="1" horizontalStretch="0" index="1">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="id_tramo" verticalStretch="0" showLabel="1" horizontalStretch="0" index="20">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="idMatricula" verticalStretch="0" showLabel="1" horizontalStretch="0" index="15">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Longitud" verticalStretch="0" showLabel="1" horizontalStretch="0" index="46">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorField name="Denominacion" verticalStretch="0" showLabel="1" horizontalStretch="10" index="9">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
        <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorContainer groupBox="1" type="GroupBox" name="DATOS BTA_CAL" visibilityExpressionEnabled="0" verticalStretch="0" collapsed="0" visibilityExpression="" columnCount="3" collapsedExpression="" collapsedExpressionEnabled="0" showLabel="1" horizontalStretch="0">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
        <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
      </labelStyle>
      <attributeEditorField name="PkINI" verticalStretch="0" showLabel="1" horizontalStretch="0" index="10">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="PkFIN" verticalStretch="0" showLabel="1" horizontalStretch="0" index="11">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Long_KM" verticalStretch="0" showLabel="1" horizontalStretch="0" index="47">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Origen" verticalStretch="0" showLabel="1" horizontalStretch="0" index="12">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Destino" verticalStretch="0" showLabel="1" horizontalStretch="0" index="13">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="Provincia" verticalStretch="0" showLabel="1" horizontalStretch="0" index="14">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer groupBox="1" type="GroupBox" name="DATOS RT" visibilityExpressionEnabled="0" verticalStretch="0" collapsed="0" visibilityExpression="" columnCount="4" collapsedExpression="" collapsedExpressionEnabled="0" showLabel="1" horizontalStretch="0">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
        <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
      </labelStyle>
      <attributeEditorField name="titular" verticalStretch="0" showLabel="1" horizontalStretch="0" index="38">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="titulard" verticalStretch="0" showLabel="1" horizontalStretch="0" index="39">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="orden" verticalStretch="0" showLabel="1" horizontalStretch="0" index="40">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="ordend" verticalStretch="0" showLabel="1" horizontalStretch="0" index="41">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="tipo_vial" verticalStretch="0" showLabel="1" horizontalStretch="0" index="4">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="tipo_viald" verticalStretch="0" showLabel="1" horizontalStretch="0" index="5">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="clase" verticalStretch="0" showLabel="1" horizontalStretch="0" index="42">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="clased" verticalStretch="0" showLabel="1" horizontalStretch="0" index="43">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="tipo_tramo" verticalStretch="0" showLabel="1" horizontalStretch="0" index="21">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="tipo_tramd" verticalStretch="0" showLabel="1" horizontalStretch="0" index="22">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="calzada" verticalStretch="0" showLabel="1" horizontalStretch="0" index="23">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="calzadad" verticalStretch="0" showLabel="1" horizontalStretch="0" index="24">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="acceso" verticalStretch="0" showLabel="1" horizontalStretch="0" index="25">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="accesod" verticalStretch="0" showLabel="1" horizontalStretch="0" index="26">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="firme" verticalStretch="0" showLabel="1" horizontalStretch="0" index="27">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="firmed" verticalStretch="0" showLabel="1" horizontalStretch="0" index="28">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="sentido" verticalStretch="0" showLabel="1" horizontalStretch="0" index="30">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="sentidod" verticalStretch="0" showLabel="1" horizontalStretch="0" index="31">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="situacion" verticalStretch="0" showLabel="1" horizontalStretch="0" index="32">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="situaciond" verticalStretch="0" showLabel="1" horizontalStretch="0" index="33">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="estadofis" verticalStretch="0" showLabel="1" horizontalStretch="0" index="34">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="estadofisd" verticalStretch="0" showLabel="1" horizontalStretch="0" index="35">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="tipovehic" verticalStretch="0" showLabel="1" horizontalStretch="0" index="36">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="tipovehicd" verticalStretch="0" showLabel="1" horizontalStretch="0" index="37">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="ncarriles" verticalStretch="0" showLabel="1" horizontalStretch="0" index="29">
        <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
          <labelFont description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorField name="fid" verticalStretch="0" showLabel="1" horizontalStretch="0" index="0">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
        <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField name="fuente_t" verticalStretch="0" showLabel="1" horizontalStretch="0" index="16">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
        <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField name="fuente_td" verticalStretch="0" showLabel="1" horizontalStretch="0" index="17">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
        <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField name="codigo" verticalStretch="0" showLabel="1" horizontalStretch="0" index="2">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
        <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField name="dgc_via" verticalStretch="0" showLabel="1" horizontalStretch="0" index="3">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
        <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField name="fuente_v" verticalStretch="0" showLabel="1" horizontalStretch="0" index="44">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
        <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField name="fuente_vd" verticalStretch="0" showLabel="1" horizontalStretch="0" index="45">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
        <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField name="alta_db" verticalStretch="0" showLabel="1" horizontalStretch="0" index="18">
      <labelStyle overrideLabelFont="0" overrideLabelColor="0" labelColor="">
        <labelFont description="MS Shell Dlg 2,8,-1,5,50,0,0,0,0,0" style="" bold="0" underline="0" strikethrough="0" italic="0"/>
      </labelStyle>
    </attributeEditorField>
  </attributeEditorForm>
  <editable>
    <field name="Denominacion" editable="1"/>
    <field name="Destino" editable="1"/>
    <field name="Long_KM" editable="1"/>
    <field name="Longitud" editable="1"/>
    <field name="Origen" editable="1"/>
    <field name="PkFIN" editable="1"/>
    <field name="PkINI" editable="1"/>
    <field name="Provincia" editable="1"/>
    <field name="SOLAPA" editable="1"/>
    <field name="acceso" editable="1"/>
    <field name="accesoD" editable="1"/>
    <field name="accesod" editable="1"/>
    <field name="alta_db" editable="1"/>
    <field name="calzada" editable="1"/>
    <field name="calzadaD" editable="1"/>
    <field name="calzadad" editable="1"/>
    <field name="clase" editable="1"/>
    <field name="claseD" editable="1"/>
    <field name="clased" editable="1"/>
    <field name="codigo" editable="1"/>
    <field name="codigoD" editable="1"/>
    <field name="dgc_via" editable="1"/>
    <field name="dgc_viaD" editable="1"/>
    <field name="estadofis" editable="1"/>
    <field name="estadofisD" editable="1"/>
    <field name="estadofisd" editable="1"/>
    <field name="fecha_alta" editable="1"/>
    <field name="fid" editable="1"/>
    <field name="firme" editable="1"/>
    <field name="firmeD" editable="1"/>
    <field name="firmed" editable="1"/>
    <field name="fuente_t" editable="1"/>
    <field name="fuente_tD" editable="1"/>
    <field name="fuente_td" editable="1"/>
    <field name="fuente_v" editable="1"/>
    <field name="fuente_vD" editable="1"/>
    <field name="fuente_vd" editable="1"/>
    <field name="idMatricula" editable="1"/>
    <field name="id_tramo" editable="1"/>
    <field name="id_vial" editable="1"/>
    <field name="ncarriles" editable="1"/>
    <field name="ncarrilesD" editable="1"/>
    <field name="nombre" editable="1"/>
    <field name="nombre_alt" editable="1"/>
    <field name="nombre_red" editable="1"/>
    <field name="orden" editable="1"/>
    <field name="ordenD" editable="1"/>
    <field name="ordend" editable="1"/>
    <field name="provincia" editable="1"/>
    <field name="rt_catcarreteras_a_descripcion" editable="1"/>
    <field name="rt_catcarreteras_a_nombre" editable="1"/>
    <field name="rt_catcarreteras_a_nombre_alt" editable="1"/>
    <field name="sentido" editable="1"/>
    <field name="sentidoD" editable="1"/>
    <field name="sentidod" editable="1"/>
    <field name="situacion" editable="1"/>
    <field name="situacionD" editable="1"/>
    <field name="situaciond" editable="1"/>
    <field name="tipo_tramD" editable="1"/>
    <field name="tipo_tramd" editable="1"/>
    <field name="tipo_tramo" editable="1"/>
    <field name="tipo_vial" editable="1"/>
    <field name="tipo_vialD" editable="1"/>
    <field name="tipo_viald" editable="1"/>
    <field name="tipovehic" editable="1"/>
    <field name="tipovehicD" editable="1"/>
    <field name="tipovehicd" editable="1"/>
    <field name="titular" editable="1"/>
    <field name="titularD" editable="1"/>
    <field name="titulard" editable="1"/>
    <field name="version" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="Denominacion" labelOnTop="0"/>
    <field name="Destino" labelOnTop="0"/>
    <field name="Long_KM" labelOnTop="0"/>
    <field name="Longitud" labelOnTop="0"/>
    <field name="Origen" labelOnTop="0"/>
    <field name="PkFIN" labelOnTop="0"/>
    <field name="PkINI" labelOnTop="0"/>
    <field name="Provincia" labelOnTop="0"/>
    <field name="SOLAPA" labelOnTop="0"/>
    <field name="acceso" labelOnTop="0"/>
    <field name="accesoD" labelOnTop="0"/>
    <field name="accesod" labelOnTop="0"/>
    <field name="alta_db" labelOnTop="0"/>
    <field name="calzada" labelOnTop="0"/>
    <field name="calzadaD" labelOnTop="0"/>
    <field name="calzadad" labelOnTop="0"/>
    <field name="clase" labelOnTop="0"/>
    <field name="claseD" labelOnTop="0"/>
    <field name="clased" labelOnTop="0"/>
    <field name="codigo" labelOnTop="0"/>
    <field name="codigoD" labelOnTop="0"/>
    <field name="dgc_via" labelOnTop="0"/>
    <field name="dgc_viaD" labelOnTop="0"/>
    <field name="estadofis" labelOnTop="0"/>
    <field name="estadofisD" labelOnTop="0"/>
    <field name="estadofisd" labelOnTop="0"/>
    <field name="fecha_alta" labelOnTop="0"/>
    <field name="fid" labelOnTop="0"/>
    <field name="firme" labelOnTop="0"/>
    <field name="firmeD" labelOnTop="0"/>
    <field name="firmed" labelOnTop="0"/>
    <field name="fuente_t" labelOnTop="0"/>
    <field name="fuente_tD" labelOnTop="0"/>
    <field name="fuente_td" labelOnTop="0"/>
    <field name="fuente_v" labelOnTop="0"/>
    <field name="fuente_vD" labelOnTop="0"/>
    <field name="fuente_vd" labelOnTop="0"/>
    <field name="idMatricula" labelOnTop="0"/>
    <field name="id_tramo" labelOnTop="0"/>
    <field name="id_vial" labelOnTop="0"/>
    <field name="ncarriles" labelOnTop="0"/>
    <field name="ncarrilesD" labelOnTop="0"/>
    <field name="nombre" labelOnTop="0"/>
    <field name="nombre_alt" labelOnTop="0"/>
    <field name="nombre_red" labelOnTop="0"/>
    <field name="orden" labelOnTop="0"/>
    <field name="ordenD" labelOnTop="0"/>
    <field name="ordend" labelOnTop="0"/>
    <field name="provincia" labelOnTop="0"/>
    <field name="rt_catcarreteras_a_descripcion" labelOnTop="0"/>
    <field name="rt_catcarreteras_a_nombre" labelOnTop="0"/>
    <field name="rt_catcarreteras_a_nombre_alt" labelOnTop="0"/>
    <field name="sentido" labelOnTop="0"/>
    <field name="sentidoD" labelOnTop="0"/>
    <field name="sentidod" labelOnTop="0"/>
    <field name="situacion" labelOnTop="0"/>
    <field name="situacionD" labelOnTop="0"/>
    <field name="situaciond" labelOnTop="0"/>
    <field name="tipo_tramD" labelOnTop="0"/>
    <field name="tipo_tramd" labelOnTop="0"/>
    <field name="tipo_tramo" labelOnTop="0"/>
    <field name="tipo_vial" labelOnTop="0"/>
    <field name="tipo_vialD" labelOnTop="0"/>
    <field name="tipo_viald" labelOnTop="0"/>
    <field name="tipovehic" labelOnTop="0"/>
    <field name="tipovehicD" labelOnTop="0"/>
    <field name="tipovehicd" labelOnTop="0"/>
    <field name="titular" labelOnTop="0"/>
    <field name="titularD" labelOnTop="0"/>
    <field name="titulard" labelOnTop="0"/>
    <field name="version" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="Denominacion" reuseLastValue="0"/>
    <field name="Destino" reuseLastValue="0"/>
    <field name="Long_KM" reuseLastValue="0"/>
    <field name="Longitud" reuseLastValue="0"/>
    <field name="Origen" reuseLastValue="0"/>
    <field name="PkFIN" reuseLastValue="0"/>
    <field name="PkINI" reuseLastValue="0"/>
    <field name="Provincia" reuseLastValue="0"/>
    <field name="SOLAPA" reuseLastValue="0"/>
    <field name="acceso" reuseLastValue="0"/>
    <field name="accesoD" reuseLastValue="0"/>
    <field name="accesod" reuseLastValue="0"/>
    <field name="alta_db" reuseLastValue="0"/>
    <field name="calzada" reuseLastValue="0"/>
    <field name="calzadaD" reuseLastValue="0"/>
    <field name="calzadad" reuseLastValue="0"/>
    <field name="clase" reuseLastValue="0"/>
    <field name="claseD" reuseLastValue="0"/>
    <field name="clased" reuseLastValue="0"/>
    <field name="codigo" reuseLastValue="0"/>
    <field name="codigoD" reuseLastValue="0"/>
    <field name="dgc_via" reuseLastValue="0"/>
    <field name="dgc_viaD" reuseLastValue="0"/>
    <field name="estadofis" reuseLastValue="0"/>
    <field name="estadofisD" reuseLastValue="0"/>
    <field name="estadofisd" reuseLastValue="0"/>
    <field name="fecha_alta" reuseLastValue="0"/>
    <field name="fid" reuseLastValue="0"/>
    <field name="firme" reuseLastValue="0"/>
    <field name="firmeD" reuseLastValue="0"/>
    <field name="firmed" reuseLastValue="0"/>
    <field name="fuente_t" reuseLastValue="0"/>
    <field name="fuente_tD" reuseLastValue="0"/>
    <field name="fuente_td" reuseLastValue="0"/>
    <field name="fuente_v" reuseLastValue="0"/>
    <field name="fuente_vD" reuseLastValue="0"/>
    <field name="fuente_vd" reuseLastValue="0"/>
    <field name="idMatricula" reuseLastValue="0"/>
    <field name="id_tramo" reuseLastValue="0"/>
    <field name="id_vial" reuseLastValue="0"/>
    <field name="ncarriles" reuseLastValue="0"/>
    <field name="ncarrilesD" reuseLastValue="0"/>
    <field name="nombre" reuseLastValue="0"/>
    <field name="nombre_alt" reuseLastValue="0"/>
    <field name="nombre_red" reuseLastValue="0"/>
    <field name="orden" reuseLastValue="0"/>
    <field name="ordenD" reuseLastValue="0"/>
    <field name="ordend" reuseLastValue="0"/>
    <field name="provincia" reuseLastValue="0"/>
    <field name="rt_catcarreteras_a_descripcion" reuseLastValue="0"/>
    <field name="rt_catcarreteras_a_nombre" reuseLastValue="0"/>
    <field name="rt_catcarreteras_a_nombre_alt" reuseLastValue="0"/>
    <field name="sentido" reuseLastValue="0"/>
    <field name="sentidoD" reuseLastValue="0"/>
    <field name="sentidod" reuseLastValue="0"/>
    <field name="situacion" reuseLastValue="0"/>
    <field name="situacionD" reuseLastValue="0"/>
    <field name="situaciond" reuseLastValue="0"/>
    <field name="tipo_tramD" reuseLastValue="0"/>
    <field name="tipo_tramd" reuseLastValue="0"/>
    <field name="tipo_tramo" reuseLastValue="0"/>
    <field name="tipo_vial" reuseLastValue="0"/>
    <field name="tipo_vialD" reuseLastValue="0"/>
    <field name="tipo_viald" reuseLastValue="0"/>
    <field name="tipovehic" reuseLastValue="0"/>
    <field name="tipovehicD" reuseLastValue="0"/>
    <field name="tipovehicd" reuseLastValue="0"/>
    <field name="titular" reuseLastValue="0"/>
    <field name="titularD" reuseLastValue="0"/>
    <field name="titulard" reuseLastValue="0"/>
    <field name="version" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"rt_catcarreteras_a_nombre"</previewExpression>
  <mapTip enabled="1">[% "nombre" %]</mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
