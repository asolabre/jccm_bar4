<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingTol="1" autoRefreshTime="0" version="3.40.15-Bratislava" maxScale="0" styleCategories="AllStyleCategories" autoRefreshMode="Disabled" minScale="100000000" simplifyAlgorithm="0" simplifyLocal="1" readOnly="0" simplifyDrawingHints="1" symbologyReferenceScale="-1" labelsEnabled="0" simplifyMaxScale="1" hasScaleBasedVisibilityFlag="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal mode="0" startExpression="" accumulate="0" limitMode="0" endField="" durationUnit="min" enabled="0" endExpression="" fixedDuration="0" startField="" durationField="fid">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation zoffset="0" symbology="Line" zscale="1" extrusionEnabled="0" respectLayerSymbol="1" type="IndividualFeatures" clamping="Terrain" showMarkerSymbolInSurfacePlots="0" binding="Centroid" extrusion="0">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties"/>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol name="" clip_to_extent="1" alpha="1" force_rhr="0" type="line" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" id="{4965f145-10fc-40cc-b036-ec2ee3aeafc0}" class="SimpleLine" enabled="1" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" value="0" type="QString"/>
            <Option name="capstyle" value="square" type="QString"/>
            <Option name="customdash" value="5;2" type="QString"/>
            <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="customdash_unit" value="MM" type="QString"/>
            <Option name="dash_pattern_offset" value="0" type="QString"/>
            <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
            <Option name="draw_inside_polygon" value="0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="line_color" value="183,72,75,255,rgb:0.71764705882352942,0.28235294117647058,0.29411764705882354,1" type="QString"/>
            <Option name="line_style" value="solid" type="QString"/>
            <Option name="line_width" value="0.6" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="trim_distance_end" value="0" type="QString"/>
            <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_end_unit" value="MM" type="QString"/>
            <Option name="trim_distance_start" value="0" type="QString"/>
            <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_start_unit" value="MM" type="QString"/>
            <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
            <Option name="use_custom_dash" value="0" type="QString"/>
            <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol name="" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" id="{b089420b-62f0-4ab4-adb3-fecb106d35d0}" class="SimpleFill" enabled="1" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="183,72,75,255,rgb:0.71764705882352942,0.28235294117647058,0.29411764705882354,1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="131,51,54,255,rgb:0.51259632257572285,0.20167849240863661,0.21007095445181964,1" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol name="" clip_to_extent="1" alpha="1" force_rhr="0" type="marker" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" id="{5ce4279b-15ce-4b2d-b9cc-d20b277bbb5c}" class="SimpleMarker" enabled="1" pass="0">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="183,72,75,255,rgb:0.71764705882352942,0.28235294117647058,0.29411764705882354,1" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="diamond" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="131,51,54,255,rgb:0.51259632257572285,0.20167849240863661,0.21007095445181964,1" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 symbollevels="0" enableorderby="0" type="categorizedSymbol" referencescale="-1" attr="CASE WHEN &quot;num_mal&quot; = 0 THEN 0 WHEN &quot;num_mal&quot; &lt;= 3 THEN 1 WHEN &quot;num_mal&quot; &lt;= 6 THEN 2 ELSE 3 END" forceraster="0">
    <categories>
      <category render="true" symbol="0" value="0" label="OK (0 mal)" type="long" uuid="{c3dc8029-944e-49ae-86f0-b6eb83d65306}"/>
      <category render="true" symbol="1" value="1" label="1-3 mal" type="long" uuid="{cad1e085-4957-4c71-8bd2-52c49843a581}"/>
      <category render="true" symbol="2" value="2" label="4-6 mal" type="long" uuid="{b1096dae-28e6-48cb-8c9b-84a6abceb3cd}"/>
      <category render="true" symbol="3" value="3" label="7+ mal" type="long" uuid="{1082f2e2-898a-41af-853b-92e5c38f10df}"/>
    </categories>
    <symbols>
      <symbol name="0" clip_to_extent="1" alpha="1" force_rhr="0" type="line" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" id="{3212678a-9c64-424e-9c82-838d4330b5bf}" class="SimpleLine" enabled="1" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" value="0" type="QString"/>
            <Option name="capstyle" value="square" type="QString"/>
            <Option name="customdash" value="5;2" type="QString"/>
            <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="customdash_unit" value="MM" type="QString"/>
            <Option name="dash_pattern_offset" value="0" type="QString"/>
            <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
            <Option name="draw_inside_polygon" value="0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="line_color" value="0,170,0,255,rgb:0,0.66666666666666663,0,1" type="QString"/>
            <Option name="line_style" value="solid" type="QString"/>
            <Option name="line_width" value="1" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="trim_distance_end" value="0" type="QString"/>
            <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_end_unit" value="MM" type="QString"/>
            <Option name="trim_distance_start" value="0" type="QString"/>
            <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_start_unit" value="MM" type="QString"/>
            <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
            <Option name="use_custom_dash" value="0" type="QString"/>
            <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="1" clip_to_extent="1" alpha="1" force_rhr="0" type="line" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" id="{6c3e9b65-3273-49e0-8be4-1491b58b74f6}" class="SimpleLine" enabled="1" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" value="0" type="QString"/>
            <Option name="capstyle" value="square" type="QString"/>
            <Option name="customdash" value="5;2" type="QString"/>
            <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="customdash_unit" value="MM" type="QString"/>
            <Option name="dash_pattern_offset" value="0" type="QString"/>
            <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
            <Option name="draw_inside_polygon" value="0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="line_color" value="255,255,0,255,rgb:1,1,0,1" type="QString"/>
            <Option name="line_style" value="solid" type="QString"/>
            <Option name="line_width" value="1.2" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="trim_distance_end" value="0" type="QString"/>
            <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_end_unit" value="MM" type="QString"/>
            <Option name="trim_distance_start" value="0" type="QString"/>
            <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_start_unit" value="MM" type="QString"/>
            <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
            <Option name="use_custom_dash" value="0" type="QString"/>
            <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="2" clip_to_extent="1" alpha="1" force_rhr="0" type="line" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" id="{718850d1-31d4-474d-8c27-644843702d04}" class="SimpleLine" enabled="1" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" value="0" type="QString"/>
            <Option name="capstyle" value="square" type="QString"/>
            <Option name="customdash" value="5;2" type="QString"/>
            <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="customdash_unit" value="MM" type="QString"/>
            <Option name="dash_pattern_offset" value="0" type="QString"/>
            <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
            <Option name="draw_inside_polygon" value="0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="line_color" value="255,136,0,255,rgb:1,0.53333333333333333,0,1" type="QString"/>
            <Option name="line_style" value="solid" type="QString"/>
            <Option name="line_width" value="1.4" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="trim_distance_end" value="0" type="QString"/>
            <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_end_unit" value="MM" type="QString"/>
            <Option name="trim_distance_start" value="0" type="QString"/>
            <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_start_unit" value="MM" type="QString"/>
            <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
            <Option name="use_custom_dash" value="0" type="QString"/>
            <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="3" clip_to_extent="1" alpha="1" force_rhr="0" type="line" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" id="{8f30e418-7d18-42e9-8886-5f6af3fe5cc7}" class="SimpleLine" enabled="1" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" value="0" type="QString"/>
            <Option name="capstyle" value="square" type="QString"/>
            <Option name="customdash" value="5;2" type="QString"/>
            <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="customdash_unit" value="MM" type="QString"/>
            <Option name="dash_pattern_offset" value="0" type="QString"/>
            <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
            <Option name="draw_inside_polygon" value="0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="line_color" value="204,0,0,255,rgb:0.80000000000000004,0,0,1" type="QString"/>
            <Option name="line_style" value="solid" type="QString"/>
            <Option name="line_width" value="1.6" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="trim_distance_end" value="0" type="QString"/>
            <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_end_unit" value="MM" type="QString"/>
            <Option name="trim_distance_start" value="0" type="QString"/>
            <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_start_unit" value="MM" type="QString"/>
            <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
            <Option name="use_custom_dash" value="0" type="QString"/>
            <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties"/>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol name="" clip_to_extent="1" alpha="1" force_rhr="0" type="line" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" id="{203c8b3a-ad28-4b9f-9adc-5ac4ed0473f1}" class="SimpleLine" enabled="1" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" value="0" type="QString"/>
            <Option name="capstyle" value="square" type="QString"/>
            <Option name="customdash" value="5;2" type="QString"/>
            <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="customdash_unit" value="MM" type="QString"/>
            <Option name="dash_pattern_offset" value="0" type="QString"/>
            <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
            <Option name="draw_inside_polygon" value="0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="line_color" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" type="QString"/>
            <Option name="line_style" value="solid" type="QString"/>
            <Option name="line_width" value="0.26" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="trim_distance_end" value="0" type="QString"/>
            <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_end_unit" value="MM" type="QString"/>
            <Option name="trim_distance_start" value="0" type="QString"/>
            <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_start_unit" value="MM" type="QString"/>
            <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
            <Option name="use_custom_dash" value="0" type="QString"/>
            <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <customproperties>
    <Option type="Map">
      <Option name="dualview/previewExpressions" type="List">
        <Option value="&quot;jccm_nombre&quot;" type="QString"/>
      </Option>
      <Option name="embeddedWidgets/count" value="0" type="int"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field name="fid" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_fid" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_id_vial" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_codigo" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_dgc_via" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_tipo_vial" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_tipo_viald" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_nombre" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_nombre_alt" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_nombre_red" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_Denominacion" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_PkINI" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_PkFIN" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_Origen" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="jccm_Destino" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="jccm_Provincia" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_idMatricula" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_fuente_t" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_fuente_td" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_alta_db" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_version" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_id_tramo" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_tipo_tramo" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_tipo_tramd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_calzada" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_calzadad" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_acceso" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_accesod" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_firme" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_firmed" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_ncarriles" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_sentido" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_sentidod" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_situacion" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_situaciond" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_estadofis" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_estadofisd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_tipovehic" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_tipovehicd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_titular" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_titulard" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_orden" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_ordend" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_clase" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_clased" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="jccm_fuente_v" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="jccm_fuente_vd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="jccm_Longitud" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="jccm_Long_KM" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="rtign_id_vial" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="rtign_tipo_viald" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="rtign_clased" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="rtign_ordend" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="rtign_titulard" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="rtign_tipo_tramod" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="rtign_calzadad" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="rtign_accesod" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="rtign_firmed" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="rtign_ncarrilesd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="rtign_sentidod" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="rtign_situaciond" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="rtign_estadofisd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="rtign_tipovehicd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="result_id_vial" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="result_tipo_viald" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="result_clased" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="result_ordend" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="result_titulard" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="result_tipo_tramd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="result_calzadad" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="result_accesod" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="result_firmed" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="result_ncarriles" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="result_sentidod" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="result_situaciond" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="result_estadofisd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="result_tipovehicd" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option type="Map">
            <Option name="IsMultiline" value="false" type="bool"/>
            <Option name="UseHtml" value="false" type="bool"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="num_ok" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="true" type="bool"/>
            <Option name="Max" value="2147483647" type="int"/>
            <Option name="Min" value="-2147483648" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
    <field name="num_mal" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="num_total" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="punto_x" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="punto_y" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="num_punto" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option type="Map">
            <Option name="AllowNull" value="true" type="bool"/>
            <Option name="Max" value="2147483647" type="int"/>
            <Option name="Min" value="-2147483648" type="int"/>
            <Option name="Precision" value="0" type="int"/>
            <Option name="Step" value="1" type="int"/>
            <Option name="Style" value="SpinBox" type="QString"/>
          </Option>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" index="0" field="fid"/>
    <alias name="" index="1" field="jccm_fid"/>
    <alias name="" index="2" field="jccm_id_vial"/>
    <alias name="" index="3" field="jccm_codigo"/>
    <alias name="" index="4" field="jccm_dgc_via"/>
    <alias name="" index="5" field="jccm_tipo_vial"/>
    <alias name="" index="6" field="jccm_tipo_viald"/>
    <alias name="" index="7" field="jccm_nombre"/>
    <alias name="" index="8" field="jccm_nombre_alt"/>
    <alias name="" index="9" field="jccm_nombre_red"/>
    <alias name="" index="10" field="jccm_Denominacion"/>
    <alias name="" index="11" field="jccm_PkINI"/>
    <alias name="" index="12" field="jccm_PkFIN"/>
    <alias name="" index="13" field="jccm_Origen"/>
    <alias name="" index="14" field="jccm_Destino"/>
    <alias name="" index="15" field="jccm_Provincia"/>
    <alias name="" index="16" field="jccm_idMatricula"/>
    <alias name="" index="17" field="jccm_fuente_t"/>
    <alias name="" index="18" field="jccm_fuente_td"/>
    <alias name="" index="19" field="jccm_alta_db"/>
    <alias name="" index="20" field="jccm_version"/>
    <alias name="" index="21" field="jccm_id_tramo"/>
    <alias name="" index="22" field="jccm_tipo_tramo"/>
    <alias name="" index="23" field="jccm_tipo_tramd"/>
    <alias name="" index="24" field="jccm_calzada"/>
    <alias name="" index="25" field="jccm_calzadad"/>
    <alias name="" index="26" field="jccm_acceso"/>
    <alias name="" index="27" field="jccm_accesod"/>
    <alias name="" index="28" field="jccm_firme"/>
    <alias name="" index="29" field="jccm_firmed"/>
    <alias name="" index="30" field="jccm_ncarriles"/>
    <alias name="" index="31" field="jccm_sentido"/>
    <alias name="" index="32" field="jccm_sentidod"/>
    <alias name="" index="33" field="jccm_situacion"/>
    <alias name="" index="34" field="jccm_situaciond"/>
    <alias name="" index="35" field="jccm_estadofis"/>
    <alias name="" index="36" field="jccm_estadofisd"/>
    <alias name="" index="37" field="jccm_tipovehic"/>
    <alias name="" index="38" field="jccm_tipovehicd"/>
    <alias name="" index="39" field="jccm_titular"/>
    <alias name="" index="40" field="jccm_titulard"/>
    <alias name="" index="41" field="jccm_orden"/>
    <alias name="" index="42" field="jccm_ordend"/>
    <alias name="" index="43" field="jccm_clase"/>
    <alias name="" index="44" field="jccm_clased"/>
    <alias name="" index="45" field="jccm_fuente_v"/>
    <alias name="" index="46" field="jccm_fuente_vd"/>
    <alias name="" index="47" field="jccm_Longitud"/>
    <alias name="" index="48" field="jccm_Long_KM"/>
    <alias name="" index="49" field="rtign_id_vial"/>
    <alias name="" index="50" field="rtign_tipo_viald"/>
    <alias name="" index="51" field="rtign_clased"/>
    <alias name="" index="52" field="rtign_ordend"/>
    <alias name="" index="53" field="rtign_titulard"/>
    <alias name="" index="54" field="rtign_tipo_tramod"/>
    <alias name="" index="55" field="rtign_calzadad"/>
    <alias name="" index="56" field="rtign_accesod"/>
    <alias name="" index="57" field="rtign_firmed"/>
    <alias name="" index="58" field="rtign_ncarrilesd"/>
    <alias name="" index="59" field="rtign_sentidod"/>
    <alias name="" index="60" field="rtign_situaciond"/>
    <alias name="" index="61" field="rtign_estadofisd"/>
    <alias name="" index="62" field="rtign_tipovehicd"/>
    <alias name="" index="63" field="result_id_vial"/>
    <alias name="" index="64" field="result_tipo_viald"/>
    <alias name="" index="65" field="result_clased"/>
    <alias name="" index="66" field="result_ordend"/>
    <alias name="" index="67" field="result_titulard"/>
    <alias name="" index="68" field="result_tipo_tramd"/>
    <alias name="" index="69" field="result_calzadad"/>
    <alias name="" index="70" field="result_accesod"/>
    <alias name="" index="71" field="result_firmed"/>
    <alias name="" index="72" field="result_ncarriles"/>
    <alias name="" index="73" field="result_sentidod"/>
    <alias name="" index="74" field="result_situaciond"/>
    <alias name="" index="75" field="result_estadofisd"/>
    <alias name="" index="76" field="result_tipovehicd"/>
    <alias name="" index="77" field="num_ok"/>
    <alias name="" index="78" field="num_mal"/>
    <alias name="" index="79" field="num_total"/>
    <alias name="" index="80" field="punto_x"/>
    <alias name="" index="81" field="punto_y"/>
    <alias name="" index="82" field="num_punto"/>
  </aliases>
  <splitPolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="jccm_fid"/>
    <policy policy="Duplicate" field="jccm_id_vial"/>
    <policy policy="Duplicate" field="jccm_codigo"/>
    <policy policy="Duplicate" field="jccm_dgc_via"/>
    <policy policy="Duplicate" field="jccm_tipo_vial"/>
    <policy policy="Duplicate" field="jccm_tipo_viald"/>
    <policy policy="Duplicate" field="jccm_nombre"/>
    <policy policy="Duplicate" field="jccm_nombre_alt"/>
    <policy policy="Duplicate" field="jccm_nombre_red"/>
    <policy policy="Duplicate" field="jccm_Denominacion"/>
    <policy policy="Duplicate" field="jccm_PkINI"/>
    <policy policy="Duplicate" field="jccm_PkFIN"/>
    <policy policy="Duplicate" field="jccm_Origen"/>
    <policy policy="Duplicate" field="jccm_Destino"/>
    <policy policy="Duplicate" field="jccm_Provincia"/>
    <policy policy="Duplicate" field="jccm_idMatricula"/>
    <policy policy="Duplicate" field="jccm_fuente_t"/>
    <policy policy="Duplicate" field="jccm_fuente_td"/>
    <policy policy="Duplicate" field="jccm_alta_db"/>
    <policy policy="Duplicate" field="jccm_version"/>
    <policy policy="Duplicate" field="jccm_id_tramo"/>
    <policy policy="Duplicate" field="jccm_tipo_tramo"/>
    <policy policy="Duplicate" field="jccm_tipo_tramd"/>
    <policy policy="Duplicate" field="jccm_calzada"/>
    <policy policy="Duplicate" field="jccm_calzadad"/>
    <policy policy="Duplicate" field="jccm_acceso"/>
    <policy policy="Duplicate" field="jccm_accesod"/>
    <policy policy="Duplicate" field="jccm_firme"/>
    <policy policy="Duplicate" field="jccm_firmed"/>
    <policy policy="Duplicate" field="jccm_ncarriles"/>
    <policy policy="Duplicate" field="jccm_sentido"/>
    <policy policy="Duplicate" field="jccm_sentidod"/>
    <policy policy="Duplicate" field="jccm_situacion"/>
    <policy policy="Duplicate" field="jccm_situaciond"/>
    <policy policy="Duplicate" field="jccm_estadofis"/>
    <policy policy="Duplicate" field="jccm_estadofisd"/>
    <policy policy="Duplicate" field="jccm_tipovehic"/>
    <policy policy="Duplicate" field="jccm_tipovehicd"/>
    <policy policy="Duplicate" field="jccm_titular"/>
    <policy policy="Duplicate" field="jccm_titulard"/>
    <policy policy="Duplicate" field="jccm_orden"/>
    <policy policy="Duplicate" field="jccm_ordend"/>
    <policy policy="Duplicate" field="jccm_clase"/>
    <policy policy="Duplicate" field="jccm_clased"/>
    <policy policy="Duplicate" field="jccm_fuente_v"/>
    <policy policy="Duplicate" field="jccm_fuente_vd"/>
    <policy policy="Duplicate" field="jccm_Longitud"/>
    <policy policy="Duplicate" field="jccm_Long_KM"/>
    <policy policy="Duplicate" field="rtign_id_vial"/>
    <policy policy="Duplicate" field="rtign_tipo_viald"/>
    <policy policy="Duplicate" field="rtign_clased"/>
    <policy policy="Duplicate" field="rtign_ordend"/>
    <policy policy="Duplicate" field="rtign_titulard"/>
    <policy policy="Duplicate" field="rtign_tipo_tramod"/>
    <policy policy="Duplicate" field="rtign_calzadad"/>
    <policy policy="Duplicate" field="rtign_accesod"/>
    <policy policy="Duplicate" field="rtign_firmed"/>
    <policy policy="Duplicate" field="rtign_ncarrilesd"/>
    <policy policy="Duplicate" field="rtign_sentidod"/>
    <policy policy="Duplicate" field="rtign_situaciond"/>
    <policy policy="Duplicate" field="rtign_estadofisd"/>
    <policy policy="Duplicate" field="rtign_tipovehicd"/>
    <policy policy="Duplicate" field="result_id_vial"/>
    <policy policy="Duplicate" field="result_tipo_viald"/>
    <policy policy="Duplicate" field="result_clased"/>
    <policy policy="Duplicate" field="result_ordend"/>
    <policy policy="Duplicate" field="result_titulard"/>
    <policy policy="Duplicate" field="result_tipo_tramd"/>
    <policy policy="Duplicate" field="result_calzadad"/>
    <policy policy="Duplicate" field="result_accesod"/>
    <policy policy="Duplicate" field="result_firmed"/>
    <policy policy="Duplicate" field="result_ncarriles"/>
    <policy policy="Duplicate" field="result_sentidod"/>
    <policy policy="Duplicate" field="result_situaciond"/>
    <policy policy="Duplicate" field="result_estadofisd"/>
    <policy policy="Duplicate" field="result_tipovehicd"/>
    <policy policy="Duplicate" field="num_ok"/>
    <policy policy="Duplicate" field="num_mal"/>
    <policy policy="Duplicate" field="num_total"/>
    <policy policy="Duplicate" field="punto_x"/>
    <policy policy="Duplicate" field="punto_y"/>
    <policy policy="Duplicate" field="num_punto"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="jccm_fid"/>
    <policy policy="Duplicate" field="jccm_id_vial"/>
    <policy policy="Duplicate" field="jccm_codigo"/>
    <policy policy="Duplicate" field="jccm_dgc_via"/>
    <policy policy="Duplicate" field="jccm_tipo_vial"/>
    <policy policy="Duplicate" field="jccm_tipo_viald"/>
    <policy policy="Duplicate" field="jccm_nombre"/>
    <policy policy="Duplicate" field="jccm_nombre_alt"/>
    <policy policy="Duplicate" field="jccm_nombre_red"/>
    <policy policy="Duplicate" field="jccm_Denominacion"/>
    <policy policy="Duplicate" field="jccm_PkINI"/>
    <policy policy="Duplicate" field="jccm_PkFIN"/>
    <policy policy="Duplicate" field="jccm_Origen"/>
    <policy policy="Duplicate" field="jccm_Destino"/>
    <policy policy="Duplicate" field="jccm_Provincia"/>
    <policy policy="Duplicate" field="jccm_idMatricula"/>
    <policy policy="Duplicate" field="jccm_fuente_t"/>
    <policy policy="Duplicate" field="jccm_fuente_td"/>
    <policy policy="Duplicate" field="jccm_alta_db"/>
    <policy policy="Duplicate" field="jccm_version"/>
    <policy policy="Duplicate" field="jccm_id_tramo"/>
    <policy policy="Duplicate" field="jccm_tipo_tramo"/>
    <policy policy="Duplicate" field="jccm_tipo_tramd"/>
    <policy policy="Duplicate" field="jccm_calzada"/>
    <policy policy="Duplicate" field="jccm_calzadad"/>
    <policy policy="Duplicate" field="jccm_acceso"/>
    <policy policy="Duplicate" field="jccm_accesod"/>
    <policy policy="Duplicate" field="jccm_firme"/>
    <policy policy="Duplicate" field="jccm_firmed"/>
    <policy policy="Duplicate" field="jccm_ncarriles"/>
    <policy policy="Duplicate" field="jccm_sentido"/>
    <policy policy="Duplicate" field="jccm_sentidod"/>
    <policy policy="Duplicate" field="jccm_situacion"/>
    <policy policy="Duplicate" field="jccm_situaciond"/>
    <policy policy="Duplicate" field="jccm_estadofis"/>
    <policy policy="Duplicate" field="jccm_estadofisd"/>
    <policy policy="Duplicate" field="jccm_tipovehic"/>
    <policy policy="Duplicate" field="jccm_tipovehicd"/>
    <policy policy="Duplicate" field="jccm_titular"/>
    <policy policy="Duplicate" field="jccm_titulard"/>
    <policy policy="Duplicate" field="jccm_orden"/>
    <policy policy="Duplicate" field="jccm_ordend"/>
    <policy policy="Duplicate" field="jccm_clase"/>
    <policy policy="Duplicate" field="jccm_clased"/>
    <policy policy="Duplicate" field="jccm_fuente_v"/>
    <policy policy="Duplicate" field="jccm_fuente_vd"/>
    <policy policy="Duplicate" field="jccm_Longitud"/>
    <policy policy="Duplicate" field="jccm_Long_KM"/>
    <policy policy="Duplicate" field="rtign_id_vial"/>
    <policy policy="Duplicate" field="rtign_tipo_viald"/>
    <policy policy="Duplicate" field="rtign_clased"/>
    <policy policy="Duplicate" field="rtign_ordend"/>
    <policy policy="Duplicate" field="rtign_titulard"/>
    <policy policy="Duplicate" field="rtign_tipo_tramod"/>
    <policy policy="Duplicate" field="rtign_calzadad"/>
    <policy policy="Duplicate" field="rtign_accesod"/>
    <policy policy="Duplicate" field="rtign_firmed"/>
    <policy policy="Duplicate" field="rtign_ncarrilesd"/>
    <policy policy="Duplicate" field="rtign_sentidod"/>
    <policy policy="Duplicate" field="rtign_situaciond"/>
    <policy policy="Duplicate" field="rtign_estadofisd"/>
    <policy policy="Duplicate" field="rtign_tipovehicd"/>
    <policy policy="Duplicate" field="result_id_vial"/>
    <policy policy="Duplicate" field="result_tipo_viald"/>
    <policy policy="Duplicate" field="result_clased"/>
    <policy policy="Duplicate" field="result_ordend"/>
    <policy policy="Duplicate" field="result_titulard"/>
    <policy policy="Duplicate" field="result_tipo_tramd"/>
    <policy policy="Duplicate" field="result_calzadad"/>
    <policy policy="Duplicate" field="result_accesod"/>
    <policy policy="Duplicate" field="result_firmed"/>
    <policy policy="Duplicate" field="result_ncarriles"/>
    <policy policy="Duplicate" field="result_sentidod"/>
    <policy policy="Duplicate" field="result_situaciond"/>
    <policy policy="Duplicate" field="result_estadofisd"/>
    <policy policy="Duplicate" field="result_tipovehicd"/>
    <policy policy="Duplicate" field="num_ok"/>
    <policy policy="Duplicate" field="num_mal"/>
    <policy policy="Duplicate" field="num_total"/>
    <policy policy="Duplicate" field="punto_x"/>
    <policy policy="Duplicate" field="punto_y"/>
    <policy policy="Duplicate" field="num_punto"/>
  </duplicatePolicies>
  <defaults>
    <default field="fid" applyOnUpdate="0" expression=""/>
    <default field="jccm_fid" applyOnUpdate="0" expression=""/>
    <default field="jccm_id_vial" applyOnUpdate="0" expression=""/>
    <default field="jccm_codigo" applyOnUpdate="0" expression=""/>
    <default field="jccm_dgc_via" applyOnUpdate="0" expression=""/>
    <default field="jccm_tipo_vial" applyOnUpdate="0" expression=""/>
    <default field="jccm_tipo_viald" applyOnUpdate="0" expression=""/>
    <default field="jccm_nombre" applyOnUpdate="0" expression=""/>
    <default field="jccm_nombre_alt" applyOnUpdate="0" expression=""/>
    <default field="jccm_nombre_red" applyOnUpdate="0" expression=""/>
    <default field="jccm_Denominacion" applyOnUpdate="0" expression=""/>
    <default field="jccm_PkINI" applyOnUpdate="0" expression=""/>
    <default field="jccm_PkFIN" applyOnUpdate="0" expression=""/>
    <default field="jccm_Origen" applyOnUpdate="0" expression=""/>
    <default field="jccm_Destino" applyOnUpdate="0" expression=""/>
    <default field="jccm_Provincia" applyOnUpdate="0" expression=""/>
    <default field="jccm_idMatricula" applyOnUpdate="0" expression=""/>
    <default field="jccm_fuente_t" applyOnUpdate="0" expression=""/>
    <default field="jccm_fuente_td" applyOnUpdate="0" expression=""/>
    <default field="jccm_alta_db" applyOnUpdate="0" expression=""/>
    <default field="jccm_version" applyOnUpdate="0" expression=""/>
    <default field="jccm_id_tramo" applyOnUpdate="0" expression=""/>
    <default field="jccm_tipo_tramo" applyOnUpdate="0" expression=""/>
    <default field="jccm_tipo_tramd" applyOnUpdate="0" expression=""/>
    <default field="jccm_calzada" applyOnUpdate="0" expression=""/>
    <default field="jccm_calzadad" applyOnUpdate="0" expression=""/>
    <default field="jccm_acceso" applyOnUpdate="0" expression=""/>
    <default field="jccm_accesod" applyOnUpdate="0" expression=""/>
    <default field="jccm_firme" applyOnUpdate="0" expression=""/>
    <default field="jccm_firmed" applyOnUpdate="0" expression=""/>
    <default field="jccm_ncarriles" applyOnUpdate="0" expression=""/>
    <default field="jccm_sentido" applyOnUpdate="0" expression=""/>
    <default field="jccm_sentidod" applyOnUpdate="0" expression=""/>
    <default field="jccm_situacion" applyOnUpdate="0" expression=""/>
    <default field="jccm_situaciond" applyOnUpdate="0" expression=""/>
    <default field="jccm_estadofis" applyOnUpdate="0" expression=""/>
    <default field="jccm_estadofisd" applyOnUpdate="0" expression=""/>
    <default field="jccm_tipovehic" applyOnUpdate="0" expression=""/>
    <default field="jccm_tipovehicd" applyOnUpdate="0" expression=""/>
    <default field="jccm_titular" applyOnUpdate="0" expression=""/>
    <default field="jccm_titulard" applyOnUpdate="0" expression=""/>
    <default field="jccm_orden" applyOnUpdate="0" expression=""/>
    <default field="jccm_ordend" applyOnUpdate="0" expression=""/>
    <default field="jccm_clase" applyOnUpdate="0" expression=""/>
    <default field="jccm_clased" applyOnUpdate="0" expression=""/>
    <default field="jccm_fuente_v" applyOnUpdate="0" expression=""/>
    <default field="jccm_fuente_vd" applyOnUpdate="0" expression=""/>
    <default field="jccm_Longitud" applyOnUpdate="0" expression=""/>
    <default field="jccm_Long_KM" applyOnUpdate="0" expression=""/>
    <default field="rtign_id_vial" applyOnUpdate="0" expression=""/>
    <default field="rtign_tipo_viald" applyOnUpdate="0" expression=""/>
    <default field="rtign_clased" applyOnUpdate="0" expression=""/>
    <default field="rtign_ordend" applyOnUpdate="0" expression=""/>
    <default field="rtign_titulard" applyOnUpdate="0" expression=""/>
    <default field="rtign_tipo_tramod" applyOnUpdate="0" expression=""/>
    <default field="rtign_calzadad" applyOnUpdate="0" expression=""/>
    <default field="rtign_accesod" applyOnUpdate="0" expression=""/>
    <default field="rtign_firmed" applyOnUpdate="0" expression=""/>
    <default field="rtign_ncarrilesd" applyOnUpdate="0" expression=""/>
    <default field="rtign_sentidod" applyOnUpdate="0" expression=""/>
    <default field="rtign_situaciond" applyOnUpdate="0" expression=""/>
    <default field="rtign_estadofisd" applyOnUpdate="0" expression=""/>
    <default field="rtign_tipovehicd" applyOnUpdate="0" expression=""/>
    <default field="result_id_vial" applyOnUpdate="0" expression=""/>
    <default field="result_tipo_viald" applyOnUpdate="0" expression=""/>
    <default field="result_clased" applyOnUpdate="0" expression=""/>
    <default field="result_ordend" applyOnUpdate="0" expression=""/>
    <default field="result_titulard" applyOnUpdate="0" expression=""/>
    <default field="result_tipo_tramd" applyOnUpdate="0" expression=""/>
    <default field="result_calzadad" applyOnUpdate="0" expression=""/>
    <default field="result_accesod" applyOnUpdate="0" expression=""/>
    <default field="result_firmed" applyOnUpdate="0" expression=""/>
    <default field="result_ncarriles" applyOnUpdate="0" expression=""/>
    <default field="result_sentidod" applyOnUpdate="0" expression=""/>
    <default field="result_situaciond" applyOnUpdate="0" expression=""/>
    <default field="result_estadofisd" applyOnUpdate="0" expression=""/>
    <default field="result_tipovehicd" applyOnUpdate="0" expression=""/>
    <default field="num_ok" applyOnUpdate="0" expression=""/>
    <default field="num_mal" applyOnUpdate="0" expression=""/>
    <default field="num_total" applyOnUpdate="0" expression=""/>
    <default field="punto_x" applyOnUpdate="0" expression=""/>
    <default field="punto_y" applyOnUpdate="0" expression=""/>
    <default field="num_punto" applyOnUpdate="0" expression=""/>
  </defaults>
  <constraints>
    <constraint notnull_strength="1" constraints="3" field="fid" unique_strength="1" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_fid" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_id_vial" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_codigo" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_dgc_via" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_tipo_vial" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_tipo_viald" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_nombre" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_nombre_alt" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_nombre_red" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_Denominacion" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_PkINI" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_PkFIN" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_Origen" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_Destino" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_Provincia" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_idMatricula" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_fuente_t" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_fuente_td" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_alta_db" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_version" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_id_tramo" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_tipo_tramo" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_tipo_tramd" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_calzada" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_calzadad" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_acceso" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_accesod" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_firme" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_firmed" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_ncarriles" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_sentido" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_sentidod" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_situacion" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_situaciond" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_estadofis" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_estadofisd" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_tipovehic" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_tipovehicd" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_titular" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_titulard" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_orden" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_ordend" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_clase" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_clased" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_fuente_v" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_fuente_vd" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_Longitud" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="jccm_Long_KM" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="rtign_id_vial" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="rtign_tipo_viald" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="rtign_clased" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="rtign_ordend" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="rtign_titulard" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="rtign_tipo_tramod" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="rtign_calzadad" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="rtign_accesod" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="rtign_firmed" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="rtign_ncarrilesd" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="rtign_sentidod" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="rtign_situaciond" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="rtign_estadofisd" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="rtign_tipovehicd" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="result_id_vial" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="result_tipo_viald" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="result_clased" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="result_ordend" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="result_titulard" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="result_tipo_tramd" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="result_calzadad" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="result_accesod" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="result_firmed" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="result_ncarriles" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="result_sentidod" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="result_situaciond" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="result_estadofisd" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="result_tipovehicd" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="num_ok" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="num_mal" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="num_total" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="punto_x" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="punto_y" unique_strength="0" exp_strength="0"/>
    <constraint notnull_strength="0" constraints="0" field="num_punto" unique_strength="0" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="fid"/>
    <constraint exp="" desc="" field="jccm_fid"/>
    <constraint exp="" desc="" field="jccm_id_vial"/>
    <constraint exp="" desc="" field="jccm_codigo"/>
    <constraint exp="" desc="" field="jccm_dgc_via"/>
    <constraint exp="" desc="" field="jccm_tipo_vial"/>
    <constraint exp="" desc="" field="jccm_tipo_viald"/>
    <constraint exp="" desc="" field="jccm_nombre"/>
    <constraint exp="" desc="" field="jccm_nombre_alt"/>
    <constraint exp="" desc="" field="jccm_nombre_red"/>
    <constraint exp="" desc="" field="jccm_Denominacion"/>
    <constraint exp="" desc="" field="jccm_PkINI"/>
    <constraint exp="" desc="" field="jccm_PkFIN"/>
    <constraint exp="" desc="" field="jccm_Origen"/>
    <constraint exp="" desc="" field="jccm_Destino"/>
    <constraint exp="" desc="" field="jccm_Provincia"/>
    <constraint exp="" desc="" field="jccm_idMatricula"/>
    <constraint exp="" desc="" field="jccm_fuente_t"/>
    <constraint exp="" desc="" field="jccm_fuente_td"/>
    <constraint exp="" desc="" field="jccm_alta_db"/>
    <constraint exp="" desc="" field="jccm_version"/>
    <constraint exp="" desc="" field="jccm_id_tramo"/>
    <constraint exp="" desc="" field="jccm_tipo_tramo"/>
    <constraint exp="" desc="" field="jccm_tipo_tramd"/>
    <constraint exp="" desc="" field="jccm_calzada"/>
    <constraint exp="" desc="" field="jccm_calzadad"/>
    <constraint exp="" desc="" field="jccm_acceso"/>
    <constraint exp="" desc="" field="jccm_accesod"/>
    <constraint exp="" desc="" field="jccm_firme"/>
    <constraint exp="" desc="" field="jccm_firmed"/>
    <constraint exp="" desc="" field="jccm_ncarriles"/>
    <constraint exp="" desc="" field="jccm_sentido"/>
    <constraint exp="" desc="" field="jccm_sentidod"/>
    <constraint exp="" desc="" field="jccm_situacion"/>
    <constraint exp="" desc="" field="jccm_situaciond"/>
    <constraint exp="" desc="" field="jccm_estadofis"/>
    <constraint exp="" desc="" field="jccm_estadofisd"/>
    <constraint exp="" desc="" field="jccm_tipovehic"/>
    <constraint exp="" desc="" field="jccm_tipovehicd"/>
    <constraint exp="" desc="" field="jccm_titular"/>
    <constraint exp="" desc="" field="jccm_titulard"/>
    <constraint exp="" desc="" field="jccm_orden"/>
    <constraint exp="" desc="" field="jccm_ordend"/>
    <constraint exp="" desc="" field="jccm_clase"/>
    <constraint exp="" desc="" field="jccm_clased"/>
    <constraint exp="" desc="" field="jccm_fuente_v"/>
    <constraint exp="" desc="" field="jccm_fuente_vd"/>
    <constraint exp="" desc="" field="jccm_Longitud"/>
    <constraint exp="" desc="" field="jccm_Long_KM"/>
    <constraint exp="" desc="" field="rtign_id_vial"/>
    <constraint exp="" desc="" field="rtign_tipo_viald"/>
    <constraint exp="" desc="" field="rtign_clased"/>
    <constraint exp="" desc="" field="rtign_ordend"/>
    <constraint exp="" desc="" field="rtign_titulard"/>
    <constraint exp="" desc="" field="rtign_tipo_tramod"/>
    <constraint exp="" desc="" field="rtign_calzadad"/>
    <constraint exp="" desc="" field="rtign_accesod"/>
    <constraint exp="" desc="" field="rtign_firmed"/>
    <constraint exp="" desc="" field="rtign_ncarrilesd"/>
    <constraint exp="" desc="" field="rtign_sentidod"/>
    <constraint exp="" desc="" field="rtign_situaciond"/>
    <constraint exp="" desc="" field="rtign_estadofisd"/>
    <constraint exp="" desc="" field="rtign_tipovehicd"/>
    <constraint exp="" desc="" field="result_id_vial"/>
    <constraint exp="" desc="" field="result_tipo_viald"/>
    <constraint exp="" desc="" field="result_clased"/>
    <constraint exp="" desc="" field="result_ordend"/>
    <constraint exp="" desc="" field="result_titulard"/>
    <constraint exp="" desc="" field="result_tipo_tramd"/>
    <constraint exp="" desc="" field="result_calzadad"/>
    <constraint exp="" desc="" field="result_accesod"/>
    <constraint exp="" desc="" field="result_firmed"/>
    <constraint exp="" desc="" field="result_ncarriles"/>
    <constraint exp="" desc="" field="result_sentidod"/>
    <constraint exp="" desc="" field="result_situaciond"/>
    <constraint exp="" desc="" field="result_estadofisd"/>
    <constraint exp="" desc="" field="result_tipovehicd"/>
    <constraint exp="" desc="" field="num_ok"/>
    <constraint exp="" desc="" field="num_mal"/>
    <constraint exp="" desc="" field="num_total"/>
    <constraint exp="" desc="" field="punto_x"/>
    <constraint exp="" desc="" field="punto_y"/>
    <constraint exp="" desc="" field="num_punto"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig sortExpression="" actionWidgetStyle="dropDown" sortOrder="0">
    <columns>
      <column name="fid" type="field" hidden="0" width="-1"/>
      <column name="jccm_fid" type="field" hidden="0" width="-1"/>
      <column name="jccm_id_vial" type="field" hidden="0" width="-1"/>
      <column name="jccm_codigo" type="field" hidden="0" width="-1"/>
      <column name="jccm_dgc_via" type="field" hidden="0" width="-1"/>
      <column name="jccm_tipo_vial" type="field" hidden="0" width="-1"/>
      <column name="jccm_tipo_viald" type="field" hidden="0" width="-1"/>
      <column name="jccm_nombre" type="field" hidden="0" width="-1"/>
      <column name="jccm_nombre_alt" type="field" hidden="0" width="-1"/>
      <column name="jccm_nombre_red" type="field" hidden="0" width="-1"/>
      <column name="jccm_Denominacion" type="field" hidden="0" width="-1"/>
      <column name="jccm_PkINI" type="field" hidden="0" width="-1"/>
      <column name="jccm_PkFIN" type="field" hidden="0" width="-1"/>
      <column name="jccm_Origen" type="field" hidden="0" width="-1"/>
      <column name="jccm_Destino" type="field" hidden="0" width="-1"/>
      <column name="jccm_Provincia" type="field" hidden="0" width="-1"/>
      <column name="jccm_idMatricula" type="field" hidden="0" width="-1"/>
      <column name="jccm_fuente_t" type="field" hidden="0" width="-1"/>
      <column name="jccm_fuente_td" type="field" hidden="0" width="-1"/>
      <column name="jccm_alta_db" type="field" hidden="0" width="-1"/>
      <column name="jccm_version" type="field" hidden="0" width="-1"/>
      <column name="jccm_id_tramo" type="field" hidden="0" width="-1"/>
      <column name="jccm_tipo_tramo" type="field" hidden="0" width="-1"/>
      <column name="jccm_tipo_tramd" type="field" hidden="0" width="-1"/>
      <column name="jccm_calzada" type="field" hidden="0" width="-1"/>
      <column name="jccm_calzadad" type="field" hidden="0" width="-1"/>
      <column name="jccm_acceso" type="field" hidden="0" width="-1"/>
      <column name="jccm_accesod" type="field" hidden="0" width="-1"/>
      <column name="jccm_firme" type="field" hidden="0" width="-1"/>
      <column name="jccm_firmed" type="field" hidden="0" width="-1"/>
      <column name="jccm_ncarriles" type="field" hidden="0" width="-1"/>
      <column name="jccm_sentido" type="field" hidden="0" width="-1"/>
      <column name="jccm_sentidod" type="field" hidden="0" width="-1"/>
      <column name="jccm_situacion" type="field" hidden="0" width="-1"/>
      <column name="jccm_situaciond" type="field" hidden="0" width="-1"/>
      <column name="jccm_estadofis" type="field" hidden="0" width="-1"/>
      <column name="jccm_estadofisd" type="field" hidden="0" width="-1"/>
      <column name="jccm_tipovehic" type="field" hidden="0" width="-1"/>
      <column name="jccm_tipovehicd" type="field" hidden="0" width="-1"/>
      <column name="jccm_titular" type="field" hidden="0" width="-1"/>
      <column name="jccm_titulard" type="field" hidden="0" width="-1"/>
      <column name="jccm_orden" type="field" hidden="0" width="-1"/>
      <column name="jccm_ordend" type="field" hidden="0" width="-1"/>
      <column name="jccm_clase" type="field" hidden="0" width="-1"/>
      <column name="jccm_clased" type="field" hidden="0" width="-1"/>
      <column name="jccm_fuente_v" type="field" hidden="0" width="-1"/>
      <column name="jccm_fuente_vd" type="field" hidden="0" width="-1"/>
      <column name="jccm_Longitud" type="field" hidden="0" width="-1"/>
      <column name="jccm_Long_KM" type="field" hidden="0" width="-1"/>
      <column name="rtign_id_vial" type="field" hidden="0" width="-1"/>
      <column name="rtign_tipo_viald" type="field" hidden="0" width="-1"/>
      <column name="rtign_clased" type="field" hidden="0" width="168"/>
      <column name="rtign_ordend" type="field" hidden="0" width="-1"/>
      <column name="rtign_titulard" type="field" hidden="0" width="-1"/>
      <column name="rtign_tipo_tramod" type="field" hidden="0" width="-1"/>
      <column name="rtign_calzadad" type="field" hidden="0" width="-1"/>
      <column name="rtign_accesod" type="field" hidden="0" width="-1"/>
      <column name="rtign_firmed" type="field" hidden="0" width="-1"/>
      <column name="rtign_ncarrilesd" type="field" hidden="0" width="-1"/>
      <column name="rtign_sentidod" type="field" hidden="0" width="-1"/>
      <column name="rtign_situaciond" type="field" hidden="0" width="-1"/>
      <column name="rtign_estadofisd" type="field" hidden="0" width="-1"/>
      <column name="rtign_tipovehicd" type="field" hidden="0" width="-1"/>
      <column name="result_id_vial" type="field" hidden="0" width="-1"/>
      <column name="result_tipo_viald" type="field" hidden="0" width="-1"/>
      <column name="result_clased" type="field" hidden="0" width="-1"/>
      <column name="result_ordend" type="field" hidden="0" width="-1"/>
      <column name="result_titulard" type="field" hidden="0" width="-1"/>
      <column name="result_tipo_tramd" type="field" hidden="0" width="-1"/>
      <column name="result_calzadad" type="field" hidden="0" width="-1"/>
      <column name="result_accesod" type="field" hidden="0" width="-1"/>
      <column name="result_firmed" type="field" hidden="0" width="-1"/>
      <column name="result_ncarriles" type="field" hidden="0" width="-1"/>
      <column name="result_sentidod" type="field" hidden="0" width="-1"/>
      <column name="result_situaciond" type="field" hidden="0" width="-1"/>
      <column name="result_estadofisd" type="field" hidden="0" width="-1"/>
      <column name="result_tipovehicd" type="field" hidden="0" width="-1"/>
      <column name="num_ok" type="field" hidden="0" width="-1"/>
      <column name="num_mal" type="field" hidden="0" width="-1"/>
      <column name="num_total" type="field" hidden="0" width="-1"/>
      <column name="punto_x" type="field" hidden="0" width="-1"/>
      <column name="punto_y" type="field" hidden="0" width="-1"/>
      <column name="num_punto" type="field" hidden="0" width="-1"/>
      <column type="actions" hidden="1" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[QGISQGIS# -*- coding: utf-8 -*-
"""
Los formularios QGIS pueden tener una función de Python a la que se llama cuando el formulario es abierto.

Utilice esta función para agregar lógica adicional a sus formularios.

Ingrese el nombre de la función en el campo"Función de inicio de Python" .
A continuación se muestra un ejemplo:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>tablayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
      <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
    </labelStyle>
    <attributeEditorContainer backgroundColor="#e497f9" name="IDENTIFICACIÓN VIAL" collapsed="0" visibilityExpressionEnabled="0" type="GroupBox" horizontalStretch="0" visibilityExpression="" showLabel="1" groupBox="1" collapsedExpressionEnabled="0" collapsedExpression="" verticalStretch="0" columnCount="3">
      <labelStyle labelColor="0,0,247,255,rgb:0,0,0.96981765468833447,1" overrideLabelFont="1" overrideLabelColor="1">
        <labelFont bold="1" style="" description="MS Shell Dlg 2,8.25,-1,5,75,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField name="jccm_nombre" index="7" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_nombre_alt" index="8" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_nombre_red" index="9" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="fid" index="0" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_fid" index="1" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_codigo" index="3" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_id_vial" index="2" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="rtign_id_vial" index="49" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="result_id_vial" index="63" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_dgc_via" index="4" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_id_tramo" index="21" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_version" index="20" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_alta_db" index="19" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_fuente_t" index="17" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_fuente_td" index="18" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorContainer name="" collapsed="0" visibilityExpressionEnabled="0" type="Row" horizontalStretch="0" visibilityExpression="" showLabel="1" groupBox="0" collapsedExpressionEnabled="0" collapsedExpression="" verticalStretch="0" columnCount="1">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorContainer>
    </attributeEditorContainer>
    <attributeEditorContainer name="COMPARATIVA" collapsed="0" visibilityExpressionEnabled="0" type="GroupBox" horizontalStretch="0" visibilityExpression="" showLabel="1" groupBox="1" collapsedExpressionEnabled="0" collapsedExpression="" verticalStretch="0" columnCount="4">
      <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField name="jccm_clase" index="43" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_clased" index="44" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="rtign_clased" index="51" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="result_clased" index="65" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_orden" index="41" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_ordend" index="42" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="rtign_ordend" index="52" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="result_ordend" index="66" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_titular" index="39" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_titulard" index="40" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="rtign_titulard" index="53" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="result_titulard" index="67" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_tipovehic" index="37" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_tipovehicd" index="38" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="rtign_tipovehicd" index="62" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="result_tipovehicd" index="76" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_estadofis" index="35" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_estadofisd" index="36" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="rtign_estadofisd" index="61" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="result_estadofisd" index="75" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_situacion" index="33" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_situaciond" index="34" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="rtign_situaciond" index="60" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="result_situaciond" index="74" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_sentido" index="31" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_sentidod" index="32" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="rtign_sentidod" index="59" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="result_sentidod" index="73" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorContainer name="ncarriles" collapsed="0" visibilityExpressionEnabled="0" type="Row" horizontalStretch="0" visibilityExpression="" showLabel="0" groupBox="0" collapsedExpressionEnabled="0" collapsedExpression="" verticalStretch="0" columnCount="1">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorContainer>
      <attributeEditorField name="jccm_ncarriles" index="30" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="rtign_ncarrilesd" index="58" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="result_ncarriles" index="72" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_firme" index="28" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_firmed" index="29" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="rtign_firmed" index="57" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="result_firmed" index="71" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_acceso" index="26" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_accesod" index="27" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="rtign_accesod" index="56" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="result_accesod" index="70" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_calzada" index="24" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_calzadad" index="25" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="rtign_calzadad" index="55" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="result_calzadad" index="69" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_tipo_tramo" index="22" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_tipo_tramd" index="23" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="rtign_tipo_tramod" index="54" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="result_tipo_tramd" index="68" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_tipo_vial" index="5" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_tipo_viald" index="6" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="rtign_tipo_viald" index="50" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="result_tipo_viald" index="64" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer name="ESTADISTICA" collapsed="0" visibilityExpressionEnabled="0" type="GroupBox" horizontalStretch="0" visibilityExpression="" showLabel="1" groupBox="1" collapsedExpressionEnabled="0" collapsedExpression="" verticalStretch="0" columnCount="3">
      <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField name="num_ok" index="77" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="num_mal" index="78" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="num_total" index="79" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="punto_x" index="80" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="punto_y" index="81" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="num_punto" index="82" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
    <attributeEditorContainer name="RESTO DATOS" collapsed="0" visibilityExpressionEnabled="0" type="GroupBox" horizontalStretch="0" visibilityExpression="" showLabel="1" groupBox="1" collapsedExpressionEnabled="0" collapsedExpression="" verticalStretch="0" columnCount="3">
      <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
        <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
      </labelStyle>
      <attributeEditorField name="jccm_idMatricula" index="16" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_Provincia" index="15" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_Destino" index="14" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_Origen" index="13" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_PkFIN" index="12" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_PkINI" index="11" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_Denominacion" index="10" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_fuente_v" index="45" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_fuente_vd" index="46" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_Longitud" index="47" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
      <attributeEditorField name="jccm_Long_KM" index="48" horizontalStretch="0" showLabel="1" verticalStretch="0">
        <labelStyle labelColor="" overrideLabelFont="0" overrideLabelColor="0">
          <labelFont bold="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" underline="0" strikethrough="0"/>
        </labelStyle>
      </attributeEditorField>
    </attributeEditorContainer>
  </attributeEditorForm>
  <editable>
    <field name="fid" editable="1"/>
    <field name="jccm_Denominacion" editable="1"/>
    <field name="jccm_Destino" editable="1"/>
    <field name="jccm_Long_KM" editable="1"/>
    <field name="jccm_Longitud" editable="1"/>
    <field name="jccm_Origen" editable="1"/>
    <field name="jccm_PkFIN" editable="1"/>
    <field name="jccm_PkINI" editable="1"/>
    <field name="jccm_Provincia" editable="1"/>
    <field name="jccm_acceso" editable="1"/>
    <field name="jccm_accesod" editable="1"/>
    <field name="jccm_alta_db" editable="1"/>
    <field name="jccm_calzada" editable="1"/>
    <field name="jccm_calzadad" editable="1"/>
    <field name="jccm_clase" editable="1"/>
    <field name="jccm_clased" editable="1"/>
    <field name="jccm_codigo" editable="1"/>
    <field name="jccm_dgc_via" editable="1"/>
    <field name="jccm_estadofis" editable="1"/>
    <field name="jccm_estadofisd" editable="1"/>
    <field name="jccm_fid" editable="1"/>
    <field name="jccm_firme" editable="1"/>
    <field name="jccm_firmed" editable="1"/>
    <field name="jccm_fuente_t" editable="1"/>
    <field name="jccm_fuente_td" editable="1"/>
    <field name="jccm_fuente_v" editable="1"/>
    <field name="jccm_fuente_vd" editable="1"/>
    <field name="jccm_idMatricula" editable="1"/>
    <field name="jccm_id_tramo" editable="1"/>
    <field name="jccm_id_vial" editable="1"/>
    <field name="jccm_ncarriles" editable="1"/>
    <field name="jccm_nombre" editable="1"/>
    <field name="jccm_nombre_alt" editable="1"/>
    <field name="jccm_nombre_red" editable="1"/>
    <field name="jccm_orden" editable="1"/>
    <field name="jccm_ordend" editable="1"/>
    <field name="jccm_sentido" editable="1"/>
    <field name="jccm_sentidod" editable="1"/>
    <field name="jccm_situacion" editable="1"/>
    <field name="jccm_situaciond" editable="1"/>
    <field name="jccm_tipo_tramd" editable="1"/>
    <field name="jccm_tipo_tramo" editable="1"/>
    <field name="jccm_tipo_vial" editable="1"/>
    <field name="jccm_tipo_viald" editable="1"/>
    <field name="jccm_tipovehic" editable="1"/>
    <field name="jccm_tipovehicd" editable="1"/>
    <field name="jccm_titular" editable="1"/>
    <field name="jccm_titulard" editable="1"/>
    <field name="jccm_version" editable="1"/>
    <field name="num_mal" editable="1"/>
    <field name="num_ok" editable="1"/>
    <field name="num_punto" editable="1"/>
    <field name="num_total" editable="1"/>
    <field name="punto_x" editable="1"/>
    <field name="punto_y" editable="1"/>
    <field name="result_accesod" editable="1"/>
    <field name="result_calzadad" editable="1"/>
    <field name="result_clased" editable="1"/>
    <field name="result_estadofisd" editable="1"/>
    <field name="result_firmed" editable="1"/>
    <field name="result_id_vial" editable="1"/>
    <field name="result_ncarriles" editable="1"/>
    <field name="result_ordend" editable="1"/>
    <field name="result_sentidod" editable="1"/>
    <field name="result_situaciond" editable="1"/>
    <field name="result_tipo_tramd" editable="1"/>
    <field name="result_tipo_viald" editable="1"/>
    <field name="result_tipovehicd" editable="1"/>
    <field name="result_titulard" editable="1"/>
    <field name="rtign_accesod" editable="1"/>
    <field name="rtign_calzadad" editable="1"/>
    <field name="rtign_clased" editable="1"/>
    <field name="rtign_estadofisd" editable="1"/>
    <field name="rtign_firmed" editable="1"/>
    <field name="rtign_id_vial" editable="1"/>
    <field name="rtign_ncarrilesd" editable="1"/>
    <field name="rtign_ordend" editable="1"/>
    <field name="rtign_sentidod" editable="1"/>
    <field name="rtign_situaciond" editable="1"/>
    <field name="rtign_tipo_tramod" editable="1"/>
    <field name="rtign_tipo_viald" editable="1"/>
    <field name="rtign_tipovehicd" editable="1"/>
    <field name="rtign_titulard" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="fid" labelOnTop="0"/>
    <field name="jccm_Denominacion" labelOnTop="0"/>
    <field name="jccm_Destino" labelOnTop="0"/>
    <field name="jccm_Long_KM" labelOnTop="0"/>
    <field name="jccm_Longitud" labelOnTop="0"/>
    <field name="jccm_Origen" labelOnTop="0"/>
    <field name="jccm_PkFIN" labelOnTop="0"/>
    <field name="jccm_PkINI" labelOnTop="0"/>
    <field name="jccm_Provincia" labelOnTop="0"/>
    <field name="jccm_acceso" labelOnTop="0"/>
    <field name="jccm_accesod" labelOnTop="0"/>
    <field name="jccm_alta_db" labelOnTop="0"/>
    <field name="jccm_calzada" labelOnTop="0"/>
    <field name="jccm_calzadad" labelOnTop="0"/>
    <field name="jccm_clase" labelOnTop="0"/>
    <field name="jccm_clased" labelOnTop="0"/>
    <field name="jccm_codigo" labelOnTop="0"/>
    <field name="jccm_dgc_via" labelOnTop="0"/>
    <field name="jccm_estadofis" labelOnTop="0"/>
    <field name="jccm_estadofisd" labelOnTop="0"/>
    <field name="jccm_fid" labelOnTop="0"/>
    <field name="jccm_firme" labelOnTop="0"/>
    <field name="jccm_firmed" labelOnTop="0"/>
    <field name="jccm_fuente_t" labelOnTop="0"/>
    <field name="jccm_fuente_td" labelOnTop="0"/>
    <field name="jccm_fuente_v" labelOnTop="0"/>
    <field name="jccm_fuente_vd" labelOnTop="0"/>
    <field name="jccm_idMatricula" labelOnTop="0"/>
    <field name="jccm_id_tramo" labelOnTop="0"/>
    <field name="jccm_id_vial" labelOnTop="0"/>
    <field name="jccm_ncarriles" labelOnTop="0"/>
    <field name="jccm_nombre" labelOnTop="0"/>
    <field name="jccm_nombre_alt" labelOnTop="0"/>
    <field name="jccm_nombre_red" labelOnTop="0"/>
    <field name="jccm_orden" labelOnTop="0"/>
    <field name="jccm_ordend" labelOnTop="0"/>
    <field name="jccm_sentido" labelOnTop="0"/>
    <field name="jccm_sentidod" labelOnTop="0"/>
    <field name="jccm_situacion" labelOnTop="0"/>
    <field name="jccm_situaciond" labelOnTop="0"/>
    <field name="jccm_tipo_tramd" labelOnTop="0"/>
    <field name="jccm_tipo_tramo" labelOnTop="0"/>
    <field name="jccm_tipo_vial" labelOnTop="0"/>
    <field name="jccm_tipo_viald" labelOnTop="0"/>
    <field name="jccm_tipovehic" labelOnTop="0"/>
    <field name="jccm_tipovehicd" labelOnTop="0"/>
    <field name="jccm_titular" labelOnTop="0"/>
    <field name="jccm_titulard" labelOnTop="0"/>
    <field name="jccm_version" labelOnTop="0"/>
    <field name="num_mal" labelOnTop="0"/>
    <field name="num_ok" labelOnTop="0"/>
    <field name="num_punto" labelOnTop="0"/>
    <field name="num_total" labelOnTop="0"/>
    <field name="punto_x" labelOnTop="0"/>
    <field name="punto_y" labelOnTop="0"/>
    <field name="result_accesod" labelOnTop="0"/>
    <field name="result_calzadad" labelOnTop="0"/>
    <field name="result_clased" labelOnTop="0"/>
    <field name="result_estadofisd" labelOnTop="0"/>
    <field name="result_firmed" labelOnTop="0"/>
    <field name="result_id_vial" labelOnTop="0"/>
    <field name="result_ncarriles" labelOnTop="0"/>
    <field name="result_ordend" labelOnTop="0"/>
    <field name="result_sentidod" labelOnTop="0"/>
    <field name="result_situaciond" labelOnTop="0"/>
    <field name="result_tipo_tramd" labelOnTop="0"/>
    <field name="result_tipo_viald" labelOnTop="0"/>
    <field name="result_tipovehicd" labelOnTop="0"/>
    <field name="result_titulard" labelOnTop="0"/>
    <field name="rtign_accesod" labelOnTop="0"/>
    <field name="rtign_calzadad" labelOnTop="0"/>
    <field name="rtign_clased" labelOnTop="0"/>
    <field name="rtign_estadofisd" labelOnTop="0"/>
    <field name="rtign_firmed" labelOnTop="0"/>
    <field name="rtign_id_vial" labelOnTop="0"/>
    <field name="rtign_ncarrilesd" labelOnTop="0"/>
    <field name="rtign_ordend" labelOnTop="0"/>
    <field name="rtign_sentidod" labelOnTop="0"/>
    <field name="rtign_situaciond" labelOnTop="0"/>
    <field name="rtign_tipo_tramod" labelOnTop="0"/>
    <field name="rtign_tipo_viald" labelOnTop="0"/>
    <field name="rtign_tipovehicd" labelOnTop="0"/>
    <field name="rtign_titulard" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="fid" reuseLastValue="0"/>
    <field name="jccm_Denominacion" reuseLastValue="0"/>
    <field name="jccm_Destino" reuseLastValue="0"/>
    <field name="jccm_Long_KM" reuseLastValue="0"/>
    <field name="jccm_Longitud" reuseLastValue="0"/>
    <field name="jccm_Origen" reuseLastValue="0"/>
    <field name="jccm_PkFIN" reuseLastValue="0"/>
    <field name="jccm_PkINI" reuseLastValue="0"/>
    <field name="jccm_Provincia" reuseLastValue="0"/>
    <field name="jccm_acceso" reuseLastValue="0"/>
    <field name="jccm_accesod" reuseLastValue="0"/>
    <field name="jccm_alta_db" reuseLastValue="0"/>
    <field name="jccm_calzada" reuseLastValue="0"/>
    <field name="jccm_calzadad" reuseLastValue="0"/>
    <field name="jccm_clase" reuseLastValue="0"/>
    <field name="jccm_clased" reuseLastValue="0"/>
    <field name="jccm_codigo" reuseLastValue="0"/>
    <field name="jccm_dgc_via" reuseLastValue="0"/>
    <field name="jccm_estadofis" reuseLastValue="0"/>
    <field name="jccm_estadofisd" reuseLastValue="0"/>
    <field name="jccm_fid" reuseLastValue="0"/>
    <field name="jccm_firme" reuseLastValue="0"/>
    <field name="jccm_firmed" reuseLastValue="0"/>
    <field name="jccm_fuente_t" reuseLastValue="0"/>
    <field name="jccm_fuente_td" reuseLastValue="0"/>
    <field name="jccm_fuente_v" reuseLastValue="0"/>
    <field name="jccm_fuente_vd" reuseLastValue="0"/>
    <field name="jccm_idMatricula" reuseLastValue="0"/>
    <field name="jccm_id_tramo" reuseLastValue="0"/>
    <field name="jccm_id_vial" reuseLastValue="0"/>
    <field name="jccm_ncarriles" reuseLastValue="0"/>
    <field name="jccm_nombre" reuseLastValue="0"/>
    <field name="jccm_nombre_alt" reuseLastValue="0"/>
    <field name="jccm_nombre_red" reuseLastValue="0"/>
    <field name="jccm_orden" reuseLastValue="0"/>
    <field name="jccm_ordend" reuseLastValue="0"/>
    <field name="jccm_sentido" reuseLastValue="0"/>
    <field name="jccm_sentidod" reuseLastValue="0"/>
    <field name="jccm_situacion" reuseLastValue="0"/>
    <field name="jccm_situaciond" reuseLastValue="0"/>
    <field name="jccm_tipo_tramd" reuseLastValue="0"/>
    <field name="jccm_tipo_tramo" reuseLastValue="0"/>
    <field name="jccm_tipo_vial" reuseLastValue="0"/>
    <field name="jccm_tipo_viald" reuseLastValue="0"/>
    <field name="jccm_tipovehic" reuseLastValue="0"/>
    <field name="jccm_tipovehicd" reuseLastValue="0"/>
    <field name="jccm_titular" reuseLastValue="0"/>
    <field name="jccm_titulard" reuseLastValue="0"/>
    <field name="jccm_version" reuseLastValue="0"/>
    <field name="num_mal" reuseLastValue="0"/>
    <field name="num_ok" reuseLastValue="0"/>
    <field name="num_punto" reuseLastValue="0"/>
    <field name="num_total" reuseLastValue="0"/>
    <field name="punto_x" reuseLastValue="0"/>
    <field name="punto_y" reuseLastValue="0"/>
    <field name="result_accesod" reuseLastValue="0"/>
    <field name="result_calzadad" reuseLastValue="0"/>
    <field name="result_clased" reuseLastValue="0"/>
    <field name="result_estadofisd" reuseLastValue="0"/>
    <field name="result_firmed" reuseLastValue="0"/>
    <field name="result_id_vial" reuseLastValue="0"/>
    <field name="result_ncarriles" reuseLastValue="0"/>
    <field name="result_ordend" reuseLastValue="0"/>
    <field name="result_sentidod" reuseLastValue="0"/>
    <field name="result_situaciond" reuseLastValue="0"/>
    <field name="result_tipo_tramd" reuseLastValue="0"/>
    <field name="result_tipo_viald" reuseLastValue="0"/>
    <field name="result_tipovehicd" reuseLastValue="0"/>
    <field name="result_titulard" reuseLastValue="0"/>
    <field name="rtign_accesod" reuseLastValue="0"/>
    <field name="rtign_calzadad" reuseLastValue="0"/>
    <field name="rtign_clased" reuseLastValue="0"/>
    <field name="rtign_estadofisd" reuseLastValue="0"/>
    <field name="rtign_firmed" reuseLastValue="0"/>
    <field name="rtign_id_vial" reuseLastValue="0"/>
    <field name="rtign_ncarrilesd" reuseLastValue="0"/>
    <field name="rtign_ordend" reuseLastValue="0"/>
    <field name="rtign_sentidod" reuseLastValue="0"/>
    <field name="rtign_situaciond" reuseLastValue="0"/>
    <field name="rtign_tipo_tramod" reuseLastValue="0"/>
    <field name="rtign_tipo_viald" reuseLastValue="0"/>
    <field name="rtign_tipovehicd" reuseLastValue="0"/>
    <field name="rtign_titulard" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"jccm_nombre"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
