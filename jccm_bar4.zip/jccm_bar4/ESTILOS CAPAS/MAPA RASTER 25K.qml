<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="2.12.0-Lyon" minimumScale="0" maximumScale="1e+08" hasScaleBasedVisibilityFlag="0">
  <pipe>
    <rasterrenderer opacity="1" alphaBand="-1" blueBand="3" greenBand="2" type="multibandcolor" redBand="1">
      <rasterTransparency>
        <threeValuePixelList>
          <pixelListEntry red="255" blue="255" green="255" percentTransparent="100"/>
          <pixelListEntry red="240" blue="240" green="240" percentTransparent="100"/>
        </threeValuePixelList>
      </rasterTransparency>
    </rasterrenderer>
    <brightnesscontrast brightness="0" contrast="6"/>
    <huesaturation colorizeGreen="128" colorizeOn="0" colorizeRed="255" colorizeBlue="128" grayscaleMode="0" saturation="0" colorizeStrength="100"/>
    <rasterresampler maxOversampling="2" zoomedOutResampler="bilinear"/>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
