<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingHints="1" minScale="50000" simplifyLocal="1" simplifyMaxScale="1" simplifyAlgorithm="0" maxScale="-4.6566128730773926e-10" simplifyDrawingTol="1" symbologyReferenceScale="-1" hasScaleBasedVisibilityFlag="1" styleCategories="AllStyleCategories" version="3.40.15-Bratislava" autoRefreshTime="0" labelsEnabled="1" readOnly="0" autoRefreshMode="Disabled">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal startExpression="" mode="0" startField="" durationField="" endExpression="" accumulate="0" durationUnit="min" fixedDuration="0" endField="" enabled="0" limitMode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation zscale="1" type="IndividualFeatures" clamping="Terrain" binding="Centroid" extrusionEnabled="0" symbology="Line" zoffset="0" showMarkerSymbolInSurfacePlots="0" respectLayerSymbol="1" extrusion="0">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol is_animated="0" type="line" force_rhr="0" clip_to_extent="1" alpha="1" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer id="{0f71083f-ad08-43b8-a2d8-8f3f71182391}" locked="0" class="SimpleLine" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="243,166,178,255,rgb:0.95294117647058818,0.65098039215686276,0.69803921568627447,1" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.6" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol is_animated="0" type="fill" force_rhr="0" clip_to_extent="1" alpha="1" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer id="{46b56b69-e36f-4ba1-a859-a7ee0fd317c7}" locked="0" class="SimpleFill" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="243,166,178,255,rgb:0.95294117647058818,0.65098039215686276,0.69803921568627447,1" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="174,119,127,255,rgb:0.68235294117647061,0.46666666666666667,0.49803921568627452,1" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol is_animated="0" type="marker" force_rhr="0" clip_to_extent="1" alpha="1" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer id="{bc54cda7-735c-4256-9f9f-c18201c797b7}" locked="0" class="SimpleMarker" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="square" name="cap_style"/>
            <Option type="QString" value="243,166,178,255,rgb:0.95294117647058818,0.65098039215686276,0.69803921568627447,1" name="color"/>
            <Option type="QString" value="1" name="horizontal_anchor_point"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="diamond" name="name"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="174,119,127,255,rgb:0.68235294117647061,0.46666666666666667,0.49803921568627452,1" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="diameter" name="scale_method"/>
            <Option type="QString" value="3" name="size"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
            <Option type="QString" value="MM" name="size_unit"/>
            <Option type="QString" value="1" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 referencescale="-1" type="singleSymbol" symbollevels="0" enableorderby="0" forceraster="0">
    <symbols>
      <symbol is_animated="0" type="fill" force_rhr="0" clip_to_extent="1" alpha="1" name="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer id="{9e25df42-fb77-493c-b3b6-ac4b97119589}" locked="0" class="SimpleFill" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="195,12,244,26,hsv:0.79769444444444448,0.94891279468986034,0.95742732890821702,0.10000762951094835" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="195,12,244,255,hsv:0.79769444444444448,0.94891279468986034,0.95742732890821702,1" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.8" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol is_animated="0" type="fill" force_rhr="0" clip_to_extent="1" alpha="1" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer id="{fce18440-c2d0-4d74-8e26-1315c4cd7f96}" locked="0" class="SimpleFill" pass="0" enabled="1">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="0,0,255,255,rgb:0,0,1,1" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.26" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style useSubstitutions="0" fontLetterSpacing="0" fontItalic="0" fontStrikeout="0" textColor="0,0,0,255,hsv:0.99730555555555556,0.40755321583886472,0,1" capitalization="0" tabStopDistanceUnit="Point" fontWordSpacing="0" textOpacity="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" allowHtml="0" fontWeight="50" tabStopDistance="80" fontSizeUnit="Point" fieldName="ex_num" multilineHeight="1" fontFamily="Arial" forcedBold="0" textOrientation="horizontal" stretchFactor="100" blendMode="0" forcedItalic="0" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" isExpression="0" fontSize="8" multilineHeightUnit="Percentage" fontKerning="1" fontUnderline="0" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Normal" legendString="Aa">
        <families/>
        <text-buffer bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSizeUnits="MM" bufferColor="255,255,255,255,hsv:0,0,1,1" bufferOpacity="1" bufferNoFill="0" bufferJoinStyle="64" bufferBlendMode="0" bufferDraw="1" bufferSize="0.5"/>
        <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskJoinStyle="128" maskType="0" maskSize="1.5" maskEnabled="0" maskSize2="1.5" maskedSymbolLayers="" maskOpacity="1"/>
        <background shapeRotation="0" shapeRadiiUnit="MM" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeOpacity="1" shapeRadiiX="0" shapeBorderWidth="0" shapeRadiiY="0" shapeSVGFile="" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeJoinStyle="64" shapeBorderWidthUnit="MM" shapeBorderColor="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" shapeSizeType="0" shapeDraw="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetUnit="MM" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeSizeUnit="MM" shapeSizeY="0" shapeRotationType="0" shapeSizeX="0" shapeOffsetX="0">
          <symbol is_animated="0" type="marker" force_rhr="0" clip_to_extent="1" alpha="1" name="markerSymbol" frame_rate="10">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name"/>
                <Option name="properties"/>
                <Option type="QString" value="collection" name="type"/>
              </Option>
            </data_defined_properties>
            <layer id="" locked="0" class="SimpleMarker" pass="0" enabled="1">
              <Option type="Map">
                <Option type="QString" value="0" name="angle"/>
                <Option type="QString" value="square" name="cap_style"/>
                <Option type="QString" value="164,113,88,255,rgb:0.64313725490196083,0.44313725490196076,0.34509803921568627,1" name="color"/>
                <Option type="QString" value="1" name="horizontal_anchor_point"/>
                <Option type="QString" value="bevel" name="joinstyle"/>
                <Option type="QString" value="circle" name="name"/>
                <Option type="QString" value="0,0" name="offset"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" name="outline_color"/>
                <Option type="QString" value="solid" name="outline_style"/>
                <Option type="QString" value="0" name="outline_width"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                <Option type="QString" value="MM" name="outline_width_unit"/>
                <Option type="QString" value="diameter" name="scale_method"/>
                <Option type="QString" value="2" name="size"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                <Option type="QString" value="MM" name="size_unit"/>
                <Option type="QString" value="1" name="vertical_anchor_point"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name"/>
                  <Option name="properties"/>
                  <Option type="QString" value="collection" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol is_animated="0" type="fill" force_rhr="0" clip_to_extent="1" alpha="1" name="fillSymbol" frame_rate="10">
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name"/>
                <Option name="properties"/>
                <Option type="QString" value="collection" name="type"/>
              </Option>
            </data_defined_properties>
            <layer id="" locked="0" class="SimpleFill" pass="0" enabled="1">
              <Option type="Map">
                <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                <Option type="QString" value="255,255,255,255,rgb:1,1,1,1" name="color"/>
                <Option type="QString" value="bevel" name="joinstyle"/>
                <Option type="QString" value="0,0" name="offset"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" name="outline_color"/>
                <Option type="QString" value="no" name="outline_style"/>
                <Option type="QString" value="0" name="outline_width"/>
                <Option type="QString" value="MM" name="outline_width_unit"/>
                <Option type="QString" value="solid" name="style"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name"/>
                  <Option name="properties"/>
                  <Option type="QString" value="collection" name="type"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowOpacity="0" shadowOffsetDist="1" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="0" shadowOffsetUnit="MM" shadowRadiusAlphaOnly="0" shadowBlendMode="6" shadowDraw="0" shadowUnder="0" shadowOffsetAngle="135" shadowScale="100"/>
        <dd_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format useMaxLineLengthForAutoWrap="1" leftDirectionSymbol="&lt;" rightDirectionSymbol=">" formatNumbers="0" wrapChar="" autoWrapLength="0" multilineAlign="0" addDirectionSymbol="0" plussign="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" decimals="3"/>
      <placement layerType="PolygonGeometry" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" fitInPolygonOnly="0" allowDegraded="0" placement="1" repeatDistanceUnits="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" distUnits="MM" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" rotationUnit="AngleDegrees" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" polygonPlacementFlags="2" rotationAngle="0" maxCurvedCharAngleIn="20" yOffset="2" centroidInside="0" offsetUnits="Pixel" xOffset="0" overrunDistanceUnit="MM" lineAnchorClipping="0" centroidWhole="0" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-20" prioritization="PreferCloser" geometryGeneratorType="PointGeometry" dist="0" preserveRotation="1" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" quadOffset="4" maximumDistance="0" lineAnchorTextPoint="CenterOfText" geometryGenerator="" priority="10" overlapHandling="AllowOverlapIfRequired" maximumDistanceUnit="MM" offsetType="0" repeatDistance="0"/>
      <rendering scaleMin="1" limitNumLabels="0" obstacleFactor="1" fontMinPixelSize="3" labelPerPart="0" zIndex="0" obstacleType="0" unplacedVisibility="0" drawLabels="1" obstacle="0" mergeLines="0" scaleMax="10000000" minFeatureSize="0" scaleVisibility="0" fontMaxPixelSize="10000" upsidedownLabels="0" fontLimitPixelSize="0" maxNumLabels="2000"/>
      <dd_properties>
        <Option type="Map">
          <Option type="QString" value="" name="name"/>
          <Option name="properties"/>
          <Option type="QString" value="collection" name="type"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
          <Option type="int" value="0" name="blendMode"/>
          <Option type="Map" name="ddProperties">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
          <Option type="bool" value="false" name="drawToAllParts"/>
          <Option type="QString" value="0" name="enabled"/>
          <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
          <Option type="QString" value="&lt;symbol is_animated=&quot;0&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; name=&quot;symbol&quot; frame_rate=&quot;10&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{4a37b7f3-1507-404a-adce-85022b7e6c9f}&quot; locked=&quot;0&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255,rgb:0.23529411764705882,0.23529411764705882,0.23529411764705882,1&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
          <Option type="double" value="0" name="minLength"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
          <Option type="QString" value="MM" name="minLengthUnit"/>
          <Option type="double" value="0" name="offsetFromAnchor"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
          <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
          <Option type="double" value="0" name="offsetFromLabel"/>
          <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
          <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option type="QString" value="copy" name="QFieldSync/action"/>
      <Option type="QString" value="{}" name="QFieldSync/attachment_naming"/>
      <Option type="invalid" name="QFieldSync/attribute_editing_locked_expression"/>
      <Option type="QString" value="offline" name="QFieldSync/cloud_action"/>
      <Option type="invalid" name="QFieldSync/feature_addition_locked_expression"/>
      <Option type="invalid" name="QFieldSync/feature_deletion_locked_expression"/>
      <Option type="invalid" name="QFieldSync/geometry_editing_locked_expression"/>
      <Option type="QString" value="{}" name="QFieldSync/photo_naming"/>
      <Option type="QString" value="{}" name="QFieldSync/relationship_maximum_visible"/>
      <Option type="int" value="30" name="QFieldSync/tracking_distance_requirement_minimum_meters"/>
      <Option type="int" value="1" name="QFieldSync/tracking_erroneous_distance_safeguard_maximum_meters"/>
      <Option type="int" value="0" name="QFieldSync/tracking_measurement_type"/>
      <Option type="int" value="30" name="QFieldSync/tracking_time_requirement_interval_seconds"/>
      <Option type="int" value="0" name="QFieldSync/value_map_button_interface_threshold"/>
      <Option type="List" name="dualview/previewExpressions">
        <Option type="QString" value="&quot;titularida&quot;"/>
      </Option>
      <Option type="QString" value="0" name="embeddedWidgets/count"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>0.75</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Pie" attributeLegend="1">
    <DiagramCategory minScaleDenominator="-4.65661e-10" diagramOrientation="Up" maxScaleDenominator="1e+08" lineSizeScale="3x:0,0,0,0,0,0" spacingUnitScale="3x:0,0,0,0,0,0" stackedDiagramSpacing="0" barWidth="5" penWidth="0" stackedDiagramSpacingUnit="MM" backgroundColor="#ffffff" opacity="1" enabled="0" stackedDiagramSpacingUnitScale="3x:0,0,0,0,0,0" labelPlacementMethod="XHeight" stackedDiagramMode="Horizontal" penColor="#000000" height="15" minimumSize="0" penAlpha="255" scaleDependency="Area" backgroundAlpha="255" showAxis="0" spacing="0" spacingUnit="MM" width="15" scaleBasedVisibility="0" sizeType="MM" direction="1" sizeScale="3x:0,0,0,0,0,0" rotationOffset="270" lineSizeType="MM">
      <fontProperties style="" italic="0" description="MS Shell Dlg 2,7.8,-1,5,50,0,0,0,0,0" underline="0" strikethrough="0" bold="0"/>
      <attribute color="#000000" label="" colorOpacity="1" field=""/>
      <axisSymbol>
        <symbol is_animated="0" type="line" force_rhr="0" clip_to_extent="1" alpha="1" name="" frame_rate="10">
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
          <layer id="{359575e9-91c1-4f26-baff-c1b1c267c315}" locked="0" class="SimpleLine" pass="0" enabled="1">
            <Option type="Map">
              <Option type="QString" value="0" name="align_dash_pattern"/>
              <Option type="QString" value="square" name="capstyle"/>
              <Option type="QString" value="5;2" name="customdash"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
              <Option type="QString" value="MM" name="customdash_unit"/>
              <Option type="QString" value="0" name="dash_pattern_offset"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
              <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
              <Option type="QString" value="0" name="draw_inside_polygon"/>
              <Option type="QString" value="bevel" name="joinstyle"/>
              <Option type="QString" value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" name="line_color"/>
              <Option type="QString" value="solid" name="line_style"/>
              <Option type="QString" value="0.26" name="line_width"/>
              <Option type="QString" value="MM" name="line_width_unit"/>
              <Option type="QString" value="0" name="offset"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
              <Option type="QString" value="MM" name="offset_unit"/>
              <Option type="QString" value="0" name="ring_filter"/>
              <Option type="QString" value="0" name="trim_distance_end"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
              <Option type="QString" value="MM" name="trim_distance_end_unit"/>
              <Option type="QString" value="0" name="trim_distance_start"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
              <Option type="QString" value="MM" name="trim_distance_start_unit"/>
              <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
              <Option type="QString" value="0" name="use_custom_dash"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name"/>
                <Option name="properties"/>
                <Option type="QString" value="collection" name="type"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings dist="0" showAll="1" linePlacementFlags="2" obstacle="0" priority="0" zIndex="0" placement="0">
    <properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option type="Map" name="QgsGeometryGapCheck">
        <Option type="double" value="0" name="allowedGapsBuffer"/>
        <Option type="bool" value="false" name="allowedGapsEnabled"/>
        <Option type="QString" value="" name="allowedGapsLayer"/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="fid">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ex_num">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ex_tmunic">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="rc14">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ex_tipoinv">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ex_textinf">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ex_supinf">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="expte1">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="nom_proyec">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ex_supexpr">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cat_nmspc">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="area">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="titularida">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="funcionali">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="provincia">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ctra">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="pkini">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="pkfin">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ctra_ant">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="pkini_ant">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="pkfin_ant">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="nom_tramo">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="layer">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="pcat1">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="pcat2">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ejercicio">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="num_exp">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="control">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="via">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="numero">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="numerodup">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="numsymbol">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="fechaalta">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="fechabaja">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="mapa">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="delegacio">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="municipio">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="masa">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="hoja">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tipo">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="parcela">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ex_geom">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="expte2">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="expte3">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="coorx">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="coory">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ex_registro">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ex_solicitante">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ex_interesado">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ex_fecha">
      <editWidget type="DateTime">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" name="" field="fid"/>
    <alias index="1" name="" field="ex_num"/>
    <alias index="2" name="" field="ex_tmunic"/>
    <alias index="3" name="" field="rc14"/>
    <alias index="4" name="" field="ex_tipoinv"/>
    <alias index="5" name="" field="ex_textinf"/>
    <alias index="6" name="" field="ex_supinf"/>
    <alias index="7" name="" field="expte1"/>
    <alias index="8" name="" field="nom_proyec"/>
    <alias index="9" name="" field="ex_supexpr"/>
    <alias index="10" name="" field="cat_nmspc"/>
    <alias index="11" name="" field="area"/>
    <alias index="12" name="" field="titularida"/>
    <alias index="13" name="" field="funcionali"/>
    <alias index="14" name="" field="provincia"/>
    <alias index="15" name="" field="ctra"/>
    <alias index="16" name="" field="pkini"/>
    <alias index="17" name="" field="pkfin"/>
    <alias index="18" name="" field="ctra_ant"/>
    <alias index="19" name="" field="pkini_ant"/>
    <alias index="20" name="" field="pkfin_ant"/>
    <alias index="21" name="" field="nom_tramo"/>
    <alias index="22" name="" field="layer"/>
    <alias index="23" name="" field="pcat1"/>
    <alias index="24" name="" field="pcat2"/>
    <alias index="25" name="" field="ejercicio"/>
    <alias index="26" name="" field="num_exp"/>
    <alias index="27" name="" field="control"/>
    <alias index="28" name="" field="via"/>
    <alias index="29" name="" field="numero"/>
    <alias index="30" name="" field="numerodup"/>
    <alias index="31" name="" field="numsymbol"/>
    <alias index="32" name="" field="fechaalta"/>
    <alias index="33" name="" field="fechabaja"/>
    <alias index="34" name="" field="mapa"/>
    <alias index="35" name="" field="delegacio"/>
    <alias index="36" name="" field="municipio"/>
    <alias index="37" name="" field="masa"/>
    <alias index="38" name="" field="hoja"/>
    <alias index="39" name="" field="tipo"/>
    <alias index="40" name="" field="parcela"/>
    <alias index="41" name="" field="ex_geom"/>
    <alias index="42" name="" field="expte2"/>
    <alias index="43" name="" field="expte3"/>
    <alias index="44" name="" field="coorx"/>
    <alias index="45" name="" field="coory"/>
    <alias index="46" name="" field="ex_registro"/>
    <alias index="47" name="" field="ex_solicitante"/>
    <alias index="48" name="" field="ex_interesado"/>
    <alias index="49" name="" field="ex_fecha"/>
  </aliases>
  <splitPolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="ex_num"/>
    <policy policy="Duplicate" field="ex_tmunic"/>
    <policy policy="Duplicate" field="rc14"/>
    <policy policy="Duplicate" field="ex_tipoinv"/>
    <policy policy="Duplicate" field="ex_textinf"/>
    <policy policy="Duplicate" field="ex_supinf"/>
    <policy policy="Duplicate" field="expte1"/>
    <policy policy="Duplicate" field="nom_proyec"/>
    <policy policy="Duplicate" field="ex_supexpr"/>
    <policy policy="Duplicate" field="cat_nmspc"/>
    <policy policy="Duplicate" field="area"/>
    <policy policy="Duplicate" field="titularida"/>
    <policy policy="Duplicate" field="funcionali"/>
    <policy policy="Duplicate" field="provincia"/>
    <policy policy="Duplicate" field="ctra"/>
    <policy policy="Duplicate" field="pkini"/>
    <policy policy="Duplicate" field="pkfin"/>
    <policy policy="Duplicate" field="ctra_ant"/>
    <policy policy="Duplicate" field="pkini_ant"/>
    <policy policy="Duplicate" field="pkfin_ant"/>
    <policy policy="Duplicate" field="nom_tramo"/>
    <policy policy="Duplicate" field="layer"/>
    <policy policy="Duplicate" field="pcat1"/>
    <policy policy="Duplicate" field="pcat2"/>
    <policy policy="Duplicate" field="ejercicio"/>
    <policy policy="Duplicate" field="num_exp"/>
    <policy policy="Duplicate" field="control"/>
    <policy policy="Duplicate" field="via"/>
    <policy policy="Duplicate" field="numero"/>
    <policy policy="Duplicate" field="numerodup"/>
    <policy policy="Duplicate" field="numsymbol"/>
    <policy policy="Duplicate" field="fechaalta"/>
    <policy policy="Duplicate" field="fechabaja"/>
    <policy policy="Duplicate" field="mapa"/>
    <policy policy="Duplicate" field="delegacio"/>
    <policy policy="Duplicate" field="municipio"/>
    <policy policy="Duplicate" field="masa"/>
    <policy policy="Duplicate" field="hoja"/>
    <policy policy="Duplicate" field="tipo"/>
    <policy policy="Duplicate" field="parcela"/>
    <policy policy="Duplicate" field="ex_geom"/>
    <policy policy="Duplicate" field="expte2"/>
    <policy policy="Duplicate" field="expte3"/>
    <policy policy="Duplicate" field="coorx"/>
    <policy policy="Duplicate" field="coory"/>
    <policy policy="Duplicate" field="ex_registro"/>
    <policy policy="Duplicate" field="ex_solicitante"/>
    <policy policy="Duplicate" field="ex_interesado"/>
    <policy policy="Duplicate" field="ex_fecha"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="ex_num"/>
    <policy policy="Duplicate" field="ex_tmunic"/>
    <policy policy="Duplicate" field="rc14"/>
    <policy policy="Duplicate" field="ex_tipoinv"/>
    <policy policy="Duplicate" field="ex_textinf"/>
    <policy policy="Duplicate" field="ex_supinf"/>
    <policy policy="Duplicate" field="expte1"/>
    <policy policy="Duplicate" field="nom_proyec"/>
    <policy policy="Duplicate" field="ex_supexpr"/>
    <policy policy="Duplicate" field="cat_nmspc"/>
    <policy policy="Duplicate" field="area"/>
    <policy policy="Duplicate" field="titularida"/>
    <policy policy="Duplicate" field="funcionali"/>
    <policy policy="Duplicate" field="provincia"/>
    <policy policy="Duplicate" field="ctra"/>
    <policy policy="Duplicate" field="pkini"/>
    <policy policy="Duplicate" field="pkfin"/>
    <policy policy="Duplicate" field="ctra_ant"/>
    <policy policy="Duplicate" field="pkini_ant"/>
    <policy policy="Duplicate" field="pkfin_ant"/>
    <policy policy="Duplicate" field="nom_tramo"/>
    <policy policy="Duplicate" field="layer"/>
    <policy policy="Duplicate" field="pcat1"/>
    <policy policy="Duplicate" field="pcat2"/>
    <policy policy="Duplicate" field="ejercicio"/>
    <policy policy="Duplicate" field="num_exp"/>
    <policy policy="Duplicate" field="control"/>
    <policy policy="Duplicate" field="via"/>
    <policy policy="Duplicate" field="numero"/>
    <policy policy="Duplicate" field="numerodup"/>
    <policy policy="Duplicate" field="numsymbol"/>
    <policy policy="Duplicate" field="fechaalta"/>
    <policy policy="Duplicate" field="fechabaja"/>
    <policy policy="Duplicate" field="mapa"/>
    <policy policy="Duplicate" field="delegacio"/>
    <policy policy="Duplicate" field="municipio"/>
    <policy policy="Duplicate" field="masa"/>
    <policy policy="Duplicate" field="hoja"/>
    <policy policy="Duplicate" field="tipo"/>
    <policy policy="Duplicate" field="parcela"/>
    <policy policy="Duplicate" field="ex_geom"/>
    <policy policy="Duplicate" field="expte2"/>
    <policy policy="Duplicate" field="expte3"/>
    <policy policy="Duplicate" field="coorx"/>
    <policy policy="Duplicate" field="coory"/>
    <policy policy="Duplicate" field="ex_registro"/>
    <policy policy="Duplicate" field="ex_solicitante"/>
    <policy policy="Duplicate" field="ex_interesado"/>
    <policy policy="Duplicate" field="ex_fecha"/>
  </duplicatePolicies>
  <defaults>
    <default applyOnUpdate="0" expression="" field="fid"/>
    <default applyOnUpdate="0" expression="" field="ex_num"/>
    <default applyOnUpdate="0" expression="" field="ex_tmunic"/>
    <default applyOnUpdate="0" expression="" field="rc14"/>
    <default applyOnUpdate="0" expression="" field="ex_tipoinv"/>
    <default applyOnUpdate="0" expression="" field="ex_textinf"/>
    <default applyOnUpdate="0" expression="" field="ex_supinf"/>
    <default applyOnUpdate="0" expression="" field="expte1"/>
    <default applyOnUpdate="0" expression="" field="nom_proyec"/>
    <default applyOnUpdate="0" expression="" field="ex_supexpr"/>
    <default applyOnUpdate="0" expression="" field="cat_nmspc"/>
    <default applyOnUpdate="0" expression="" field="area"/>
    <default applyOnUpdate="0" expression="" field="titularida"/>
    <default applyOnUpdate="0" expression="" field="funcionali"/>
    <default applyOnUpdate="0" expression="" field="provincia"/>
    <default applyOnUpdate="0" expression="" field="ctra"/>
    <default applyOnUpdate="0" expression="" field="pkini"/>
    <default applyOnUpdate="0" expression="" field="pkfin"/>
    <default applyOnUpdate="0" expression="" field="ctra_ant"/>
    <default applyOnUpdate="0" expression="" field="pkini_ant"/>
    <default applyOnUpdate="0" expression="" field="pkfin_ant"/>
    <default applyOnUpdate="0" expression="" field="nom_tramo"/>
    <default applyOnUpdate="0" expression="" field="layer"/>
    <default applyOnUpdate="0" expression="" field="pcat1"/>
    <default applyOnUpdate="0" expression="" field="pcat2"/>
    <default applyOnUpdate="0" expression="" field="ejercicio"/>
    <default applyOnUpdate="0" expression="" field="num_exp"/>
    <default applyOnUpdate="0" expression="" field="control"/>
    <default applyOnUpdate="0" expression="" field="via"/>
    <default applyOnUpdate="0" expression="" field="numero"/>
    <default applyOnUpdate="0" expression="" field="numerodup"/>
    <default applyOnUpdate="0" expression="" field="numsymbol"/>
    <default applyOnUpdate="0" expression="" field="fechaalta"/>
    <default applyOnUpdate="0" expression="" field="fechabaja"/>
    <default applyOnUpdate="0" expression="" field="mapa"/>
    <default applyOnUpdate="0" expression="" field="delegacio"/>
    <default applyOnUpdate="0" expression="" field="municipio"/>
    <default applyOnUpdate="0" expression="" field="masa"/>
    <default applyOnUpdate="0" expression="" field="hoja"/>
    <default applyOnUpdate="0" expression="" field="tipo"/>
    <default applyOnUpdate="0" expression="" field="parcela"/>
    <default applyOnUpdate="0" expression="" field="ex_geom"/>
    <default applyOnUpdate="0" expression="" field="expte2"/>
    <default applyOnUpdate="0" expression="" field="expte3"/>
    <default applyOnUpdate="0" expression="" field="coorx"/>
    <default applyOnUpdate="0" expression="" field="coory"/>
    <default applyOnUpdate="0" expression="" field="ex_registro"/>
    <default applyOnUpdate="0" expression="" field="ex_solicitante"/>
    <default applyOnUpdate="0" expression="" field="ex_interesado"/>
    <default applyOnUpdate="0" expression="" field="ex_fecha"/>
  </defaults>
  <constraints>
    <constraint constraints="3" notnull_strength="1" field="fid" unique_strength="1" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="ex_num" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="ex_tmunic" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="rc14" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="ex_tipoinv" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="ex_textinf" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="ex_supinf" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="expte1" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="nom_proyec" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="ex_supexpr" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="cat_nmspc" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="area" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="titularida" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="funcionali" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="provincia" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="ctra" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="pkini" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="pkfin" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="ctra_ant" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="pkini_ant" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="pkfin_ant" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="nom_tramo" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="layer" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="pcat1" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="pcat2" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="ejercicio" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="num_exp" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="control" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="via" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="numero" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="numerodup" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="numsymbol" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="fechaalta" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="fechabaja" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="mapa" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="delegacio" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="municipio" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="masa" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="hoja" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="tipo" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="parcela" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="ex_geom" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="expte2" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="expte3" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="coorx" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="coory" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="ex_registro" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="ex_solicitante" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="ex_interesado" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" notnull_strength="0" field="ex_fecha" unique_strength="0" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="fid"/>
    <constraint exp="" desc="" field="ex_num"/>
    <constraint exp="" desc="" field="ex_tmunic"/>
    <constraint exp="" desc="" field="rc14"/>
    <constraint exp="" desc="" field="ex_tipoinv"/>
    <constraint exp="" desc="" field="ex_textinf"/>
    <constraint exp="" desc="" field="ex_supinf"/>
    <constraint exp="" desc="" field="expte1"/>
    <constraint exp="" desc="" field="nom_proyec"/>
    <constraint exp="" desc="" field="ex_supexpr"/>
    <constraint exp="" desc="" field="cat_nmspc"/>
    <constraint exp="" desc="" field="area"/>
    <constraint exp="" desc="" field="titularida"/>
    <constraint exp="" desc="" field="funcionali"/>
    <constraint exp="" desc="" field="provincia"/>
    <constraint exp="" desc="" field="ctra"/>
    <constraint exp="" desc="" field="pkini"/>
    <constraint exp="" desc="" field="pkfin"/>
    <constraint exp="" desc="" field="ctra_ant"/>
    <constraint exp="" desc="" field="pkini_ant"/>
    <constraint exp="" desc="" field="pkfin_ant"/>
    <constraint exp="" desc="" field="nom_tramo"/>
    <constraint exp="" desc="" field="layer"/>
    <constraint exp="" desc="" field="pcat1"/>
    <constraint exp="" desc="" field="pcat2"/>
    <constraint exp="" desc="" field="ejercicio"/>
    <constraint exp="" desc="" field="num_exp"/>
    <constraint exp="" desc="" field="control"/>
    <constraint exp="" desc="" field="via"/>
    <constraint exp="" desc="" field="numero"/>
    <constraint exp="" desc="" field="numerodup"/>
    <constraint exp="" desc="" field="numsymbol"/>
    <constraint exp="" desc="" field="fechaalta"/>
    <constraint exp="" desc="" field="fechabaja"/>
    <constraint exp="" desc="" field="mapa"/>
    <constraint exp="" desc="" field="delegacio"/>
    <constraint exp="" desc="" field="municipio"/>
    <constraint exp="" desc="" field="masa"/>
    <constraint exp="" desc="" field="hoja"/>
    <constraint exp="" desc="" field="tipo"/>
    <constraint exp="" desc="" field="parcela"/>
    <constraint exp="" desc="" field="ex_geom"/>
    <constraint exp="" desc="" field="expte2"/>
    <constraint exp="" desc="" field="expte3"/>
    <constraint exp="" desc="" field="coorx"/>
    <constraint exp="" desc="" field="coory"/>
    <constraint exp="" desc="" field="ex_registro"/>
    <constraint exp="" desc="" field="ex_solicitante"/>
    <constraint exp="" desc="" field="ex_interesado"/>
    <constraint exp="" desc="" field="ex_fecha"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig sortExpression="&quot;ex_num&quot;" sortOrder="1" actionWidgetStyle="dropDown">
    <columns>
      <column hidden="1" type="actions" width="-1"/>
      <column hidden="0" type="field" width="-1" name="fid"/>
      <column hidden="0" type="field" width="-1" name="ex_num"/>
      <column hidden="0" type="field" width="229" name="ex_tmunic"/>
      <column hidden="0" type="field" width="170" name="ex_textinf"/>
      <column hidden="0" type="field" width="-1" name="rc14"/>
      <column hidden="0" type="field" width="-1" name="nom_proyec"/>
      <column hidden="0" type="field" width="-1" name="ex_supinf"/>
      <column hidden="0" type="field" width="-1" name="ex_supexpr"/>
      <column hidden="0" type="field" width="-1" name="area"/>
      <column hidden="0" type="field" width="314" name="ex_tipoinv"/>
      <column hidden="0" type="field" width="-1" name="expte1"/>
      <column hidden="0" type="field" width="-1" name="titularida"/>
      <column hidden="0" type="field" width="-1" name="funcionali"/>
      <column hidden="0" type="field" width="-1" name="provincia"/>
      <column hidden="0" type="field" width="-1" name="ctra"/>
      <column hidden="0" type="field" width="-1" name="pkini"/>
      <column hidden="0" type="field" width="-1" name="pkfin"/>
      <column hidden="0" type="field" width="-1" name="ctra_ant"/>
      <column hidden="0" type="field" width="-1" name="pkini_ant"/>
      <column hidden="0" type="field" width="-1" name="pkfin_ant"/>
      <column hidden="0" type="field" width="-1" name="nom_tramo"/>
      <column hidden="0" type="field" width="-1" name="layer"/>
      <column hidden="0" type="field" width="-1" name="pcat1"/>
      <column hidden="0" type="field" width="-1" name="pcat2"/>
      <column hidden="0" type="field" width="-1" name="ejercicio"/>
      <column hidden="0" type="field" width="-1" name="num_exp"/>
      <column hidden="0" type="field" width="-1" name="control"/>
      <column hidden="0" type="field" width="-1" name="via"/>
      <column hidden="0" type="field" width="-1" name="numero"/>
      <column hidden="0" type="field" width="-1" name="numerodup"/>
      <column hidden="0" type="field" width="-1" name="numsymbol"/>
      <column hidden="0" type="field" width="-1" name="fechaalta"/>
      <column hidden="0" type="field" width="-1" name="fechabaja"/>
      <column hidden="0" type="field" width="-1" name="mapa"/>
      <column hidden="0" type="field" width="-1" name="delegacio"/>
      <column hidden="0" type="field" width="-1" name="municipio"/>
      <column hidden="0" type="field" width="-1" name="masa"/>
      <column hidden="0" type="field" width="-1" name="hoja"/>
      <column hidden="0" type="field" width="-1" name="tipo"/>
      <column hidden="0" type="field" width="-1" name="parcela"/>
      <column hidden="0" type="field" width="-1" name="ex_geom"/>
      <column hidden="0" type="field" width="-1" name="expte2"/>
      <column hidden="0" type="field" width="-1" name="expte3"/>
      <column hidden="0" type="field" width="-1" name="coorx"/>
      <column hidden="0" type="field" width="-1" name="coory"/>
      <column hidden="0" type="field" width="-1" name="cat_nmspc"/>
      <column hidden="0" type="field" width="-1" name="ex_registro"/>
      <column hidden="0" type="field" width="-1" name="ex_solicitante"/>
      <column hidden="0" type="field" width="-1" name="ex_interesado"/>
      <column hidden="0" type="field" width="-1" name="ex_fecha"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from PyQt4.QtGui import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>1</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="AREA"/>
    <field editable="1" name="CAT_NMSPC"/>
    <field editable="1" name="CONTROL"/>
    <field editable="1" name="COORX"/>
    <field editable="1" name="COORY"/>
    <field editable="1" name="CTRA"/>
    <field editable="1" name="CTRA_ANT"/>
    <field editable="1" name="DELEGACIO"/>
    <field editable="1" name="EJERCICIO"/>
    <field editable="1" name="EXPTE1"/>
    <field editable="1" name="EXPTE2"/>
    <field editable="1" name="EXPTE3"/>
    <field editable="1" name="EX_GEOM"/>
    <field editable="1" name="EX_NUM"/>
    <field editable="1" name="EX_SUPEXPR"/>
    <field editable="1" name="EX_SUPINF"/>
    <field editable="1" name="EX_TEXTINF"/>
    <field editable="1" name="EX_TIPOINV"/>
    <field editable="1" name="EX_TMUNIC"/>
    <field editable="1" name="FECHAALTA"/>
    <field editable="1" name="FECHABAJA"/>
    <field editable="1" name="FUNCIONALI"/>
    <field editable="1" name="HOJA"/>
    <field editable="1" name="Layer"/>
    <field editable="1" name="MAPA"/>
    <field editable="1" name="MASA"/>
    <field editable="1" name="MUNICIPIO"/>
    <field editable="1" name="NOM_PROYEC"/>
    <field editable="1" name="NOM_TRAMO"/>
    <field editable="1" name="NUMERO"/>
    <field editable="1" name="NUMERODUP"/>
    <field editable="1" name="NUMSYMBOL"/>
    <field editable="1" name="NUM_EXP"/>
    <field editable="1" name="PARCELA"/>
    <field editable="1" name="PCAT1"/>
    <field editable="1" name="PCAT2"/>
    <field editable="1" name="PKFIN"/>
    <field editable="1" name="PKFIN_ANT"/>
    <field editable="1" name="PKINI"/>
    <field editable="1" name="PKINI_ANT"/>
    <field editable="1" name="PROVINCIA"/>
    <field editable="1" name="RC14"/>
    <field editable="1" name="TIPO"/>
    <field editable="1" name="TITULARIDA"/>
    <field editable="1" name="VIA"/>
    <field editable="1" name="area"/>
    <field editable="1" name="cat_nmspc"/>
    <field editable="1" name="control"/>
    <field editable="1" name="coorx"/>
    <field editable="1" name="coory"/>
    <field editable="1" name="ctra"/>
    <field editable="1" name="ctra_ant"/>
    <field editable="1" name="delegacio"/>
    <field editable="1" name="ejercicio"/>
    <field editable="1" name="ex_destinatario"/>
    <field editable="1" name="ex_fecha"/>
    <field editable="1" name="ex_fechaexpte"/>
    <field editable="1" name="ex_geom"/>
    <field editable="1" name="ex_interesado"/>
    <field editable="1" name="ex_num"/>
    <field editable="1" name="ex_registro"/>
    <field editable="1" name="ex_solicitante"/>
    <field editable="1" name="ex_supexpr"/>
    <field editable="1" name="ex_supinf"/>
    <field editable="1" name="ex_textinf"/>
    <field editable="1" name="ex_tipoinv"/>
    <field editable="1" name="ex_tmunic"/>
    <field editable="1" name="expte1"/>
    <field editable="1" name="expte2"/>
    <field editable="1" name="expte3"/>
    <field editable="1" name="fechaalta"/>
    <field editable="1" name="fechabaja"/>
    <field editable="1" name="fid"/>
    <field editable="1" name="funcionali"/>
    <field editable="1" name="hoja"/>
    <field editable="1" name="layer"/>
    <field editable="1" name="mapa"/>
    <field editable="1" name="masa"/>
    <field editable="1" name="municipio"/>
    <field editable="1" name="nom_proyec"/>
    <field editable="1" name="nom_tramo"/>
    <field editable="1" name="num_exp"/>
    <field editable="1" name="numero"/>
    <field editable="1" name="numerodup"/>
    <field editable="1" name="numsymbol"/>
    <field editable="1" name="parcela"/>
    <field editable="1" name="pcat1"/>
    <field editable="1" name="pcat2"/>
    <field editable="1" name="pkfin"/>
    <field editable="1" name="pkfin_ant"/>
    <field editable="1" name="pkini"/>
    <field editable="1" name="pkini_ant"/>
    <field editable="1" name="provincia"/>
    <field editable="1" name="rc14"/>
    <field editable="1" name="tipo"/>
    <field editable="1" name="titularida"/>
    <field editable="1" name="via"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="AREA"/>
    <field labelOnTop="0" name="CAT_NMSPC"/>
    <field labelOnTop="0" name="CONTROL"/>
    <field labelOnTop="0" name="COORX"/>
    <field labelOnTop="0" name="COORY"/>
    <field labelOnTop="0" name="CTRA"/>
    <field labelOnTop="0" name="CTRA_ANT"/>
    <field labelOnTop="0" name="DELEGACIO"/>
    <field labelOnTop="0" name="EJERCICIO"/>
    <field labelOnTop="0" name="EXPTE1"/>
    <field labelOnTop="0" name="EXPTE2"/>
    <field labelOnTop="0" name="EXPTE3"/>
    <field labelOnTop="0" name="EX_GEOM"/>
    <field labelOnTop="0" name="EX_NUM"/>
    <field labelOnTop="0" name="EX_SUPEXPR"/>
    <field labelOnTop="0" name="EX_SUPINF"/>
    <field labelOnTop="0" name="EX_TEXTINF"/>
    <field labelOnTop="0" name="EX_TIPOINV"/>
    <field labelOnTop="0" name="EX_TMUNIC"/>
    <field labelOnTop="0" name="FECHAALTA"/>
    <field labelOnTop="0" name="FECHABAJA"/>
    <field labelOnTop="0" name="FUNCIONALI"/>
    <field labelOnTop="0" name="HOJA"/>
    <field labelOnTop="0" name="Layer"/>
    <field labelOnTop="0" name="MAPA"/>
    <field labelOnTop="0" name="MASA"/>
    <field labelOnTop="0" name="MUNICIPIO"/>
    <field labelOnTop="0" name="NOM_PROYEC"/>
    <field labelOnTop="0" name="NOM_TRAMO"/>
    <field labelOnTop="0" name="NUMERO"/>
    <field labelOnTop="0" name="NUMERODUP"/>
    <field labelOnTop="0" name="NUMSYMBOL"/>
    <field labelOnTop="0" name="NUM_EXP"/>
    <field labelOnTop="0" name="PARCELA"/>
    <field labelOnTop="0" name="PCAT1"/>
    <field labelOnTop="0" name="PCAT2"/>
    <field labelOnTop="0" name="PKFIN"/>
    <field labelOnTop="0" name="PKFIN_ANT"/>
    <field labelOnTop="0" name="PKINI"/>
    <field labelOnTop="0" name="PKINI_ANT"/>
    <field labelOnTop="0" name="PROVINCIA"/>
    <field labelOnTop="0" name="RC14"/>
    <field labelOnTop="0" name="TIPO"/>
    <field labelOnTop="0" name="TITULARIDA"/>
    <field labelOnTop="0" name="VIA"/>
    <field labelOnTop="0" name="area"/>
    <field labelOnTop="0" name="cat_nmspc"/>
    <field labelOnTop="0" name="control"/>
    <field labelOnTop="0" name="coorx"/>
    <field labelOnTop="0" name="coory"/>
    <field labelOnTop="0" name="ctra"/>
    <field labelOnTop="0" name="ctra_ant"/>
    <field labelOnTop="0" name="delegacio"/>
    <field labelOnTop="0" name="ejercicio"/>
    <field labelOnTop="0" name="ex_destinatario"/>
    <field labelOnTop="0" name="ex_fecha"/>
    <field labelOnTop="0" name="ex_fechaexpte"/>
    <field labelOnTop="0" name="ex_geom"/>
    <field labelOnTop="0" name="ex_interesado"/>
    <field labelOnTop="0" name="ex_num"/>
    <field labelOnTop="0" name="ex_registro"/>
    <field labelOnTop="0" name="ex_solicitante"/>
    <field labelOnTop="0" name="ex_supexpr"/>
    <field labelOnTop="0" name="ex_supinf"/>
    <field labelOnTop="0" name="ex_textinf"/>
    <field labelOnTop="0" name="ex_tipoinv"/>
    <field labelOnTop="0" name="ex_tmunic"/>
    <field labelOnTop="0" name="expte1"/>
    <field labelOnTop="0" name="expte2"/>
    <field labelOnTop="0" name="expte3"/>
    <field labelOnTop="0" name="fechaalta"/>
    <field labelOnTop="0" name="fechabaja"/>
    <field labelOnTop="0" name="fid"/>
    <field labelOnTop="0" name="funcionali"/>
    <field labelOnTop="0" name="hoja"/>
    <field labelOnTop="0" name="layer"/>
    <field labelOnTop="0" name="mapa"/>
    <field labelOnTop="0" name="masa"/>
    <field labelOnTop="0" name="municipio"/>
    <field labelOnTop="0" name="nom_proyec"/>
    <field labelOnTop="0" name="nom_tramo"/>
    <field labelOnTop="0" name="num_exp"/>
    <field labelOnTop="0" name="numero"/>
    <field labelOnTop="0" name="numerodup"/>
    <field labelOnTop="0" name="numsymbol"/>
    <field labelOnTop="0" name="parcela"/>
    <field labelOnTop="0" name="pcat1"/>
    <field labelOnTop="0" name="pcat2"/>
    <field labelOnTop="0" name="pkfin"/>
    <field labelOnTop="0" name="pkfin_ant"/>
    <field labelOnTop="0" name="pkini"/>
    <field labelOnTop="0" name="pkini_ant"/>
    <field labelOnTop="0" name="provincia"/>
    <field labelOnTop="0" name="rc14"/>
    <field labelOnTop="0" name="tipo"/>
    <field labelOnTop="0" name="titularida"/>
    <field labelOnTop="0" name="via"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="area" reuseLastValue="0"/>
    <field name="cat_nmspc" reuseLastValue="0"/>
    <field name="control" reuseLastValue="0"/>
    <field name="coorx" reuseLastValue="0"/>
    <field name="coory" reuseLastValue="0"/>
    <field name="ctra" reuseLastValue="0"/>
    <field name="ctra_ant" reuseLastValue="0"/>
    <field name="delegacio" reuseLastValue="0"/>
    <field name="ejercicio" reuseLastValue="0"/>
    <field name="ex_fecha" reuseLastValue="0"/>
    <field name="ex_geom" reuseLastValue="0"/>
    <field name="ex_interesado" reuseLastValue="0"/>
    <field name="ex_num" reuseLastValue="0"/>
    <field name="ex_registro" reuseLastValue="0"/>
    <field name="ex_solicitante" reuseLastValue="0"/>
    <field name="ex_supexpr" reuseLastValue="0"/>
    <field name="ex_supinf" reuseLastValue="0"/>
    <field name="ex_textinf" reuseLastValue="0"/>
    <field name="ex_tipoinv" reuseLastValue="0"/>
    <field name="ex_tmunic" reuseLastValue="0"/>
    <field name="expte1" reuseLastValue="0"/>
    <field name="expte2" reuseLastValue="0"/>
    <field name="expte3" reuseLastValue="0"/>
    <field name="fechaalta" reuseLastValue="0"/>
    <field name="fechabaja" reuseLastValue="0"/>
    <field name="fid" reuseLastValue="0"/>
    <field name="funcionali" reuseLastValue="0"/>
    <field name="hoja" reuseLastValue="0"/>
    <field name="layer" reuseLastValue="0"/>
    <field name="mapa" reuseLastValue="0"/>
    <field name="masa" reuseLastValue="0"/>
    <field name="municipio" reuseLastValue="0"/>
    <field name="nom_proyec" reuseLastValue="0"/>
    <field name="nom_tramo" reuseLastValue="0"/>
    <field name="num_exp" reuseLastValue="0"/>
    <field name="numero" reuseLastValue="0"/>
    <field name="numerodup" reuseLastValue="0"/>
    <field name="numsymbol" reuseLastValue="0"/>
    <field name="parcela" reuseLastValue="0"/>
    <field name="pcat1" reuseLastValue="0"/>
    <field name="pcat2" reuseLastValue="0"/>
    <field name="pkfin" reuseLastValue="0"/>
    <field name="pkfin_ant" reuseLastValue="0"/>
    <field name="pkini" reuseLastValue="0"/>
    <field name="pkini_ant" reuseLastValue="0"/>
    <field name="provincia" reuseLastValue="0"/>
    <field name="rc14" reuseLastValue="0"/>
    <field name="tipo" reuseLastValue="0"/>
    <field name="titularida" reuseLastValue="0"/>
    <field name="via" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"titularida"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
