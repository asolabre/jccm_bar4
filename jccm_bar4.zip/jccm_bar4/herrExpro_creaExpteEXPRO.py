# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           herrExpro_creaExpteEXPRO.py
Purpose: Creación de expediente de expropiaciones completo

        --------------------------------------------------------------------
        begin                : 2020-12-27
        git sha              : $Format:%H$
        copyright            : (C) 2020 by JCCM. Dirección General de Carreteras
        Codigo               : A. Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License", or    *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtWidgets import QDialog, QFileDialog, QListWidgetItem, QInputDialog, QLineEdit
from qgis.PyQt.QtGui import QIcon, QStandardItemModel, QStandardItem
from qgis.PyQt.QtCore import QSettings, Qt, QVariant, QMetaType
from qgis.PyQt import uic
from qgis.core import Qgis, QgsProcessingFeatureSourceDefinition, QgsVectorLayer, QgsField, QgsProject, \
                    QgsFeature, QgsLayerTreeLayer, QgsMapLayer, QgsWkbTypes, QgsFeatureRequest, QgsExpression, \
                    QgsGeometry, QgsVectorFileWriter
from qgis import processing
# import processing

from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import QApplication

import sys
import os
import timeit
import datetime

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .settings import Settings           # CLASE DE CONFIGURACIÓN DE VARIABLES GLOBALES
current_configuration = configuration()

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrExpro_expteExpro.ui'))

# VARIABLES
srcVal = current_configuration.general["EPSG"]

# CLASES PROGRAMADAS
class herrExpro_creaExpteEXPRO(QDialog, FORM_CLASS):
    def __init__(self, iface, parent=None):
        """Constructor."""
        super(herrExpro_creaExpteEXPRO, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface;
        self.fun = Functions()
        self.qs = QSettings()
        
        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        self.setWindowIcon(QIcon(f":/plugins/jccm_bar4/iconos/jccm_EXPINTPARC.jpg"))

        lista_CAPAS = self.getCAPAS()
        self.cbxCapaentrada.clear()
        self.cbxCapaentrada.addItems(lista_CAPAS)
        lastCapaentradaExpro = self.qs.value(f"{self.nombre_plugin}/last/lastCapaentradaExpro")
        try:
            if iface.activeLayer().name() in lista_CAPAS:
                self.cbxCapaentrada.setCurrentText(iface.activeLayer().name())
            else:
                self.cbxCapaentrada.setCurrentIndex(1)     
        except:
            self.cbxCapaentrada.setCurrentIndex(1)     
        if lastCapaentradaExpro in lista_CAPAS:
            self.cbxCapaentrada.setCurrentIndex(lista_CAPAS.index(lastCapaentradaExpro))
            
        self.lastDirGPKG = self.qs.value(f"{self.nombre_plugin}/last/lastDirGPKG")
        if self.lastDirGPKG is None:
            self.lastDirGPKG = 'C:/temp/ficheroEXPRO.gpkg'
        self.srcExtORI = '.gpkg'
        self.lneGPKGsalida.setText(self.lastDirGPKG)
        
        # self.rbtDetecTTMM.toggled.connect(self.cambiaWIDGETSPKS)
        self.rbtCargadosTTMM.toggled.connect(self.cambiaWIDGETSPKS)

        self.chbCargaTTMM.setEnabled(False)
        self.chbCargaTTMM.setChecked(True)

        self.chbELEMSELEC.setEnabled(True)
        self.chbCARGAGPKG.setEnabled(True)
        self.chbRESTOSPARC.setEnabled(True)
        self.btnGENERA.clicked.connect(self.generaExpteEXPRO)
        # self.layerResultFIN = self.btnGENERA.clicked.connect(lambda: self.generaExpteEXPRO())
        self.btnCANCELA.clicked.connect(self.cancela)
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)
        self.btnSeleccionfich.clicked.connect(self.gpkg_salida_file_click)
        self.lblINFO.show() == True
        self.btnGeneraConsMasivaCAT.clicked.connect(self.GeneraConsMasivaCAT)
        # self.btnGeneraConsMasivaCAT.clicked.connect(lambda: self.GeneraConsMasivaCAT(self.layerResultFIN))
        self.btnGeneraConsMasivaCAT.setEnabled(False)


    def getCAPAS(self):
        capas = []
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == QgsMapLayer.VectorLayer:
                if layer.wkbType() == QgsWkbTypes.Polygon:
                    feat=layer.featureCount()
                    featsel=layer.selectedFeatureCount()
                    capas.append(layer.name())
                if layer.wkbType() == QgsWkbTypes.MultiPolygon:
                    feat=layer.featureCount()
                    featsel=layer.selectedFeatureCount()
                    capas.append(layer.name())
        return capas


    def cambiaWIDGETSPKS(self):
        if self.rbtCargadosTTMM.isChecked():
            # DETECTAMOS LOS TTMM CARGADOS
            capasCat = []
            for layer in QgsProject.instance().mapLayers().values():
                if layer.type() == QgsMapLayer.VectorLayer:
                    if layer.name()[:8] == 'CAT- PAR':
                        capasCat.append(layer.name())
                        self.lwgLISTA_TM.addItem(layer.name())
            if len(capasCat) == 0:
                message = u'NO EXISTEN CAPAS DE PARCELAS CATASTRALES\n\n  - SE DEBEN CARGAR - '
                self.fun.showMessage( message,'','FALTA CATASTRO' )
                self.btnGENERA.setEnabled(False)
            return
        else:
            self.btnGENERA.setEnabled(True)
            return
        return

    '''
    def getCAPAStermcat(self):
        capas = []
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == QgsMapLayer.VectorLayer:
                if layer.wkbType() == QgsWkbTypes.Polygon:
                    # feat=layer.featureCount()
                    # featsel=layer.selectedFeatureCount()
                    if layer.fields().indexFromName('DELEGACIO') != -1 and layer.fields().indexFromName('MUNICIPIO') != -1:
                        print (u'AÑADIMOS CAPA -  ', layer.name())
                        capas.append(layer.name())
                if layer.wkbType() == QgsWkbTypes.MultiPolygon:
                    # feat=layer.featureCount()
                    # featsel=layer.selectedFeatureCount()
                    if layer.fields().indexFromName('DELEGACIO') != -1 and layer.fields().indexFromName('MUNICIPIO') != -1:
                        print (u'AÑADIMOS CAPA -  ', layer.name())
                        capas.append(layer.name())
        return capas
    '''

    def cancela(self):
        self.close()
        pass


    def gpkg_salida_file_click(self):
        gpkg_salida_file= self.lneGPKGsalida.text()
        ext = "*.gpkg"
        filename, tipofile = QFileDialog.getSaveFileName(self, "Fichero GPKG de salida", gpkg_salida_file, ext)
        print (filename, tipofile)
        if filename != None and filename != "":
            self.lneGPKGsalida.setText(filename)
        else:
            filename = gpkg_salida_file
        # Comprobamos que existe el directorio y si no, se crea
        if not os.path.exists(os.path.dirname(filename)):
            os.makedirs(os.path.dirname(filename))


    def generaExpteEXPRO(self):
        start = timeit.default_timer()

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        # VARIABLES
        self.qs.setValue(f"{self.nombre_plugin}/last/lastCapaentradaExpro", self.cbxCapaentrada.currentText())

        srs =  self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        capaExpro = self.cbxCapaentrada.currentText()

        layerResultFile= self.lneGPKGsalida.text()
        layerResultTable= self.lneGPKGtable.text()
        layerResultName = self.lneGPKGtable.text()
        layerResult = '%s|layername=%s'%(layerResultFile,layerResultTable)
        estiloCAPA = os.path.join(os.path.dirname(__file__), u"./ESTILOS CAPAS/EXPRO_REPARCELACION_REMISION.qml")

        # Controlamos si la capa de entrada existe
        layerEXIST = QgsProject.instance().mapLayersByName(capaExpro)
        if not layerEXIST:
            message = u"PARECE QUE NO EXISTE LA CAPA\n"+capaExpro
            QApplication.restoreOverrideCursor()
            self.fun.showMessage( message,'','Error de capa' )
            return

        # Se genera el fichero de destino de los datos.
        destLYR = self.creaFichRESUL("Polygon?crs=epsg:"+str(srcVal), layerResultName+'_PRE')
        QgsProject.instance().addMapLayer(destLYR)
        
        # Establecemos el estilo de la capa
        destLYR.loadNamedStyle(estiloCAPA)

        if self.rbtCargadosTTMM.isChecked():
            listcapaCatastro=[]
            listcapaCatastro =  [str(self.lwgLISTA_TM.item(i).text()) for i in range(self.lwgLISTA_TM.count())]
        
        else:
            # Detectar los TM del servicio de MUNIPIOS y PROVINCIAS
            text1 = u'PASO 1. DETECTANDO TTMM'
            paso = 1
            self.iface.mainWindow().statusBar().showMessage(text1)
            self.lblINFO.setText(text1)
            self.progressBar.setValue(5)
            self.fun.wait(0.5)
            # print ( text1)

            listPolig = []
            layersExpro = QgsProject.instance().mapLayersByName(capaExpro)
            sf = layersExpro[0].selectedFeatures() #returns QgsFeature object
            if len(sf) == 0:
                sf = layersExpro[0].getFeatures() #returns QgsFeature object
            
            for feat in sf:
                listPolig.append(feat.geometry())
            listaProv, listaMuni = self.fun.buscaTTMMpoligono(listPolig)
            
            if listaProv == 'Error':
                text = 'Error: '+listaMuni
                text += '\nProbablemente se ha seleccionado un conjunto de polígonos muy grande'
                text += '\n\nSE RECOMIENDA FRACCIONAR LA ZONA SLECCIONADA'
                self.close()
                QApplication.restoreOverrideCursor()
                self.fun.showMessage(text)
                return text
            
            root = QgsProject.instance().layerTreeRoot()
            listcapaCatastro=[]
            numpasos = 1+len(listaMuni)*9
            numTermMuni = 0
            totalTermMuni = len(listaMuni)
            
            print ('listaProv\n',listaProv,'\n','listaMuni\n',listaMuni)
            for Muni in listaMuni:
                paso = 2+ 9*numTermMuni
                text1 = u'PASO %s. OBTENIENDO DATOS CATASTRALES DE TTMM'%(str(paso))
                self.iface.mainWindow().statusBar().showMessage(text1)
                self.lblINFO.setText(text1)
                self.progressBar.setValue(int(100 * paso/numpasos))
                self.fun.wait(0.5)

                codigo_provincia = Muni[2][0:2]
                nombre_prov = self.fun.consultaCatastroCodProvtoProvincia(codigo_provincia)
                codineMuni = Muni[2]
                nombre_muni = Muni[1].upper()
                nombre_prov = self.fun.consultaCatastroCodProvtoProvincia(codigo_provincia)
                nombre_muni1, cmc = self.fun.consultaCatastroCodMunitoMunicipio(nombre_prov, codineMuni[2:5])
                codigo_muni_final = self.fun.completarCeros(cmc,3)
            
                codigo = self.fun.completarCeros(codigo_provincia,2) + codigo_muni_final
                nombregrupo = "CAT - " + nombre_muni + " - " + codigo + " - (WEB)"
                # print ('codigo_provincia - ', codigo_provincia, 'codigo_muni_final - ',codigo_muni_final, 'nombre_muni - ', nombre_muni)

                paso = 3+ 9*numTermMuni
                text1 = u'PASO %s CARGANDO %s %s'%(str(paso),codigo, nombre_muni)
                self.iface.mainWindow().statusBar().showMessage(text1)
                self.lblINFO.setText(text1)
                self.progressBar.setValue(int(100 * paso/numpasos))
                self.fun.wait(0.5)
                # print (text1)

                # COMPROBAMOS SI EXISTE EL GRUPO DE PARCELAS CATASTRALES
                nombregrupo = "CAT - " + nombre_muni + " - " + codigo + " - (WEB)"
                grupoBUSCAT = QgsProject.instance().layerTreeRoot().findGroup(nombregrupo)
                if grupoBUSCAT is None:
                    mess = False
                    cargaIface = False
                    if self.chbCargaTTMM.isChecked():
                        cargaIface = True
                    
                    # capaCatPol, capaCatPar = self.fun.cargaCatastroMuni(codigo_provincia, codigo_muni_final, nombre_muni, 'web', 'WEB', self.iface, mess = False)
                    # capaCatPol, capaCatPar = self.fun.cargaCatastroMuni(codigo_provincia, codigo_muni_final, nombre_muni, 'web', 'WEB', self.iface, mess = False, cargaIface = False)
                    capaCatPol, capaCatPar, capaCatPolFich, capaCatParFich  = self.fun.cargaCatastroMuni(codigo_provincia, codigo_muni_final, nombre_muni, 'web', 'WEB', self.iface, mess, cargaIface)
                    listcapaCatastro.append(capaCatPar)
                    capaCatastro = capaCatPar
                else:
                    listcapaCatastro.append("CAT- PAR- " + nombre_muni + " - " + codigo)
                    capaCatastro = "CAT- PAR- " + nombre_muni + " - " + codigo
                self.lwgLISTA_TM.addItem(u'%s %s %s'%(codigo_provincia,codigo_muni_final, nombre_muni))
            
            numTermMuni +=1

        #####################################################################################

        numpasos = 1+len(listcapaCatastro)*9
        numTermMuni = 0
        totalTermMuni = len(listcapaCatastro)
        no_orden = 1
        for capaCatastro in listcapaCatastro:
            print (capaCatastro)
            nombre_muni = capaCatastro[10:(len(capaCatastro)-8)]
            codigo = capaCatastro[-5:]
            vlayerCAT = QgsProject.instance().mapLayersByName(capaCatastro)[0]
            cp = int(codigo[:2])
            cm = int(codigo[2:5])
            expr = "\"DELEGACIO\" = %d and \"MUNICIPIO\" = %d"%(cp,cm)
            selection = vlayerCAT.getFeatures(QgsFeatureRequest(QgsExpression("\"DELEGACIO\" = %d and \"MUNICIPIO\" = %d"%(cp,cm))))


            ############################################################
            #####       SELECCIÓN DE ELEMENTOS EN CAPACATASTRO     #####
            ############################################################
            paso = 4+ 9*numTermMuni
            text1 = u'PASO %s %s %s SELECCIONANDO ELEMENTOS'%(str(paso), codigo, nombre_muni)
            self.iface.mainWindow().statusBar().showMessage(text1)
            self.lblINFO.setText(text1)
            self.progressBar.setValue(int(100 * paso/numpasos))
            self.fun.wait(0.5)

            processing.run("native:selectbylocation", {
                            'INPUT' : capaCatastro,
                            'INTERSECT' : capaExpro,
                            'METHOD' : 0,
                            'PREDICATE' : [0]
                            })


            ############################################################
            ####            INTERSECCIÓN DE CAPAS                  #####
            ############################################################
            paso = 5+ 9*numTermMuni
            text1 = u'PASO %s %s %s INTERSEC. PARCELAS CATASTRALES'%(str(paso), codigo, nombre_muni)
            self.iface.mainWindow().statusBar().showMessage(text1)
            self.lblINFO.setText(text1)
            self.progressBar.setValue(int(100 * paso/numpasos))
            self.fun.wait(0.5)
            
            if self.chbELEMSELEC.isChecked():
                algresult = processing.run("native:intersection", {
                            'INPUT' : QgsProcessingFeatureSourceDefinition(capaCatastro, True),
                            'INPUT_FIELDS' : [],
                            # 'OUTPUT' : 'ogr:dbname=\'%s\' table=\"%s\" (geom) sql='%(layerResultFile,layerResultTable+'0'),
                            'OUTPUT' : 'TEMPORARY_OUTPUT',
                            'OVERLAY' : capaExpro,
                            'OVERLAY_FIELDS' : [],
                            'OVERLAY_FIELDS_PREFIX' : 'exp_'
                            })
            else:
                algresult = processing.run("native:intersection", {
                            'INPUT' : QgsProcessingFeatureSourceDefinition(capaCatastro),
                            'INPUT_FIELDS' : [],
                            # 'OUTPUT' : 'ogr:dbname=\'%s\' table=\"%s\" (geom) sql='%(layerResultFile,layerResultTable+'0'),
                            'OUTPUT' : 'TEMPORARY_OUTPUT',
                            # 'OVERLAY' : QgsProcessingFeatureSourceDefinition(capaExpro, True),
                            'OVERLAY' : capaExpro,
                            'OVERLAY_FIELDS' : [],
                            'OVERLAY_FIELDS_PREFIX' : 'exp_'
                            })

            # vlayer0 = QgsVectorLayer(layerResult+'0', layerResultName+'0', "ogr")
            vlayer0 = algresult['OUTPUT']
            if not vlayer0.isValid():
                print(u"FALLÓ LA CARGA DE LA CAPA!\n"+layerResult+'0')
            else:
                
                pr = vlayer0.dataProvider()
                vlayer0.startEditing()
                pr.addAttributes([QgsField('no_orden',QMetaType.Type.QString)])
                pr.addAttributes([QgsField('TIPORES',QMetaType.Type.QString)])                 # Se añade campo TIPORES
                pr.addAttributes([QgsField('CAT_NMSPC',QMetaType.Type.QString)])               # Se añade campo CAT_NMSPC
                pr.addAttributes([QgsField('AREA_PARTE',QMetaType.Type.Double,'', 10,2)])     # Se añade campo AREA_PARTE
                pr.addAttributes([QgsField('cod_term_m',QMetaType.Type.QString)])
                pr.addAttributes([QgsField('term_munic',QMetaType.Type.QString)])
                pr.addAttributes([QgsField('X_LABEL',QMetaType.Type.Double,'', 10,2)])
                pr.addAttributes([QgsField('Y_LABEL',QMetaType.Type.Double,'', 10,2)])
                vlayer0.commitChanges()
                # Se añade capa a la vista
                # QgsProject.instance().addMapLayer(vlayer0)
                
                # Se modifican los valores de los atributos conocidos
                vlayer0.startEditing()
                it = vlayer0.getFeatures()
                for feat in it:
                  vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('no_orden'), str(no_orden))
                  vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('TIPORES'), 'EXPRO')
                  vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('CAT_NMSPC'), 'ES.LOCAL.CP')
                  vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('cod_term_m'), codigo)
                  vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('term_munic'), nombre_muni)
                  no_orden += 1
                vlayer0.commitChanges()
                alias = {'RC14':'localId','supcat':'areaValue'}

            # paso = 6
            paso = 6+ 9*numTermMuni
            # textPaso = u'COPIANDO PARCELAS INTERSECCIÓN A RESULT'

            text1 = u'PASO %s. %s %s'%(str(paso), codigo, u'COPIANDO PARCELAS INTERSECCIÓN A RESULT')
            self.iface.mainWindow().statusBar().showMessage(text1)
            self.lblINFO.setText(text1)
            self.progressBar.setValue(int(100 * paso/numpasos))
            self.fun.wait(0.5)

            # self.copiaFeatToLayer(self.iface, (paso, numpasos, textPaso, codigo, destLYR, vlayer0, alias)
            self.copiaFeatToLayer(self.iface, codigo, destLYR, vlayer0, alias)


            '''
            # DIFERENCIA PARA LOCALIZAR DESCUENTOS
            paso = 7+ 9*numTermMuni
            text1 = u'PASO %s.%s %s %s DIFER. DESC CATASTRALES'%(str(paso), str(numTermMuni), codigo, nombre_muni)
            self.iface.mainWindow().statusBar().showMessage(text1)
            self.lblINFO.setText(text1)
            self.progressBar.setValue(100 * ((paso-3)*numTermMuni/totalcapaCat)/numpasos)
            self.fun.wait(0.5)
            # print ( text1)

            processing.run("native:difference", {
                            'INPUT' : capaExpro,
                            'OUTPUT' : 'ogr:dbname=\'%s\' table=\"%s\" (geom) sql='%(layerResultFile,layerResultTable+'1'),
                            'OVERLAY' : layerResultName
                            })
            # vlayer0 = QgsVectorLayer(layerResult+'1', layerResultName+'1', "ogr")
            vlayer0 = QgsVectorLayer(layerResult+'1', 'RESULT_DESC', "ogr")
            if not vlayer0.isValid():
                print(u"FALLÓ LA CARGA DE LA CAPA!\n"+layerResult+'1')
            else:
                # Se añade campo TIPORES
                pr = vlayer0.dataProvider()
                vlayer0.startEditing()
                pr.addAttributes([QgsField('TIPORES',QVariant.String)])
                pr.addAttributes([QgsField('cod_term_m',QVariant.String)])
                vlayer0.commitChanges()
                # Se añade capa a la vista
                QgsProject.instance().addMapLayer(vlayer0)
                # Se modifica el valor del atributo
                vlayer0.startEditing()
                it = vlayer0.getFeatures()
                for feat in it:
                  vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('TIPORES'), 'DESCUENTO')
                  vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('cod_term_m'), codigo)
                vlayer0.commitChanges()

            ############################################################
            ####   HAY QUE SABER SI EL DESCUENTO ESTÁ DENTRO DEL TM  ####
            ############################################################
            ############################################################
            ############################################################
            # mapcanvas = self.iface.mapCanvas()
            # layers = mapcanvas.layers()
            feats_A = [ feat for feat in vlayer0.getFeatures() ]    # Features de Descuentos
            # feats_B = vlayerCAT.getFeatures().next()                # Features de Terminos Municipales
            for i, feat in enumerate(feats_A):
                if geomTMCAT.contains(feat.geometry()):
                    # if listGeom.geometry().contains(feat.geometry()):
                    print ("La geometria SI está incluida en %s, "%(codigo), "feature: ", i)
                else:
                    print ("La geometria NO está incluida en %s, "%(codigo), "feature: ", i)


            paso = 8
            textPaso = u'COPIANDO PARCELAS DESCUENTOS A RESULT'
            self.copiaFeatToLayer(self.iface, ((paso-3)*numTermMuni/totalcapaCat), numpasos, textPaso, codigo, destLYR, vlayer0, alias)

            ############################################################
            ############################################################
            ############################################################
            '''

            ############################################################
            ##### CÁLCULO RESTOS DE LAS PARCELAS SELECCIONADAS     #####
            ############################################################
            if self.chbRESTOSPARC.isChecked():

                # paso = 8
                paso = 8+ 9*numTermMuni
                text1 = u'PASO %s %s %s CALC. RESTOS PARCELAS CATAST.'%(str(paso), codigo, nombre_muni)
                self.iface.mainWindow().statusBar().showMessage(text1)
                self.lblINFO.setText(text1)
                self.progressBar.setValue(int(100 * paso/numpasos))
                self.fun.wait(0.5)

                algresult = processing.run("native:difference", {
                                'INPUT' : QgsProcessingFeatureSourceDefinition(capaCatastro, True),
                                # 'OUTPUT' : 'ogr:dbname=\'%s\' table=\"%s\" (geom) sql='%(layerResultFile,layerResultTable+'2'),
                                'OUTPUT' : 'TEMPORARY_OUTPUT',
                                'OVERLAY' : capaExpro
                                })
                # vlayer0 = QgsVectorLayer(layerResult+'2', layerResultName+'2', "ogr")
                vlayer0 = algresult['OUTPUT']

                if not vlayer0.isValid():   
                    print(u"FALLÓ LA CARGA DE LA CAPA!\n"+layerResult+'2')
                else:
                    # Se añade campo TIPORES
                    pr = vlayer0.dataProvider()
                    vlayer0.startEditing()
                    pr.addAttributes([QgsField('TIPORES',QMetaType.Type.QString)])
                    pr.addAttributes([QgsField('CAT_NMSPC',QMetaType.Type.QString)])               # Se añade campo CAT_NMSPC
                    pr.addAttributes([QgsField('AREA_PARTE',QMetaType.Type.Double,'', 10,2)])     # Se añade campo AREA_PARTE
                    pr.addAttributes([QgsField('cod_term_m',QMetaType.Type.QString)])
                    vlayer0.commitChanges()
                    # Se añade capa a la vista
                    # QgsProject.instance().addMapLayer(vlayer0)
                    # Se modifica el valor del atributo
                    vlayer0.startEditing()
                    it = vlayer0.getFeatures()
                    for feat in it:
                      vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('TIPORES'), 'RESTO')
                      vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('CAT_NMSPC'), 'ES.SDGC.CP')
                      vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('cod_term_m'), codigo)
                      vlayer0.changeAttributeValue(feat.id(), vlayer0.fields().indexFromName('term_munic'), nombre_muni)
                    vlayer0.commitChanges()

                # paso = 9
                paso = 9+ 9*numTermMuni
                # textPaso = u'COPIANDO RESTOS PARCELAS A RESULT'
                
                text1 = u'PASO %s. %s %s'%(str(paso), codigo, u'COPIANDO RESTOS PARCELAS A RESULT')
                self.iface.mainWindow().statusBar().showMessage(text1)
                self.lblINFO.setText(text1)
                self.progressBar.setValue(int(100 * paso/numpasos))
                self.fun.wait(0.5)
            
                # self.copiaFeatToLayer(self.iface, (paso, numpasos, textPaso, codigo, destLYR, vlayer0, alias)
                self.copiaFeatToLayer(self.iface, codigo, destLYR, vlayer0, alias)

            # Se deseleccionan los elementos
            QgsProject.instance().mapLayersByName( capaCatastro )[0].removeSelection()
            
            numTermMuni += 1

        self.btnGENERA.setEnabled(False)

        '''
        ## Metemos todo en la capa GPKG final
        # QgsVectorFileWriter.writeAsVectorFormat(destLYR, layerResultFile, "UTF-8", destLYR.crs())
        
        transform_context = QgsProject.instance().transformContext()
        save_options = QgsVectorFileWriter.SaveVectorOptions()
        save_options.layerName = layerResultTable               # Nombre de la capa
        save_options.fileEncoding = "UTF-8"                     # Encoding
        save_options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
        QgsVectorFileWriter.writeAsVectorFormatV2(destLYR, layerResultFile, transform_context, save_options) 

        self.layerResultFIN=QgsVectorLayer(layerResultFile,layerResultTable,"ogr")
        QgsProject.instance().addMapLayer(self.layerResultFIN)
        self.layerResultFIN.loadNamedStyle(estiloCAPA)

        # Se borra la capa previa
        QgsProject.instance().removeMapLayer(destLYR)
        '''
        
        
        ## Metemos todo en la capa GPKG final
        ##############################################################################
        ##############################################################################
        ##          CONTROLAR ESTO                                                  ##
        ##############################################################################
        ##############################################################################
        # layerResultFile = 'C:/temp/ficheroGDB.gpkg'
        # layerResultTable = 'EJES_GDB'
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.layerName = layerResultTable          # Nombre de la capa
        options.fileEncoding = "UTF-8"                # Encoding
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer 
        options.EditionCapability = QgsVectorFileWriter.CanAddNewLayer
        
        _writer = QgsVectorFileWriter.writeAsVectorFormat(destLYR, layerResultFile, options)
        if _writer:
            print(destLYR.name(), _writer)

        self.layerResultFIN=QgsVectorLayer(layerResultFile,layerResultTable,"ogr")
        QgsProject.instance().addMapLayer(self.layerResultFIN)
        self.layerResultFIN.loadNamedStyle(estiloCAPA)

        # Se borra la capa previa
        # QgsProject.instance().removeMapLayer(destLYR)
        
        
        
        
        text = '  --- FINALIZADO ---'
        self.progressBar.setValue(100)
        QApplication.restoreOverrideCursor()
        self.btnGeneraConsMasivaCAT.setEnabled(True)
        stop = timeit.default_timer()
        tiempo = 'Tiempo: '+"%0.2f"%(stop - start)+' seg.'
        self.lblINFO.setText(text+tiempo)
        self.fun.showMessage(text+'\n\n'+tiempo)
        
        # return layerResultFIN


    def creaFichRESUL(self,uri,name,dest='memory'):
        # createVectorLayer(self,uri,name,dest='memory')
        #   Crea una capa vectorial memoria añadiendoles campos
        #           LISTA CAMPOS
        #   Devuelve la capa vectorial
        #   return vl

        vl = QgsVectorLayer(uri, name, dest)

        pr = vl.dataProvider()

        # Enter editing mode
        vl.startEditing()

        # add fields
        '''
        pr.addAttributes([
            # DATOS PARCELA CATASTRAL
            QgsField('no_orden'     ,QVariant.String,'', 50,0,u"Nº Orden.- Número de orden de la finca relativo al proyecto; único para cada finca dentro del expediente. Texto: 1, 2,3…"),
            QgsField('EXPEDIENTE'   ,QVariant.String,'', 50,0,u"EXPEDIENTE.- Clave del expediente de Expropiaciones. Texto: 50"),
            QgsField('term_munic'   ,QVariant.String,'',150,0,u"term_munic.- Nombre término municipal donde radica la finca. Texto: 150"),
            QgsField('cod_term_m'   ,QVariant.String,'',  5,0,u"Cod. Term. Municipal.- Código del término municipal donde radica la finca,"),
            QgsField('pedanía'      ,QVariant.String,'',150,0,u"Pedanía.- En caso de que el término municipal esté dividido en pedanías, nombre de la pedanía donde se ubica la finca."),
            QgsField('pol'          ,QVariant.String,'',  5,0,u"Poligono.- Polígono catastral donde se ubica la finca."),
            QgsField('par'          ,QVariant.String,'',  5,0,u"Parcela.- Parcela catastral donde se ubica la finca."),
            QgsField('subpar'       ,QVariant.String,'',  3,0,u"SubParcela.- Subparcela catastral donde ubica la finca (en caso de existir)."),
            QgsField('RC14'         ,QVariant.String,'', 20,0,u"Ref. Catrastal.- Referencia catastral."),
            QgsField('dirfinca'     ,QVariant.String,'',255,0,u"Dirección.- Para aquellas fincas de las que se disponga de este dato."),
            QgsField('paraje'       ,QVariant.String,'',255,0,u"Paraje.- Donde se encuentra la finca."),
            QgsField('uso'          ,QVariant.String,'',150,0,u"Uso.- Uso del terreno de la finca."),
            QgsField('concepto'     ,QVariant.String,'', 50,0,u"Concepto.- Dentro del proyecto a realizar, uso que se le dará al terreno; usado sobre todo por IACLM; ejemplo EDAR, línea eléctrica, tubería…"),
            QgsField('tipopropi'    ,QVariant.String,'',  1,0,u"Propiedad Pública.- 0 en caso de propiedad privada, 1 en caso de propiedad a nombre de la JCCM y 2 en caso de propiedad pública no JCCM."),
            QgsField('supcat'       ,QVariant.Double,'', 10,2,u"Superf. Catastral Comp.- Superficie completa de la finca según el catastro en metros cuadrados."),
            QgsField('calificacion' ,QVariant.String,'',  5,0,u"Calificación.- Urbana (U), o Rústica (R). Toda la columna de contener o R o U. Si es Domini Público poner R."),
            # DATOS SUPERFICIES EXPROPIACIÓN
            QgsField('superfpd'     ,QVariant.Double,'', 10,2,u"Superf. P.D.- Superficie en metros cuadrados a ser expropiada en pleno dominio."),
            QgsField('valorunitpd'  ,QVariant.Double,'', 10,2,u"Valor Unit. P.D.- Valor unitario por metro cuadrado que supone la expropiación en pleno dominio de esta finca."),
            QgsField('importepd'    ,QVariant.Double,'', 10,2,u"Importe P.D.- Importe total a abonar por la parte expropiada en pleno dominio."),
            QgsField('superfot'     ,QVariant.Double,'', 10,2,u"Superf. O.T.- Superficie en metros cuadrados a ser expropiada en ocupación temporal."),
            QgsField('valorunitot'  ,QVariant.Double,'', 10,2,u"Valor Unit. O.T.- Valor unitario por metro cuadrado que supone la expropiación en ocupación temporal de esta finca."),
            QgsField('importeot'    ,QVariant.Double,'', 10,2,u"Importe O.T.- Importe total a abonar por la parte expropiada en ocupación temporal."),
            QgsField('superfsp'     ,QVariant.Double,'', 10,2,u"Superf. S.P.- Superficie en metros cuadrados a ser expropiada en servidumbre de paso."),
            QgsField('valorunitsp'  ,QVariant.Double,'', 10,2,u"Valor Unit. S.P.- Valor unitario por metro cuadrado que supone la expropiación en servidumbre de paso de esta finca."),
            QgsField('importesp'    ,QVariant.Double,'', 10,2,u"Importe S.P.- Importe total a abonar por la parte expropiada en servidumbre de paso."),
            QgsField('superfsv'     ,QVariant.Double,'', 10,2,u"Superf. S.V.- Superficie en metros cuadrados a ser expropiada en servidumbre de vuelo."),
            QgsField('valorunitsv'  ,QVariant.Double,'', 10,2,u"Valor Unit. S.V.- Valor unitario por metro cuadrado que supone la expropiación en servidumbre de vuelo de esta finca."),
            QgsField('importesv'    ,QVariant.Double,'', 10,2,u"Importe S.V.- Importe total a abonar por la parte expropiada en servidumbre de vuelo."),
            # DATOS CAPA
            QgsField('TIPORES'      ,QVariant.String,'', 25,0,u"TIPO PARCELA.- 'EXPRO', 'RESTO', 'DESCUENTO'"),
            QgsField('CAT_NMSPC'    ,QVariant.String,'', 25,0,u"Dato Namespace.- 'ES.SDGC.CP', 'ES.LOCAL.CP'"),
            QgsField('AREA_PARTE'   ,QVariant.Double,'', 10,2,u"Superficie de la parte"),
            QgsField('X_LABEL'      ,QVariant.Double,'', 10,2,u"X_LABEL. - X para etiquetado"),
            QgsField('Y_LABEL'      ,QVariant.Double,'', 10,2,u"X_LABEL. - Y para etiquetado")
            ] )
        '''
            
            
        pr.addAttributes([
            # DATOS PARCELA CATASTRAL
            QgsField('EXPEDIENTE'   , QMetaType.Type.QString,'',  50,0, u"EXPEDIENTE.- Clave del expediente de Expropiaciones. Texto: 50", alias='EXPEDIENTE'),
            QgsField('no_orden'     , QMetaType.Type.QString,'',  50,0, u"Nº Orden.- Número de orden de la finca relativo al proyecto; único para cada finca dentro del expediente.", alias='Nº Orden'),
            QgsField('Entrada'      , QMetaType.Type.QString,'',  50,0, u"Entrada.- Tipo de dato PARCELA/TITULAR/BIENES. Texto: 50", alias='Entrada'),
            QgsField('term_munic'   , QMetaType.Type.QString,'', 150,0, u"term_munic.- Nombre término municipal donde radica la finca. Texto: 150", alias='term_munic'),
            QgsField('cod_term_m'   , QMetaType.Type.QString,'',   5,0, u"Cod. Term. Municipal.- Código del término municipal donde radica la finca,", alias='Cod. Term. Municipal'),
            QgsField('pedanía'      , QMetaType.Type.QString,'', 150,0, u"Pedanía.- En caso de que el término municipal esté dividido en pedanías, nombre de la pedanía donde se ubica la finca.", alias='Pedanía'),
            QgsField('pol'          , QMetaType.Type.QString,'',   5,0, u"Poligono.- Polígono catastral donde se ubica la finca.", alias='Poligono'),
            QgsField('par'          , QMetaType.Type.QString,'',   5,0, u"Parcela.- Parcela catastral donde se ubica la finca.", alias='Parcela'),
            QgsField('subpar'       , QMetaType.Type.QString,'',   3,0, u"SubParcela.- Subparcela catastral donde ubica la finca (en caso de existir).", alias='SubParcela'),
            QgsField('RC14'         , QMetaType.Type.QString,'',  20,0, u"Ref. Catrastal.- Referencia catastral o LOCALID -CASO DE RESTO PARCELA-.", alias='Ref. Catrastal'),
            QgsField('dirfinca'     , QMetaType.Type.QString,'', 255,0, u"Dirección.- Para aquellas fincas de las que se disponga de este dato.", alias='Dirección'),
            QgsField('paraje'       , QMetaType.Type.QString,'', 255,0, u"Paraje.- Donde se encuentra la finca.", alias='Paraje'),
            QgsField('uso'          , QMetaType.Type.QString,'', 150,0, u"Uso.- Uso del terreno de la finca.", alias='Uso'),
            QgsField('concepto'     , QMetaType.Type.QString,'',  50,0, u"Concepto.- Dentro del proyecto a realizar, uso que se le dará al terreno; usado sobre todo por IACLM; ejemplo EDAR, línea eléctrica, tubería…", alias='Concepto'),
            QgsField('tipopropi'    , QMetaType.Type.QString,'',   1,0, u"Propiedad Pública.- 0 en caso de propiedad privada, 1 en caso de propiedad a nombre de la JCCM y 2 en caso de propiedad pública no JCCM.", alias='Propiedad Pública'),
            QgsField('supcat'       , QMetaType.Type.Double,'',  10,2, u"Superf. Catastral Comp.- Superficie completa de la finca según el catastro en metros cuadrados.", alias='Superf. Catastral Comp'),
            QgsField('calificacion' , QMetaType.Type.QString,'',   5,0, u"Calificación.- Urbana (U), o Rústica (R). Toda la columna de contener o R o U. Si es Domini Público poner R.", alias='Calificación'),
            QgsField('DomPub'       , QMetaType.Type.QString,'',  25,0, u"Tipo DP.- Tipo de Dominio Público (parcelas 9000) según calificación de catastro. Si privado poner 'P'.", alias='Tipo DP'),

            # DATOS SUPERFICIES EXPROPIACIÓN (EN EXCEL UNA LINEA POR TIPO SUPERFICIE)
            QgsField('superfnum'    , QMetaType.Type.Integer,'', 0,0, u"Num. Superficies.- Número de Superficies de distinto Valor.", alias='Num. Superf'),
            QgsField('superfpd'     , QMetaType.Type.Double,'', 10,2, u"Superf. P.D.- Superficie en metros cuadrados a ser expropiada en pleno dominio.", alias='Superf. P.D'),
            QgsField('valorunitpd'  , QMetaType.Type.Double,'', 10,2, u"Valor Unit. P.D.- Valor unitario por metro cuadrado que supone la expropiación en pleno dominio de esta finca.", alias='Valor Unit. P.D'),
            QgsField('importepd'    , QMetaType.Type.Double,'', 10,2, u"Importe P.D.- Importe total a abonar por la parte expropiada en pleno dominio.", alias='Importe P.D'),
            QgsField('superfot'     , QMetaType.Type.Double,'', 10,2, u"Superf. O.T.- Superficie en metros cuadrados a ser expropiada en ocupación temporal.", alias='Superf. O.T'),
            QgsField('valorunitot'  , QMetaType.Type.Double,'', 10,2, u"Valor Unit. O.T.- Valor unitario por metro cuadrado que supone la expropiación en ocupación temporal de esta finca.", alias='Valor Unit. O.T'),
            QgsField('importeot'    , QMetaType.Type.Double,'', 10,2, u"Importe O.T.- Importe total a abonar por la parte expropiada en ocupación temporal.", alias='Importe O.T'),
            QgsField('superfsp'     , QMetaType.Type.Double,'', 10,2, u"Superf. S.P.- Superficie en metros cuadrados a ser expropiada en servidumbre de paso.", alias='Superf. S.P'),
            QgsField('valorunitsp'  , QMetaType.Type.Double,'', 10,2, u"Valor Unit. S.P.- Valor unitario por metro cuadrado que supone la expropiación en servidumbre de paso de esta finca.", alias='Valor Unit. S.P'),
            QgsField('importesp'    , QMetaType.Type.Double,'', 10,2, u"Importe S.P.- Importe total a abonar por la parte expropiada en servidumbre de paso.", alias='Importe S.P'),
            QgsField('superfsv'     , QMetaType.Type.Double,'', 10,2, u"Superf. S.V.- Superficie en metros cuadrados a ser expropiada en servidumbre de vuelo.", alias='Superf. S.V'),
            QgsField('valorunitsv'  , QMetaType.Type.Double,'', 10,2, u"Valor Unit. S.V.- Valor unitario por metro cuadrado que supone la expropiación en servidumbre de vuelo de esta finca.", alias='Valor Unit. S.V'),
            QgsField('importesv'    , QMetaType.Type.Double,'', 10,2, u"Importe S.V.- Importe total a abonar por la parte expropiada en servidumbre de vuelo.", alias='Importe S.V'),

            # DATOS BIENES EXPROPIACIÓN (EN EXCEL UNA LINEA POR TIPO BIENES)
            QgsField('bienesDistnum', QMetaType.Type.Integer,'', 0,0, u"Num. Bienes distintos.- Número de distintos Bienes valorados.", alias='Num. Bienes distintos'),
            QgsField('numBie'       , QMetaType.Type.Double,'', 10,2, u"Num. Bienes VU.- Número de Bienes por Valor Unitario.", alias='Num. Bienes VU'),
            QgsField('valorunitBin' , QMetaType.Type.Double,'', 10,2, u"Valor Unit. Bienes.- Valor unitario de cada tipo de bienes.", alias='Valor Unit. Bienes'),
            QgsField('importeBie'   , QMetaType.Type.Double,'', 10,2, u"Importe Bienes.- Importe total Bienes.", alias='Importe Bienes'),

            QgsField('importeTotal' , QMetaType.Type.Double,'', 10,2, u"Importe TOTAL Tit.- Importe total PD+OT+SP+SV+BIE.", alias='Importe TOTAL Tit'),

            # DATOS LINDEROS
            QgsField('lindeN   '    , QMetaType.Type.QString,'',200,0, u"Linderos Norte.- Linderos Norte de la parte a expropiar.", alias='Linderos Norte'),            
            QgsField('lindeS   '    , QMetaType.Type.QString,'',200,0, u"Linderos Sur.- Linderos Sur de la parte a expropiar.", alias='Linderos Sur'),            
            QgsField('lindeE   '    , QMetaType.Type.QString,'',200,0, u"Linderos Este.- Linderos Este de la parte a expropiar.", alias='Linderos Este'),            
            QgsField('lindeO   '    , QMetaType.Type.QString,'',200,0, u"Linderos Oeste.- Linderos Oeste de la parte a expropiar.", alias='Linderos Oeste'),            
            
            # DATOS REGISTRALES
            QgsField('registro'     , QMetaType.Type.QString,'',100,0, u"Registro.- Datos registrales que se rellenarán en caso de ser conocidos", alias='Registro'),
            QgsField('regtomo'      , QMetaType.Type.QString,'', 20,0, u"Tomo, Datos registrales que se rellenarán en caso de ser conocidos.", alias='Tomo'),
            QgsField('reglibro'     , QMetaType.Type.QString,'', 20,0, u"Libro, Datos registrales que se rellenarán en caso de ser conocidos.", alias='Libro'),
            QgsField('regfolio'     , QMetaType.Type.QString,'', 20,0, u"Folio, Datos registrales que se rellenarán en caso de ser conocidos.", alias='Folio'),
            QgsField('regfinca'     , QMetaType.Type.QString,'', 20,0, u"Finca, Datos registrales que se rellenarán en caso de ser conocidos.", alias='Finca'),
            QgsField('regsuperf'    , QMetaType.Type.QString,'', 20,0, u"Superficie Registral Completa.- Datos registrales que se rellenarán en caso de ser conocidos.", alias='Superficie Registral Completa'),

            # DATOS TITULARES (EN EXCEL UNA LINEA POR TITULAR)
            QgsField('titunum'       , QMetaType.Type.Integer,'', 0,0, u"Num. Titulares.- Número de titulares.", alias='Num. Titulares'),
            QgsField('titunombre'    , QMetaType.Type.QString,'',100,0, u"Nombre del Titular.- Nombre del titular de la finca o del derecho.", alias='Nombre del Titular'),
            QgsField('tituapelli'    , QMetaType.Type.QString,'',200,0, u"Apellidos del Titular.- Apellidos del titular de la finca o del derecho.", alias='Apellidos del Titular'),
            QgsField('tituDNI'       , QMetaType.Type.QString,'', 50,0, u"DNI/NIF.- Dni o Nif del titular de la finca", alias='DNI/NIF'),
            QgsField('tituDirNot'    , QMetaType.Type.QString,'',255,0, u"Dirección Notificaciones.- Dirección donde el titular quiere que se envíen las notificaciones", alias='Dirección Notificaciones'),
            QgsField('tituPorProp'   , QMetaType.Type.Double,'', 10,2, u"% Propiedad.- Tanto por ciento de propiedad sobre la finca que tiene el titular; 100 en caso de titular único, 0 en caso de desconocimiento ,-1 en caso de arrendatario, -2 en caso de usufructuario  y -3 en caso de concesionario", alias='Dirección Notificaciones'),
            QgsField('titulo'        , QMetaType.Type.QString,'',200,0, u"Título Propiedad.- Título Propiedad o derecho.", alias='Título Propiedad'),

            # DATOS REPRESENTANTE
            QgsField('repnombre'     , QMetaType.Type.QString,'',100,0, u"Nombre del REP.- Nombre del REPRESENTANTE del titular de la finca o del derecho.", alias='Nombre del Rep'),
            QgsField('repapelli'     , QMetaType.Type.QString,'',200,0, u"Apellidos del REP.- Apellidos del REPRESENTANTE del titular de la finca o del derecho.", alias='Apellidos del Rep'),
            QgsField('repuDNI'       , QMetaType.Type.QString,'', 50,0, u"DNI/NIF Rep.- Dni o Nif del REPRESENTANTE", alias='DNI/NIF Rep.'),

            # DATOS TITULARES OTROS DERECHOS (EN EXCEL UNA LINEA POR TIPO DERECHO)
            QgsField('tituDnum'      , QMetaType.Type.Integer,'', 0,0, u"Num. Tit. Otros Der.- Número de titulares (arrendador) de otros derechos.", alias='Num. Tit. Otros Der'),
            QgsField('Derecho'       , QMetaType.Type.QString,'',100,0, u"Derecho.- Derecho por el que se indemniza al arrendatario.", alias='Derecho'),
            QgsField('tituDnombre'   , QMetaType.Type.QString,'',100,0, u"Nombre Tit. Otros Der.- Nombre del titular del derecho.", alias='Nombre Tit. Otros Der'),
            QgsField('tituDapelli'   , QMetaType.Type.QString,'',200,0, u"Apellidos Tit. Otros Der.- Apellidos del titular del derecho.", alias='Apellidos Tit. Otros Der'),
            QgsField('tituDerDNI'    , QMetaType.Type.QString,'', 50,0, u"DNI/NIF Otros Der.- Dni o Nif del titular del derecho", alias='DNI/NIF Otros Der'),
            QgsField('tituDerDirNot' , QMetaType.Type.QString,'',255,0, u"Dir. Notif. Otros Der.- Dirección del titular  del derecho", alias='Dir. Notif. Otros Der'),
            QgsField('SuperfDER'     , QMetaType.Type.Double,'', 10,2, u"Superf. D.- Superficie en metros cuadrados a ser expropiados que afectan al derecho correspondiente.", alias='Superf. D'),
            QgsField('ValorUnitD'    , QMetaType.Type.Double,'', 10,2, u"Valor Unit. D.- Valor unitario por metro cuadrado que supone la expropiación del derecho correspondiente", alias='Valor Unit. D'),
            QgsField('ImporteD'      , QMetaType.Type.Double,'', 10,2, u"Importe D.- Importe total a abonar por la parte expropiada que afecta al derecho correspondiente.", alias='Importe D'),

            # DATOS EXPEDIENTE (A RELLENAR PARA CITACION Y TRAS ACTAS)
            QgsField('CodUniActa'    , QMetaType.Type.QString,'', 25,0, u"Cod. Unico Acta.- Codigo único acta (formado por clave expte+numorden+digito) VALOR INDICE.", alias='Cod. Unico Acta'),
            QgsField('Carta'         , QMetaType.Type.QString,'', 25,0, u"Carta.- Recibe carta SI/NO.", alias='Carta'),
            QgsField('FechaLAP'      , QMetaType.Type.QString,'', 25,0, u"Fecha Firma LAP.- Fecha Firma Levantamiento Actas Previas.", alias='Fecha Firma LAP'),
            QgsField('horaCitaLAP'   , QMetaType.Type.QString,'', 25,0, u"Hora Cita LAP.- Hora Cita Levantamiento Actas Previas.", alias='Hora Cita LAP'),
            QgsField('firmaLAP'      , QMetaType.Type.QString,'', 25,0, u"Firma LAP.- Firma Levantamiento actas Previas SI/NO.", alias='Firma LAP'),
            QgsField('firmaJP'       , QMetaType.Type.QString,'', 25,0, u"Firma JP.- Firma Justiprecio SI/NO.", alias='Firma LAP'),
            QgsField('JuradoRV'      , QMetaType.Type.QString,'', 25,0, u"Jurado Reg. Val.- Acude a Jurado de Valoraciones SI/NO.", alias='Jurado Reg. Val'),
            QgsField('ImporteDP'     , QMetaType.Type.Double,'', 10,2, u"Importe Dep. Previo.- Importe Depósito Previo.", alias='Importe Dep. Previo'),
            QgsField('RenunciaDP'    , QMetaType.Type.QString,'', 25,0, u"Renuncia Dep. Previo.- Renuncia Dep. Prev. SI/NO.", alias='Renuncia Dep. Previo'),
            QgsField('Intereses'     , QMetaType.Type.Double,'', 10,2, u"Importe Intereses Demora.- Importe Intereses Demora.", alias='Importe Intereses Demora'),
            QgsField('ResolJudi'     , QMetaType.Type.QString,'',255,0, u"Resolucion Judicial.- Datos Resolución Judicial.", alias='Resolucion Judicial'),
            QgsField('DiaPago'       , QMetaType.Type.QString,'', 25,0, u"Fecha Pago.- Fecha de Pago.", alias='Fecha Pago'),
            QgsField('Observaciones' , QMetaType.Type.QString,'',255,0, u"Observaciones.- ", alias='Observaciones'),
            
            
            # DATOS CAPA PARA GML (INCLUYE RESTO-S- DE PARCELA CATASTRAL)
            QgsField('TIPORES'      , QMetaType.Type.QString,'', 25,0, u"TIPO PARCELA.- 'EXPRO', 'RESTO', 'DESCUENTO'", alias='TIPO PARCELA'),
            QgsField('CAT_NMSPC'    , QMetaType.Type.QString,'', 25,0, u"Dato Namespace.- 'ES.SDGC.CP', 'ES.LOCAL.CP'", alias='Dato Namespace'),
            QgsField('AREA_PARTE'   , QMetaType.Type.Double,'', 10,2, u"Superficie de la parte", alias='Superficie de la parte'),
            QgsField('X_LABEL'      , QMetaType.Type.Double,'', 10,2, u"X_LABEL. - X para etiquetado", alias='X_LABEL'),
            QgsField('Y_LABEL'      , QMetaType.Type.Double,'', 10,2, u"X_LABEL. - Y para etiquetado", alias='X_LABEL')
        ])
            
            
        # Commit changes
        vl.commitChanges()
        return vl


    def copiaFeatToLayer(self, iface, codigo, destLYR, vlayer, alias):
        # Se copian los elementos de layerResultName0 a layerResultName
        pr = destLYR.dataProvider()
        destfield_names = [field.name() for field in destLYR.fields()]
        srcfield_names = [field.name() for field in vlayer.fields()]

        destLYR.startEditing()
        sourceLYR = vlayer

        values = [1]
        newIndex = 1
        for feat in destLYR.getFeatures():
            attrs = feat.attributes()
            if isinstance(attrs[0], int) == True:
                values.append(attrs[0])

        if len(values) != 0:
            newIndex = max(values) + 1
        else:
            newIndex = 1

        for feature in sourceLYR.getFeatures():
            fet = QgsFeature(destLYR.fields())
            fet.setGeometry(feature.geometry())
            concepto = 'DP CARRETERA'
            pol = 's/d'
            par = 's/d'
            calificacion = 's/d'
            tipopropi = '0'
            for field in destLYR.fields():
                if field.name() == 'fid':
                    fet.setAttribute('fid', newIndex)
                    newIndex += 1
                    continue
                if sourceLYR.fields().indexFromName(field.name()) != -1:
                    fet.setAttribute(field.name(), feature[field.name()])

                # Cálculo de campos
                concepto = 'DP CARRETERA'
                pol = 's/d'
                par = 's/d'
                calificacion = 's/d'
                tipopropi = '0'
                for aliascampo in alias:
                    if aliascampo in destfield_names and alias[aliascampo] in srcfield_names:
                        fet.setAttribute(aliascampo, feature[alias[aliascampo]])

                    if aliascampo == 'RC14' and feature['TIPORES'] != 'DESCUENTO':
                        RC14 = feature[alias['RC14']]
                        if RC14[5].isalpha():   # Parcela Rústica
                            pol = RC14[6:9]
                            par = RC14[9:14]
                            if RC14[10] == '9':
                                tipopropi = '2' # Parcela Rústica DP
                                calificacion = 'X'
                            else:               # Parcela Rústica Privada
                                tipopropi = '0'
                                calificacion = 'R'
                        else:                   # Parcela Urbana
                            pol = RC14[:5]
                            par = RC14[5:7]
                            calificacion = 'U'
                            tipopropi = '0'
            # print (feature['RC14'], calificacion, 'tipopropi', '0')

            # fet.setAttribute('no_orden'    , '0')           #"Nº Orden.- Número de orden de la finca relativo al proyecto; único para cada finca dentro del expediente. Numérico: 1, 2,3…"
            # fet.setAttribute('cod_term_m'  , codigo)      #"Cod. Term. Municipal.- Código del término municipal donde radica la finca (ver tabla adjunta)"
            fet.setAttribute('EXPEDIENTE'   , 'EXP_EXPRO')
            # fet.setAttribute('term_munic'  , 'TTMM')
            fet.setAttribute('pedanía'      , 's/d')       #"Pedanía.- En caso de que el término municipal esté dividido en pedanías, nombre de la pedanía donde se ubica la finca."
            fet.setAttribute('pol'          , pol)         #"Poligono.- Polígono catastral donde se ubica la finca."
            fet.setAttribute('par'          , par)         #"Parcela.- Parcela catastral donde se ubica la finca."
            fet.setAttribute('subpar'       , 's/d')       #"SubParcela.- Subparcela catastral donde ubica la finca (en caso de existir)."
            # fet.setAttribute('RC14'        , 0)           #"Ref. Catrastal.- Referencia catastral."
            fet.setAttribute('dirfinca'     , 's/d')       #"Dirección.- Para aquellas fincas de las que se disponga de este dato."
            fet.setAttribute('paraje'       , 's/d')       #"Paraje.- Donde se encuentra la finca."
            fet.setAttribute('uso'          , 's/d')       #"Uso.- Uso del terreno de la finca."
            fet.setAttribute('concepto'     , concepto)    #"Concepto.- Dentro del proyecto a realizar, uso que se le dará al terreno; usado sobre todo por IACLM; ejemplo EDAR, línea eléctrica, tubería…"
            fet.setAttribute('tipopropi'    , tipopropi)   #"Propiedad Pública.- 0 en caso de propiedad privada, 1 en caso de propiedad a nombre de la JCCM y 2 en caso de propiedad pública no JCCM."
            # fet.setAttribute('supcat'      , 0)           #"Superf. Catastral Comp.- Superficie completa de la finca según el catastro en metros cuadrados."
            fet.setAttribute('calificacion' , calificacion)#"Calificación.- Urbana (U) o Rústica (R). Toda la columna de contener o R o U. Si es Domini Público poner R."
            fet.setAttribute('superfpd'     , feature.geometry().area())
            fet.setAttribute('AREA_PARTE'   , feature.geometry().area())
            fet.setAttribute('X_LABEL'      , feature.geometry().centroid().asPoint()[0])
            fet.setAttribute('Y_LABEL'      , feature.geometry().centroid().asPoint()[1])

            pr.addFeatures( [ fet ] )

        destLYR.updateExtents()
        destLYR.commitChanges()

        QgsProject.instance().removeMapLayer(vlayer)


    def GeneraConsMasivaCAT(self):
        # Analiamos si la lista de REFCAT tiene alguna entrada
        start = timeit.default_timer()
        text = 'CREANDO FICH. CONSULTA MASIVA CATASTRO ...'
        self.lblINFO.setText(text)
        self.progressBar.setValue(0)
        
        listaRCs = []
        for feat in self.layerResultFIN.getFeatures():
            if feat['TIPORES'] == 'EXPRO':
                listaRCs.append(feat['RC14'])
        
        if len(listaRCs) < 1:
            self.fun.showMessage("No hay elementos en la lista")
            QApplication.restoreOverrideCursor()   
            return
        
        # Creación de fichero de consulta XML
        ###############################################################
        ###                  CONTROL    qué fichero                 ###
        ###############################################################
        xml_salida_file= 'c:/temp/CATASTRO_ENVIO.XML'

        # Establecemos la fecha
        now = datetime.datetime.now()
        fecha = now.strftime("%d/%m/%y")
        
        # Introducir FINALIDAD
        qid = QInputDialog()
        qid.setWindowIcon(QIcon(f":/plugins/jccm_bar4/iconos/jccm_EXPINTPARC.jpg"))

        title = "CONSULTA MASIVA CATASTRO - FINALIDAD -"
        label = "FINALIDAD: --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---"
        mode = QLineEdit.EchoMode.Normal
        default = "CONSULTA COLINDANTES A CARRETERA "
        finalidad, ok = QInputDialog.getText(qid, title, label, mode, default)
        if ok == False:
            QApplication.restoreOverrideCursor()
            return
        
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        
        filexml = open(xml_salida_file, 'w')
        PLANTILLA_1  = u'<?xml version="1.0" encoding="UTF-8"?>\n'
        PLANTILLA_1 += u'   <LISTADATOS>\n'
        PLANTILLA_1 += u'       <FEC>%s</FEC>\n'%fecha
        PLANTILLA_1 += u'       <FIN>%s</FIN>\n'%finalidad
        filexml.writelines(PLANTILLA_1) # Añade el encabezamiento al GML

            
        for rc in listaRCs:
            linXml = u'       <DAT><RC>%s</RC></DAT>\n'%rc
            filexml.writelines(linXml) # Añade el dato RC al XML

        PLANTILLA_2 = u'   </LISTADATOS>\n'
        filexml.writelines(PLANTILLA_2) # Añade el final al XML
        self.lblINFO.setText('Fichero dest. CONS.CATASTRO:   '+xml_salida_file)
        
        stop = timeit.default_timer()
        tiempo = 'Tiempo: '+"%0.2f"%(stop - start)+' seg.'
        self.progressBar.setValue(100)
        text = 'CREADO FICH. CONSULTA MASIVA CATASTRO'
        self.lblINFO.setText('FICH: '+xml_salida_file)
        self.fun.showMessage(text+'\n\n'+tiempo)
        
        QApplication.restoreOverrideCursor()   




'''
# RELACIÓN DE DATOS DEL PARCELARIO DICTADO POR LOS SSJJ DE LA CONSEJERÍA
# ----------------------------------------------------------------------
# Datos pensados para una hoja excel
# DATOS PARCELA CATASTRAL
# CAMPO         ,ALIAS                      ,DESCRIPCIÓN
'no_orden',     u"Nº Orden",                u"Nº Orden.- Número de orden de la finca relativo al proyecto; único para cada finca dentro del expediente. Numérico: 1, 2,3…"
'cod_term_m',   u"Cod. Term. Municipal",    u"Cod. Term. Municipal.- Código del término municipal donde radica la finca (ver tabla adjunta)"
'pedanía',      u"Pedanía",                 u"Pedanía.- En caso de que el término municipal esté dividido en pedanías, nombre de la pedanía donde se ubica la finca."
    DSA - LBI - - DT - NEM
    DSA - LBI - - DT - LOCS - LOUS - LOURB - DIR - TV+NV+PNP+PLP - #PEDANIA DISEMINADOS
'pol',          u"Polígono",                u"Poligono.- Polígono catastral donde se ubica la finca."
'par',          u"Parcela",                 u"Parcela.- Parcela catastral donde se ubica la finca."
'subpar',       u"SubParcela",              u"SubParcela.- Subparcela catastral donde ubica la finca (en caso de existir)."
'RC14',         u"Ref. Catastral",          u"Ref. Catrastal.- Referencia catastral."
    DSA - RC
'dirfinca',     u"Dirección Finca",         u"Dirección.- Para aquellas fincas de las que se disponga de este dato."
    DSA - LBI - BIE - DTR
'paraje',       u"Paraje",                  u"Paraje.- Donde se encuentra la finca."
    DSA - LBI - BIE - DT - LOCS - LOUS - LORUS - NPA #----- Solo RÚSTICOS
'uso',          u"Uso",                     u"Uso.- Uso del terreno de la finca."
    DSA - LBI - BIE - IBI - USO                #----- Solo URBANOS
'concepto'      u"Concepto",                u"Concepto.- Dentro del proyecto a realizar, uso que se le dará al terreno; usado sobre todo por IACLM; ejemplo EDAR, línea eléctrica, tubería…"
'tipopropi'     u"P. Pública",              u"Propiedad Pública.- 0 en caso de propiedad privada, 1 en caso de propiedad a nombre de la JCCM y 2 en caso de propiedad pública no JCCM."
'supcat'        u"Superf. Catastral Comp.", u"Superf. Catastral Comp.- Superficie completa de la finca según el catastro en metros cuadrados."
'calificacion'  u"Calificación",            u"Calificación.- Urbana (U) o Rústica (R). Toda la columna de contener o R o U. Si es Domini Público poner R."
    DSA - LBI - BIE - IBI - TIP
# DATOS LEVANTAMIENTO DE ACTAS
'registro',     u"Registro",                u"Registro.- Datos registrales que se rellenarán en caso de ser conocidos."
'tomo',         u"Tomo",                    u"Tomo, Datos registrales que se rellenarán en caso de ser conocidos."
'libro',        u"Libro",                   u"Libro, Datos registrales que se rellenarán en caso de ser conocidos."
'folio',        u"Folio",                   u"Folio, Datos registrales que se rellenarán en caso de ser conocidos."
'finca',        u"Finca",                   u"Finca, Datos registrales que se rellenarán en caso de ser conocidos."
'inscripcion',  u"Inscripción",             u"Inscripción, Datos registrales que se rellenarán en caso de ser conocidos. "
'suoregcomp',   u"Superf. Reg. Comp.",      u"Superficie Registral Completa.- Datos registrales que se rellenarán en caso de ser conocidos."
# DATOS SUPERFICIES EXPROPIACIÓN
'superfpd',     u"Superf. P.D.",            u"Superf. P.D.- Superficie en metros cuadrados a ser expropiada en pleno dominio."
'valorunitpd',  u"Valor Unit. P.D.",        u"Valor Unit. P.D.- Valor unitario por metro cuadrado que supone la expropiación en pleno dominio de esta finca."
'importepd',    u"Importe P.D.",            u"Importe P.D.- Importe total a abonar por la parte expropiada en pleno dominio."
'superfot',     u"Superf. O.T.",            u"Superf. O.T.- Superficie en metros cuadrados a ser expropiada en ocupación temporal."
'valorunitot',  u"Valor Unit. O.T.",        u"Valor Unit. O.T.- Valor unitario por metro cuadrado que supone la expropiación en ocupación temporal de esta finca."
'importeot',    u"Importe O.T.",            u"Importe O.T.- Importe total a abonar por la parte expropiada en ocupación temporal."
'superfsp',     u"Superf. S.P.",            u"Superf. S.P.- Superficie en metros cuadrados a ser expropiada en servidumbre de paso."
'valorunitsp',  u"Valor Unit. S.P.",        u"Valor Unit. S.P.- Valor unitario por metro cuadrado que supone la expropiación en servidumbre de paso de esta finca."
'importesp',    u"Importe S.P.",            u"Importe S.P.- Importe total a abonar por la parte expropiada en servidumbre de paso."
'superfsv',     u"Superf. S.V.",            u"Superf. S.V.- Superficie en metros cuadrados a ser expropiada en servidumbre de vuelo."
'valorunitsv',  u"Valor Unit. S.V.",        u"Valor Unit. S.V.- Valor unitario por metro cuadrado que supone la expropiación en servidumbre de vuelo de esta finca."
'importesv',    u"Importe S.V.",            u"Importe S.V.- Importe total a abonar por la parte expropiada en servidumbre de vuelo."
# DATOS TITULARES
'titularnombre',u"Titular Nombre",          u"Nombre del Titular.- Nombre del titular de la finca o del derecho SI ES PERSONA JURÍDICA, SOLO SE USA EL CAMPO NOMBRE."
'titularapel',  u"Titular Apellidos",       u"Apellidos del Titular.- Apellidos del titular de la finca o del derecho."
'titlardninif', u"DNI/NIF",                 u"DNI/NIF.- Dni o Nif del titular de la finca."
'titulardir',   u"Dirección Notificaciones",u"Dirección Notificaciones.- Dirección donde el titular quiere que se envíen las notificaciones."
'codpostal',    u"Cod  Postal",             u"Código Postal"
'poblacion',    u"Población",               u"Población"
'"provincia'     u"Provincia",              u"Provincia""
'porcpropiedad',u"% Propiedad",             u"% Propiedad.- Tanto por ciento de propiedad sobre la finca que tiene el titular; 100 en caso de titular único, 0 en caso de desconocimiento ,-1 en caso de arrendatario, -2 en caso de usufructuario  y -3 en caso de concesionario."
# DATOS ARRENDATARIOS
'derecho',      u"Derecho",                 u"Derecho.- Derecho por el que se indemniza al arrendatario."
'superfder',    u"Superf. D.",              u"Superf. D.- Superficie en metros cuadrados a ser expropiados que afectan al derecho correspondiente."
'valorunitder', u"Valor Unit. D.",          u"Valor Unit. D.- Valor unitario por metro cuadrado que supone la expropiación del derecho correspondiente."
'importeder',   u"Importe D.",              u"Importe D.- Importe total a abonar por la parte expropiada que afecta al derecho correspondiente."



        ############################################################
        ############################################################
        ########## CONSULTA DE MUNICIPIOS DESDE CAPA
        ############################################################
        ############################################################
            
        processing.run("native:selectbylocation", {
                        'INPUT' : capaTMcatastro,
                        'INTERSECT' : capaExpro,
                        'METHOD' : 0,
                        'PREDICATE' : [0]
                        })
        layer=layerEXIST[0]
        feats = layer.selectedFeatures()
        numfeats = layer.selectedFeatureCount()
        if numfeats == 0:
            feats = layer.getFeatures()
            numfeats = layer.featureCount()

        muniAfec = []
        root = QgsProject.instance().layerTreeRoot()
        listcapaCatastro=[]


        listaTM = []
        for feature in feats:
            paso = 2
            text1 = u'PASO 2. OBTENIENDO DATOS DE TTMM'
            self.iface.mainWindow().statusBar().showMessage(text1)
            self.lblINFO.setText(text1)
            self.progressBar.setValue(100 * paso/numpasos)
            self.fun.wait(0.5)
            # print ( text1)

            #attrs = feature.attributes()
            valCampoProv = feature['DELEGACIO']
            valCampoMuni = feature['MUNICIPIO']
            muniAfec.append([valCampoProv,valCampoMuni])
            codigo_provincia = self.fun.completarCeros(str(valCampoProv),2)
            codigo_muni_ine = self.fun.completarCeros(str(valCampoMuni),3)

            # CONSULTA DE NOMBRE PROVINCIA DESDE COD_PROV - Se mete en functions.py
            try:
                nombre_prov = self.fun.consultaCatastroCodProvtoProvincia(codigo_provincia)
            except:
                QApplication.restoreOverrideCursor()
                resp = self.fun.showMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(herrExpro_creaExpteEXPRO.py-133- self.fun.consultaCatastroCodProvtoProvincia)','','Capas de Catastro' )
                self.iface.mainWindow().statusBar().clearMessage()
                QApplication.restoreOverrideCursor()
                return

            # CONSULTA DE LOS MUNICIPIOS DE LA PROVINCIA
            try:
                result = self.fun.consultaCatastroCodMunitoMunicipio(nombre_prov, codigo_muni_ine)
            except:
                QApplication.restoreOverrideCursor()
                resp = self.fun.showMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(herrExpro_creaExpteEXPRO.py-158 except1- self.fun.consultaCatastroCodMunitoMunicipio lin:159)','','Capas de Catastro' )
                self.iface.mainWindow().statusBar().clearMessage()
                QApplication.restoreOverrideCursor()
                return
            if result[0] == "ERROR":
                QApplication.restoreOverrideCursor()
                resp = self.fun.showMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(herrExpro_creaExpteEXPRO.py-164 except2- self.fun.consultaCatastroCodMunitoMunicipio)','','Capas de Catastro' )
                self.iface.mainWindow().statusBar().clearMessage()
                QApplication.restoreOverrideCursor()
                return
            nombre_muni = result[0]
            codigo_muni_final = self.fun.completarCeros(result[1],3)
            nombre_muni = str(nombre_muni)
            codigo = self.fun.completarCeros(codigo_provincia,2) + codigo_muni_final
            nombregrupo = "CAT - " + nombre_muni + " - " + codigo + " - (WEB)"
            listaTM.append(u'%s %s %s'%(codigo_provincia,codigo_muni_final, nombre_muni))


        ############################################################
        ############################################################
        ########## CONSULTA DE MUNICIPIOS DESDE CAPA
        ############################################################
        ############################################################
            
        processing.run("native:selectbylocation", {
                        'INPUT' : capaTMcatastro,
                        'INTERSECT' : capaExpro,
                        'METHOD' : 0,
                        'PREDICATE' : [0]
                        })
        layer=layerEXIST[0]
        feats = layer.selectedFeatures()
        numfeats = layer.selectedFeatureCount()
        if numfeats == 0:
            feats = layer.getFeatures()
            numfeats = layer.featureCount()

        muniAfec = []
        root = QgsProject.instance().layerTreeRoot()
        listcapaCatastro=[]


        listaTM = []
        for feature in feats:
            paso = 2
            text1 = u'PASO 2. OBTENIENDO DATOS DE TTMM'
            self.iface.mainWindow().statusBar().showMessage(text1)
            self.lblINFO.setText(text1)
            self.progressBar.setValue(100 * paso/numpasos)
            self.fun.wait(0.5)
            # print ( text1)

            #attrs = feature.attributes()
            valCampoProv = feature['DELEGACIO']
            valCampoMuni = feature['MUNICIPIO']
            muniAfec.append([valCampoProv,valCampoMuni])
            codigo_provincia = self.fun.completarCeros(str(valCampoProv),2)
            codigo_muni_ine = self.fun.completarCeros(str(valCampoMuni),3)

            # CONSULTA DE NOMBRE PROVINCIA DESDE COD_PROV - Se mete en functions.py
            try:
                nombre_prov = self.fun.consultaCatastroCodProvtoProvincia(codigo_provincia)
            except:
                QApplication.restoreOverrideCursor()
                resp = self.fun.showMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(herrExpro_creaExpteEXPRO.py-133- self.fun.consultaCatastroCodProvtoProvincia)','','Capas de Catastro' )
                self.iface.mainWindow().statusBar().clearMessage()
                QApplication.restoreOverrideCursor()
                return

            # CONSULTA DE LOS MUNICIPIOS DE LA PROVINCIA
            try:
                result = self.fun.consultaCatastroCodMunitoMunicipio(nombre_prov, codigo_muni_ine)
            except:
                QApplication.restoreOverrideCursor()
                resp = self.fun.showMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(herrExpro_creaExpteEXPRO.py-158 except1- self.fun.consultaCatastroCodMunitoMunicipio lin:159)','','Capas de Catastro' )
                self.iface.mainWindow().statusBar().clearMessage()
                QApplication.restoreOverrideCursor()
                return
            if result[0] == "ERROR":
                QApplication.restoreOverrideCursor()
                resp = self.fun.showMessageYESNO( '- NO HAY RESPUESTA DE CATASTRO -\n'+'(herrExpro_creaExpteEXPRO.py-164 except2- self.fun.consultaCatastroCodMunitoMunicipio)','','Capas de Catastro' )
                self.iface.mainWindow().statusBar().clearMessage()
                QApplication.restoreOverrideCursor()
                return
            nombre_muni = result[0]
            codigo_muni_final = self.fun.completarCeros(result[1],3)
            nombre_muni = str(nombre_muni)
            codigo = self.fun.completarCeros(codigo_provincia,2) + codigo_muni_final
            nombregrupo = "CAT - " + nombre_muni + " - " + codigo + " - (WEB)"
            listaTM.append(u'%s %s %s'%(codigo_provincia,codigo_muni_final, nombre_muni))
'''
