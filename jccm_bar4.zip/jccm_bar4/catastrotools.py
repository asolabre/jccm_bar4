﻿# -*- coding: utf-8 -*-
'''
/***************************************************************************
catastrotools.py
                                 A QGIS4 plugin
Plugin:     catastroesp - Catastro de España
Purpose:        Tools for plugin catastroesp
        --------------------------------------------------------------------
        begin                : 2016-06-07
        validacion transfQG4 : 2026-10-22
        git sha              : $Format:%H$
        Codigo Corregido     : Agustín Solabre
        email                : agusass@hotmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
'''


from qgis.PyQt.QtGui import QCursor, QIcon, QPixmap, QPainter, QDesktopServices
from qgis.PyQt.QtCore import Qt, QSettings, QUrl, QEventLoop, QTimer
from qgis.PyQt.QtNetwork import QNetworkRequest
from qgis.PyQt.QtWidgets import (
    QApplication, QDialog, QGraphicsPixmapItem, QGraphicsView, QGraphicsScene
)

from qgis.gui import QgsMapTool
from qgis.core import (
    QgsFeature, QgsProject, QgsVectorLayer, QgsLayerTreeLayer, QgsGeometry,
    QgsPointXY, QgsVectorDataProvider, QgsField, QgsWkbTypes,
    QgsNetworkAccessManager
)

import urllib.parse

from xml.etree import cElementTree as ElementTree
from xml.dom import minidom
from xml.dom.minidom import parseString

from osgeo import ogr, osr

import os
import json
import locale
from time import sleep

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES


# Cargamos la clase del menú dialogo de Parcela catastral
from .catastroParcelaINFO import catastroParcelaINFODialog

locale.setlocale(locale.LC_ALL, 'ESP')


class catastroCargaMuni(QgsMapTool):
    # Carga del catastro de todo un municipio pinchado
    # ------------------------------------------------
    def __init__(self, canvas, iface, action):

        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.fun = Functions()
        self.qs = QSettings()
        self.conf = configuration()

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        cursor = QCursor()
        cursor.setShape(Qt.CursorShape.CrossCursor)
        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action
        self.url_catastro_municipios = self.qs.value(
            f'{self.nombre_plugin}/CATASTRO/url_catastro_municipio')
        if self.url_catastro_municipios is None:
            self.url_catastro_municipios = self.conf.catastro_tool['url_catastro_municipios']
            self.qs.setValue(
                f"{self.nombre_plugin}/CATASTRO/url_catastro_municipios",
                self.url_catastro_municipios)
        QApplication.restoreOverrideCursor()

    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        pass

    def canvasReleaseEvent(self, event):
        # ICONO DE ESPERA
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        progress = 'Cargando datos desde CATASTRO {txt}...'.format(txt='')
        self.iface.mainWindow().statusBar().showMessage(progress)

        year = self.qs.value(f'{self.nombre_plugin}/CATASTRO/cat_year')
        if year is None:
            year = self.conf.catastro_tool['cat_year']
            self.qs.setValue(f"{self.nombre_plugin}/CATASTRO/cat_year", year)
        year = str(year)

        cat_dir_shps = self.qs.value(f'{self.nombre_plugin}/CATASTRO/cat_dir_shps')
        if cat_dir_shps is None:
            cat_dir_shps = self.conf.catastro_tool['cat_dir_shps']
            self.qs.setValue(f"{self.nombre_plugin}/CATASTRO/cat_dir_shps", cat_dir_shps)

        origenData = 'web'

        # Get the click
        x = event.pos().x()
        y = event.pos().y()

        srs = self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        # CONSULTA DE RC POR COORDENADAS DIST - Se mete en functions.py
        try:
            result = self.fun.consultaCatastroXYDISTtoRC(point[0], point[1], srs)
        except:
            QApplication.restoreOverrideCursor()
            resp = self.fun.showMessageYESNO(
                '- NO HAY RESPUESTA DE CATASTRO -\n'
                '(catastrotools-114- self.fun.consultaCatastroXYDISTtoRC)',
                '', 'Capas de Catastro')
            self.iface.mainWindow().statusBar().clearMessage()
            return
        if result[0] == u'ERROR':
            QApplication.restoreOverrideCursor()
            self.iface.mainWindow().statusBar().clearMessage()
            return
        codigo_provincia = result[5]
        codigo_muni_ine = result[6]

        # CONSULTA DE NOMBRE PROVINCIA DESDE COD_PROV
        try:
            nombre_prov = self.fun.consultaCatastroCodProvtoProvincia(codigo_provincia)
        except:
            QApplication.restoreOverrideCursor()
            resp = self.fun.showMessageYESNO(
                '- NO HAY RESPUESTA DE CATASTRO -\n'
                '(catastrotools-133- self.fun.consultaCatastroCodProvtoProvincia)',
                '', 'Capas de Catastro')
            self.iface.mainWindow().statusBar().clearMessage()
            return

        # CONSULTA DE LOS MUNICIPIOS DE LA PROVINCIA
        try:
            result = self.fun.consultaCatastroCodMunitoMunicipio(nombre_prov, codigo_muni_ine)
        except:
            QApplication.restoreOverrideCursor()
            resp = self.fun.showMessageYESNO(
                '- NO HAY RESPUESTA DE CATASTRO -\n'
                '(catastrotools-158 except1- self.fun.consultaCatastroCodMunitoMunicipio)',
                '', 'Capas de Catastro')
            self.iface.mainWindow().statusBar().clearMessage()
            return

        if result[0] == 'ERROR':
            QApplication.restoreOverrideCursor()
            resp = self.fun.showMessageYESNO(
                '- NO HAY RESPUESTA DE CATASTRO -\n'
                '(catastrotools-164 except2- self.fun.consultaCatastroCodMunitoMunicipio)',
                '', 'Capas de Catastro')
            self.iface.mainWindow().statusBar().clearMessage()
            return

        nombre_muni = result[0]
        codigo_muni = result[1]
        nombre_muni = str(nombre_muni)

        mess = True
        cargaIface = True
        self.fun.cargaCatastroMuni(
            codigo_provincia, codigo_muni, nombre_muni,
            origenData, year, self.iface, mess, cargaIface)

        QApplication.restoreOverrideCursor()
        self.iface.mainWindow().statusBar().clearMessage()

    def activate(self):
        pass

    def deactivate(self):
        pass

    def isZoomTool(self):
        return False

    def isTransient(self):
        return False

    def isEditTool(self):
        return False


class catastroToolINF(QgsMapTool):
    # -----------  PERMITE IDENTIFICAR UNA PARCELA CATASTRAL AL PINCHARLA  -----------

    def __init__(self, canvas, iface, action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.fun = Functions()
        self.qs = QSettings()
        self.conf = configuration()

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        cursor = QCursor()
        cursor.setShape(Qt.CursorShape.CrossCursor)
        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action
        self.url_catastro_municipios = self.qs.value(
            f'{self.nombre_plugin}/CATASTRO/url_catastro_municipio')
        if self.url_catastro_municipios is None:
            self.url_catastro_municipios = self.conf.catastro_tool['url_catastro_municipios']
            self.qs.setValue(
                f"{self.nombre_plugin}/CATASTRO/url_catastro_municipios",
                self.url_catastro_municipios)

        self.dlg = catastroParcelaINFODialog(iface)

        QApplication.restoreOverrideCursor()
        self.dlg.setFixedSize(550, 500)
        self.dlg.btnIMGcatastro.setEnabled(False)
        self.dlg.btnIMGcatastro.clicked.connect(self.setIMGcatastro)

        ## Acceso a Registradores (botón REGPROP)
        self.dlg.btnREGPROP.hide()
        self.dlg.btnREGPROP.setEnabled(False)
        self.dlg.lblDatosREGISTRO.hide()
        self.dlg.btnREGPROP.clicked.connect(self.abrirRegistradores)

        self._scene = QGraphicsScene(self.dlg)
        self.dlg.gvImagenCAT.setScene(self._scene)

    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        pass

    def setIMGcatastro(self):
        foto = getattr(self.dlg, '_fotoFachada', None)
        if foto is None:
            self.dlg.btnIMGcatastro.setEnabled(False)
            return

        self.dlg.setFixedSize(900, 500)

        item = QGraphicsPixmapItem(foto)
        self._scene.clear()
        self._scene.addItem(item)

        self.dlg.gvImagenCAT.fitInView(item, Qt.AspectRatioMode.KeepAspectRatio)
        self.dlg.gvImagenCAT.setTransformationAnchor(
            QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.dlg.gvImagenCAT.setResizeAnchor(
            QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.dlg.gvImagenCAT.setRenderHint(
            QPainter.RenderHint.SmoothPixmapTransform)

        self.dlg.btnIMGcatastro.setEnabled(False)

    def _descargarFotoFachada(self, rc14):
        """
        Descarga la foto de fachada del Catastro.
        Devuelve un QPixmap si existe, o None si no hay imagen o hay error.
        """
        url = ("http://ovc.catastro.meh.es/OVCServWeb/OVCWcfLibres/"
               "OVCFotoFachada.svc/RecuperarFotoFachadaGet?"
               f"ReferenciaCatastral={rc14}.jpeg")

        nam = QgsNetworkAccessManager.instance()
        request = QNetworkRequest(QUrl(url))
        reply = nam.get(request)

        loop = QEventLoop()
        reply.finished.connect(loop.quit)
        QTimer.singleShot(10000, loop.quit)
        loop.exec()

        if reply.error():
            reply.deleteLater()
            return None

        img_data = reply.readAll()
        reply.deleteLater()

        # Descartamos imágenes absurdamente pequeñas
        if len(img_data) < 2000:
            return None

        pixmap = QPixmap()
        if not pixmap.loadFromData(img_data):
            return None

        return pixmap

    def canvasReleaseEvent(self, event):
        # ICONO DE ESPERA
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        progress = 'Cargando parcela catastral {txt}...'.format(txt='')
        self.iface.mainWindow().statusBar().showMessage(progress)

        # Get the click
        x = event.pos().x()
        y = event.pos().y()
        srs = self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        # CONSULTA DE RC POR COORDENADAS
        try:
            result = self.fun.consultaCatastroXYtoRC(point[0], point[1], srs)
        except:
            QApplication.restoreOverrideCursor()
            resp = self.fun.showMessageYESNO(
                '- NO HAY RESPUESTA DE CATASTRO -',
                '', 'Capas de Catastro')
            self.iface.mainWindow().statusBar().clearMessage()
            return

        if result[0] == u'ERROR' or result[0] == 'E' or result[0] is None:
            QApplication.restoreOverrideCursor()
            self.iface.mainWindow().statusBar().clearMessage()
            return

        RC14 = result[0]
        xml_txt = result[1]
        pc1 = result[2]
        pc2 = result[3]
        ldt = result[4]
        cp = ''
        cm = ''

        if pc1[5] == 'A' or pc1[5] == 'B':
            # RC rústica
            if pc2[3] == '9':
                tipoPAR = u'X-Descuento'
            else:
                tipoPAR = u'RU-Rústica'
            cpo = pc1[6] + pc2[0:2]
            cpa = pc2[2:7]
            HOJA = pc1[0:6]
        else:
            # RC urbana / diseminados
            if ldt[0:14] == 'TN DISEMINADOS':
                tipoPAR = u'DI- Diseminado'
            else:
                tipoPAR = u'UR-Urbana'
            cpo = pc1[0:5]
            cpa = pc1[5:7]
            HOJA = pc2

        codnomPRO = ''
        codnomMUN = ''
        message = ''
        listaSUBP = ''
        listaCONSTRU = ''
        supTOTAL = 0
        supCONSTR = 0
        DATOSURBA = ''
        cp = 0
        cm = ''
        cmc = 0
        REFCAT = RC14
        cn = 'N'
        cv = ''
        pnp = 0
        np = ''
        nm = ''
        CAT_NMSPC = 'ES.SDGC.CP'
        PARAJE = 's/d'
        direccion = ldt
        codine = str(cp) + str(cm)

        # Se ejecuta la consulta a catastro datos dado un RC
        result = self.fun.consultaCatastroDATPARCELA(RC14, 'SI')

        if result[:5] == 'ERROR':
            message = result
            listaSUBP = result
            listaCONSTRU = result
            QApplication.restoreOverrideCursor()
            self.iface.mainWindow().statusBar().clearMessage()
        else:
            codnomPRO = result[1]
            codnomMUN = result[2]
            message = result[3]
            listaSUBP = result[4]
            listaCONSTRU = result[5]
            supTOTAL = result[6]
            supCONSTR = result[7]
            DATOSURBA = result[8]
            cp = result[9]
            cm = result[10]
            cmc = result[11]
            REFCAT = result[12]
            cn = result[13]
            cpo = result[14]
            cpa = result[15]
            cv = result[16]
            pnp = result[17]
            np = result[18]
            nm = result[19]
            CAT_NMSPC = 'ES.SDGC.CP'
            PARAJE = result[21]
            direccion = ldt
            codine = str(cp) + str(cm)

        # URL info catastral en SEC
        url = self.qs.value(f'{self.nombre_plugin}/CATASTRO/url_catastro_InfoWEB')
        if url is None:
            url = self.conf.catastro_tool['url_catastro_InfoWEB']
            self.qs.setValue(
                f"{self.nombre_plugin}/CATASTRO/url_catastro_InfoWEB", url)

        params = {'del': cp, 'mun': cmc, 'RefC': REFCAT}
        str_values = {}
        for k, v in params.items():
            str_values[k] = str(v)          # urlencode codifica a UTF-8 internamente
        data = urllib.parse.urlencode(str_values)
        urlSEC = url + data

        # Obtener datos registrales si existen
        resultadoReg = self.fun.getCatastroCoordRegistro(REFCAT, cp, cmc)

        if resultadoReg[0]:
            COORDINADA = True
            REGFECOORD = resultadoReg[1]
            REGPROP = resultadoReg[2]
            REGCRU = resultadoReg[3]
        else:
            COORDINADA = False
            REGFECOORD = resultadoReg[1]
            REGPROP = resultadoReg[2]
            REGCRU = resultadoReg[3]

        # Atributos de la parcela
        nombrecapa = 'PARCELAS CATASTRALES'

        atributosDICT = {
            'RC14': RC14, 'PCAT1': pc1, 'PCAT2': pc2,
            'EJERCICIO': 0, 'NUM_EXP': 0, 'CONTROL': 0, 'COORY': 0, 'VIA': cv,
            'NUMERO': pnp, 'NUMERODUP': 0, 'NUMSYMBOL': 0, 'AREA': 0,
            'FECHAALTA': 0, 'FECHABAJA': 0, 'MAPA': 0, 'DELEGACIO': cp,
            'MUNICIPIO': cmc, 'MASA': cpo, 'HOJA': pc2, 'TIPO': cn,
            'PARCELA': cpa, 'COORX': 0, 'NOM_MUNI': nm, 'CAT_NMSPC': CAT_NMSPC,
            'DIRECCION': ldt, 'PROVINCIA': np, 'REF_CAT': REFCAT,
            'COD_INE': codine, 'PARAJE': PARAJE,
            'COORDINADA': COORDINADA, 'REGFECOORD': REGFECOORD,
            'REGPROP': REGPROP, 'REGCRU': REGCRU
        }
        result = self.fun.cargarCapaParcelaCatastral(
            RC14, nombrecapa, atributosDICT, 'shp', srs)

        if result[0] == 'ERROR':
            QApplication.restoreOverrideCursor()
            return
        layer = result[0]
        supTOTAL = result[1]

        # Lista de valores para el diálogo
        listaVALORES = [
            RC14,        # 0
            tipoPAR,     # 1
            codnomPRO,   # 2
            codnomMUN,   # 3
            ldt,         # 4
            message,     # 5
            listaSUBP,   # 6
            listaCONSTRU,  # 7
            supTOTAL,    # 8
            supCONSTR,   # 9
            DATOSURBA,   # 10
            urlSEC,      # 11
            REFCAT       # 12
        ]

        result = self.rundialogparcela(listaVALORES, atributosDICT)
        QApplication.restoreOverrideCursor()
        self.iface.mainWindow().statusBar().clearMessage()

    def activate(self):
        pass

    def deactivate(self):
        pass

    def isZoomTool(self):
        return False

    def isTransient(self):
        return False

    def isEditTool(self):
        return False

    def rundialogparcela(self, listaVALORES, atributosDICT):
        # Relleno de campos del diálogo
        self.dlg.logo.setPixmap(
            QPixmap(f':/plugins/{self.nombre_plugin}/iconos/catastroesp.jpg'))
        self.dlg.setWindowIcon(
            QIcon(f':/plugins/{self.nombre_plugin}/iconos/cat_identificador.jpg'))

        self.dlg.valREFCAT.setText(listaVALORES[0])
        self.dlg.valTIPO.setText(listaVALORES[1])
        self.dlg.valPROVINCIA.setText(listaVALORES[2])
        self.dlg.valMUNICIPIO.setText(listaVALORES[3])
        self.dlg.valSITUACION.setText(listaVALORES[4])
        self.dlg.valCUENTAS.setText(listaVALORES[5])
        self.dlg.valSUBPARC.setText(''.join(listaVALORES[6]))
        self.dlg.valCONSTRU.setText(''.join(listaVALORES[7]))

        self.dlg.valSUPTOTAL.setText(u'SUP: %s m2' % str(listaVALORES[8]))
        self.dlg.valSUPCONS.setText(u'SUP.Const: %s m2' % str(listaVALORES[9]))
        self.dlg.lblDATOSURBA.setText(listaVALORES[10])
        self.dlg.enlaceWEB.setText(
            u'<html><head/><body><p><a href="' + listaVALORES[11] +
            u'"><span style=" text-decoration: underline; color:#0000ff;">' +
            listaVALORES[12] + u'</span></a></p></body></html>')

        # Datos registrales
        if atributosDICT['COORDINADA']:
            txtDatosREGISTRO = (
                f"COORD: {atributosDICT['REGFECOORD']} "
                f"CRU:{atributosDICT['REGCRU']} "
                f"RP: {atributosDICT['REGPROP']}")
            self.dlg.lblDatosREGISTRO.setText(txtDatosREGISTRO)
            self.dlg.lblDatosREGISTRO.setStyleSheet(
                "background-color: #DFFF6F; "
                "border: 1px solid #00AA07; "
            )
            self.dlg.btnREGPROP.show()
            self.dlg.btnREGPROP.setEnabled(True)
            self.dlg.lblDatosREGISTRO.show()

            self.dlg._REGCRU = atributosDICT['REGCRU']
            self.dlg._REGPROP = atributosDICT['REGPROP']
            self.dlg._REGFECOORD = atributosDICT['REGFECOORD']
            self.dlg._COORDINADA = True
        else:
            self.dlg.lblDatosREGISTRO.setText(
                'PARCELA NO COORDINADA CON REGISTRO (según CATASTRO)')
            self.dlg.lblDatosREGISTRO.setStyleSheet("")
            self.dlg.btnREGPROP.hide()
            self.dlg.lblDatosREGISTRO.show()
            self.dlg._REGCRU = None
            self.dlg._REGPROP = None
            self.dlg._REGFECOORD = None
            self.dlg._COORDINADA = False

        # Resetear estado del diálogo para nueva consulta
        self.dlg.setFixedSize(550, 500)
        self._scene.clear()
        self.dlg.btnIMGcatastro.show()

        # Descargar foto de fachada ANTES de abrir el diálogo
        rc14 = listaVALORES[0][:14]
        foto = self._descargarFotoFachada(rc14)

        if foto is not None:
            self.dlg._fotoFachada = foto
            self.dlg.btnIMGcatastro.setEnabled(True)
        else:
            self.dlg._fotoFachada = None
            self.dlg.btnIMGcatastro.setEnabled(False)

        QApplication.restoreOverrideCursor()
        result = self.dlg.exec()

        if result:
            pass

    def abrirRegistradores(self):
        cru = getattr(self.dlg, '_REGCRU', None)
        if not cru:
            self.fun.showMessageERR("No hay CRU disponible para esta parcela.")
            return
        url = self.qs.value(f'{self.nombre_plugin}/CATASTRO/url_RegPROP_IDUFIR')
        if url is None:
            url = self.conf.catastro_tool['url_RegPROP_IDUFIR']
            self.qs.setValue(
                f"{self.nombre_plugin}/CATASTRO/url_RegPROP_IDUFIR", url)
        QDesktopServices.openUrl(QUrl(url + cru))


class catastroBorraParc(QgsMapTool):
    # -----------  PERMITE BORRAR UNA PARCELA CATASTRAL AL PINCHARLA  -----------

    def __init__(self, canvas, iface, action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.fun = Functions()
        self.qs = QSettings()
        self.conf = configuration()

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        cursor = QCursor()
        cursor.setShape(Qt.CursorShape.CrossCursor)
        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action
        QApplication.restoreOverrideCursor()

    def canvasReleaseEvent(self, event):
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        progress = 'Borrado de parcela catastral'
        self.iface.mainWindow().statusBar().showMessage(progress)

        x = event.pos().x()
        y = event.pos().y()
        srs = self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        try:
            layerPARC = QgsProject.instance().mapLayersByName(
                'PARCELAS CATASTRALES')[0]
        except:
            QApplication.restoreOverrideCursor()
            text = u'NO HAY PARCELA CARGADA EN ESTA POSICIÓN'
            self.fun.showMessage(text)
            return

        MyPnt = QgsGeometry.fromPointXY(QgsPointXY(point[0], point[1]))
        feats = layerPARC.getFeatures()
        feature = None
        for feat in feats:
            if MyPnt.intersects(feat.geometry()):
                feature = feat
        try:
            print(feature['RC14'])
        except:
            QApplication.restoreOverrideCursor()
            text = u'NO HAY PARCELA CARGADA EN ESTA POSICIÓN'
            self.fun.showMessage(text)
            return

        RC14sel = feature['RC14']

        caps = layerPARC.dataProvider().capabilities()
        if caps & QgsVectorDataProvider.Capability.DeleteFeatures:
            dfeats = []
            featureslayerPARC = layerPARC.getFeatures()

            for featLayerPARC in featureslayerPARC:
                RC14 = featLayerPARC['RC14']
                if RC14 == RC14sel:
                    dfeats.append(featLayerPARC.id())

            res = layerPARC.dataProvider().deleteFeatures(dfeats)
            progress = 'Borrado de parcela catastral %s' % (RC14)
            self.iface.mainWindow().statusBar().showMessage(progress)

            layerPARC.triggerRepaint()
            layerPARC.updateExtents()

        QApplication.restoreOverrideCursor()


class catastroASIGNA_RC(QgsMapTool):
    # -----------  ASIGNAR ATRIBUTOS DE PARCELA CATASTRAL A LA CAPA ACTIVA EN EL PUNTO PINCHADO  -----------

    def __init__(self, canvas, iface, action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.fun = Functions()
        self.qs = QSettings()
        self.conf = configuration()

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        cursor = QCursor()
        cursor.setShape(Qt.CursorShape.CrossCursor)
        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action
        QApplication.restoreOverrideCursor()

    def canvasReleaseEvent(self, event):
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        progress = 'Asignando atributos de parcela catastral'
        self.iface.mainWindow().statusBar().showMessage(progress)

        x = event.pos().x()
        y = event.pos().y()
        srs = self.iface.mapCanvas().mapSettings().destinationCrs().authid()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        try:
            result = self.fun.consultaCatastroXYtoRC(point[0], point[1], srs)
        except:
            QApplication.restoreOverrideCursor()
            resp = self.fun.showMessageYESNO(
                '- NO HAY RESPUESTA DE CATASTRO -',
                '', 'Capas de Catastro')
            self.iface.mainWindow().statusBar().clearMessage()
            return

        if result[0] == u'ERROR' or result[0] == 'E' or result[0] is None:
            QApplication.restoreOverrideCursor()
            self.iface.mainWindow().statusBar().clearMessage()
            return

        RC14 = result[0]
        xml_txt = result[1]
        pc1 = result[2]
        pc2 = result[3]
        ldt = result[4]
        cp = ''
        cm = ''

        if pc1[5] == 'A' or pc1[5] == 'B':
            if pc2[3] == '9':
                tipoPAR = u'X-Descuento'
            else:
                tipoPAR = u'RU-Rústica'
            cpo = pc1[6] + pc2[0:2]
            cpa = pc2[2:7]
            HOJA = pc1[0:6]
        else:
            if ldt[0:14] == 'TN DISEMINADOS':
                tipoPAR = u'DI- Diseminado'
            else:
                tipoPAR = u'UR-Urbana'
            cpo = pc1[0:5]
            cpa = pc1[5:7]
            HOJA = pc2

        codnomPRO = ''
        codnomMUN = ''
        message = ''
        listaSUBP = ''
        listaCONSTRU = ''
        supTOTAL = 0
        supCONSTR = 0
        DATOSURBA = ''
        cp = 0
        cm = ''
        cmc = 0
        REFCAT = RC14
        cn = 'N'
        cv = ''
        pnp = 0
        np = ''
        nm = ''
        CAT_NMSPC = 'ES.SDGC.CP'
        direccion = ldt
        codine = str(cp) + str(cm)

        result = self.fun.consultaCatastroDATPARCELA(RC14, 'SI')

        if result[:5] == 'ERROR':
            message = result
            listaSUBP = result
            listaCONSTRU = result
            QApplication.restoreOverrideCursor()
            self.iface.mainWindow().statusBar().clearMessage()
        else:
            codnomPRO = result[1]
            codnomMUN = result[2]
            message = result[3]
            listaSUBP = result[4]
            listaCONSTRU = result[5]
            supTOTAL = result[6]
            supCONSTR = result[7]
            DATOSURBA = result[8]
            cp = result[9]
            cm = result[10]
            cmc = result[11]
            REFCAT = result[12]
            cn = result[13]
            cpo = result[14]
            cpa = result[15]
            cv = result[16]
            pnp = result[17]
            np = result[18]
            nm = result[19]
            CAT_NMSPC = 'ES.SDGC.CP'
            direccion = ldt
            codine = str(cp) + str(cm)

        atributosDICT = {
            'RC14': RC14,
            'PCAT1': pc1,
            'PCAT2': pc2,
            'EJERCICIO': 0,
            'NUM_EXP': 0,
            'CONTROL': 0,
            'COORY': 0,
            'VIA': cv,
            'NUMERO': pnp,
            'NUMERODUP': 0,
            'NUMSYMBOL': 0,
            'AREA': supTOTAL,
            'FECHAALTA': 0,
            'FECHABAJA': 0,
            'MAPA': 0,
            'DELEGACIO': cp,
            'MUNICIPIO': cmc,
            'MASA': cpo,
            'HOJA': pc2,
            'TIPO': cn,
            'PARCELA': cpa,
            'COORX': 0,
            'NOM_MUNI': nm,
            'CAT_NMSPC': CAT_NMSPC,
            'DIRECCION': ldt,
            'PROVINCIA': np,
            'REF_CAT': REFCAT,
            'COD_INE': codine
        }
        self.asignaAtribCatastro(point, atributosDICT)

        QApplication.restoreOverrideCursor()

    def asignaAtribCatastro(self, point, atributosDICT):
        # Se asignan los atributos al polígono de la capa activa en el punto pinchado
        layer = self.iface.activeLayer()

        if not layer:
            self.fun.showMessageERR("No hay ninguna capa activa.")
            QApplication.restoreOverrideCursor()
            return

        if layer.geometryType() != QgsWkbTypes.GeometryType.PolygonGeometry:
            self.fun.showMessageERR(
                f"La capa activa {layer.name()} no es de tipo polígono.")
            QApplication.restoreOverrideCursor()
            return

        # Convertir todos los nombres de atributos a mayúsculas
        atributosDICT = {k.upper(): v for k, v in atributosDICT.items()}

        # Obtener los campos de la capa en un diccionario {NOMBRE_MAYUS: QgsField}
        fields = layer.fields()
        fields_dict = {field.name().upper(): field for field in fields}

        # Campos obligatorios y sus tipos (usar tipo nativo de Python)
        campos_obligatorios = {'RC14': str, 'CAT_NMSPC': str}

        nuevos_campos = []
        for campo, tipo in campos_obligatorios.items():
            if campo not in fields_dict:
                nuevos_campos.append(QgsField(campo, tipo))

        if nuevos_campos:
            layer.startEditing()
            layer.dataProvider().addAttributes(nuevos_campos)
            layer.updateFields()
            layer.commitChanges()

            fields = layer.fields()
            fields_dict = {field.name().upper(): field for field in fields}

        # Buscar el polígono en el punto pinchado
        point_geometry = QgsGeometry.fromPointXY(QgsPointXY(point))

        layer.startEditing()

        try:
            for feature in layer.getFeatures():
                if feature.geometry().contains(point_geometry):
                    for field_name, value in atributosDICT.items():
                        field_name_upper = field_name.upper()
                        if field_name_upper in fields_dict:
                            field = fields_dict[field_name_upper]
                            field_type_name = field.typeName().lower()

                            # Convertir valor al tipo correcto según el tipo del campo
                            try:
                                if field_type_name in ('integer', 'int', 'integer64', 'longlong'):
                                    value_conv = int(value)
                                elif field_type_name in ('double', 'real'):
                                    value_conv = float(value)
                                elif field_type_name in ('boolean', 'bool'):
                                    value_conv = bool(value)
                                else:
                                    value_conv = str(value)

                                feature.setAttribute(field.name(), value_conv)
                            except (ValueError, TypeError):
                                print(f'No se pudo convertir {value} a '
                                      f'{field.name()} ({field.typeName()})')

                    layer.updateFeature(feature)
                    layer.commitChanges()
                    self.fun.showMessage(
                        f"Atributos asignados correctamente\n\n"
                        f"RC {feature[fields_dict['RC14'].name()]}")
                    return

            layer.rollBack()
            self.fun.showMessageERR(
                "No se encontró ningún polígono en el punto pinchado.")

        except Exception as e:
            layer.rollBack()
            self.fun.showMessageERR(f"Error al modificar la capa: {str(e)}")

        QApplication.restoreOverrideCursor()