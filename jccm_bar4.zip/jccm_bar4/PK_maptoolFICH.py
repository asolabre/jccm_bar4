# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           PK_maptoolFICH.py
Purpose:

        --------------------------------------------------------------------
        begin                : 2020-10-02
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import QIcon, QColor, QCursor
from qgis.PyQt.QtCore import QVariant, Qt, QSettings, QTranslator, QCoreApplication, QRect, QMetaType
from qgis.PyQt.QtWidgets import QAction, QApplication, QWidget, QPushButton, QMessageBox, QToolButton, QMenu, QDialogButtonBox, QLabel, QTableWidget, QTableWidgetItem, QTextEdit

from qgis.gui import QgsMapTool,QgsVertexMarker, QgsDialog
from qgis.core import (QgsProject, QgsVectorLayer, QgsField, QgsFeature, QgsGeometry, QgsWkbTypes, QgsPoint,
                    QgsPointXY, QgsLineString, QgsMapLayer)
from qgis.utils import iface

import os, glob, codecs

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .PK_info_dialog import Form_PK_info
from .PK_balizas_carretera import balizas_carreteraDialog

nombre_plugin = os.path.basename(os.path.dirname(__file__))
# VARIABLES
srcVal = QSettings().value(f"{nombre_plugin}/GENERAL/EPSG")
dest_path = QSettings().value(f"{nombre_plugin}/LRS/bal_dest_path")
nom_layer = QSettings().value(f"{nombre_plugin}/LRS/bal_nom_layer")
estiloCAPA = os.path.join(os.path.dirname(__file__), QSettings().value(f"{nombre_plugin}/LRS/bal_estiloCAPA"))

dest_path = 'en memoria'


class PkToolFICH(QgsMapTool):
    def __init__(self,canvas,iface,action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.fun = Functions()
        
        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        cursor = QCursor()
        cursor.setShape(Qt.CursorShape.CrossCursor)
        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action


    def canvasReleaseEvent(self, event):
        #Get the click
        x = event.pos().x()
        y = event.pos().y()

        # Comprobamos el tipo de capa
        layer = self.iface.activeLayer()

        text2=''
        tittle="ERROR"
        if not layer or layer.type() != QgsMapLayer.VectorLayer:
            text = u'SELECCIONE UNA CAPA DE LINEAS'
            self.fun.showMessageERR( text,text2,tittle)
            return

        geom_type = layer.geometryType()
        if geom_type != QgsWkbTypes.LineGeometry:
            text = u"La capa '"+ layer.name()  + u' no es de tipo LINEA \n\n'
            text += u"SELECCIONE UNA CAPA DE LINEAS"
            self.fun.showMessageERR( text,text2,tittle)
            return

        geomTypeString = QgsWkbTypes.displayString(QgsWkbTypes.Type(layer.wkbType()))

        # print (layer.name(), layer.type(), geomTypeString)

        tipos = ['LINESTRING', 'MULTILINESTRING', 'LINESTRINGZ', 'MULTILINESTRINGZ', 'LINESTRINGM', 'MULTILINESTRINGM', 'LINESTRINGZM', 'MULTILINESTRINGZM', 'LINESTRING25D', 'MULTILINESTRING25D', 'MULTICURVE', 'MULTICURVE', 'MULTICURVEM', 'MULTICURVEZ', 'MULTICURVEZM']
        tipoCapa = 0    # tipoCapa = 1: Capa de carreteras estandard / tipoCapa = 0 :Capa de lineas de cualquier tipo
        if geomTypeString.upper() not in tipos:
            text = u"La capa '"+ layer.name()  + u"' es de tipo " + geomTypeString + u'\n\n'
            text += u"SELECCIONE UNA CAPA DE LINEAS"
            self.fun.showMessageERR( text,text2,tittle)
            return
        else:
            field_names_tipo=['idMatricula', 'Matricula', 'Longitud', 'PkINI', 'PkFin', 'Matricula_Plan', 'Titularidad', 'Funcionalidad',
                    'Tipologia_DobleC', 'Tipologia_UnaC', 'Denominacion', 'Long_Km', 'idOrdenCtra', 'Origen', 'Destino', 'Provincia']
            fields = layer.fields()
            # field_names = [field.name() for field in fields]
            field_names = [field.name().lower() for field in fields]
            capa = layer.name() + ' -  TIPO: '+ geomTypeString
            tipoCapa = 1
            for field in field_names_tipo:      # Se comprueba si la capa tiene todos los campos de la capa de carreteras estandard
                # if field not in field_names:
                if field.lower() not in field_names:
                    # print (f'field: {field} no existe en la capa')
                    tipoCapa = 0
                    break

        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        self.getPointPK(point,self.iface, layer, tipoCapa)


    def getPointPK(self,point,iface, layer, tipoCapa):
        carretera_pk = self.fun.pointToPKfich(point,iface,'SI', 'NO', tipoCapa)
        #return         0        1         2        3          4        5        6         7,        8        9       10
        #return [the_road, m_final, the_road, funcion, atributos, distEJE, acimEJE, pointEJE, geometry, distINI, distFIN]

        if carretera_pk is not None:
            MuniProv = self.fun.getCARTOCMuniProv(carretera_pk[7], self.iface, pintar='NO')
            atributos = self.renombrar_clavesMinMay(carretera_pk[4]) ## Se cambian los atributos a sus mayusculas si no las tienen
            carretera_pk[4] = atributos
            geometry = carretera_pk[8]
            longGeom = carretera_pk[8].length()

            Zmdt = 0

            if tipoCapa == 1:
                # PRESENTACIÓN DE RESULTADOS TIPO CARRETERA ESTANDARD
                self.PK_info = Form_PK_info(self, self.iface.mapCanvas(), carretera_pk)

                self.PK_info.Matricula_plan.setText(atributos['nombre'])
                if str(carretera_pk[1]) != 'nan':
                    self.PK_info.pk_pinchado.setText(self.fun.mostrarPK(carretera_pk[1],2))
                else:
                    self.PK_info.pk_pinchado.setText(str(round(carretera_pk[9],5)))
                self.PK_info.distEje.setText(str(round(carretera_pk[5],2)))
                self.PK_info.acimEje.setText(str(round(carretera_pk[6],4)))
                self.PK_info.cotaEje.setText(str(round(Zmdt,3)))
                self.PK_info.Titularidad.setText(atributos['titulard'])
                self.PK_info.Funcionalidad.setText(atributos['ordend'])
                self.PK_info.Provincia.setText(MuniProv[1])
                self.PK_info.tmunicipal.setText(MuniProv[0])
                self.PK_info.Idmatricula.setText(" (Idmat:" + str(atributos['id_vial']) + ")")
                self.PK_info.FuenteDatos.setText('FUENTE: '+layer.name())
                self.PK_info.Denominacion.setText(atributos['Denominacion'])
                self.PK_info.PkINI.setText(self.fun.mostrarPK(atributos['PkINI'],2))
                self.PK_info.PkFin.setText(self.fun.mostrarPK(atributos['PkFIN'],2))
                self.PK_info.Origen.setText(atributos['Origen'])
                self.PK_info.Destino.setText(atributos['Destino'])
                self.PK_info.Longitud.setText(str(round(atributos['Longitud'],2)) + " m.")
                self.PK_info.Long_Km.setText(str(round(atributos['Long_Km'],3)) + " Km.")
                # Longitudes del elemento
                self.PK_info.Long_Geom.setText(str(round(longGeom,2)) + " m.")      # Longitud del elemento
                self.PK_info.Long_FIN_INI.setText(str(round((atributos['PkFIN']-atributos['PkINI'])*1000,2)) + " m.")
                # self.PK_info.Tipologia_DobleC.setText(atributos['Tipologia_DobleC'])
                # self.PK_info.Tipologia_UnaC.setText(atributos['Tipologia_UnaC'])
                # self.PK_info.idOrdenCtra.setText(str(atributos['idOrdenCtra']))

                self.PK_info.DistINI.setText(str(round(carretera_pk[9],3)))
                self.PK_info.DistFIN.setText(str(round(carretera_pk[10],3)))
                self.PK_info.XE.setText(str(round(carretera_pk[7][0],2)))
                self.PK_info.YE.setText(str(round(carretera_pk[7][1],2)))
                self.PK_info.ZE.setText(str(round(Zmdt,3)))
                self.PK_info.XP.setText(str(round(point[0],2)))
                self.PK_info.YP.setText(str(round(point[1],2)))

                # Establecemos el color de la etiqueta CARRETERA
                # COLORES CARRETERAS
                color_morado  = '255,0,255'
                color_naranja = '255,127,0'
                color_verde   = '0,255,0'
                color_amarillo= '255,255,0'
                color_blanco  = '255,255,255'
                color_azul  = '1,103,200'
                color_rojo  = '255,50,50'
                color_negro = '0,0,0'

                colorF = color_blanco
                colorT = color_negro
                if atributos['Titularidad'] == 'JCCM' and atributos['Funcionalidad'] == 'Básica alta capacidad':
                    colorF = color_morado
                    colorT = color_negro
                elif atributos['Titularidad'] == 'JCCM' and atributos['Funcionalidad'] == 'Básica':
                    colorF = color_naranja
                    colorT = color_negro
                elif atributos['Titularidad'] == 'JCCM' and atributos['Funcionalidad'] == 'Comarcal':
                    colorF = color_verde
                    colorT = color_negro
                elif atributos['Titularidad'] == 'JCCM' and atributos['Funcionalidad'] == 'Local':
                    colorF = color_amarillo
                    colorT = color_negro
                elif atributos['Titularidad'] == 'JCCM' and atributos['Funcionalidad'] == 'Travesía':
                    colorF = color_amarillo
                    colorT = color_negro
                elif atributos['Titularidad'] == 'JCCM' and atributos['Funcionalidad'] == 'Ramal':
                    colorF = color_amarillo
                    colorT = color_negro
                elif atributos['Titularidad'] == 'Estatal' and atributos['Funcionalidad'] == 'Básica alta capacidad':
                    colorF = color_azul
                    colorT = color_blanco
                elif atributos['Titularidad'] == 'Estatal' and atributos['Funcionalidad'] == 'Básica':
                    colorF = color_rojo
                    colorT = color_blanco

                self.PK_info.Matricula_plan.setStyleSheet("background: rgb(" +colorF+ " );border: 2px solid black ; color: rgb(" +colorT+ " );border-radius:7px;")
                self.PK_info.pk_pinchado.setStyleSheet("background: rgb(" +color_blanco+ " );border: 1px solid black; border-radius:7px;")

                # Se ejecuta el menu PK_info
                result = self.PK_info.exec()
                
            else:
                # PRESENTACIÓN DE RESULTADOS EN MENÚ BÁSICO
                # return [the_road, m_final, the_road, funcion, atributos, distEJE, acimEJE, pointEJE, geometry, distINI, distFIN]
                text=u"DATOS DE ELEMENTO"
                listaGeometria =  '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt; font-weight:600;">'
                listaGeometria += 'SISTEMA DE COORDENADAS:  %s\n'%(self.iface.mapCanvas().mapSettings().destinationCrs().authid())
                listaGeometria += '</span></p>'
                listaGeometria += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt; font-weight:600;">'
                listaGeometria += ' Longitud =  %s\n'%(str(round(longGeom,2)))
                listaGeometria += '</span></p>'
                listaGeometria += '<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-size:8pt;">'
                listaGeometria += '      X           /      Y           /   M   /  dif \n'
                listaGeometria += '</span></p>'
                listaGeometria += self.fun.makeHtmlListCoord(geometry)

                camposATTRS = []
                for campo, valor in atributos.items():
                    # print(campo, valor)
                    elem  = campo + ':' +str(valor)
                    camposATTRS.append(elem)
                coordMouse = ' X= {}, Y= {}'.format(round(point[0],2),round(point[1],2))
                capa = layer.name()
                elemId = ''

                if str(carretera_pk[1]) != 'nan':
                    pk = 'PK= '+str(round(carretera_pk[1],2))
                else:
                    pk = 's/d'

                distINIFIN = 'Dist.INI= '+str(round(carretera_pk[9],2)) + '  -  Dist.FIN= '+str(round(carretera_pk[10],2))

                self.showDialogPK(text, listaGeometria, camposATTRS, coordMouse, capa, elemId, pk, distINIFIN, "JCCM")

        else:
            message = u"--- Se debe aproximar más a una carretera ---"
            self.fun.showMessage( message,'','Identificador de Carreteras' )


    def showDialogPK(self, text,listaGeometria,listaDatos, coordMouse, capa, elemId, pk, distINIFIN, tittle="JCCM"):
        main_window = self.iface.mainWindow()
        dialog = QgsDialog(main_window,
                           fl=Qt.WindowFlags(),
                           buttons=QDialogButtonBox.StandardButton.NoButton,
                           orientation=Qt.Orientation.Vertical)
        dialog.setWindowTitle("LISTADO DE COORDENADAS LINEA")
        dialog.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/logo_general.jpg'))
        dialog.resize(630, 420)

        # Etiquetas
        labelCoordPinch = QLabel(dialog)
        labelCoordPinch.setGeometry(QRect(5, 5, 510, 20))
        labelCoordPinch.setAlignment(Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignLeft)
        labelCoordPinch.setText("COORDENADAS CURSOR: " + coordMouse)
        labelCapa = QLabel(dialog)
        labelCapa.setGeometry(QRect(5, 25, 390, 20))
        labelCapa.setAlignment(Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignLeft)
        labelCapa.setText("CAPA: " + capa)
        labelElemento = QLabel(dialog)
        labelElemento.setGeometry(QRect(5, 45, 510, 20))
        labelElemento.setAlignment(Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignLeft)
        labelElemento.setText("ELEMENTO: " + elemId)
        labelPk = QLabel(dialog)
        labelPk.setGeometry(QRect(400, 25, 510, 20))
        labelPk.setAlignment(Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignLeft)
        if pk == None:
            labelPk.setText(' --- ')
        else:
            labelPk.setText('PK: '.format(pk))
        labeldistINIFIN = QLabel(dialog)
        labeldistINIFIN.setGeometry(QRect(400, 45, 510, 20))
        labeldistINIFIN.setAlignment(Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignLeft)
        labeldistINIFIN.setText(distINIFIN)

        # Tabla de atributos
        tableWidget = QTableWidget(dialog)
        tableWidget.setGeometry(QRect(5, 65, 360, 340))
        tableWidget.setObjectName("tableWidget")
        tableWidget.setColumnCount(2)
        tableWidget.setRowCount(len(listaDatos))
        tableWidget.setColumnWidth( 0, 100)
        tableWidget.setColumnWidth( 1, 300)
        tableWidget.setHorizontalHeaderLabels (['CAMPO      ', 'VALOR ATRIBUTO    '])
        j=0
        for data in listaDatos:
            dataDescomp = data.split(':')
            tableWidget.setItem(j, 0,  QTableWidgetItem(dataDescomp[0]))
            tableWidget.setItem(j, 1, QTableWidgetItem(dataDescomp[1]))
            j+=1

        # Listado de Coordenadas
        textEdit = QTextEdit(dialog)
        textEdit.setGeometry(QRect(370, 65, 255, 340))
        textEdit.setObjectName("textEdit")
        textEdit.setHtml(listaGeometria)

        QApplication.restoreOverrideCursor()
        dialog.show()


    def renombrar_clavesMinMay(self, diccionario):
        """
        Renombra las claves de un diccionario si coinciden con las claves en el alias.

        :param diccionario: Diccionario original.
        :return: Nuevo diccionario con claves renombradas.
        """

        # Lista de alias
        # alias: Lista de tuplas con pares (clave_original, clave_nueva).
        alias = [
            ('matricula', 'Matricula'),
            ('idmatricula', 'idMatricula'),
            ('matricula_plan', 'Matricula_Plan'),
            ('titularidad', 'Titularidad'),
            ('funcionalidad', 'Funcionalidad'),
            ('provincia', 'Provincia'),
            ('denominacion', 'Denominacion'),
            ('pkini', 'PkINI'),
            ('origen', 'Origen'),
            ('pkfin', 'PkFin'),
            ('destino', 'Destino'),
            ('tipologia_doblec', 'Tipologia_DobleC'),
            ('tipologia_unac', 'Tipologia_UnaC'),
            ('longitud', 'Longitud'),
            ('long_km', 'Long_Km'),
            ('idordenctra', 'idOrdenCtra'),
            ('shape_stlength__', 'Shape_STLength__'),
            ('objectid', 'OBJECTID')
        ]

        # Crear un mapa de alias para acceso rápido
        alias_dict = dict(alias)

        # Renombrar claves verificando en alias
        diccionarioRenom = {alias_dict.get(clave, clave): valor for clave, valor in diccionario.items()}

        return diccionarioRenom


class PkBalizaToolFICH(QgsMapTool):

    def __init__(self,canvas,iface,action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.fun = Functions()
        cursor = QCursor()
        cursor.setShape(Qt.CursorShape.CrossCursor)

        # POSIBLE SOLUCIOB DE SNAPPING
        # for item in QgsMapLayerRegistry.instance().mapLayers().values():
            # QgsProject.instance().setSnapSettingsForLayer(item.id(), False, 2, 0, 2, True)

        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action
        self.dlgBalizaPK = balizas_carreteraDialog(iface)


    def canvasReleaseEvent(self, event):
        #Get the click
        x = event.pos().x()
        y = event.pos().y()

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        layerAct = self.iface.activeLayer()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        # print self.snap(layerAct, point, QgsSnapper.SnapToSegment, 10)

        # print "map position", point

        self.getBalizaPK(point,self.iface)

        pass


    def getBalizaPK(self,point,iface):
        if dest_path == 'en memoria':
            dest = 'memory'
        else:
            # dest = os.path.splitext(dest_path) + os.path.splitext( nom_layer.replace(' ', '_') ) + ".shp"
            dest = dest_path + nom_layer.replace(' ', '_') + ".shp"
        # print dest

        tipo_layer= "point"
        # src= "crs=epsg:25830"
        src= "crs=epsg:"+str(srcVal)

        # Comprobamos si existe la capa
        # layerEXIST = QgsMapLayerRegistry.instance().mapLayersByName(nom_layer)
        layerEXIST = QgsProject.instance().mapLayersByName(nom_layer)

        if not layerEXIST or layerEXIST[0].featureCount() == 0:
            if layerEXIST and layerEXIST[0].featureCount() == 0:
                vl = layerEXIST[0]
                # QgsMapLayerRegistry.instance().removeMapLayer( vl.id() )
                QgsProject.instance().removeMapLayer( vl.id() )

            # CREACIÓN DE LA CAPA
            if dest == 'memory':
                vl = QgsVectorLayer(tipo_layer+'?'+src, nom_layer, dest)
                # qgis.utils.iface.messageBar().clearWidgets()
                # vl.setCrs(QgsCoordinateReferenceSystem(epsg, QgsCoordinateReferenceSystem.EpsgCrsId))
            else:
                # print (dest)
                if not os.path.isfile(dest):
                    print (u'NO EXISTE %s - HAY QUE CREARLO'%(dest))
                vl = QgsVectorLayer(dest+'|'+tipo_layer+'?'+crs, nom_layer, "ogr")
            pr = vl.dataProvider()
            vl.startEditing()

            # AÑADIMOS LOS CAMPOS
            pr.addAttributes( [ QgsField("CTRA", QMetaType.Type.QString),
                            QgsField("PK", QMetaType.Type.Double),
                            QgsField("CTRA1",  QMetaType.Type.QString),
                            QgsField("idMat", QMetaType.Type.Int),
                            QgsField("DIST", QMetaType.Type.Double),
                            QgsField("ACIM", QMetaType.Type.Double),
                            QgsField("XE", QMetaType.Type.Double),
                            QgsField("YE", QMetaType.Type.Double),
                            QgsField("ZE", QMetaType.Type.Double),
                            QgsField("XP", QMetaType.Type.Double),
                            QgsField("YP", QMetaType.Type.Double),
                            QgsField("ZP", QMetaType.Type.Double),
                            QgsField("DAT1", QMetaType.Type.QString),
                            QgsField("DAT2", QMetaType.Type.QString) ] )

            vl.updateFields()

            # Añade la capa a la TOC
            # QgsMapLayerRegistry.instance().addMapLayer(vl)
            QgsProject.instance().addMapLayer(vl)

            # Establecemos el estilo de la capa
            vl.loadNamedStyle(estiloCAPA)


            # Commit changes
            vl.commitChanges()
            # vl.startEditing()
        else:
            vl = layerEXIST[0]
            # vl.startEditing()

        # Ponemos la capa arriba
        root = QgsProject.instance().layerTreeRoot()
        myvl = root.findLayer(vl.id())
        myvlclone = myvl.clone()
        parent = myvl.parent()
        root.insertChildNode(0, myvlclone)
        parent.removeChildNode(myvl)

        # Hacemos la capa visible
        # qgis.utils.iface.legendInterface().setLayerVisible(vl, True)
        # QgsProject.instance().layerTreeRoot().setLayerVisible(vl, True)
        QgsProject.instance().layerTreeRoot().findLayer(vl.id()).setItemVisibilityChecked(True)

        # carretera_pk = self.fun.pointToPK(point,iface,pintar='NO')
        carretera_pk = self.fun.pointToPK(point,iface,pintar='NO', no9000='SI')

        if carretera_pk is not None:
            ZE = self.fun.Zmdt([carretera_pk[7][0],carretera_pk[7][1]],iface,pintar='NO')
            ZP = self.fun.Zmdt(point,iface,pintar='NO')
            atributos = carretera_pk[4]

            listaVALORES = [atributos['Matricula'],
                            self.fun.mostrarPK(carretera_pk[1],2),
                            atributos['Matricula_Plan'],
                            str(atributos['idMatricula']),
                            str(round(carretera_pk[5],2)),
                            str(round(carretera_pk[6],4)),
                            str(round(carretera_pk[7][0],2)),
                            str(round(carretera_pk[7][1],2)),
                            str(round(ZE,3)),
                            str(round(point[0],2)),
                            str(round(point[1],2)),
                            str(round(ZP,3))
                            ]

            # Se lanza el cuadro de diálogo de la baliza
            result = self.rundialogBalizaPK(listaVALORES)

            # print 'result ',result
            if (result=='CANCEL'):
                QApplication.restoreOverrideCursor()
                vl.commitChanges()
                return
            else:
                vl.startEditing()

            if (result[14]=='ptoEJE'):
                distEJE=0
            else:
                distEJE=carretera_pk[5]

            attr = [atributos['Matricula'],     #Dato 0, Matricula
                    carretera_pk[1],            #Dato 1, Pk
                    atributos['Matricula_Plan'],#Dato 2, Matricula_Plan
                    atributos['idMatricula'],   #Dato 3, idMatricula
                    # carretera_pk[5],
                    distEJE,                    #Dato 4, Dist Eje
                    carretera_pk[6],            #Dato 5, Acimut
                    carretera_pk[7][0],         #Dato 6, XE
                    carretera_pk[7][1],         #Dato 7, YE
                    str(round(ZE,3)),           #Dato 8, ZE
                    point[0],                   #Dato 9, XP
                    point[1],                   #Dato10, YP
                    str(round(ZP,3)),           #Dato11, ZP
                    result[12],                 #Dato12, DATO1
                    result[13]                  #Dato13, DATO2
                    ]

            QApplication.restoreOverrideCursor()

            # Añadimos la geometría
            feat = QgsFeature()
            if (result[14]=='ptoEJE'):
                # feat.setGeometry(QgsGeometry.fromPoint(carretera_pk[7]))
                feat.setGeometry(QgsGeometry.fromPointXY(carretera_pk[7]))
            else:
                # feat.setGeometry(QgsGeometry.fromPoint(point))
                feat.setGeometry(QgsGeometry.fromPointXY(point))
            # Añadimos los atributos
            # attr =[atributos['Matricula'], carretera_pk[1], atributos['Matricula_Plan'], atributos['idMatricula'], carretera_pk[5], carretera_pk[6], carretera_pk[7][0], carretera_pk[7][1], point[0], point[1], '', '']
            feat.setAttributes(attr)
            vl.addFeature(feat)

            vl.commitChanges()

        else:
            QApplication.restoreOverrideCursor()
            message = u"--- Se debe aproximar más a una carretera ---"
            self.fun.showMessage( message,'','Balizador de Carreteras' )

            pass

        pass


    def rundialogBalizaPK(self,listaVALORES):

        self.dlgBalizaPK.Matricula.setText(listaVALORES[0])
        self.dlgBalizaPK.PK.setText(listaVALORES[1])
        self.dlgBalizaPK.Matricula_Plan.setText(listaVALORES[2])
        self.dlgBalizaPK.idMatricula.setText(listaVALORES[3])
        self.dlgBalizaPK.DIST.setText(listaVALORES[4])
        self.dlgBalizaPK.ACIM.setText(listaVALORES[5])
        self.dlgBalizaPK.XE.setText(listaVALORES[6])
        self.dlgBalizaPK.YE.setText(listaVALORES[7])
        self.dlgBalizaPK.ZE.setText(listaVALORES[8])
        self.dlgBalizaPK.XP.setText(listaVALORES[9])
        self.dlgBalizaPK.YP.setText(listaVALORES[10])
        self.dlgBalizaPK.ZP.setText(listaVALORES[11])
        # self.dlgBalizaPK.DAT1.setText(listaVALORES[12])
        # self.dlgBalizaPK.DAT2.setText(listaVALORES[13])

        QApplication.restoreOverrideCursor()
        result = self.dlgBalizaPK.exec()

        # ANALIZAMOS LOS RADIOBUTTON
        if self.dlgBalizaPK.qrbPTOEJE.isChecked():
            tipoPUN = 'ptoEJE'
        if self.dlgBalizaPK.qrbPTOPIN.isChecked():
            tipoPUN = 'ptoPIN'

        # print 'result ',result

        if result != 0:
            return [self.dlgBalizaPK.Matricula.text(),
                    self.dlgBalizaPK.PK.text(),
                    self.dlgBalizaPK.Matricula_Plan.text(),
                    self.dlgBalizaPK.idMatricula.text(),
                    self.dlgBalizaPK.DIST.text(),
                    self.dlgBalizaPK.ACIM.text(),
                    self.dlgBalizaPK.XE.text(),
                    self.dlgBalizaPK.YE.text(),
                    self.dlgBalizaPK.ZE.text(),
                    self.dlgBalizaPK.XP.text(),
                    self.dlgBalizaPK.YP.text(),
                    self.dlgBalizaPK.ZP.text(),
                    self.dlgBalizaPK.DAT1.text(),
                    self.dlgBalizaPK.DAT2.text(),
                    tipoPUN]
        else:
            return 'CANCEL'
            pass

