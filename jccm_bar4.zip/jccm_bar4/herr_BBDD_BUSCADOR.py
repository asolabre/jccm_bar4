# -*- coding: utf-8 -*-
"""
/***************************************************************************
herr_BBDD_BUSCADOR
                                 A QGIS4 plugin
                             -------------------
        begin                : 2026-03-12
        git sha              : $Format:%H$
        Codigo Original     : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

Buscador de registros para la BD de Informes de Expropiaciones
"""

from qgis.PyQt.QtWidgets import QDialog, QMessageBox, QComboBox
from qgis.PyQt.QtCore import Qt, QSettings
from qgis.PyQt import uic

import os

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herr_BBDD_BUSCADOR.ui'))

class herr_BBDD_BUSCADOR(QDialog, FORM_CLASS):
    def __init__(self, parent=None, campos=None, historial=None):
        """Constructor."""
        super(herr_BBDD_BUSCADOR, self).__init__(parent)
        self.setupUi(self)
        
        # Configurar ventana como diálogo modal independiente
        self.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.WindowCloseButtonHint)
        
        # Guardar referencia al padre y campos
        self.parent_dialog = parent
        self.campos = campos or []
        self.historial = historial or []
        
        # Variables de control
        self.texto_busqueda = ""
        self.campo_seleccionado = ""
        self.modo_coincidencia = "Cualquier parte del campo"
        self.resultado = None
        
        # Inicializar combos
        self.inicializarCombos()
        self.cargarHistorial()
        
        # Conectar señales
        self.btnBUSCAR.clicked.connect(self.onBuscarClicked)
        self.btnCANCELAR.clicked.connect(self.onCancelarClicked)
        self.cbxTextoBUSQUEDA.currentTextChanged.connect(self.onHistorialSeleccionado)
        
        # Configurar el combo de texto como editable
        self.cbxTextoBUSQUEDA.setEditable(True)
        self.cbxTextoBUSQUEDA.setInsertPolicy(QComboBox.InsertPolicy.InsertAtTop)  # Insertar nuevos elementos al inicio
        
        # Establecer foco en el campo de texto
        self.cbxTextoBUSQUEDA.setFocus()
    
    def inicializarCombos(self):
        """Inicializa los combos con los valores disponibles"""
        # Limpiar combo de campos
        self.cbxCAMPOS.clear()
        
        # Añadir opción "Cualquier campo" al inicio
        self.cbxCAMPOS.addItem("Cualquier campo")
        
        # Añadir todos los campos disponibles
        if self.campos:
            for campo in sorted(self.campos):
                self.cbxCAMPOS.addItem(campo)
        
        # Configurar combo de coincidencia
        self.cbxCOINCIDENCIA.setCurrentIndex(0)  # "Cualquier parte del campo"
    
    def cargarHistorial(self):
        """Carga el historial de búsquedas en el combo editable"""
        self.cbxTextoBUSQUEDA.clear()
        
        # Añadir el historial al combo
        if self.historial:
            for texto in self.historial:
                self.cbxTextoBUSQUEDA.addItem(texto)
            
            # Establecer el texto más reciente como texto actual (no como selección de ítem)
            self.cbxTextoBUSQUEDA.setCurrentText(self.historial[0])
    
    def onHistorialSeleccionado(self, texto):
        """Cuando se selecciona un elemento del historial"""
        # No hacemos nada especial, solo mostramos el texto seleccionado
        # El texto ya se muestra automáticamente en el combo editable
        pass
    
    def onBuscarClicked(self):
        """Ejecuta la búsqueda sin cerrar el diálogo"""
        # Obtener el texto actual del combo editable
        texto = self.cbxTextoBUSQUEDA.currentText().strip()
        
        if not texto:
            QMessageBox.warning(
                self,
                "Aviso",
                "Por favor, introduzca un texto para buscar.",
                QMessageBox.StandardButton.Ok
            )
            return
        
        # Guardar parámetros de búsqueda
        self.texto_busqueda = texto
        self.campo_seleccionado = self.cbxCAMPOS.currentText()
        self.modo_coincidencia = self.cbxCOINCIDENCIA.currentText()
        
        # Emitir señal o notificar al padre
        self.resultado = True
        
        # No cerramos el diálogo, solo emitimos la búsqueda
        # El padre debe implementar un método para recibir la búsqueda
        if hasattr(self.parent_dialog, 'onBusquedaRealizada'):
            self.parent_dialog.onBusquedaRealizada(self.getParametrosBusqueda())
        
        # Añadir al historial si no existe
        if texto not in self.historial:
            self.historial.insert(0, texto)
            # Mantener solo las últimas 10
            self.historial = self.historial[:10]
            self.actualizarHistorial()
    
    def onCancelarClicked(self):
        """Cancela la búsqueda y cierra el diálogo"""
        self.resultado = False
        self.reject()
    
    def getParametrosBusqueda(self):
        """Devuelve los parámetros de búsqueda seleccionados"""
        return {
            'texto': self.texto_busqueda,
            'campo': self.campo_seleccionado if self.campo_seleccionado != "Cualquier campo" else None,
            'modo': self.modo_coincidencia
        }
    
    def actualizarHistorial(self):
        """Actualiza el combo con el nuevo historial"""
        # Guardar el texto actual
        texto_actual = self.cbxTextoBUSQUEDA.currentText()
        
        self.cbxTextoBUSQUEDA.clear()
        
        # Añadir el historial actualizado
        for texto in self.historial:
            self.cbxTextoBUSQUEDA.addItem(texto)
        
        # Restaurar el texto actual (puede ser el mismo o uno nuevo)
        self.cbxTextoBUSQUEDA.setCurrentText(texto_actual)


# # -*- coding: utf-8 -*-
# """
# /***************************************************************************
# herr_BBDD_BUSCADOR
                                 # A QGIS4 plugin
                             # -------------------
        # begin                : 2026-03-12
        # git sha              : $Format:%H$
        # Codigo Original     : Agustín Solabre (JCCM)
        # email                : gis.carreteras@jccm.es
 # ***************************************************************************/

# Buscador de registros para la BD de Informes de Expropiaciones
# """

# from PyQt5.QtWidgets import QDialog, QMessageBox
# from PyQt5.QtCore import Qt
# from PyQt5 import uic

# import os

# FORM_CLASS, _ = uic.loadUiType(os.path.join(
    # os.path.dirname(__file__), './menus/herr_BBDD_BUSCADOR.ui'))

# class herr_BBDD_BUSCADOR(QDialog, FORM_CLASS):
    # def __init__(self, parent=None, campos=None):
        # """Constructor."""
        # super(herr_BBDD_BUSCADOR, self).__init__(parent)
        # self.setupUi(self)
        
        # # Configurar ventana como diálogo modal independiente
        # self.setWindowModality(Qt.ApplicationModal)
        # self.setWindowFlags(Qt.Dialog | Qt.WindowTitleHint | Qt.WindowCloseButtonHint)
        
        # # Guardar referencia al padre y campos
        # self.parent_dialog = parent
        # self.campos = campos or []
        
        # # Variables de control
        # self.texto_busqueda = ""
        # self.campo_seleccionado = ""
        # self.modo_coincidencia = "Cualquier parte del campo"
        # self.resultado = None
        
        # # Inicializar combos
        # self.inicializarCombos()
        
        # # Conectar señales
        # self.btnBUSCAR.clicked.connect(self.onBuscarClicked)
        # self.btnCANCELAR.clicked.connect(self.onCancelarClicked)
        
        # # Establecer foco en el campo de texto
        # self.lneTextoBUSQUEDA.setFocus()
    
    # def inicializarCombos(self):
        # """Inicializa los combos con los valores disponibles"""
        # # Limpiar combos
        # self.cbxCAMPOS.clear()
        
        # # Añadir opción "Cualquier campo" al inicio
        # self.cbxCAMPOS.addItem("Cualquier campo")
        
        # # Añadir todos los campos disponibles
        # if self.campos:
            # for campo in sorted(self.campos):
                # self.cbxCAMPOS.addItem(campo)
        
        # # Configurar combo de coincidencia
        # self.cbxCOINCIDENCIA.setCurrentIndex(0)  # "Cualquier parte del campo"
    
    # def onBuscarClicked(self):
        # """Ejecuta la búsqueda"""
        # texto = self.lneTextoBUSQUEDA.text().strip()
        
        # if not texto:
            # QMessageBox.warning(
                # self,
                # "Aviso",
                # "Por favor, introduzca un texto para buscar.",
                # QMessageBox.Ok
            # )
            # return
        
        # # Guardar parámetros de búsqueda
        # self.texto_busqueda = texto
        # self.campo_seleccionado = self.cbxCAMPOS.currentText()
        # self.modo_coincidencia = self.cbxCOINCIDENCIA.currentText()
        
        # # Cerrar el diálogo con resultado aceptado
        # self.resultado = True
        # self.accept()
    
    # def onCancelarClicked(self):
        # """Cancela la búsqueda"""
        # self.resultado = False
        # self.reject()
    
    # def getParametrosBusqueda(self):
        # """Devuelve los parámetros de búsqueda seleccionados"""
        # return {
            # 'texto': self.texto_busqueda,
            # 'campo': self.campo_seleccionado if self.campo_seleccionado != "Cualquier campo" else None,
            # 'modo': self.modo_coincidencia
        # }