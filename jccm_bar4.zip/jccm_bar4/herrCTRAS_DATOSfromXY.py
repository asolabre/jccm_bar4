"""
-------------------------------------------------------------------------------
Name:        herrCTRAS_DATOSfromXY.py
Purpose:

Author:           A. Solabre (JCCM)
Comienzo:         25/01/2019
Traducción QGIS3: 29/3/2020


-------------------------------------------------------------------------------
"""

from qgis.PyQt.QtGui import QIcon, QPixmap
from qgis.PyQt.QtCore import Qt, QVariant, QMetaType
from qgis.PyQt.QtWidgets import QDialog, QFileDialog, QApplication

from qgis.PyQt import uic
from qgis.core import Qgis, QgsProject, QgsMapLayer, QgsWkbTypes, QgsVectorLayer, QgsField, QgsMessageLog, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsGeometry, QgsPointXY, QgsVectorFileWriter
from qgis.utils import qgsfunction, reloadPlugin, iface

import os, glob, codecs
from os.path import basename
from osgeo import ogr, osr
from time import sleep

# import urllib2
import urllib
import json
from xml.etree import cElementTree as ElementTree

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

current_configuration = configuration()


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrCTRAS_DATOSfromXY.ui'))


# VARIABLES
srcVal = current_configuration.general["EPSG"]

class herrCTRAS_DATOSfromXY(QDialog, FORM_CLASS):

    def __init__(self, iface,parent=None):
        """Constructor."""
        super(herrCTRAS_DATOSfromXY, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface;
        self.fun = Functions()
        self.canvas = self.iface.mapCanvas()

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        self.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/jccm_XYCTRAPK.jpg'))
        self.logo.setPixmap(QPixmap(f":/plugins/jccm_bar4/iconos/logo_general.jpg"))

        self.chbXYCapaPol.hide()
        self.combo_tabla.currentIndexChanged.connect(self.actualizarCampos) # Revisar esto y tal vez quitar el botón ACTUALIZAR CAMPOS
        self.chbXYCapaPun.clicked.connect(self.actualizarCampos)

        lista_CAPAS = self.getCapasCsv(self.iface)
        self.combo_tabla.clear()
        self.combo_tabla.addItems(lista_CAPAS)
        if iface.activeLayer():
            if iface.activeLayer().name() in lista_CAPAS:
                # print (iface.activeLayer().name() ,u'ESTÁ EN LA LISTA')
                self.combo_tabla.setCurrentText(iface.activeLayer().name())
            else:
                self.combo_tabla.setCurrentIndex(1)
        self.combo_tabla.setEditable(True)

        self.lblCampoX.setEnabled(False)
        self.lblCampoY.setEnabled(False)
        self.combo_XP.setEnabled(False)
        self.combo_YP.setEnabled(False)

        # BOTONES
        self.btnGENERAR.clicked.connect(self.jccmCTRAS_DATOSfromXY_calc)
        self.btnCancelar.hide()

        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)
        self.progressBar.setValue(0)
        self.lblINFO.setText('INFO:')
        maxfeat = 0
        self.chbMaxFeat.clicked.connect(self.cambiaMaxFeat)
        self.chbXYCapaPun.clicked.connect(self.cambiaCapaCampos)

        self.chbCALCctra.setChecked(False)
        self.chbCALCpk.setChecked(False)
        self.chbCALCdist.setChecked(False)
        self.chbCALCacimut.setChecked(False)
        self.chbCALCXeYe.setChecked(False)
        self.chbCALCXpYp.setChecked(False)


    def getCapasCsv(self, iface):
        ################################################################################
        ####          HAY QUE COMPROBAR QUE LA CAPA ES DE PUNTOS O ES TABLA         ####
        ################################################################################

        layers = QgsProject.instance().mapLayers().values()
        layer_names = []
        for layer in layers:
            source = layer.source()
            if layer.type() == QgsMapLayer.VectorLayer:
                if layer.name() != '':
                    if layer.wkbType()==QgsWkbTypes.Point or layer.wkbType()==QgsWkbTypes.MultiPoint or layer.wkbType()==QgsWkbTypes.PointZ or layer.wkbType()==QgsWkbTypes.MultiPointZ or layer.wkbType()==QgsWkbTypes.PointM or layer.wkbType()==QgsWkbTypes.MultiPointM or layer.wkbType()==QgsWkbTypes.PointZM or layer.wkbType()==QgsWkbTypes.MultiPointZM or layer.wkbType()==QgsWkbTypes.Point25D or layer.wkbType()==QgsWkbTypes.MultiPoint25D:
                        layer_names.append(layer.name())

        # Comprobamos si hay CAPAS susceptibles de cálculo
        if len(layer_names) == 0:
            text = u'NO HAY CAPAS DE PUNTOS PARA CALCULAR DATOS'
            self.fun.showMessage(text)
            self.btnGENERAR.setEnabled(False)
        else:
            self.btnGENERAR.setEnabled(True)
        return layer_names


    def cambiaMaxFeat(self):
        if self.chbMaxFeat.isChecked():
            self.lneMaxFeat.setEnabled(True)
        else:
            self.lneMaxFeat.setEnabled(False)
        pass


    def cambiaCapaCampos(self):
        if self.chbXYCapaPun.isChecked():
            self.lblCampoX.setEnabled(False)
            self.lblCampoY.setEnabled(False)
            self.combo_XP.setEnabled(False)
            self.combo_YP.setEnabled(False)
        else:
            self.lblCampoX.setEnabled(True)
            self.lblCampoY.setEnabled(True)
            self.combo_XP.setEnabled(True)
            self.combo_YP.setEnabled(True)
        pass


    def actualizarCampos(self):
        layername = self.combo_tabla.currentText()
        if layername == "":
            return None
        selected_table = self.fun.getLayerByName(layername)
        fields = selected_table.fields()
        ################################################################################
        ####              HAY QUE REVISAR QUE LOS CAMPOS SEAN NUMÉRICOS             ####
        ####    SE PUEDE TRATAR DE BUSCAR SEÑALES DE QUE LOS CAMPOS CONTIENEN X,Y   ####
        ################################################################################

        list_fields = ['']
        for field in fields:
            list_fields.append(field.name())

        self.combo_XP.clear()
        self.combo_XP.addItems(list_fields)
        self.combo_YP.clear()
        self.combo_YP.addItems(list_fields)

        # Colocamos el primer field no vacío
        for field in list_fields:
            if field != '':
                self.combo_XP.setCurrentIndex(list_fields.index(field))
                self.combo_YP.setCurrentIndex(list_fields.index(field))
                break


    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        pass


    def jccmCTRAS_DATOSfromXY_calc(self):
        # RUTINA DE CÁLCULO DE DATOS X,Y A CARRETERA,PK
        # DERIVADO DESDE fun.mostraEventosFromCSVLayer(...)
        #           y    fun.addEventoPuntual(...)
        ################################################################################
        ####          HAY QUE COMPROBAR QUE LA CAPA ES DE PUNTOS O ES TABLA         ####
        ################################################################################

        if not self.chbCALCctra.isChecked() and not self.chbCALCpk.isChecked() and not self.chbCALCdist.isChecked() and not self.chbCALCacimut.isChecked() and not self.chbCALCXeYe.isChecked()and not self.chbCALCXeYe.isChecked() and not self.chbCALCXpYp.isChecked():
            text = u'NO SE HA SELECCIONADO NINGÚN DATO A AÑADIR'
            self.fun.showMessage(text)
            return

        iface= self.iface

        capaPUNTOS = self.combo_tabla.currentText()
        campo_XP = self.combo_XP.currentText()
        campo_YP = self.combo_YP.currentText()

        dir_logCSV = u'C:/TEMP/'
        dest_path = u'C:/temp/CapaFromXY.shp'

        if self.chbMaxFeat.isChecked():
            maxfeat = int(self.lneMaxFeat.text())
        else:
            maxfeat = 0
        progressBar_dlg = self.progressBar
        infolbl = self.lblINFO
        infolbl.setText('INFO: COMENZANDO LECTURA DE ARCHIVO...')
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        layer = self.fun.getLayerByName(capaPUNTOS)

        if dest_path == 'en memoria':
            es_memoria = True
        else:
            es_memoria = False

        if self.chbXYCapaPun.isChecked() or (campo_XP != "" and campo_YP != ""):
            coorGEOM = False
            if self.chbXYCapaPun.isChecked():
                coorGEOM = True


            # CREACIÓN DE UN LOG DE RESULTADOS
            log_csv = dir_logCSV + "Log_XYtoPK.csv"

            if(es_memoria == False):
                log_csv =  os.path.splitext(dest_path)[0] +  os.path.splitext(dest_path)[1].split(".")[0] + "_log.csv"

            self.fun.comprobarDirectorio(log_csv)

            QgsMessageLog.logMessage( "Creando archivo de log",self.nombre_plugin)

            # Borremoa si existe la capa 'Log_XYtoPK'
            layerLOG = 'Log_XYtoPK'
            for lyr in QgsProject.instance().mapLayers().values():
                if lyr.name() == layerLOG:
                    QgsProject.instance().removeMapLayers( [lyr.id()] )

            target  = codecs.open(log_csv, 'w+',encoding='utf-8')
            encabezado = u'XP; YP; CTRA; PK; result; observaciones'
            target.write(encabezado)
            target.write("\n")
            target.close()

            # Esto crea la capa de LOG
            log_csv_uri = u"file:///"+ log_csv +"?type=csv&geomType=none&subsetIndex=no&delimiter=%s&watchFile=no" % (";")
            log_lyr = QgsVectorLayer(log_csv_uri, 'Log_XYtoPK','delimitedtext')
            QgsProject.instance().addMapLayer(log_lyr)

            # SE AÑADEN AL FICHERO ORIGEN LOS NUEVOS CAMPOS
            pr = layer.dataProvider()
            layer.startEditing()

            fields = pr.fields()
            field_names = []
            for field_name in fields:
                field_names.append(field_name.name().lower())

            # Comprobamos si hay campos a añaddir activoa
            camposADDactivos = 0
            if self.chbCALCctra.isChecked():
                camposADDactivos += 1
            if self.chbCALCpk.isChecked():
                camposADDactivos += 1
            if self.chbCALCdist.isChecked():
                camposADDactivos += 1
            if self.chbCALCacimut.isChecked():
                camposADDactivos += 1
            if self.chbCALCXeYe.isChecked():
                camposADDactivos += 1
            if self.chbCALCXpYp.isChecked():
                camposADDactivos += 1

            if camposADDactivos == 0:
                self.fun.showMessage("Se debe seleccionar algún campo a calcular")
                QApplication.restoreOverrideCursor()
                return


            if not 'carretera'.lower() in field_names and self.chbCALCctra.isChecked():
                pr.addAttributes([QgsField('carretera',     QMetaType.Type.QString)])
            if not 'pk_calc'.lower() in field_names   and self.chbCALCpk.isChecked():
                pr.addAttributes([QgsField('pk_calc',       QMetaType.Type.Double,'', 10,3)])
            if not 'distancia'.lower() in field_names and self.chbCALCdist.isChecked():
                pr.addAttributes([QgsField('distancia',     QMetaType.Type.Double,'', 10,3)])
            if not 'acimut'.lower() in field_names    and self.chbCALCacimut.isChecked():
                pr.addAttributes([QgsField('acimut',        QMetaType.Type.Double,'', 10,4)])
            if not 'XE'.lower() in field_names        and self.chbCALCXeYe.isChecked():
                pr.addAttributes([QgsField('XE',            QMetaType.Type.Double,'', 10,3)])
            if not 'YE'.lower() in field_names        and self.chbCALCXeYe.isChecked():
                pr.addAttributes([QgsField('YE',            QMetaType.Type.Double,'', 10,3)])
            if not 'XP'.lower() in field_names        and self.chbCALCXpYp.isChecked():
                pr.addAttributes([QgsField('XP',            QMetaType.Type.Double,'', 10,3)])
            if not 'YP'.lower() in field_names        and self.chbCALCXpYp.isChecked():
                pr.addAttributes([QgsField('YP',            QMetaType.Type.Double,'', 10,3)])
            if not 'idMatricula'.lower() in field_names:
                pr.addAttributes([QgsField('idMatricula',   QMetaType.Type.Int)])

            layer.updateFields()
            layer.commitChanges()

            fields = pr.fields()
            field_names = []
            for field_name in fields:
                field_names.append(field_name.name())


            # COMENZAMOS A LEER TODOS LOS REGISTROS DEL FICHERO ORIGEN
            nofeat = 1
            if maxfeat == 0:
                maxfeat = 99999

            if self.chbELEMSELEC.isChecked():
                features = layer.selectedFeatures()
                numfeat = layer.selectedFeatureCount()
                if numfeat == 0:
                    features = layer.getFeatures()
                    numfeat = layer.featureCount()
            else:
                features = layer.getFeatures()
                numfeat = layer.featureCount()


            # features = layer.selectedFeatures()
            # numfeat = len(features)

            # print 'numfeat = ' + str(numfeat)
            if numfeat == 0:
                features = layer.getFeatures()
                numfeat = layer.featureCount()

            if coorGEOM == True:
                sourceCrsAUTH = layer.crs().authid()
                # destCrsAUTH = u'EPSG:25830'
                destCrsAUTH = self.canvas.mapSettings().destinationCrs().authid()
                sourceCrs = QgsCoordinateReferenceSystem(sourceCrsAUTH)
                destCrs = QgsCoordinateReferenceSystem(destCrsAUTH)
                tr = QgsCoordinateTransform(sourceCrs, destCrs, QgsProject.instance())
                # print 'SOURCE=', sourceCrsAUTH, 'DEST=', destCrsAUTH

            for feature in features:
                if nofeat > maxfeat:
                    break

                # print u'(nofeat %s, maxfeat %s, numfeat %s)'%(nofeat, maxfeat, numfeat )
                progress = 'Calculando punto %s de %s...'%(nofeat,numfeat)
                self.iface.mainWindow().statusBar().showMessage(progress)
                if coorGEOM == True:
                    geom = feature.geometry().asPoint()
                    XP0 = geom[0]
                    YP0 = geom[1]
                    geom = tr.transform(XP0, YP0)
                    XP = geom[0]
                    YP = geom[1]
                    # print XP, YP
                else:
                    XP = float(feature[campo_XP])
                    YP = float(feature[campo_YP])

                if (not XP0 or not YP0):
                    matricula = 'NO-CARRETERA'

                # print 'XP0=', XP0,' YP0=',YP0,' XTra=', XP,' XTra=', YP
                carretera_pk = self.fun.pointToPK([XP,YP],iface,pintar='NO',no9000='SI')
                # carretera_pk = self.fun.pointToPK([point[0],point[1]],iface,pintar='NO',no9000='SI')
                # return [the_road, m_final, the_road, funcion, atributos, distEJE, acimEJE, pointEJE]
                # carretera_pk [0],     [1],      [2],     [3],       [4],     [5],     [6],       [7]

                ############################################################
                ####    HAY QUE ANALIZAR LOS RESULTADOS 9000   ####
                ############################################################
                target  = codecs.open(log_csv, 'a',encoding='utf-8')

                pr = layer.dataProvider()
                layer.startEditing()

                if carretera_pk is not None:
                    atributos = carretera_pk[4]
                    # print str(nofeat),XP,YP, carretera_pk[0], round(carretera_pk[1],5), round(carretera_pk[5],3), round(carretera_pk[6],4), atributos['idMatricula']

                    if "carretera" in field_names and self.chbCALCctra.isChecked():
                        feature["carretera"] = carretera_pk[0]
                    if "pk_calc" in field_names and self.chbCALCpk.isChecked():
                        feature["pk_calc"] = round(carretera_pk[1],3)
                    if "distancia" in field_names and self.chbCALCdist.isChecked():
                        feature["distancia"] = round(carretera_pk[5],3)
                    if "acimut" in field_names and self.chbCALCacimut.isChecked():
                        feature["acimut"] = round(carretera_pk[6],4)
                    if "XE" in field_names and self.chbCALCXeYe.isChecked():
                        feature["XE"] = round(carretera_pk[7][0],3)
                    if "YE" in field_names and self.chbCALCXeYe.isChecked():
                        feature["YE"] = round(carretera_pk[7][1],3)
                    if "XP" in field_names and self.chbCALCXpYp.isChecked():
                        feature["XP"] = round(XP,3)
                    if "YP" in field_names and self.chbCALCXpYp.isChecked():
                        feature["YP"] = round(YP,3)
                    if "idMatricula" in field_names:
                        feature["idMatricula"] = atributos['idMatricula']
                    layer.updateFeature(feature)

                    linea = str(XP)+';'+str(YP)+';'+carretera_pk[0]+';'+str(round(carretera_pk[1],5))+';"OK";""'

                else:
                    if "carretera" in field_names:
                        feature["carretera"] = 'S/D'
                    if "pk_calc" in field_names:
                        feature["pk_calc"] = 0
                    if "distancia" in field_names:
                        feature["distancia"] = 0
                    if "acimut" in field_names:
                        feature["acimut"] = 0
                    if "XE" in field_names:
                        feature["XE"] = 0
                    if "YE" in field_names:
                        feature["YE"] = 0
                    if "XP" in field_names:
                        feature["XP"] = 0
                    if "YP" in field_names:
                        feature["YP"] = 0
                    if "idMatricula" in field_names:
                        feature["idMatricula"] = 0
                    layer.updateFeature(feature)


                    message = u"Punto muy alejado de una carretera"
                    linea = str(XP)+';'+str(YP)+';"s/d";"s/d";"ERROR COORD";"'+ message+'"'
                    # print str(nofeat),XP,YP, u"Punto muy alejado de una carretera"

                layer.updateExtents()
                layer.commitChanges()

                target.write(linea)
                target.write("\n")
                target.close()

                if maxfeat != 99999 and maxfeat<numfeat:
                    progressBar_dlg.setValue(int(100*nofeat/maxfeat))
                    infolbl.setText('INFO: ('+str(nofeat)+' / '+str(maxfeat)+') Total: '+str(numfeat)+' elementos')
                else:
                    progressBar_dlg.setValue(int(100*nofeat/numfeat))
                    infolbl.setText('INFO: ('+str(nofeat)+' / '+str(numfeat)+')')

                nofeat += 1

            # writer = QgsVectorFileWriter(dest_path, "latin-1", fields, QgsWkbTypes.Point, pr.crs(), "ESRI Shapefile")
            # iter = layer.getFeatures()
            # for ft in iter:  # Loop on the subseted features
                # # Create a new feature for each original feature
                # new_ft = QgsFeature()
                # # Give it its geometry :
                # new_ft.setGeometry(ft.geometry())
                # attributes = []
                # for field in field_names:
                    # attributes.append(ft[field])
                    # #attributes.append(0)
                # #print attributes
                # # Only keep the 2 selected fields :
                # new_ft.setAttributes(attributes)
                # # Add the feature to the writer, ie. your output shapefile :
                # #print ft
                # writer.addFeature(new_ft)

            # del writer # Features are written when the writer is deleted
            # new_layer = iface.addVectorLayer(dest_path, os.path.splitext(dest_path)[1].split(".")[0], "ogr")
            # new_layer = iface.addVectorLayer(dest_path, capaPUNTOS, "ogr")

            # QgsProject.instance().addMapLayer(new_layer)

            QApplication.restoreOverrideCursor()
            self.fun.showMessage("--- TERMINADA LA ASIGNACIÓN DE DATOS ---")
            progress = '--- TERMINADA LA ASIGNACIÓN DE PUNTOS --- (%s/%s)'%(nofeat-1,numfeat)
            self.iface.mainWindow().statusBar().showMessage(progress)
            self.close()

        else:
            self.fun.showMessage("Hay que seleccionar una tabla y seleccionar los campos X, Y")

        QApplication.restoreOverrideCursor()
        return



