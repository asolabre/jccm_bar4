# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           puntoZ_cont.py
Purpose:        Herramienta para obtener la Z de un punto desde el servicio WMS del IGN
                Mostrando resultados en un panel flotante en tiempo real
        --------------------------------------------------------------------
        begin                : 2019-09-11
        modified             : 2023-11-15
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/
"""

from qgis.PyQt.QtCore import Qt, QSize, QTimer, QDateTime
from qgis.PyQt.QtWidgets import (QApplication, QTextEdit, QDockWidget,
                                QVBoxLayout, QWidget, QLabel)
from qgis.PyQt.QtGui import QCursor, QIcon

from qgis.gui import QgsMapTool

import os
import re

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

# current_configuration = configuration()

class puntoZ_cont(QgsMapTool):
    def __init__(self, canvas, iface, action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.fun = Functions()
        self.conf = configuration()
        self.iface = iface
        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        # Configurar cursor
        self.normal_cursor = QCursor(Qt.CursorShape.CrossCursor)
        self.iface.mapCanvas().setCursor(self.normal_cursor)
        self.setAction(action)
        self.action = action

        # Inicializar el panel como None
        self.dock = None

        # Variables para manejar consultas en tiempo real
        self.last_point = None
        self.last_muni_prov_result = None
        self.last_muni_prov_point = None
        self.current_z_value = None
        self.current_muni_prov_info = None

        # Timers para consultas separadas
        self.z_timer = QTimer()
        self.z_timer.setSingleShot(True)
        self.z_timer.timeout.connect(self.update_z_position)

        self.muni_timer = QTimer()
        self.muni_timer.setSingleShot(True)
        self.muni_timer.timeout.connect(self.update_muni_position)

        # Variables de tiempo para control de intervalos
        self.last_movement_time = QDateTime.currentDateTime()
        self.last_z_update_time = QDateTime.currentDateTime()
        self.last_muni_update_time = QDateTime.currentDateTime()

        # Intervalos de actualización (en milisegundos)
        self.Z_UPDATE_INTERVAL = 500     # 500ms para actualización de Z
        self.MUNI_UPDATE_INTERVAL = 10000  # 10 segundos para actualización de municipio

        # Estado de consultas en curso
        self.z_query_in_progress = False
        self.muni_query_in_progress = False

        self.is_active = False

        # Crear el panel de resultados
        self.create_results_panel()

    def create_results_panel(self):
        """Crea el panel de resultados flotante si no existe"""
        # Verificar si el panel ya existe
        if self.dock is None:
            # Crear el widget dockable
            self.dock = QDockWidget("Datos del Punto", self.iface.mainWindow())
            self.dock.setObjectName("puntoZ_cont_panel")
            self.dock.setAllowedAreas(Qt.DockWidgetArea.NoDockWidgetArea)  # No permitir docking inicialmente

            # Conectar señal de cierre para limpiar correctamente
            self.dock.destroyed.connect(self.on_panel_closed)

            # Crear widget contenido
            self.panel_widget = QWidget()
            self.layout = QVBoxLayout()

            # Añadir título
            self.title_label = QLabel("DATOS DEL PUNTO EN TIEMPO REAL")
            self.title_label.setStyleSheet("font-weight: bold; font-size: 14px;")
            self.layout.addWidget(self.title_label)

            # Área de texto para mostrar resultados
            self.text_edit = QTextEdit()
            self.text_edit.setReadOnly(True)
            self.layout.addWidget(self.text_edit)

            # Etiqueta para estado
            self.status_label = QLabel("Estado: Inactivo")
            self.status_label.setStyleSheet("font-size: 10px; color: #7f8c8d;")
            self.layout.addWidget(self.status_label)

            # Establecer tamaño inicial del QDockWidget
            self.dock.setMinimumSize(QSize(350, 350))

            # Mensaje inicial
            txtINSTRUCCIONES = "PUEDE DESPLAZAR ESTE PANEL A OTRO PUNTO DE LA PANTALLA"
            txtINSTRUCCIONES += "\n\nMueva el cursor sobre el mapa para obtener datos del punto en tiempo real..."
            txtINSTRUCCIONES += "\nHaga clic para fijar el punto actual."
            self.text_edit.setText(txtINSTRUCCIONES)

            # Configurar layout
            self.panel_widget.setLayout(self.layout)
            self.dock.setWidget(self.panel_widget)

            # Icono del panel
            self.dock.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/Z_icon.jpg'))

            # Configurar como flotante
            self.dock.setFloating(True)  # Hacerlo flotante
            self.dock.setFeatures(QDockWidget.DockWidgetFeature.DockWidgetClosable | QDockWidget.DockWidgetFeature.DockWidgetMovable)

            # Posicionar en esquina superior derecha
            screen_geometry = QApplication.primaryScreen().availableGeometry()  # QApplication.desktop() removed in Qt6
            dock_width = 350
            dock_height = 350
            x_pos = screen_geometry.width() - dock_width - 50  # 50px de margen
            y_pos = 50  # 50px desde el borde superior

            self.dock.setGeometry(x_pos, y_pos, dock_width, dock_height)

            # Mostrar el panel (no lo añadimos como dock widget todavía)
            self.dock.show()
        else:
            # Si el panel ya existe, simplemente lo mostramos
            self.dock.setFloating(True)
            self.dock.show()

    def update_results_panel(self, point, Zmdt=None, Result=None):
        """Actualiza el panel con los nuevos datos con formato de colores"""
        # Actualizar valores actuales si se proporcionan nuevos
        if Zmdt is not None:
            self.current_z_value = Zmdt
        if Result is not None:
            self.current_muni_prov_info = Result

        # Preparar valores para mostrar
        estilo_titulo = "color: #2c3e50; font-weight: bold;"
        estilo_valor = "color: #1039b6;"                            # Color AZUL
        estilo_error = "color: #e74c3c;"
        estilo_subtitulo = "color: #7f8c8d; font-style: italic; font-size: small"
        estilo_instrucciones = "color: #fb0408;"                    # Color ROJO
        estilo_actualizando = "color: #f39c12;"                     # Color NARANJA

        # Elevación
        if self.current_z_value is None:
            elevacion_html = f'<span style="{estilo_actualizando}">Actualizando...</span>'
        elif self.current_z_value == 'Error':
            elevacion_html = f'<span style="{estilo_error}">SIN DATOS</span>'
        else:
            elevacion_html = f'<span style="{estilo_valor}">{self.current_z_value:.3f}</span>'

        # Municipio y provincia
        if self.current_muni_prov_info:
            provincia_html = f'<span style="{estilo_valor}">{self.current_muni_prov_info[1]}</span>'
            municipio_html = f'<span style="{estilo_valor}">{self.current_muni_prov_info[0]}</span>'
            fuente_html = f'<span style="{estilo_subtitulo}">FUENTE: {self.current_muni_prov_info[7]}</span>'
        else:
            provincia_html = f'<span style="{estilo_actualizando}">Actualizando...</span>'
            municipio_html = f'<span style="{estilo_actualizando}">Actualizando...</span>'
            fuente_html = f'<span style="{estilo_subtitulo}">FUENTE: Actualizando...</span>'

        # Construimos el contenido HTML con estilos
        html_content = f"""
        <div style="font-family: Arial; font-size: 11pt;">
            <p style="{estilo_titulo}">Elevación: {elevacion_html} <span style="{estilo_subtitulo}">(Modelo Digital del Terreno IGN 5 m.)</span></p>

            <p style="{estilo_titulo}">X: <span style="{estilo_valor}">{point[0]:.3f}</span></p>
            <p style="{estilo_titulo}">Y: <span style="{estilo_valor}">{point[1]:.3f}</span></p>
            <p style="{estilo_subtitulo}">(UTM30-ETRS89)</p>

            <p style="{estilo_titulo}">Provincia: {provincia_html}</p>
            <p style="{estilo_titulo}">Municipio: {municipio_html}</p>
            {fuente_html}

            <p style="{estilo_instrucciones}">Mueva el cursor para actualizar datos en tiempo real...</p>
            <p style="{estilo_instrucciones}">Haga clic para fijar este punto.</p>
        </div>
        """

        # Configuramos el QTextEdit para aceptar HTML
        self.text_edit.setHtml(html_content)

    def canvasMoveEvent(self, event):
        """Evento al mover el ratón sobre el canvas"""
        if not self.is_active:
            return

        current_time = QDateTime.currentDateTime()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(event.pos())

        # Actualizar coordenadas en el panel (sin consultar servicios)
        self.last_point = point
        self.last_movement_time = current_time

        # Actualizar etiqueta de estado
        self.status_label.setText(f"Estado: Movimiento detectado")

        # Actualizar las coordenadas en el panel inmediatamente
        self.update_coordinates_only(point)

        # Reiniciar timers solo si ha pasado el tiempo suficiente desde la última actualización
        msecs_since_last_z = self.last_z_update_time.msecsTo(current_time)
        msecs_since_last_muni = self.last_muni_update_time.msecsTo(current_time)

        # Cancelar timers en curso
        self.z_timer.stop()
        self.muni_timer.stop()

        # Programar actualización de Z si ha pasado el intervalo
        if msecs_since_last_z >= self.Z_UPDATE_INTERVAL and not self.z_query_in_progress:
            self.z_timer.start(100)  # Pequeño delay para agrupar movimientos
        elif msecs_since_last_z < self.Z_UPDATE_INTERVAL:
            self.status_label.setText(f"Estado: Esperando para Z ({self.Z_UPDATE_INTERVAL - msecs_since_last_z}ms)")

        # Programar actualización de municipio si ha pasado el intervalo
        if msecs_since_last_muni >= self.MUNI_UPDATE_INTERVAL and not self.muni_query_in_progress:
            # Solo actualizar municipio si nos hemos movido significativamente
            if self.should_update_muni(point):
                self.muni_timer.start(200)  # Pequeño delay

    def update_coordinates_only(self, point):
        """Actualiza solo las coordenadas manteniendo el resto de información"""
        # Si no tenemos texto aún, mostrar un mensaje inicial
        if not self.text_edit.toPlainText() or "Herramienta desactivada" in self.text_edit.toPlainText():
            txtINSTRUCCIONES = "Mueva el cursor sobre el mapa para obtener datos del punto en tiempo real...\n\nHaga clic para fijar el punto actual."
            self.text_edit.setText(txtINSTRUCCIONES)
            return

        try:
            # Extraer los valores actuales del HTML si existe
            current_html = self.text_edit.toHtml()

            # Buscar valores existentes en el HTML
            elevacion_match = re.search(r'Elevación: <span[^>]*>([^<]+)</span>', current_html)
            provincia_match = re.search(r'Provincia: <span[^>]*>([^<]+)</span>', current_html)
            municipio_match = re.search(r'Municipio: <span[^>]*>([^<]+)</span>', current_html)

            # Usar valores existentes o valores por defecto
            if elevacion_match:
                elevacion_html = f'<span[^>]*>{elevacion_match.group(1)}</span>'
                # Extraer solo el contenido sin el span completo
                elevacion_text = elevacion_match.group(1)
                # Determinar color basado en el contenido
                if "SIN DATOS" in elevacion_text:
                    elevacion_style = "color: #e74c3c;"
                elif "Actualizando" in elevacion_text:
                    elevacion_style = "color: #f39c12;"
                else:
                    elevacion_style = "color: #1039b6;"
                elevacion_display = f'<span style="{elevacion_style}">{elevacion_text}</span>'
            else:
                elevacion_display = '<span style="color: #f39c12;">Actualizando...</span>'

            if provincia_match:
                provincia_display = f'<span style="color: #1039b6;">{provincia_match.group(1)}</span>'
            else:
                provincia_display = '<span style="color: #f39c12;">Actualizando...</span>'

            if municipio_match:
                municipio_display = f'<span style="color: #1039b6;">{municipio_match.group(1)}</span>'
            else:
                municipio_display = '<span style="color: #f39c12;">Actualizando...</span>'

            # Buscar fuente (puede estar en diferentes formatos)
            fuente_match = re.search(r'FUENTE: ([^<]+)', current_html)
            if fuente_match:
                fuente_text = fuente_match.group(1).strip()
            else:
                fuente_text = "Actualizando..."

            # Construir nuevo HTML manteniendo los valores existentes
            estilo_titulo = "color: #2c3e50; font-weight: bold;"
            estilo_subtitulo = "color: #7f8c8d; font-style: italic; font-size: small"
            estilo_instrucciones = "color: #fb0408;"

            html_content = f"""
            <div style="font-family: Arial; font-size: 11pt;">
                <p style="{estilo_titulo}">Elevación: {elevacion_display} <span style="{estilo_subtitulo}">(Modelo Digital del Terreno IGN 5 m.)</span></p>

                <p style="{estilo_titulo}">X: <span style="color: #1039b6;">{point[0]:.3f}</span></p>
                <p style="{estilo_titulo}">Y: <span style="color: #1039b6;">{point[1]:.3f}</span></p>
                <p style="{estilo_subtitulo}">(UTM30-ETRS89)</p>

                <p style="{estilo_titulo}">Provincia: {provincia_display}</p>
                <p style="{estilo_titulo}">Municipio: {municipio_display}</p>
                <p style="{estilo_subtitulo}">FUENTE: {fuente_text}</p>

                <p style="{estilo_instrucciones}">Mueva el cursor para actualizar datos en tiempo real...</p>
                <p style="{estilo_instrucciones}">Haga clic para fijar este punto.</p>
            </div>
            """

            self.text_edit.setHtml(html_content)
        except Exception as e:
            # En caso de error, simplemente actualizar las coordenadas de forma simple
            simple_text = f"X: {point[0]:.3f}\nY: {point[1]:.3f}\n\nMueva el cursor para obtener más datos..."
            self.text_edit.setPlainText(simple_text)

    def should_update_muni(self, new_point):
        """Determina si debemos actualizar la info de municipio"""
        if self.last_muni_prov_point is None:
            return True

        # Calcular distancia desde la última consulta de municipio
        dx = new_point[0] - self.last_muni_prov_point[0]
        dy = new_point[1] - self.last_muni_prov_point[1]
        distance = (dx**2 + dy**2)**0.5

        # Actualizar si nos hemos movido más de 100 metros
        return distance > 100

    def update_z_position(self):
        """Actualiza solo la información de elevación (Z)"""
        if self.last_point is None or self.z_query_in_progress:
            return

        self.z_query_in_progress = True

        try:
            # Cambiar cursor solo durante la consulta real
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            self.status_label.setText("Estado: Consultando elevación...")

            # Obtener la cota MDT
            Zmdt = self.fun.Zmdt(self.last_point, self.iface, pintar='NO')

            # Actualizar el valor actual
            self.current_z_value = Zmdt

            # Actualizar el panel manteniendo municipio/provincia
            self.update_results_panel(self.last_point, Zmdt=Zmdt)

            # Actualizar tiempo de última actualización de Z
            self.last_z_update_time = QDateTime.currentDateTime()
            self.status_label.setText(f"Estado: Z actualizada")

        except Exception as e:
            # En caso de error
            self.status_label.setText(f"Estado: Error en Z - {str(e)[:30]}...")
            self.current_z_value = 'Error'
            self.update_results_panel(self.last_point)
        finally:
            # Restaurar cursor SIEMPRE
            QApplication.restoreOverrideCursor()
            self.iface.mapCanvas().setCursor(self.normal_cursor)
            self.z_query_in_progress = False

    def update_muni_position(self):
        """Actualiza solo la información de municipio y provincia"""
        if self.last_point is None or self.muni_query_in_progress:
            return

        self.muni_query_in_progress = True

        try:
            self.status_label.setText("Estado: Consultando municipio...")

            # Obtener información municipal/provincial
            ResultMuniProv = self.fun.getCatastroMuniProv(self.last_point, self.iface, pintar='NO')

            if ResultMuniProv[0] == 's/d':
                ResultMuniProv = self.fun.getJCCMMuniProv(self.last_point, self.iface, pintar='NO')
            if ResultMuniProv[0] == 's/d':
                ResultMuniProv = self.fun.getCARTOCMuniProv(self.last_point, self.iface, pintar='NO')

            # Guardar resultados para futuras comparaciones
            self.last_muni_prov_result = ResultMuniProv
            self.last_muni_prov_point = self.last_point

            # Actualizar el valor actual
            self.current_muni_prov_info = ResultMuniProv

            # Actualizar el panel manteniendo la Z
            self.update_results_panel(self.last_point, Result=ResultMuniProv)

            # Actualizar tiempo de última actualización de municipio
            self.last_muni_update_time = QDateTime.currentDateTime()
            self.status_label.setText(f"Estado: Municipio actualizado")

        except Exception as e:
            # En caso de error
            self.status_label.setText(f"Estado: Error en municipio - {str(e)[:30]}...")
        finally:
            self.muni_query_in_progress = False

    def canvasReleaseEvent(self, event):
        """Evento al hacer click en el mapa - fija el punto actual"""
        point = self.canvas.getCoordinateTransform().toMapCoordinates(event.pos())

        # Forzar actualización inmediata de ambos
        self.last_point = point
        self.last_movement_time = QDateTime.currentDateTime()

        # Cancelar timers pendientes
        self.z_timer.stop()
        self.muni_timer.stop()

        try:
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            self.status_label.setText("Estado: Fijando punto...")

            # Obtener ambos datos inmediatamente
            Zmdt = self.fun.Zmdt(point, self.iface, pintar='NO')
            ResultMuniProv = self.fun.getCatastroMuniProv(point, self.iface, pintar='NO')

            if ResultMuniProv[0] == 's/d':
                ResultMuniProv = self.fun.getJCCMMuniProv(point, self.iface, pintar='NO')
            if ResultMuniProv[0] == 's/d':
                ResultMuniProv = self.fun.getCARTOCMuniProv(point, self.iface, pintar='NO')

            # Actualizar valores actuales
            self.current_z_value = Zmdt
            self.current_muni_prov_info = ResultMuniProv

            self.update_results_panel(point, Zmdt, ResultMuniProv)

            # Actualizar tiempos
            self.last_z_update_time = QDateTime.currentDateTime()
            self.last_muni_update_time = QDateTime.currentDateTime()
            self.last_muni_prov_result = ResultMuniProv
            self.last_muni_prov_point = point

            # Mostrar mensaje de confirmación
            self.status_label.setText("Estado: Punto fijado")

        finally:
            # Restaurar cursor SIEMPRE
            QApplication.restoreOverrideCursor()
            self.iface.mapCanvas().setCursor(self.normal_cursor)

    def activate(self):
        """Se ejecuta al activar la herramienta"""
        self.is_active = True
        self.last_point = None
        self.last_muni_prov_result = None
        self.last_muni_prov_point = None
        self.current_z_value = None
        self.current_muni_prov_info = None
        self.last_movement_time = QDateTime.currentDateTime()
        self.last_z_update_time = QDateTime.currentDateTime()
        self.last_muni_update_time = QDateTime.currentDateTime()

        # Resetear estado de consultas
        self.z_query_in_progress = False
        self.muni_query_in_progress = False

        # Configurar cursor normal
        self.iface.mapCanvas().setCursor(self.normal_cursor)

        # Asegurarse de que no hay cursor override activo
        while QApplication.overrideCursor():
            QApplication.restoreOverrideCursor()

        super().activate()

        # Cambiar el mensaje inicial
        initial_text = "Mueva el cursor sobre el mapa para obtener datos del punto en tiempo real...\n\nHaga clic para fijar el punto actual."
        self.text_edit.setText(initial_text)
        self.status_label.setText("Estado: Activo - Mueva el cursor")

    def deactivate(self):
        """Se ejecuta al desactivar la herramienta"""
        self.is_active = False

        # Detener todos los timers
        self.z_timer.stop()
        self.muni_timer.stop()

        # Resetear estado de consultas
        self.z_query_in_progress = False
        self.muni_query_in_progress = False

        # Restaurar cursor completamente
        self.iface.mapCanvas().unsetCursor()

        # Asegurarse de que no hay cursor override activo
        while QApplication.overrideCursor():
            QApplication.restoreOverrideCursor()

        # Mostrar mensaje de desactivación
        self.text_edit.setText("Herramienta desactivada.\n\nActívela de nuevo para obtener datos en tiempo real.")
        self.status_label.setText("Estado: Inactivo")

        super().deactivate()

    def on_panel_closed(self):
        """Se ejecuta cuando se cierra el panel"""
        # Asegurarse de restaurar cursor
        self.iface.mapCanvas().unsetCursor()
        while QApplication.overrideCursor():
            QApplication.restoreOverrideCursor()

        # Detener timers
        self.z_timer.stop()
        self.muni_timer.stop()

        # Marcar como inactivo
        self.is_active = False

        # Limpiar referencias
        self.dock = None

