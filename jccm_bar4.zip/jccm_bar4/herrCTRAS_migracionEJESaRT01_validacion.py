# -*- coding: utf-8 -*-

# /***************************************************************************
# Name:           herrCTRAS_migracionEJESaRT01_validacion.py
                                 # A QGIS4 plugin
# Plugin:     jccm_bar4
# Purpose:    Validación de la migración de EJES a RT contra RT_IGN (WMS IGN)

    # Compara los atributos migrados con los datos oficiales del IGN RT
    # consultando por WMS en N puntos de cada geometría.

    # Genera un GPKG de errores con:
        # - Geometría original del elemento
        # - Todos los campos migrados
        # - Campos 'rtign_<campo>' con los valores obtenidos de RT_IGN
        # - Campos 'resultado_<campo>' = 'OK' / 'MAL' / 'N/C'
        # - Campo 'num_puntos_ok' y 'num_puntos_total'
# ***************************************************************************/


from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QApplication

from qgis.PyQt.core import (
    QgsProject, Qgis, QgsVectorLayer, QgsFeature, QgsGeometry,
    QgsField, QgsVectorFileWriter, QgsCoordinateTransformContext,
    QgsFeatureRequest, QgsExpression, QgsPointXY, QgsWkbTypes,
    QgsSymbol, QgsSimpleLineSymbolLayer, QgsMarkerSymbol
)
from qgis.PyQt.QtCore import QVariant

import os
import datetime
import xml.etree.ElementTree as ET
import timeit

from .functions4 import Functions


# ============================================================================
# CONFIGURACIÓN DE VALIDACIÓN
# ============================================================================

# URL del WMS de RT del IGN
URL_WMS_RT = 'https://servicios.idee.es/wms-inspire/transportes?'
LAYER_WMS_RT = 'TN.RoadTransportNetwork.RoadLink'
TIPO_WMS_RT = 'text/xml'

# Número de puntos a consultar por geometría (por defecto)
NUM_PUNTOS_VALIDACION = 3

# Fracciones de la longitud de la geometría donde tomar los puntos
# (evitamos extremos por posibles problemas en nodos compartidos)
FRACCIONES_PUNTOS = [0.15, 0.50, 0.85]

# Campos de RT_IGN (WMS) y su equivalente en nuestra migración JCCM
# Mapeo:  campo_RTIGN : campo_JCCM
MAPEO_CAMPOS_RTIGN_RTJCCM = {
    'id_vial':       'id_vial',
    'tipo_viald':    'tipo_viald',
    'clased':        'clased',
    'ordend':        'ordend',
    'titulard':      'titulard',
    'tipo_tramod':   'tipo_tramd',      # OJO: en RT_IGN se llama tipo_tramod
    'calzadad':      'calzadad',
    'accesod':       'accesod',
    'firmed':        'firmed',
    'ncarrilesd':    'ncarriles',       # OJO: en RT_IGN es ncarrilesd
    'sentidod':      'sentidod',
    # 'situaciond':    'situaciond',    # EXCLUIDO: no se migra en RT_JCCM
    'estadofisd':    'estadofisd',
    'tipovehicd':    'tipovehicd',
}

# Campos de RT_IGN que NO se comparan (no tienen equivalente o son propios del IGN)
CAMPOS_RTIGN_EXCLUIDOS = [
    'id_unique',    # Identificador interno IGN
    'id_tramo',     # Propio del IGN
    'rotulo',       # Nombre comercial (nuestro 'nombre' puede diferir)
    'geometry',     # Geometría WMS
]


# ============================================================================
# CLASE DE VALIDACIÓN
# ============================================================================

class ValidadorMigracionRT:
    # 
    # Clase para validar la migración de EJES a RT contra los datos del IGN RT.
    # 

    def __init__(self, iface, fun=None):
        self.iface = iface
        self.fun = fun if fun is not None else Functions()
        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

    # ------------------------------------------------------------------------
    # CONSULTA WMS A RT_IGN
    # ------------------------------------------------------------------------

    def consultar_rt_ign_en_punto(self, punto_xy):
        # Consulta el WMS de RT_IGN en un punto y devuelve un diccionario
        # con todos los campos de RT_IGN disponibles.

        # Args:
            # punto_xy (QgsPointXY): Punto a consultar (en coordenadas del proyecto)

        # Returns:
            # dict: Diccionario con los campos RT_IGN, o None si no hay datos
        try:
            result = self.fun.WMSgetFeatureInfo(
                (punto_xy.x(), punto_xy.y()),
                self.iface,
                'NO',           # No pintar
                URL_WMS_RT,
                TIPO_WMS_RT,
                LAYER_WMS_RT
            )

            # result = (url_completa, xml_txt) o ('Error', mensaje)
            if not result or result[0] == 'Error':
                return None

            xml_data = result[1]

            # Parsear el XML
            tree = ET.fromstring(xml_data)

            # Iterar sobre cada featureMember y extraer los campos
            features_list = []
            for feature_member in tree.findall('.//{*}featureMember'):
                feature_dict = {}

                # Extraer todos los campos hijos (sin prefijo de namespace)
                for child in feature_member.iter():
                    tag = child.tag.split('}')[-1]  # sin namespace

                    # Saltar tags de estructura
                    if tag in ('featureMember', 'RoadLink', 'geometry',
                               'LineString', 'coordinates', 'boundedBy',
                               'Envelope', 'lowerCorner', 'upperCorner'):
                        continue

                    if child.text and child.text.strip():
                        feature_dict[tag] = child.text.strip()
                    elif len(child) == 0:
                        # Elemento sin hijos y sin texto
                        if tag not in feature_dict:
                            feature_dict[tag] = None

                if feature_dict:
                    features_list.append(feature_dict)

            if not features_list:
                return None

            # Devolver el primer elemento (el más próximo al punto)
            return features_list[0]

        except ET.ParseError as e:
            print(f"Error parseando XML de RT_IGN: {e}")
            return None
        except Exception as e:
            print(f"Error consultando RT_IGN: {e}")
            return None

    # ------------------------------------------------------------------------
    # PUNTOS DE MUESTREO SOBRE LA GEOMETRÍA
    # ------------------------------------------------------------------------

    def obtener_puntos_muestreo(self, geometria, num_puntos=None, fracciones=None):
        # Devuelve una lista de QgsPointXY distribuidos a lo largo de la geometría
        # según las fracciones indicadas.

        # Args:
            # geometria (QgsGeometry): Geometría lineal
            # num_puntos (int): Número de puntos (si no se dan fracciones)
            # fracciones (list): Lista de fracciones [0.0 - 1.0]

        # Returns:
            # list: Lista de QgsPointXY
        if geometria is None or geometria.isNull():
            return []

        # Longitud total
        longitud = geometria.length()
        if longitud <= 0:
            return []

        # Determinar fracciones
        if fracciones is None:
            if num_puntos is None:
                num_puntos = NUM_PUNTOS_VALIDACION
            if num_puntos <= 0:
                return []
            if num_puntos == 1:
                fracciones = [0.5]
            else:
                fracciones = [(i + 1) / (num_puntos + 1) for i in range(num_puntos)]

        # Generar puntos
        puntos = []
        for frac in fracciones:
            distancia = longitud * frac
            try:
                punto_geom = geometria.interpolate(distancia)
                if punto_geom and not punto_geom.isEmpty():
                    p = punto_geom.asPoint()
                    puntos.append(QgsPointXY(p.x(), p.y()))
            except Exception:
                continue

        return puntos

    # ------------------------------------------------------------------------
    # COMPARACIÓN DE CAMPOS
    # ------------------------------------------------------------------------

    def comparar_campos(self, feature_migracion, dict_rtign):
        # Compara los campos del feature migrado con los datos de RT_IGN.

        # Args:
            # feature_migracion (QgsFeature): Feature de la capa migrada
            # dict_rtign (dict): Diccionario con los datos de RT_IGN

        # Returns:
            # dict: Diccionario con:
                # - 'rtign': {campo_rtign: valor}  (todos los valores RT_IGN)
                # - 'resultado': {campo_jccm: 'OK'/'MAL'/'N/C'}
                # - 'num_ok': int
                # - 'num_mal': int
                # - 'num_total': int
        resultado = {
            'rtign': {},
            'rtign_dict': dict_rtign or {},   # <-- añadir esto
            'resultado': {},
            'num_ok': 0,
            'num_mal': 0,
            'num_total': 0,
        }

        if not dict_rtign:
            # Sin datos de RT_IGN → todos los campos como 'N/C'
            for campo_rtign in MAPEO_CAMPOS_RTIGN_RTJCCM.keys():
                resultado['rtign'][campo_rtign] = None
                campo_jccm = MAPEO_CAMPOS_RTIGN_RTJCCM[campo_rtign]
                resultado['resultado'][campo_jccm] = 'N/C'
            return resultado

        # Guardar todos los valores de RT_IGN
        for campo_rtign in MAPEO_CAMPOS_RTIGN_RTJCCM.keys():
            resultado['rtign'][campo_rtign] = dict_rtign.get(campo_rtign)

        # Comparar campo a campo
        for campo_rtign, campo_jccm in MAPEO_CAMPOS_RTIGN_RTJCCM.items():
            valor_rtign = dict_rtign.get(campo_rtign)
            valor_jccm = None

            # Obtener el valor del feature migrado
            try:
                valor_jccm = feature_migracion[campo_jccm]
            except Exception:
                valor_jccm = None

            # Normalizar valores para comparación
            val_rtign_norm = self._normalizar_valor(valor_rtign)
            val_jccm_norm = self._normalizar_valor(valor_jccm)

            # Comparar
            if val_rtign_norm is None:
                resultado['resultado'][campo_jccm] = 'N/C'
            elif val_jccm_norm is None:
                resultado['resultado'][campo_jccm] = 'MAL'
                resultado['num_mal'] += 1
                resultado['num_total'] += 1
            elif val_rtign_norm == val_jccm_norm:
                resultado['resultado'][campo_jccm] = 'OK'
                resultado['num_ok'] += 1
                resultado['num_total'] += 1
            else:
                resultado['resultado'][campo_jccm] = 'MAL'
                resultado['num_mal'] += 1
                resultado['num_total'] += 1

        return resultado

    def _normalizar_valor(self, valor):
        # Normaliza un valor para comparación (string, sin espacios, minúsculas).
        if valor is None:
            return None
        s = str(valor).strip()
        if s == '':
            return None
        return s.lower()

    # ------------------------------------------------------------------------
    # VALIDACIÓN DE UN FEATURE (CON MÚLTIPLES PUNTOS)
    # ------------------------------------------------------------------------

    def validar_feature(self, feature, num_puntos=3, fracciones=None):
        # Valida un feature tomando N puntos y consultando RT_IGN en cada uno.
        # Devuelve el resultado agregado (el punto que más campos OK tenga).

        # Args:
            # feature (QgsFeature): Feature a validar
            # num_puntos (int): Número de puntos
            # fracciones (list): Fracciones de la longitud

        # Returns:
            # dict: Mejor resultado de todos los puntos consultados
        geom = feature.geometry()
        if geom is None or geom.isNull():
            return None

        # Obtener puntos de muestreo
        puntos = self.obtener_puntos_muestreo(geom, num_puntos, fracciones)
        if not puntos:
            return None

        mejor_resultado = None
        mejor_num_ok = -1

        for i, punto in enumerate(puntos):
            dict_rtign = self.consultar_rt_ign_en_punto(punto)

            resultado = self.comparar_campos(feature, dict_rtign)
            resultado['punto'] = (punto.x(), punto.y())
            resultado['num_punto'] = i + 1

            # Nos quedamos con el resultado que tenga más campos OK
            if resultado['num_ok'] > mejor_num_ok:
                mejor_num_ok = resultado['num_ok']
                mejor_resultado = resultado

        return mejor_resultado

    # ------------------------------------------------------------------------
    # VALIDACIÓN MASIVA Y GENERACIÓN DEL GPKG DE ERRORES
    # ------------------------------------------------------------------------

    def validar_capa_migrada(
        self,
        capa_migrada,
        ruta_gpkg_errores='c:/temp/logERROR.gpkg',
        nombre_capa_errores='capaerrores',
        num_puntos=3,
        fracciones=None,
        limite_pruebas=0,
        progressBar=None,
        lblINFO=None,
    ):
        # Valida una capa migrada contra RT_IGN y genera un GPKG de errores.

        # Args:
            # capa_migrada (QgsVectorLayer): Capa migrada a validar
            # ruta_gpkg_errores (str): Ruta del GPKG de salida
            # nombre_capa_errores (str): Nombre de la capa de errores
            # num_puntos (int): Número de puntos por geometría
            # fracciones (list): Fracciones de longitud
            # limite_pruebas (int): 0 = todos
            # progressBar: Barra de progreso del UI (opcional)
            # lblINFO: Label de info del UI (opcional)

        # Returns:
            # dict: Resumen de la validación
        if capa_migrada is None or not capa_migrada.isValid():
            return {'error': 'Capa migrada no válida'}

        start = timeit.default_timer()

        # --------------------------------------------------------------------
        # 1. CREAR CAPA DE ERRORES EN MEMORIA
        # --------------------------------------------------------------------
        capa_errores = QgsVectorLayer(
            "MultiLineString?crs=" + capa_migrada.crs().authid(),
            nombre_capa_errores,
            "memory"
        )
        if not capa_errores.isValid():
            return {'error': 'No se pudo crear capa de errores'}

        pr = capa_errores.dataProvider()

        # Campos base: todos los de la capa migrada
        campos_errores = []

        # Campos de la capa migrada
        campos_migrada = [f.name() for f in capa_migrada.fields()]
        for field in capa_migrada.fields():
            campos_errores.append(QgsField('jccm_' + field.name(), field.type()))

        # Campos de RT_IGN
        for campo_rtign in MAPEO_CAMPOS_RTIGN_RTJCCM.keys():
            campos_errores.append(QgsField('rtign_' + campo_rtign, QVariant.String))

        # Campos de resultado (uno por campo comparable)
        for campo_jccm in MAPEO_CAMPOS_RTIGN_RTJCCM.values():
            campos_errores.append(QgsField('result_' + campo_jccm, QVariant.String))

        # Campos de resumen
        campos_errores.append(QgsField('num_ok', QVariant.Int))
        campos_errores.append(QgsField('num_mal', QVariant.Int))
        campos_errores.append(QgsField('num_total', QVariant.Int))
        campos_errores.append(QgsField('punto_x', QVariant.Double))
        campos_errores.append(QgsField('punto_y', QVariant.Double))
        campos_errores.append(QgsField('num_punto', QVariant.Int))
        # Campos de refinamiento (advertencias)
        campos_errores.append(QgsField('refinamiento', QVariant.String))
        campos_errores.append(QgsField('campos_refinados', QVariant.String))

        pr.addAttributes(campos_errores)
        capa_errores.updateFields()

        # --------------------------------------------------------------------
        # 2. OBTENER FEATURES A VALIDAR
        # --------------------------------------------------------------------
        features = list(capa_migrada.getFeatures())

        # Si hay selección, usar solo esos
        selected_ids = capa_migrada.selectedFeatureIds()
        if selected_ids:
            request = QgsFeatureRequest().setFilterFids(selected_ids)
            features = list(capa_migrada.getFeatures(request))

        if limite_pruebas > 0:
            features = features[:limite_pruebas]

        total = len(features)
        if total == 0:
            return {'error': 'No hay features para validar'}

        # --------------------------------------------------------------------
        # 3. VALIDAR CADA FEATURE
        # --------------------------------------------------------------------
        capa_errores.startEditing()

        count_val = 0
        count_err = 0
        count_sin_rtign = 0

        for idx, feature in enumerate(features):
            try:
                if progressBar:
                    progressBar.setValue(int((idx + 1) / total * 100))
                if lblINFO:
                    lblINFO.setText(f'INFO: Validando {idx+1}/{total}')
                QApplication.processEvents()

                # 1. Consultar RT_IGN
                geom = feature.geometry()
                puntos = self.obtener_puntos_muestreo(geom, num_puntos, fracciones)
                if not puntos:
                    count_err += 1
                    continue

                mejor_resultado = None
                mejor_num_ok = -1
                for i, punto in enumerate(puntos):
                    dict_rtign = self.consultar_rt_ign_en_punto(punto)
                    resultado = self.comparar_campos(feature, dict_rtign)
                    resultado['punto'] = (punto.x(), punto.y())
                    resultado['num_punto'] = i + 1
                    if resultado['num_ok'] > mejor_num_ok:
                        mejor_num_ok = resultado['num_ok']
                        mejor_resultado = resultado

                if mejor_resultado is None:
                    count_err += 1
                    continue

                if mejor_resultado['num_total'] == 0:
                    count_sin_rtign += 1

                # 2. APLICAR REFINAMIENTO CON RT_IGN
                # (sobre una copia del feature para no modificar la capa original)
                fet_refinado = QgsFeature(feature)
                dict_rtign_mejor = mejor_resultado.get('rtign_dict')  # añadir en comparar_campos
                info_refin = self.refinar_con_rtign(fet_refinado, self._rtign_a_dict(mejor_resultado))

                # 3. Recalcular comparación tras refinamiento
                resultado_post = self.comparar_campos(fet_refinado, self._rtign_a_dict(mejor_resultado))

                # 4. Crear feature de error
                fet_err = QgsFeature(capa_errores.fields())
                fet_err.setGeometry(QgsGeometry(feature.geometry()))

                # Campos migrados (POST-refinamiento)
                for field in capa_migrada.fields():
                    nombre_orig = field.name()
                    try:
                        valor = fet_refinado[nombre_orig]
                        fet_err['jccm_' + nombre_orig] = valor
                    except Exception:
                        pass

                # Campos RT_IGN
                for campo_rtign, valor in mejor_resultado['rtign'].items():
                    try:
                        fet_err['rtign_' + campo_rtign] = str(valor) if valor is not None else None
                    except Exception:
                        pass

                # Resultados POST-refinamiento
                for campo_jccm, val_resultado in resultado_post['resultado'].items():
                    try:
                        fet_err['result_' + campo_jccm] = val_resultado
                    except Exception:
                        pass

                # Resumen post-refinamiento
                fet_err['num_ok'] = resultado_post['num_ok']
                fet_err['num_mal'] = resultado_post['num_mal']
                fet_err['num_total'] = resultado_post['num_total']

                if 'punto' in mejor_resultado:
                    fet_err['punto_x'] = mejor_resultado['punto'][0]
                    fet_err['punto_y'] = mejor_resultado['punto'][1]
                fet_err['num_punto'] = mejor_resultado.get('num_punto', 0)

                # Refinamiento
                fet_err['refinamiento'] = 'SI' if info_refin['campos_refinados'] else 'NO'
                fet_err['campos_refinados'] = ', '.join(info_refin['campos_refinados'])

                pr.addFeatures([fet_err])
                count_val += 1

            except Exception as e:
                print(f"Error validando feature {idx}: {e}")
                import traceback
                traceback.print_exc()
                count_err += 1
                continue

        # for idx, feature in enumerate(features):
            # try:
                # if progressBar:
                    # progressBar.setValue(int((idx + 1) / total * 100))
                # if lblINFO:
                    # lblINFO.setText(f'INFO: Validando {idx+1}/{total}')
                # QApplication.processEvents()

                # # Validar contra RT_IGN
                # resultado = self.validar_feature(feature, num_puntos, fracciones)

                # if resultado is None:
                    # count_err += 1
                    # continue

                # if resultado['num_total'] == 0:
                    # count_sin_rtign += 1

                # # Crear feature de error
                # fet_err = QgsFeature(capa_errores.fields())

                # # Geometría original
                # fet_err.setGeometry(QgsGeometry(feature.geometry()))

                # # Campos de la capa migrada (con prefijo jccm_)
                # for field in capa_migrada.fields():
                    # nombre_orig = field.name()
                    # try:
                        # valor = feature[nombre_orig]
                        # fet_err['jccm_' + nombre_orig] = valor
                    # except Exception:
                        # pass

                # # Campos de RT_IGN (con prefijo rtign_)
                # for campo_rtign, valor in resultado['rtign'].items():
                    # try:
                        # fet_err['rtign_' + campo_rtign] = str(valor) if valor is not None else None
                    # except Exception:
                        # pass

                # # Campos de resultado
                # for campo_jccm, val_resultado in resultado['resultado'].items():
                    # try:
                        # fet_err['result_' + campo_jccm] = val_resultado
                    # except Exception:
                        # pass

                # # Resumen
                # fet_err['num_ok'] = resultado['num_ok']
                # fet_err['num_mal'] = resultado['num_mal']
                # fet_err['num_total'] = resultado['num_total']

                # if 'punto' in resultado:
                    # fet_err['punto_x'] = resultado['punto'][0]
                    # fet_err['punto_y'] = resultado['punto'][1]
                # fet_err['num_punto'] = resultado.get('num_punto', 0)

                # # Añadir
                # pr.addFeatures([fet_err])
                # count_val += 1

            # except Exception as e:
                # print(f"Error validando feature {idx}: {e}")
                # count_err += 1
                # continue

        capa_errores.commitChanges()
        capa_errores.updateExtents()

        # --------------------------------------------------------------------
        # 4. EXPORTAR A GPKG
        # --------------------------------------------------------------------
        resultado_export = self._exportar_capa_errores(
            capa_errores, ruta_gpkg_errores, nombre_capa_errores
        )

        # --------------------------------------------------------------------
        # 5. RESUMEN
        # --------------------------------------------------------------------
        elapsed = datetime.timedelta(seconds=(timeit.default_timer() - start))

        return {
            'total_features': total,
            'features_validados': count_val,
            'features_error': count_err,
            'features_sin_rtign': count_sin_rtign,
            'tiempo': str(elapsed).split('.')[0],
            'gpkg': ruta_gpkg_errores,
            'capa': nombre_capa_errores,
            'export_ok': resultado_export,
        }

    def _exportar_capa_errores(self, capa, ruta_gpkg, nombre_capa):
        # Exporta la capa de errores a un GPKG.
        try:
            # Crear directorio
            dir_salida = os.path.dirname(ruta_gpkg)
            if dir_salida and not os.path.exists(dir_salida):
                os.makedirs(dir_salida)

            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "GPKG"
            options.layerName = nombre_capa

            if os.path.exists(ruta_gpkg):
                options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

            error = QgsVectorFileWriter.writeAsVectorFormatV2(
                capa, ruta_gpkg, QgsCoordinateTransformContext(), options
            )

            return error[0] == QgsVectorFileWriter.NoError

        except Exception as e:
            print(f"Error exportando GPKG de errores: {e}")
            return False

    # ------------------------------------------------------------------------
    # CARGA DEL GPKG DE ERRORES CON ESTILO POR RESULTADO
    # ------------------------------------------------------------------------

    def cargar_gpkg_errores(self, ruta_gpkg, nombre_capa, agregar_a_toc=True):
        # Carga el GPKG de errores y aplica un estilo categorizado por
        # el número de campos MAL.

        # Args:
            # ruta_gpkg (str): Ruta al GPKG
            # nombre_capa (str): Nombre de la capa dentro del GPKG
            # agregar_a_toc (bool): Si True, añade la capa a la TOC
                                  # Si False, solo devuelve la capa (la añade el llamante)

        # Returns:
            # QgsVectorLayer: Capa cargada, o None si falla
        try:
            uri = f"{ruta_gpkg}|layername={nombre_capa}"
            capa = QgsVectorLayer(uri, nombre_capa, "ogr")

            if not capa.isValid():
                print(f"Capa no válida: {uri}")
                return None

            # Aplicar estilo según 'num_mal' con renderer categorizado
            self._aplicar_estilo_errores(capa)

            # Añadir a la TOC solo si se indica
            if agregar_a_toc:
                QgsProject.instance().addMapLayer(capa)

            return capa

        except Exception as e:
            print(f"Error cargando GPKG de errores: {e}")
            import traceback
            traceback.print_exc()
            return None

    def _aplicar_estilo_errores(self, capa):
        # Aplica un estilo categorizado por el campo 'num_mal':
            # - 0 errores   -> Verde
            # - 1-3 errores -> Amarillo
            # - 4-6 errores -> Naranja
            # - 7+ errores  -> Rojo
        try:
            from qgis.PyQt.core import (
                QgsRendererCategory, QgsCategorizedSymbolRenderer,
                QgsSymbol, QgsWkbTypes
            )
            from qgis.PyQt.QtGui import QColor

            def crear_simbolo(color_hex, ancho=1.0):
                sym = QgsSymbol.defaultSymbol(QgsWkbTypes.LineGeometry)
                sym.setColor(QColor(color_hex))
                sym.setWidth(ancho)
                return sym

            categorias = [
                QgsRendererCategory(0,  crear_simbolo('#00AA00', 1.0), 'OK (0 mal)'),
                QgsRendererCategory(1,  crear_simbolo('#FFFF00', 1.2), '1-3 mal'),
                QgsRendererCategory(2,  crear_simbolo('#FF8800', 1.4), '4-6 mal'),
                QgsRendererCategory(3,  crear_simbolo('#CC0000', 1.6), '7+ mal'),
            ]

            # Si no existe el campo num_mal, usar un estilo simple
            if capa.fields().indexFromName('num_mal') == -1:
                sym = crear_simbolo('#CC0000', 1.2)
                capa.setRenderer(sym.clone())
                capa.triggerRepaint()
                return

            # Renderer categorizado basado en expresión CASE
            from qgis.PyQt.core import QgsExpression
            expresion = QgsExpression(
                "CASE "
                "WHEN \"num_mal\" = 0 THEN 0 "
                "WHEN \"num_mal\" <= 3 THEN 1 "
                "WHEN \"num_mal\" <= 6 THEN 2 "
                "ELSE 3 END"
            )

            renderer = QgsCategorizedSymbolRenderer(expresion.expression(), categorias)
            capa.setRenderer(renderer)
            capa.triggerRepaint()

        except Exception as e:
            print(f"Error aplicando estilo a capa de errores: {e}")
            import traceback
            traceback.print_exc()

    # ------------------------------------------------------------------------
    # REFINAMIENTO POR RT_IGN
    # ------------------------------------------------------------------------

    def refinar_con_rtign(self, feature_migracion, dict_rtign):
        # Aplica las reglas de refinamiento (REGLAS_REFINAMIENTO_RTIGN) para
        # corregir los valores migrados usando RT_IGN como referencia.

        # Args:
            # feature_migracion (QgsFeature): Feature migrado (se MODIFICA in-place)
            # dict_rtign (dict): Datos de RT_IGN

        # Returns:
            # dict: Información del refinamiento aplicado
                # {
                  # 'campos_refinados': [lista de campos que se han modificado],
                  # 'detalles': {campo: {'valor_antes': X, 'valor_despues': Y, 'rtign': Z}},
                # }
        resultado = {
            'campos_refinados': [],
            'detalles': {},
        }

        if not dict_rtign:
            return resultado

        # Importar las reglas desde RT_CONFIG
        try:
            from .RT_CONFIG import REGLAS_REFINAMIENTO_RTIGN
        except ImportError:
            return resultado

        # Recorrer cada regla
        for campo_jccm, regla in REGLAS_REFINAMIENTO_RTIGN.items():
            # Saltar campos sin adoptar
            if not regla.get('adoptar_rtign', False):
                continue

            # Saltar campos excluidos
            if regla.get('excluir_comparacion', False):
                continue

            # Obtener el campo RT_IGN origen
            campo_rtign = None
            for rtign_field, jccm_field in MAPEO_CAMPOS_RTIGN_RTJCCM.items():
                if jccm_field == campo_jccm:
                    campo_rtign = rtign_field
                    break

            # Casos especiales: campos derivados (tipo_vial, calzada, etc.)
            if campo_rtign is None:
                # Buscar en 'derivar_codigo_desde_rtign'
                derivar = regla.get('derivar_codigo_desde_rtign')
                if derivar:
                    campo_rtign = derivar.get('campo_texto_rtign')

            if not campo_rtign:
                continue

            valor_rtign = dict_rtign.get(campo_rtign)
            if valor_rtign is None:
                continue

            # Verificar condiciones
            if not self._cumple_condiciones(regla.get('condiciones', []), dict_rtign, valor_rtign):
                continue

            # Determinar el valor objetivo (puede ser derivado del texto RT_IGN)
            valor_objetivo = valor_rtign

            # Si hay mapa de derivación, convertir texto → código
            if 'derivar_codigo_desde_rtign' in regla:
                mapa = regla['derivar_codigo_desde_rtign'].get('mapa', {})
                if valor_rtign in mapa:
                    valor_objetivo = mapa[valor_rtign]

            # Comparar con el valor actual
            try:
                valor_actual = feature_migracion[campo_jccm]
            except Exception:
                valor_actual = None

            # Normalizar para comparación
            va_norm = str(valor_actual).strip() if valor_actual is not None else ''
            vo_norm = str(valor_objetivo).strip() if valor_objetivo is not None else ''

            if va_norm == vo_norm:
                continue  # No hay nada que refinar

            # Aplicar refinamiento
            try:
                feature_migracion[campo_jccm] = valor_objetivo
                resultado['campos_refinados'].append(campo_jccm)
                resultado['detalles'][campo_jccm] = {
                    'valor_antes': valor_actual,
                    'valor_despues': valor_objetivo,
                    'rtign': valor_rtign,
                }
            except Exception as e:
                print(f"Error refinando {campo_jccm}: {e}")

        return resultado

    def _cumple_condiciones(self, condiciones, dict_rtign, valor_rtign):
        # Verifica si se cumplen las condiciones de refinamiento.
        if not condiciones:
            return True

        for cond in condiciones:
            tipo = cond.get('tipo')

            if tipo == 'rtign_no_vacio':
                if not valor_rtign or str(valor_rtign).strip() == '':
                    return False

            elif tipo == 'matricula_9000':
                mat = dict_rtign.get('matricula', '')
                if str(mat) != '9000':
                    return False

            elif tipo == 'rtign_in':
                valores = cond.get('valores', [])
                if valor_rtign not in valores:
                    return False

            elif tipo == 'rtign_not_in':
                valores = cond.get('valores', [])
                if valor_rtign in valores:
                    return False

            elif tipo == 'campo_rtign_igual':
                campo = cond.get('campo')
                valor = cond.get('valor')
                if dict_rtign.get(campo) != valor:
                    return False

        return True