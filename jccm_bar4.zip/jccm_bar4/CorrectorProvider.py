## CorrectorProvider.py

from qgis.core import QgsProcessingProvider
from .CorrectorDeCapasDePoligonos import CorrectorDeCapasDePoligonos
from .herrExpro_CalculaReparcelacionParaGml import herrExpro_CalculaReparcelacionParaGml


class CorrectorProvider(QgsProcessingProvider):
    def loadAlgorithms(self):
        # Añade tu algoritmo personalizado al proveedor
        self.addAlgorithm(CorrectorDeCapasDePoligonos())
        self.addAlgorithm(herrExpro_CalculaReparcelacionParaGml())

    def id(self):
        return 'jccm_bar4'  # ID único para tu proveedor

    def name(self):
        return self.tr('JCCM herramientas')  # Nombre corto

    def longName(self):
        return self.tr('JCCM Processing Tools')  # Nombre largo o descriptivo
