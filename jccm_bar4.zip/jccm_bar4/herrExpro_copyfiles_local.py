# -*- coding: utf-8 -*-
"""
/***************************************************************************
 herrExpro_copyfiles_local.py
                                 A QGIS4 plugin
 herrExpro
                             -------------------
        begin                : 2017-01-25
        git sha              : $Format:%H$
        copyright            : (C) A.Solabre 2017
        email                : gis.carreteras@jccm.es
        
COPIA FICHEROS DESDE EQUIP LOCAL A SERVIDORES
        
 ***************************************************************************/
"""
from qgis.PyQt.QtCore import Qt,  QSettings
from qgis.PyQt.QtWidgets import QApplication
from qgis.gui import QgsMessageBar
from qgis.core import Qgis

import os, time, fnmatch
import shutil
import datetime
import sys
from stat import *
from os.path import isfile, join

# 1- Creamos variables
# 1A- EXISTE EL DIRECTORIO ORIGEN?
# 2- Obtenemos datos (tamano, fecha) del SHP origen O DE TODOS
# 3- Buscamos SHP destino similares en dir destino
# 4- Existe si diferente tamano y fecha -> copia seg
# 5- Existe igual tamano y fecha -> NO copia seg
# 6- No existe -> copia seg

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

udConfig = u'U:'
sys.path.append(udConfig + '/cartografia/datos_Q/QSIG/config/')

class copyFilesLocal():

    def __init__(self, iface, parent=None):
        self.fun = Functions()
        self.iface = iface
        self.current_configuration = configuration()
        self.qs = QSettings();

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))
        
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        
        # Se comprueba si existe configuración usuario de ficheros de copia seguridad
        ficherosCopyLocal = f"{self.nombre_plugin}/ficherosCopyLocal"
        self.qs.beginGroup(ficherosCopyLocal)
        listficherosCopyLocal = self.qs.childKeys()
        self.qs.endGroup()
        if len(listficherosCopyLocal) == 0:
            ficherosCopyLocal = self.current_configuration.ficherosCopyLocal

        print (ficherosCopyLocal)

        text = u'COPIA DE SEGURIDAD DE FICHEROS DE LOCAL A SERVIDOR'+'\n\n'
        progress = 'Copia de seguridad de Ficheros de LOCAL a SERVIDOR...'.format(txt='')
        self.iface.mainWindow().statusBar().showMessage(progress)

        # Presenta un messagebar de información
        iface.messageBar().pushMessage(u'Copia de seguridad de Ficheros de LOCAL a SERVIDOR', u'', level=Qgis.Info, duration=3 )

        # Comienza la identifcación de ficheros
        datoCopy = []
        for dato in ficherosCopyLocal:
            print (dato)
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

            fichOri  =dato['origen']
            fichDest =dato['destino']
            oriDir = os.path.split(fichOri)[0]
            oriFil = os.path.split(fichOri)[1]
            dstDir = os.path.split(fichDest)[0]
            dstFil = os.path.split(fichDest)[1]
            
            # Comprobamos que existe la unidad DESTINO Y SI EXISTE EL DIRECTORIO
            unidstDir = dstDir[:2]
            if not os.path.exists(unidstDir):
                QApplication.restoreOverrideCursor()
                text = u'NO EXISTE UNIDAD DESTINO %s\n\nESTUDIAR DÓNDE SE GUARDA LA COPIA DE SEGURIDAD \n\nDESTINO:\n%s'%(unidstDir,dstDir)
                self.fun.showMessage(text)
                self.iface.mainWindow().statusBar().showMessage('')
                continue
            else:
                # Creamos el directorio destino si no existe
                try:
                    if not os.path.exists(dstDir):
                        os.makedirs(dstDir)
                except:
                    QApplication.restoreOverrideCursor()
                    text = u'NO SE PUEDE ESCRIBIR UNIDAD DESTINO %s\n\nESTUDIAR DÓNDE SE GUARDA LA COPIA DE SEGURIDAD \n\nDESTINO:\n%s'%(unidstDir,dstDir)
                    self.fun.showMessage(text)
                    self.iface.mainWindow().statusBar().showMessage('')
                    continue
            datoCopy.apppend(dato)
                
            srcDir = ''
            dstDir +=u'/'
            
            text = ''
            text += '--ORIGEN--- ' + oriDir +'\n'
            text += '            ' + oriFil +'\n\n'
            text += '--DESTINO-- ' + dstDir+'\n'
            text += '            ' + dstFil +'\n\n'

            QApplication.restoreOverrideCursor()
            self.fun.showMessage(text)
            
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        return
        
        
        textMsg = u'FICHEROS COPIADOS: \n--------------------\n\n' 
        for srcFile in files:
            print (srcFile)
            copiarfile = 0

            if os.path.isfile(srcFile):
                # 1A- EXISTE EL FICHERO ORIGEN
                # Datos del fichero origen SRC
                stSrc = os.stat(srcFile)
                srcSIZE = stSrc[ST_SIZE]                                    # Tamaño del fichero
                srcDATEM = time.asctime(time.localtime(stSrc[ST_MTIME]))    # Fecha del fichero en TXT
                srcDATEMt = stSrc[ST_MTIME]                                 # Fecha del fichero
                # srcDir = os.path.dirname(srcFile)
                srcDir, srcFilExtName = os.path.split(srcFile)
                srcFilName, srcExt = os.path.splitext(srcFilExtName)
                print ('  stSrc ', stSrc, '\n', 'srcSIZE ', srcSIZE, '\n', 'srcDATEM ', srcDATEM, '\n', 'srcDATEMt ', srcDATEMt, '\n')
                
                fileModerno = 0
                
                for dstFilExt in extList:
                    if srcExt == dstFilExt:
                        for f in fnmatch.filter(os.listdir(dstDir),srcFilName+ u'*'+dstFilExt):
                            progress = 'Comprobando - '+f
                            self.iface.mainWindow().statusBar().showMessage(progress)  
                            filcopSIZE = stSrc = os.stat(join(dstDir, f))[ST_SIZE]
                            filcopDATEM = time.asctime(time.localtime(os.stat(join(dstDir, f))[ST_MTIME]))
                            filcopDATEMt = os.stat(join(dstDir, f))[ST_MTIME]
                            # filcopDATEMt = # Hay que obtener el fichero mas moderno de 
                            print ('  f ', f, '\n', 'filcopSIZE ', filcopSIZE, '\n', 'filcopDATEM ', filcopDATEM, '\n', 'filcopDATEMt ', filcopDATEMt, 'copiarfile =', copiarfile, '\n')
                            
                            #############   REVISAR ESTO DE LAS FECHAS      #############
                            
                            if filcopDATEMt > fileModerno:  #
                               fileModerno = filcopDATEMt
                               
                        if (fileModerno < srcDATEMt):
                            copiarfile = 1
                        
                        print ('dstFilExt', dstFilExt, u"  len(fnmatch.filter(os.listdir(dstDir),srcFilName+ u'*'+dstFilExt)) = ", len(fnmatch.filter(os.listdir(dstDir),srcFilName+ u'*'+dstFilExt)))
                        print ('  copiarfile =', copiarfile)
                        if len(fnmatch.filter(os.listdir(dstDir),srcFilName+ u'*'+dstFilExt)) == 0:
                            copiarfile = 1

                if copiarfile == 1:
                    # HACEMOS COPIA DE SEGURIDAD
                    # print 'HACEMOS COPIA DE SEGURIDAD'
                    textMsg += u' + COPIADO - ' + srcFile +u'\n\n'
                    t= datetime.datetime.now()
                    fechor = t.strftime('%Y%m%d%H%M')

                    # filename_ext = os.path.basename(srcDir+srcFilName+'.shp')
                    # dstFilName, dstFilExt = os.path.splitext(srcFile)
                    dstFilName = srcFilName+'_'+fechor

                    for dstFilExt in extList:
                        # print srcFilName,dstFilExt
                        # print dstDir,dstFilName+dstFilExt
                        # shutil.copy(srcFilName+dstFilExt, dstDir+dstFilName+dstFilExt)
                        # print '  ORIGEN  - ',srcDir+'/'+srcFilName+dstFilExt
                        # print '  DESTINO - ',dstDir+dstFilName+dstFilExt
                        if os.path.exists(srcDir+'/'+srcFilName+dstFilExt):
                            shutil.copy(srcDir+'/'+srcFilName+dstFilExt, dstDir+dstFilName+dstFilExt)
                else:
                    # print ' - NO se copia'
                    # print u'LA COPIA DE SEGURIDAD ES ACTUAL'
                    textMsg += u' - NO COPIADO, ES ACTUAL - ' + srcFile + u'\n\n' 
                    self.iface.mainWindow().statusBar().clearMessage()

            else:
                # 1B- NO EXISTE EL FICHERO ORIGEN
                textMsg += u' - NO EXISTE FICHERO ORIGEN - ' + srcFile +u'\n\n'

        # Muestra del mensaje de resultado y cierre del messagebar
        QApplication.restoreOverrideCursor()
        progress = 'Copiados Ficheros de EXPROPIACIONES'.format(txt='')
        self.iface.mainWindow().statusBar().showMessage(progress)
        self.fun.showMessage(textMsg, '','Copia de Seguridad de ficheros')
        
        iface.messageBar().clearWidgets()
        
