# -*- coding: utf-8 -*-
"""
/***************************************************************************
 herrExpro_controlCalidadGDB.py
                                 A QGIS4 plugin
 jcml_bar
                             -------------------
        begin                : 2019-02-14
        git sha              : $Format:%H$
        copyright            : (C) 2016 by ASS
        email                : asolabre@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import QIcon, QPixmap
from qgis.PyQt.QtCore import QSettings, QCoreApplication, QTranslator, qVersion, Qt, QVariant, QUrl, QMetaType
from qgis.PyQt.QtWidgets import QApplication, QMessageBox, QToolButton, QMenu, QAction, QDialog, QCheckBox, QFileDialog
from qgis.PyQt import uic

from qgis.gui import QgsMessageBar
from qgis.core import ( QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsApplication,
                        QgsExpression, QgsFeatureRequest, QgsField, QgsFeature, QgsGeometry, QgsPoint, QgsPointXY,
                        QgsLineString, QgsMultiLineString, QgsProviderRegistry, QgsWkbTypes)

from qgis.utils import iface
from qgis.PyQt.QtPrintSupport import QPrinter, QPrintDialog
from qgis.PyQt.QtWebEngineWidgets import QWebEngineView

import os
from osgeo import ogr, osr
import urllib
import json
from time import sleep
import glob, codecs
from functools import partial
import shutil
import datetime
import locale
import tempfile
import sys
import subprocess
import csv
import io
import math
import timeit

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .settings import Settings           # CLASE DE CONFIGURACIÓN DE VARIABLES GLOBALES

from .GDBDominios import GDBdominios

conf = configuration()

# VARIABLES
srcVal = conf.general["EPSG"]
FICHsalida = 'c:/temp/ExproGDB_ctrl.csv'

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrExpro_controlCalidadGDB.ui'))


class herrExpro_controlCalidadGDB(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(herrExpro_controlCalidadGDB, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        self.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/E_icon.jpg'))
        self.logo.setPixmap(QPixmap(f":/plugins/jccm_bar4/iconos/E_icon.jpg"))

        self.fun = Functions()
        self.qs = QSettings()

        self.GDBDom = GDBdominios()
        self.Sett = Settings()
        global tipoUser

        # Comprobamos el rol del usuario
        userSIG, tipoUser = self.Sett.entrarUser()

        self.plugin_dir = os.path.dirname(__file__)
        self.QgisVersion = Qgis.QGIS_VERSION_INT

        # PDF print options
        self.maxLinesPerPage = 40
        self.maxAttributesBeforeSmallFontSize = 15
        self.orientation = QPrinter.Landscape
        self.pageSize = QPrinter.A4

        # CSS template file
        self.cssPath = os.path.join(
            self.plugin_dir, "templates/table.css" )

        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)
        self.progressBar.setValue(0)
        self.lblINFO.setText('INFO:')

        self.buttonBoxOK.clicked.connect(self.ctrlGDBlimExpro)
        self.strPrecision = "{:."+str(self.spnPRECISION.value())+"f}"

        # COMBOS DESPLEGABLES
        # Diccionario con los combos y sus configuraciones
        combos_config = {
            'cbxCapaLimExpro': {
                'tipo': 'Polygon',
                'variable': '/EXPROPIACION/EXPlayerLIMEXPRO'
            },
            'cbxCapaParExpro': {
                'tipo': 'Polygon',
                'variable': '/EXPROPIACION/EXPlayerPARCEXPRO'
            },
            'cbxCapaListExpro': {
                'tipo': 'Table',
                'variable': '/EXPROPIACION/EXPlayerLISTAEXPRO'
            },
            'cbxCapaInfotExpro': {
                'tipo': 'Polygon',
                'variable': '/EXPROPIACION/EXPlayerINFOEXPRO'
            }
        }

        # Inicializar todos los combos
        for combo_nombre, config in combos_config.items():
            combo_widget = getattr(self, combo_nombre)
            lista_capas = self.getCAPAS(config['tipo'])

            combo_widget.clear()
            combo_widget.addItems(lista_capas)

            # Establecer capa por defecto desde config
            last_capa = self.qs.value(f"{self.nombre_plugin}{config['variable']}")
            if last_capa and last_capa in lista_capas:
                index = lista_capas.index(last_capa)
                combo_widget.setCurrentIndex(index)

        ################################################################################
                                        ####   todo CONTROL   ####
        ################################################################################
        # if tipoUser == 'ADMINISTRADOR':
            # # valpredet = u'Básica'
            # pass

        # Controles inactivos
        self.chb01.setVisible(False)
        self.chb02.setVisible(False)
        self.chb03.setVisible(False)
        self.lblPrec.setVisible(False)
        self.spnPRECISION.setVisible(False)
        self.chbTODOSELEMEN.setVisible(False)

        self.cbx_otro.setEnabled(False)
        self.cbx_congruencia.setEnabled(False)
        self.cbx_congruencia_01.setEnabled(False)
        self.cbx_congruencia_02.setEnabled(False)
        self.cbx_sintaxis.setEnabled(False)
        self.cbx_sintaxis_1.setEnabled(False)
        self.cbx_sintaxis_2.setEnabled(False)
        self.cbx_sintaxis_3.setEnabled(False)
        self.cbx_sintaxis_4.setEnabled(False)
        self.cbx_sintaxis_5.setEnabled(False)

        self.grpCTRLcpaLimExpro.setVisible(False)
        self.lblCtrlCapaLimExpro.setVisible(False)
        ################################################################################
                                        ####   todo CONTROL   ####
        ################################################################################


    def getCAPAS(self, tipo):
        """Devuelve lista de nombres de capas según tipo solicitado"""
        capas = []

        # Definir tipos QgsWkbTypes según parámetro
        if tipo == 'Polygon':
            tipos_aceptados = [
                QgsWkbTypes.Polygon,
                QgsWkbTypes.PolygonZ,
                QgsWkbTypes.PolygonM,
                QgsWkbTypes.PolygonZM,
                QgsWkbTypes.MultiPolygon,
                QgsWkbTypes.MultiPolygonZ,
                QgsWkbTypes.MultiPolygonM,
                QgsWkbTypes.MultiPolygonZM
            ]
        elif tipo == 'Table':
            tipos_aceptados = [
                QgsWkbTypes.NoGeometry
            ]
        else:
            return capas

        for layer in QgsProject.instance().mapLayers().values():
            if (isinstance(layer, QgsVectorLayer) and
                layer.geometryType() in [QgsWkbTypes.PolygonGeometry, QgsWkbTypes.NullGeometry]):

                if layer.wkbType() in tipos_aceptados:
                    capas.append(layer.name())

        return sorted(capas)  # Ordenadas alfabéticamente


    def guardar_configuracion_capas(self):
        """Guarda las capas seleccionadas en cada combo"""
        configs = {
            'cbxCapaLimExpro': '/EXPROPIACION/EXPlayerLIMEXPRO',
            'cbxCapaParExpro': '/EXPROPIACION/EXPlayerPARCEXPRO',
            'cbxCapaListExpro': '/EXPROPIACION/EXPlayerLISTAEXPRO',
            'cbxCapaInfotExpro': '/EXPROPIACION/EXPlayerINFOEXPRO'
        }

        for combo_nombre, variable in configs.items():
            combo_widget = getattr(self, combo_nombre)
            capa_seleccionada = combo_widget.currentText()
            if capa_seleccionada:
                self.qs.setValue(f"{self.nombre_plugin}{variable}", capa_seleccionada)


    def closeEvent(self, event):
        QApplication.restoreOverrideCursor()


    def encode(self,text):
        """
        For printing unicode characters to the console.
        """
        # return text.encode('utf-8')
        return text.encode('ISO-8859-14')


    def ctrlGDBlimExpro(self):
        start = timeit.default_timer()
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        self.guardar_configuracion_capas()

        fileTipe = self.cbxTipoExport.currentText()
        if fileTipe == 'IMPRESORA':
            fileTipe = 'printer'
        if fileTipe == u'Solo CSV':
            fileTipe = 'csv'


        ### DATOS DE ENTRADA PARA HTML
        dataEntrada = []

        # COMPROBACIÓN DE CONTROLES PARA AÑADIR CAMPOS CONTROL
        self.listCamposCTRL = []
        chkDominios = False
        if self.cbx_ClaveEXPTE.isChecked():
            self.listCamposCTRL.append('ClaveEXPTE')
        if self.cbx_ProvMuni.isChecked():
            self.listCamposCTRL.append('ProvMuni')

        '''



        # CAMPOS A PONER EN ENCABEZAMIENTOS
        outfields = '*'
        self.listCamposCOMP = ['OBJECTID', 'idMatricula','Matricula','Longitud','PkINI','PkFin','Matricula_Plan',
            'Titularidad','Funcionalidad','Tipologia_DobleC','Tipologia_UnaC','Denominacion',
            'Long_Km','idOrdenCtra','Origen','Destino','Provincia','Shape.STLength()']

        self.listCampos = ['OBJECTID', 'Matricula', 'idMatricula', 'Funcionalidad','Provincia', 'Origen', 'Destino']
        if self.cbx_denomTramos.isChecked():
            self.listCampos = self.listCampos + ['Denominacion']
        self.listCampos = self.listCampos + ['Longitud','PkINI','PkFin','Long_Km']
        self.listCamposCOMP += self.listCamposCTRL
        if chkDominios == True:
            self.listCampos+=['Tipologia_DobleC','Tipologia_UnaC','idOrdenCtra']

        self.listCampos += self.listCamposCTRL

        self.listCamposOrder = ['Titularidad', 'idOrdenCtra', 'Funcionalidad', 'Matricula', 'PkINI', 'Provincia']


        # Comprobamos CAMPOS INCLUIDOS en la salida
        listBorrar = []
        for campo in self.listCampos:
            if not campo in self.listCamposCOMP:
                listBorrar.append(campo)
        for campo in listBorrar:
            self.listCampos.remove(campo)


        # Comprobamos CAMPOS INCLUIDOS en la lista de orden de campos
        listBorrar = []
        for campo in self.listCamposOrder:
            if not campo in self.listCamposCOMP:
                listBorrar.append(campo)
        for campo in listBorrar:
            self.listCamposOrder.remove(campo)
        orderByFields = ",".join(self.listCamposOrder)

        self.lblINFO.setText('INFO: Leyendo url .....')

        TipoExport = self.cbxTipoExport.currentText()


        # CONSULTA DE LA CAPA DE CARRETERAS
        #   QUERY AL WFS Plan_Carreteras_BTA_WFS -- PARCIAL --
        url = conf.general["rest_carreteras"]

        values = {'where' : whereTXT,
                  'text': '',
                  'objectIds': '',
                  'returnGeometry' : False,
                  'returnM': False,
                  'outFields': outfields,
                  'orderByFields' : orderByFields,
                  'f': 'json'}

        restfeatures = self.fun.getFeaturesBTAcalibrada(values)

        if self.cbx_PKSxCtra.isChecked() or self.cbx_calibrPKS.isChecked():
            # DESCARGAMOS LA CAPA DE PKS DE LA PROVINCIA
            nomLayerPKS = 'JCCM CTRAS PKS '+valcbxProvincia
            nomFichPKS = 'C:/TEMP/JCCM_CTRAS_PKS.json'
            layerEXIST = QgsProject.instance().mapLayersByName(nomLayerPKS)
            if layerEXIST:
                self.layerPKS = layerEXIST[0]
                print ('EXISTE ',nomLayerPKS)
            else:
                print ('NO EXISTE ',nomLayerPKS)
                ###  LECTURA DE DATOS DE PKS ###
                self.lblINFO.setText('INFO: Descargando fichero de PKS')
                whereTXTPKS = 'Provincia LIKE '+"'"+valcbxProvincia+"'"
                resultPKS = self.GetJSONPKS(whereTXTPKS)

                self.layerPKS = QgsVectorLayer(json.dumps(resultPKS), nomLayerPKS, "ogr")

                if self.cbx_cargaPKS.isChecked():
                    # Cargar capa solo si se ve necesario
                    #######################################################
                    #####  TODO SUSTITUIR LA CARGA DE LA CAPA  ############
                    # QgsProject.instance().addMapLayer(self.layerPKS, False)
                    QgsProject.instance().addMapLayer(self.layerPKS, True)
                    #######################################################
                    # Colocamos la capa arriba del todo
                    root = QgsProject.instance().layerTreeRoot()
                    root.insertLayer(0, self.layerPKS)

                self.lblINFO.setText('INFO: Leido fichero de PKS')


        numfeats = len(restfeatures)
        nfeat = 0
        if numfeats==0:
            return

        # FICHEROS Y CAPAS
        fich_csv = FICHsalida
        # Comprobamos que existe el directorio y si no, se crea
        dirCsv,nameFichCsv = os.path.split(fich_csv)
        if not os.path.exists(dirCsv):
            os.makedirs(dirCsv)
        fich = FICHsalida.replace('csv', fileTipe)

        QgsMessageLog.logMessage( "Creando archivo de log",self.nombre_plugin)

        # ESCRIBIMOS ENCABEZADOS FICHERO 'CSV'
        target  = codecs.open(fich_csv, 'w+',encoding='utf-8')
        encabezado = ''
        for campo in self.listCamposCOMP:
            encabezado += campo + u';'


        target.write(encabezado)
        target.write("\n")

        # ESCRIBIMOS LISTA DE DATOS
        # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
        countFeat = 0

        for feat in restfeatures:
            attributes = feat["attributes"]
            datErr = False
            # COMPROBAMOS DOBLE VIA
            grabar = True
            if grabar:  # En caso de DOBLE VIA desmarcado, solo grabamos CALZADA D
                datos = u''
                for attr in self.listCamposCOMP:
                    if attr not in self.listCamposCTRL:
                        dat = u''
                        if isinstance(attributes[attr], str):
                            dat = attributes[attr]
                        elif isinstance(attributes[attr], unicode):
                            dat = attributes[attr]
                        elif isinstance(attributes[attr], int):
                            dat = str(attributes[attr])
                        elif isinstance(attributes[attr], float):
                            # print attr, attributes[attr], 'float', ("{:.3f}".format(attributes[attr]))
                            dat = (self.strPrecision.format(attributes[attr]))
                            # self.strPrecision = "{:.3f}"

                        ################################################################################
                        # --- SE REALIZA EL CONTROL DE DOMINIOS ---
                        ################################################################################
                        if self.cbx_dominios.isChecked():
                            if attr == 'Titularidad':
                                if dat not in self.GDBDom.Titularidad:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'Funcionalidad':
                                if dat not in self.GDBDom.Funcionalidad:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'Tipologia_DobleC':
                                if dat not in self.GDBDom.Tipologia_DobleC:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'Tipologia_UnaC':
                                if dat not in self.GDBDom.Tipologia_UnaC:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'Provincia':
                                if dat not in self.GDBDom.Provincia:
                                    dat = '(x) '+dat
                                    datErr = True
                            if attr == 'idOrdenCtra':
                                # Comprobamos la concordancia entre 'Funcionalidad' e 'idOrdenCtra'
                                dataFunc = attributes['Funcionalidad']
                                if dat in self.GDBDom.idOrdenCtra.keys():
                                    if dataFunc != self.GDBDom.idOrdenCtra[dat]:
                                        dat = '(x) '+dat
                                        datErr = True
                                else:
                                    dat = '(x) '+dat+ ' DATO ERRONEO'
                                    datErr = True

                        datos += (dat + u';')

                ################################################################################
                # --- SE REALIZA EL CONTROL DE IDMATRÍCULA DUPLICADO ---
                ################################################################################
                if self.cbx_idmatricula.isChecked():
                    idMatBusq = attributes['idMatricula']
                    result = self.ControlAtributos(idMatBusq)
                    if result != 'OK':
                        datErr = True
                    datos += result + u';'

                ################################################################################
                # --- SE REALIZA EL CONTROL DE DENOMINACION DIFERENTE ---
                ################################################################################
                if self.cbx_denomTramos.isChecked():
                    matriculaFEAT = attributes['Matricula']
                    denominacionFEAT = attributes['Denominacion']
                    if matriculaFEAT[-1] != 'a': # Solo se revisan tramos troncales, no 'a'
                        result = self.ControlDenomTramo(matriculaFEAT, denominacionFEAT)
                        if result != 'OK':
                            datErr = True
                    datos += result + u';'

                ################################################################################
                # --- SE REALIZA EL CONTROL DE CALIBRACIÓN ---
                ################################################################################
                if self.cbx_calibracion.isChecked() or self.cbx_longPks.isChecked():
                    objIdBusq = attributes['OBJECTID']
                    # print ('OBJECTID:', objIdBusq, ' Matricula: ', attributes['Matricula'])
                    result = self.ControlGeometrico(objIdBusq)
                    if result != None:

                        if self.cbx_calibracion.isChecked():
                            datos += result[0] + u';'
                            if result[0] != 'OK':
                                datErr = True
                        if self.cbx_longPks.isChecked():
                            datos += result[1] + u';'
                            if result[1] != 'OK':
                                datErr = True
                        if self.cbx_inicioNeg.isChecked():
                            datos += result[2] + u';'
                            if result[2] != 'OK':
                                datErr = True
                        if self.cbx_congrPKStramos.isChecked():
                            datos +=  'OK' + u';'

                ################################################################################
                # --- SE REALIZA EL CONTROL DE PKS ---
                ################################################################################
                if self.cbx_PKSxCtra.isChecked() or self.cbx_calibrPKS.isChecked():
                    objIdBusq = attributes['OBJECTID']
                    resultPKSxCtra, resultcalibrPKS = self.ControlPKS(objIdBusq)

                    if self.cbx_PKSxCtra.isChecked():
                        if isinstance(resultPKSxCtra,str):
                            datos += resultPKSxCtra + u';'
                            if resultPKSxCtra == 'COMPLETO':
                                datErr = True

                        if isinstance(resultPKSxCtra,list):
                            dataResult = '/'.join(str(e) for e in resultPKSxCtra)
                            datos += dataResult + u';'
                            datErr = True

                    if self.cbx_calibrPKS.isChecked():
                        if isinstance(resultcalibrPKS,str):
                            datos += resultcalibrPKS + u';'
                            if resultcalibrPKS == 'COMPLETO':
                                datErr = True

                        if isinstance(resultcalibrPKS,list):
                            dataResult = '/'.join(str(e) for e in resultcalibrPKS)
                            datos += dataResult + u';'
                            datErr = True


                #####################################
                # --- AÑADIENDO LINEA AL FICHERO ---
                #####################################
                items = datos.split(";")
                # print (datos)
                # print ('TOTAL: ', len(items), items)

                if datErr == True or self.chbTODOSELEMEN.isChecked():
                    # print datos
                    target.write(datos)
                    target.write("\n")
                nfeat +=1
                prog = 50 * nfeat/numfeats
                self.progressBar.setValue(int(prog))
                self.lblINFO.setText(u'INFO: Añadiendo a CSV registro ' + str(nfeat) +'/' +str(numfeats)
                    +' Ctra: '+ attributes['Matricula'])

        #####################################
        # --- CERRANDO FICHERO target ---
        #####################################
        target.close()

        # Se carga la capa de EJES
        if self.cbx_calcEJESCAL.isChecked():
            QgsProject.instance().addMapLayer(self.dest_layerEJES, False)
            # TODO Habrá que crear un estilo
            # estiloCAPA = os.path.join(os.path.dirname(__file__), conf.general["carpeta_estilos"] + '/GDB_PKS_AUSENTES.qml')
            # self.dest_layerEJES.loadNamedStyle(estiloCAPA)

            # Colocamos la capa arriba del todo
            root = QgsProject.instance().layerTreeRoot()
            root.insertLayer(0, self.dest_layerEJES)


        # Se carga la capa de PKS
        if self.cbx_PKSxCtra.isChecked() and self.cbx_calcPKS.isChecked():
            QgsProject.instance().addMapLayer(self.dest_layerPKS, False)
            estiloCAPA = os.path.join(os.path.dirname(__file__), conf.general["carpeta_estilos"] + '/GDB_PKS_AUSENTES.qml')
            self.dest_layerPKS.loadNamedStyle(estiloCAPA)

            # Colocamos la capa arriba del todo
            root = QgsProject.instance().layerTreeRoot()
            root.insertLayer(0, self.dest_layerPKS)


        fich_csv_uri = u"file:///"+ fich_csv +"?type=csv&geomType=none&subsetIndex=no&delimiter=%s&watchFile=no" % (";")

        abstract = ''
        if self.cbxTitularidad.currentText() != '%':
                    abstract += u'Titularidad - %s / '%self.cbxTitularidad.currentText()
        if self.cbxFuncionalidad.currentText() != '%':
                    abstract += u'Funcionalidad - %s / '%self.cbxFuncionalidad.currentText()
        if self.cbxProvincia.currentText() != '%':
                    abstract += u'Provincia - %s / '%self.cbxProvincia.currentText()

        # Esto crea la capa CSV
        #   Si existe la capa se debe borrar
        nomcapa = u'CATALOGO CARRETERAS CTRL'
        csv_lyrLIST = QgsProject.instance().mapLayersByName(nomcapa)
        if len(csv_lyrLIST) >0:
            for csv_lyr in csv_lyrLIST:
                QgsProject.instance().removeMapLayer(csv_lyr.id())
        csv_lyr = QgsVectorLayer(fich_csv_uri, nomcapa,'delimitedtext')
        # csv_lyr.setAbstract (abstract)
        QgsProject.instance().addMapLayer(csv_lyr, False)

        # Colocamos la capa arriba del todo
        root = QgsProject.instance().layerTreeRoot()
        root.insertLayer(0, csv_lyr)
        self.iface.setActiveLayer(csv_lyr)


        self.tbrURLCOMPLETA.setHtml(self.creaHTML(''))
        pass

        # self.exportLayer(fileTipe, fich)
        self.exportLayer(dataEntrada, fileTipe, fich)


        # Abrir el fichero resultante
        if os.path.exists(self.exportedFile):
            os.startfile(self.exportedFile)
        else:
            self.iface.messageBar().pushMessage('Parece que no se ha creado el fichero ' +self.exportedFile, self.nombre_plugin, QgsMessageBar.WARNING, 5)

        self.progressBar.setValue(0)
        '''
        QApplication.restoreOverrideCursor()

        stop = timeit.default_timer()
        text = '  --- TERMINADO ---'
        tiempo = 'Tiempo: '+"%0.2f"%(stop - start)+' seg.'
        self.lblINFO.setText(text+tiempo)
        self.fun.showMessage(text+'\n\n'+tiempo)
        self.close


    def ControlAtributos(self,idMatBusq):
        # QUERY AL WFS Plan_Carreteras_BTA_WFS para contar elementos con el 'idMatBusq'
        url = conf.general["rest_carreteras"]
        values = {
                  'where' : ' idMatricula = '+str(idMatBusq),
                  'text': '',
                  'objectIds': '',
                  'returnCountOnly': True,
                  'f': 'json'}

        str_values = {}
        for k, v in values.items():
            str_values[k] = unicode(v).encode('utf-8')
        data = urllib.parse.urlencode(str_values)
        self.tbrURLCOMPLETA.setHtml(self.creaHTML(url+data))
        # print url+data
        respuesta = self.fun.getFeaturesBTAcalibradaCount(values)
        if respuesta['count'] > 1:
            return str(respuesta['count'])
        else:
            return 'OK'
        pass


    def exportLayer(self, dataEntrada, etype='csv', fich=''):
        # Se exporta la tabla de atributos de la tabla seleccionada al tipo de fichero elegido

        # Establece propiedades del tipo de salida
        self.etype = etype
        self.exportHiddenAttributes = False
        self.csvDelimiter = '\t'

        # Cojemos la capa activa
        layer = self.iface.activeLayer()
        msg= None

        # Comprobamos si la capa es valida para exportar
        if layer and layer.type() == QgsMapLayer.VectorLayer and hasattr(layer, 'providerType'):

            # Se acude al método adecuado según el tipo seleccionado
            if etype != 'printer':

                ePath = fich
                self.exportedFile = fich

                if etype == 'csv':
                    self.lblINFO.setText(u'INFO: Capa CSV exportada adecuadamente')
                    msg = u'La capa ha sido cargada adecuadamente.'
                    status = 'info'

                elif etype == 'html':
                    self.lblINFO.setText(u'INFO: Exportando datos de CSV a HTML ')
                    msg, status = self.exportLayerToHtml(layer, dataEntrada, fich, False, 'html')

                elif etype == 'pdf':
                    self.lblINFO.setText(u'INFO: Exportando datos de CSV a PDF ')
                    msg, status = self.exportLayerToPdf(layer)

            else:
                msg, status = self.exportLayerToPdf(layer, True)

        else:
            self.lblINFO.setText(u'INFO: Falta seleccionar una capa vectorial')
            msg = u'Selecciona primero una capa vectorial'
            status = 'warning'


    def exportLayerToHtml(self, layer, dataEntrada, ePath=None, cutPages=False, etype=None):
        '''
        Exporta la capa a HTML
        usando una plantilla y leyendo los datos
        desde la capa seleccionada
        '''
        self.lblINFO.setText(u'INFO: Exportando datos de CSV a HTML ')

        # VALORES ENCABEZADOS
        title = u'CATÁLOGO DE CARRETERAS - CONTROL DE CALIDAD'

        campoGrupo = u'Funcionalidad'
        campoGrupo1 = u'Titularidad'

        campoSumaGrupo = u'Long_Km'
        udSuma = u'Km'

        # DEFINICIONES DE REDES (Funcionalidad)
        listaTitulos = [
            {'Grupo' : u'Autopistas Peaje', 'Titulo' : u'RED ESTATALES - Autopistas Peaje', 'Color' : u'rgb(90, 110, 255)'},
            {'Grupo' : u'Autopistas', 'Titulo' : u'RED ESTATALES - Autopistas', 'Color' : u'rgb(90, 110, 255)'},
            {'Grupo' : u'Convencionales', 'Titulo' : u'RED ESTATALES - Convencionales', 'Color' : u'rgb(255, 90, 90)'},
            {'Grupo' : u'Básica alta capacidad', 'Titulo' : u'RED REGIONAL - BÁSICA ALTA CAPACIDAD', 'Color' : u'rgb(255, 115, 223)'},
            {'Grupo' : u'Básica', 'Titulo' : u'RED REGIONAL - BÁSICA', 'Color' : u'rgb(255, 170, 0)'},
            {'Grupo' : u'Comarcal', 'Titulo' : u'RED REGIONAL - COMARCAL', 'Color' : u'rgb(85, 255, 0)'},
            {'Grupo' : u'Local', 'Titulo' : u'RED REGIONAL - LOCAL', 'Color' : u'rgb(255, 255, 0)'},
            {'Grupo' : u'Travesía', 'Titulo' : u'RED REGIONAL - TRAVESÍAS (RED LOCAL)', 'Color' : u'rgb(255, 255, 0)'},
            {'Grupo' : u'Ramal', 'Titulo' : u'RED REGIONAL - RAMALES (RED LOCAL)', 'Color' : u'rgb(255, 255, 0)'},
            {'Grupo' : u'Enlace', 'Titulo' : u'RED REGIONAL - ENLACES', 'Color' : u'rgb(200, 200, 200)'},
            {'Grupo' : u'Diputación', 'Titulo' : u'RED DIPUTACIÓN PROVINCIAL', 'Color' : u'rgb(254, 254, 254)'}
            ]

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        # Leemos el fichero de plantilla
        tplPath = os.path.join(
            self.plugin_dir,
            "templates/htmlTempCTRL.tpl"
        )
        fin = open(tplPath)
        data = fin.read()
        fin.close()

        # Se obtienen los datos de la capa
        layerData, nb = self.getLayerData(layer)

        # Obtenemos los tipos de cada campo
        fields = layer.fields()
        tipoCampos = []
        for field in fields:
            tipoCampos.append(field.typeName())


        # Nombres de campos de la capa
        fieldNames = layerData[0]
        nbAttr = len(fieldNames)
        numcampoGrupo = fieldNames.index(campoGrupo )
        numcampoGrupo1 = fieldNames.index(campoGrupo1)
        numcampoSumaGrupo = fieldNames.index(campoSumaGrupo )

        # Calculamos posiciones de los campos a listar
        numColumnas = u'"'+str(len(self.listCampos))+u'"'
        numColumnasDat  = u'"'+str(len(self.listCampos)-len(self.listCamposCTRL))+u'"'
        numColumnasCtrl = u'"'+str(len(self.listCamposCTRL))+u'"'
        poslistCampos = []
        poslistCamposCTRL = []
        for campo in self.listCampos:
            poslistCampos.append(self.listCamposCOMP.index(campo))
        for campo in self.listCamposCTRL:
            poslistCamposCTRL.append(self.listCamposCOMP.index(campo))


        # Creamos el contenido de 'tbody' con los datos de atributos de los elementos
        valcampoGrupo = ''
        tbody = ''
        i = 6 # num lineas
        page = 1
        totalGrup = 0
        totalGlobal = 0
        table = 0
        attrValues = layerData[1:]


        # Escribir la tabla de contenido como HTML
        for values in attrValues:
            prog = 50 +50 * attrValues.index(values)/len(attrValues)
            self.progressBar.setValue(int(prog))
            self.lblINFO.setText(u'INFO: Añadiendo a -'+etype+'- registro ' + str(attrValues.index(values)) +'/' +str(len(attrValues)))

            valorTestigo = values[numcampoGrupo]
            if valorTestigo == u'Básica alta capacidad' and values[numcampoGrupo1] == 'Estatal':
                valorTestigo = u'Autopistas'
            if valorTestigo == u'Básica' and values[numcampoGrupo1] == 'Estatal':
                valorTestigo = u'Convencionales'
            if values[numcampoGrupo1] == u'Diputación':
                valorTestigo = u'Diputación'

            if valorTestigo != valcampoGrupo:
                if table != 0:
                    totalGlobal += totalGrup
                    totalGrup = 0
                    i += 2
                thead = ''
                if table == 0:
                    thead+='        <table>\n'
                    thead+='            <tbody>\n'
                table+=1
                valcampoGrupo = valorTestigo
                tituloGrupo = ''
                colBck = 'rgb(200, 200, 200)'
                colBlanco = 'rgb(250, 250, 250)'
                colError = 'rgb(255, 150, 150)'
                for dataGrupos in listaTitulos:
                    if dataGrupos['Grupo'] == valcampoGrupo:
                        tituloGrupo = dataGrupos['Titulo']
                        colBck = dataGrupos["Color"]
                thead+='                <tr>\n'
                thead+='                    <th colspan=%s align="left" style="background: %s">%s</th>\n'%(numColumnasDat, colBck, tituloGrupo)
                thead+='                    <th colspan=%s align="left" style="background: %s">%s</th>\n'%(numColumnasCtrl, colBlanco, 'CONTROL')
                thead+='                </tr>\n\n'
                thead+='                <tr>\n'
                i += 3

                # GENERAR ENCABEZADO DE CADA GRUPO DE DATOS
                for field in self.listCampos:
                    if self.listCampos.index(field)<(len(self.listCampos)-len(self.listCamposCTRL)):
                        thead+= '                    <th style="background: %s">%s</th>\n' %(colBck, field)
                    else:
                        thead+= '                    <th style="background: %s">%s</th>\n' %(colBlanco, field)

                thead+= '                </tr>\n\n'
                tbody+= thead

            # Se crea la lista de valores de cada registro
            valuesLista = []
            tbody+= '                <tr>\n'
            for pos in poslistCampos:
                # Caso de que se trate de datos del CONTROL DE CALIDAD
                if pos in poslistCamposCTRL:
                    valueTD = values[pos]
                    if valueTD == 'OK':
                        tbody+= '                    <td align="left">' + valueTD + '</td>\n'
                    else:
                        tbody+= '                    <td align="left" style="background: %s">%s</td>\n'%(colError,valueTD)

                else:
                # Caso de que se trate de datos NORMALES
                    if tipoCampos[pos] == 'integer':
                        try:
                            valueTD = "{:.0f}".format(float(values[pos]))
                            tbody+= '                    <td align="right">' + valueTD + '</td>\n'
                        except:
                            valueTD = valueTD = values[pos]
                    elif tipoCampos[pos] == 'double':
                        try:
                            valueTD = "{:.3f}".format(float(values[pos]))
                            tbody+= '                    <td align="right">' + valueTD + '</td>\n'
                        except:
                            valueTD = valueTD = values[pos]
                    else:
                        valueTD = values[pos]
                        if valueTD[:3] != '(x)':
                            tbody+= '                    <td align="left">' + valueTD + '</td>\n'
                        else:
                            tbody+= '                    <td align="left" style="background: %s">%s</td>\n'%(colError,valueTD)

            tbody+= '                    </td>\n'
            tbody+= '                </tr>\n\n'


            try:
                totalGrup += float(values[numcampoSumaGrupo])

            except:
                pass
            i+=1
            if i == self.maxLinesPerPage and cutPages and self.QgisVersion > 10900:
                i = 3
                tbody+= '</table>\n\n'
                tbody+= '<span>Page %s</span>' % page
                tbody+= '<div class="saltopagina"></div>\n\n'
                tbody+= '<table><thead>' + thead + '</thead><tbody>'
                page+=1


        # LÍNEAS FINALES
        totalGlobal += totalGrup
        tbody+='            </tbody>\n'
        tbody+='        </table>\n'

        # Get creation date
        locale.setlocale(locale.LC_TIME,'')
        if hasattr(locale, 'nl_langinfo'):
            date_format = locale.nl_langinfo(locale.D_T_FMT)
        else:
            date_format = "%x %X"
        today = datetime.datetime.today()
        date = today.strftime(date_format)
        dt_date = u'JCCM. Dirección General de Carreteras '

        # Icono, Titulo, Resumen, número de Carreteras
        fileIcono = f'python/plugins/{self.nombre_plugin}/iconos/jccm.jpg'
        dirPYTJCCM = QgsApplication.qgisSettingsDirPath()
        fileIcono = os.path.normpath(os.path.join(os.path.dirname(dirPYTJCCM), fileIcono))
        dt_icono = '<img src="%s" border="0" width="100" height="80">'%fileIcono
        dt_title = u''
        dt_abstract = u'Datos'
        dt_info = u'Información'
        abstract = layer.abstract()
        info = u'TOTAL {:.0f} Carreteras - {:.3f} Km'.format(nb, totalGlobal)


        # Adapt style if needed
        style = ''
        # Get CSS style from table.css
        with open(self.cssPath, 'r') as content_file:
            style = content_file.read()
        if nbAttr > self.maxAttributesBeforeSmallFontSize:
            # style+= 'th, td {font-size:x-small;}'
            style+= 'th, td {font-size:10px;}'

        # Se confeccionan los datos de entrada
        datosEntrada = ''
        if self.cbx_idmatricula.isChecked():
            datosEntrada += 'idmatricula / '
        if self.cbx_dominios.isChecked():
            datosEntrada += 'CTRLdominios / '
        if self.cbx_denomTramos.isChecked():
            datosEntrada += 'CTRLdenomTramos / '
        if self.cbx_calibracion.isChecked():
            datosEntrada += 'CTRLcalibracion / '
        if self.cbx_longPks.isChecked():
            datosEntrada += 'CTRLpkini-pkfin / '
        if self.cbx_inicioNeg.isChecked():
            datosEntrada += 'CTRLinineg / '
        if self.cbx_PKSxCtra.isChecked():
            datosEntrada += 'PKSxCtra / '
        if self.cbx_calibrPKS.isChecked():
            datosEntrada += 'CalibrPKS / '


        # Replace values
        data = data.replace('$icono', dt_icono)
        data = data.replace('$dt_title', dt_title)
        data = data.replace('$title', title)
        data = data.replace('$dt_abstract', dt_abstract)
        data = data.replace('$abstract', abstract)
        data = data.replace('$dt_info', dt_info)
        data = data.replace('$info', info)
        data = data.replace('$tbody', tbody)
        # data = data.replace('$tbody1', tbody1)
        data = data.replace('$dt_date', dt_date)
        data = data.replace('$date', date)
        data = data.replace('$style', style)
        data = data.replace('$totalPages', "Pag. %s" % page)

        data = data.replace('$Campo1', 'Titularidad=')
        data = data.replace('$linea1', dataEntrada[0])
        data = data.replace('$Campo2', 'Funcionalidad=')
        data = data.replace('$linea2', dataEntrada[1])
        data = data.replace('$Campo3', 'TDC/TUC=')
        data = data.replace('$linea3', 's/d')
        data = data.replace('$Campo4', 'Provincia=')
        data = data.replace('$linea4', dataEntrada[3])
        data = data.replace('$Campo5', 'Otros=')
        data = data.replace('$linea5', dataEntrada[4])
        data = data.replace('$Campo6', 'CONTROL:')
        data = data.replace('$linea6', datosEntrada)

        # File path
        if not ePath:
            ePath = self.exportedFile

        try:
            # write html content
            f = open(ePath, 'w')
            # f.write(data.encode('utf-8'))
            f.write(data)
            f.close()

        # except IOError, e:
        except:
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación')
            status = 'critical'
        finally:
            msg = QApplication.translate("quickExport", u'La capa ha sido adecuadamente exportada')
            status = 'info'

        QApplication.restoreOverrideCursor()

        return msg, status


    def ListaIndices(self):
        numColumnas = 4
        colBck = 'rgb(200, 200, 200)'
        tituloGrupo= u'Lista de CÓDIGOS'
        tbody1+='                <tr>\n'
        tbody1+='                    <th colspan=%s align="left" style="background: %s">%s</th>\n'%(numColumnasDat, colBck, tituloGrupo)
        tbody1+='                </tr>\n\n'
        return tbody1
        pass


    def exportLayerToPdf(self, layer, doPrint=False):
        '''
        Exports the layer to PDF
        First export to HTML then convert to PDF.
        If not output file given, send directly to the printer
        '''

        # Create temporary file path
        temp = tempfile.NamedTemporaryFile()
        try:
            # Create temporary HTML file
            tPath = "%s.html" % temp.name

            msg, status = self.exportLayerToHtml(layer, tPath, True, 'pdf')

            # NOTE: this method already relied on QWebView and QPrintDialog
            # without ever importing them (a pre-existing bug, present
            # before the QGIS4/Qt6 migration - it would raise a NameError
            # the moment it was called under Qt5 too). Fixed here using
            # QWebEngineView, the QtWebEngine-based replacement for the
            # QtWebKit-based QWebView removed in Qt6, along with the
            # missing QPrintDialog import.
            #
            # Create a web view and fill it with the html file content
            web = QWebEngineView()
            web.load(QUrl.fromLocalFile(tPath))

            # Keep a strong reference so the QWebEngineView isn't garbage
            # collected before the asynchronous load/print finishes (this
            # wasn't a concern with the old, synchronous QWebView).
            if not hasattr(self, '_pdfExportWebViews'):
                self._pdfExportWebViews = []
            self._pdfExportWebViews.append(web)

            # Print only when HTML content is loaded
            def printIt(ok=True):
                # Open the printer dialog if needed
                if doPrint:
                    dialog = QPrintDialog()
                    if dialog.exec() == QDialog.DialogCode.Accepted:
                        printer = dialog.printer()
                    else:
                        return
                # No print, only PDF export
                else:
                    # Set page options for PDF
                    printer = QPrinter()
                    printer.setPageSize(self.pageSize)
                    printer.setOrientation(self.orientation)
                    printer.setFontEmbeddingEnabled(True)
                    printer.setColorMode(QPrinter.ColorMode.Color)
                    # set output file name in case of PDF export
                    printer.setOutputFileName(self.exportedFile)

                # Set some metadata
                printer.setCreator(u"QGIS - Complemento JCCM Carreteras")
                printer.setDocName(u"Exportado - %s" % layer.title() and layer.title() or layer.name())

                # Print (asynchronous under QWebEngineView; the callback
                # just releases our reference to the view once it is done)
                def _printFinished(success):
                    try:
                        self._pdfExportWebViews.remove(web)
                    except ValueError:
                        pass
                web.page().print(printer, _printFinished)

            # Only print when the HTML content has been loaded in the QWebEngineView
            web.loadFinished.connect(printIt)

        except:
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación.')
            status = 'critical'
        finally:
            # Automatically cleans up the file
            temp.close()
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación.')
            status = 'info'

        return msg, status


    def getLayerData(self, layer):
        '''
        Get fields and data from
        a vector layer
        '''
        data = []

        # Get layer fields names
        fields = layer.fields()
        if self.QgisVersion > 10900:
            fieldNames = [
                field.name() for i, field in enumerate(fields)
                # if layer.editType(i) != QgsVectorLayer.Hidden
                # or self.exportHiddenAttributes
            ]
        else:
            fieldNames = [
                str(fields[i].name()) for i in fields
                # if layer.editType(i) != QgsVectorLayer.Hidden
                # or self.exportHiddenAttributes
            ]
        data.append(fieldNames)

        # Get selected features or all features
        if layer.selectedFeatureCount():
            nb = layer.selectedFeatureCount()
        else:
            nb = layer.featureCount()

        # QGIS >= 2.0
        if self.QgisVersion > 10900:
            if layer.selectedFeatureCount():
                features = layer.selectedFeatures()
            else:
                features = layer.getFeatures()
            for feat in features:
                # Get attribute data
                values = [
                    self.displayAttributeValue(a) for i, a in enumerate(feat.attributes())
                    # if layer.editType(i) != QgsVectorLayer.Hidden
                    # or self.exportHiddenAttributes
                ]
                data.append(values)

        # QGIS 1.8
        else:
            provider = layer.dataProvider()
            allAttrs = provider.attributeIndexes()
            provider.select(allAttrs, QgsRectangle(), False)
            layer.select(allAttrs, QgsRectangle(), False)
            if layer.selectedFeatureCount():
                items = layer.selectedFeatures()
            else:
                items = layer
            for feat in items:
                attrs = feat.attributeMap()
                values = [
                    self.displayAttributeValue(v) for k,v in attrs.items()
                    # if layer.editType(k) != QgsVectorLayer.Hidden
                    # or self.exportHiddenAttributes
                ]
                data.append(values)

        return data, nb


    def displayAttributeValue(self, value):
        '''
        Convert QGIS attribute data into readable values
        '''
        # QGIS version
        isQgis2 = self.QgisVersion > 10900

        # Get locale date representation
        locale.setlocale(locale.LC_TIME,'')
        if hasattr(locale, 'nl_langinfo'):
            date_format = locale.nl_langinfo(locale.D_FMT)
            datetime_format = locale.nl_langinfo(locale.D_T_FMT)
        else:
            date_format = "%x"
            datetime_format = "%x %X"

        # Convert value depending of type
        if hasattr(value, 'toPyDate'):
            output = value.toPyDate().strftime(date_format)
        elif hasattr(value, 'toPyDateTime'):
            output = value.toPyDateTime().strftime(datetime_format)
        else:
            output = u"%s" % value if isQgis2 else u"%s" % value.toString()

        return output


    def creaHTML(self, url):
        textHTML = u'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">'
        textHTML+= u'<html><head><meta name="qrichtext" content="1" /><style type="text/css">'
        textHTML+= u'p, li { white-space: pre-wrap; }'
        textHTML+= u'</style></head><body style=" font-family:'+"'Tahoma'"+'; font-size:8.25pt; font-weight:400; font-style:normal;">'
        textHTML+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><a href="'
        textHTML+= url
        textHTML+= u'<span style=" font-size:8pt; text-decoration: underline; color:#0000ff;">'
        textHTML+= url
        textHTML+= u'</span></a></p></body></html>'
        return textHTML
