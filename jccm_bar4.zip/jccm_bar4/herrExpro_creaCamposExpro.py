# -*- coding: utf-8 -*-
'''
/***************************************************************************
Name:           herrExpro_creaCamposExpro.py

                                 A QGIS4 plugin
Plugin:     jccmbar3
Purpose:        RUTINA Crear Campos de Datos de Expropiaciones
# Se crean campos en la capa activa de polígonos, de acuerdo con la estructura mejorada de la Secretaría General de Fomento
        --------------------------------------------------------------------
        begin                : 2025-07-29
        git sha              : $Format:%H$
        Codigo Corregido     : Agustín Solabre
        email                : agusass@hotmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
'''

from qgis.PyQt.QtWidgets import (QDialog, QFileDialog, QDialogButtonBox, QTableWidget, QLabel, QTableWidgetItem, QApplication,
                            QComboBox, QWidget, QVBoxLayout)
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QVariant, QSettings, Qt, QMetaType
from qgis.PyQt import uic

from qgis.core import (Qgis, QgsProject, QgsField, QgsVectorLayer, QgsWkbTypes, QgsMapLayer)

import os
import math
import json

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .settings import Settings           # CLASE DE CONFIGURACIÓN DE VARIABLES GLOBALES

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrExpro_creaCamposExpro.ui'))

class herrExpro_creaCamposExpro(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        '''Constructor.'''
        super(herrExpro_creaCamposExpro, self).__init__(parent)
        self.setupUi(self)

        self.iface = iface
        self.fun = Functions()
        self.qs = QSettings()
        self.conf = configuration()

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        self.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/jccm.jpg'))

        self.lblFichDatos.setEnabled(False)
        self.lneFichDatos.setEnabled(False)
        self.btnSeleccionfich.setEnabled(False)

        self.cargarCapas()
        
        # CARGAR CONFIGURACIONES EXTERNAS
        self.cargar_configuraciones()
        
        self.cbxTipoCampos.currentIndexChanged.connect(self.actualizarTipoDatos) # ACTUALIZA WIDGETS SEGÚN TIPO DATOS

        self.btnCreaCampos.clicked.connect(self.CreaCampos)
        self.btnCERRAR.clicked.connect(self.cancela)
        self.cbxTodoTipoCapas.clicked.connect(self.cargarCapas)
        
        self.lblFichDatos.hide()
        self.lneFichDatos.hide()
        self.btnSeleccionfich.hide()
        
        self.lblImportar.hide()
        self.btnImportarDatos.hide()
        self.lblNOHAYFILE.setVisible(False)

    def cargarCapas(self):
        lista_CAPAS = self.getCAPAS()
        self.cbxCapaentrada.clear()
        self.cbxCapaentrada.addItems(lista_CAPAS)
        
        # Comprobamos si la capa activa está en lista_CAPAS y se pone como current en el combo
        self.cbxCapaentrada.setCurrentIndex(0)
        if self.iface.activeLayer():
            if self.iface.activeLayer().name() in lista_CAPAS:
                self.cbxCapaentrada.setCurrentText(self.iface.activeLayer().name())
        self.cbxCapaentrada.setEditable(True)

    def cargar_configuraciones(self):
        '''Carga las configuraciones desde archivo JSON externo'''
        try:
            # Ruta al archivo de configuración
            config_path = os.path.join(os.path.dirname(__file__), 'configCreaCampos.json')
            
            # Verificar si el archivo existe
            if not os.path.exists(config_path):
                print(f"Archivo de configuración no encontrado: {config_path}")
                self._cargar_configuraciones_por_defecto()
                return
            
            # Leer y parsear el archivo JSON
            with open(config_path, 'r', encoding='utf-8') as f:
                config_data = json.load(f)
            
            # Cargar tipos de campos
            self.cbxTipoCampos.clear()
            if 'listaDefinCampos' in config_data:
                for config in config_data['listaDefinCampos']:
                    self.cbxTipoCampos.addItem(config['nameFields_to_add'])
            
            # Cargar equivalencias de datos
            self.cbxEquivDatos.clear()
            if 'listaEquivalenciaDatos' in config_data:
                for config in config_data['listaEquivalenciaDatos']:
                    self.cbxEquivDatos.addItem(config['nameEquivalenciaDatos'])
            
            # Guardar los datos para uso posterior
            self.config_data = config_data
            
            print(f"Configuraciones cargadas desde JSON: {len(config_data.get('listaDefinCampos', []))} tipos de campos, {len(config_data.get('listaEquivalenciaDatos', []))} equivalencias")
            
        except Exception as e:
            print(f"Error cargando configuraciones desde JSON: {e}")
            self._cargar_configuraciones_por_defecto()

    def _cargar_configuraciones_por_defecto(self):
        '''Carga configuraciones por defecto en caso de error'''
        print("Cargando configuraciones por defecto...")
        self.cbxTipoCampos.clear()
        self.cbxTipoCampos.addItem('- NO HAY LISTAS DE DEFINICIONES DE CAMPOS -')
        self.cbxEquivDatos.clear()
        self.cbxEquivDatos.addItem('- NO HAY LISTA DE EQUIVALENCIA DE DATOS -')
        self.config_data = {
            'listaDefinCampos': [],
            'listaEquivalenciaDatos': []
        }
        self.lblNOHAYFILE.setVisible(True)
        self.btnCreaCampos.setEnabled(False)
        

    def getCAPAS(self):
        capas = []
        for layer in QgsProject.instance().mapLayers().values():
            if self.cbxTodoTipoCapas.isChecked():
                capas.append(layer.name())
            elif layer.type() == QgsMapLayer.VectorLayer:
                # Capas con geometría Polygon
                if layer.wkbType() == QgsWkbTypes.Polygon:
                    feat = layer.featureCount()
                    featsel = layer.selectedFeatureCount()
                    capas.append(layer.name())
                # Capas con geometría MultiPolygon
                elif layer.wkbType() == QgsWkbTypes.MultiPolygon:
                    feat = layer.featureCount()
                    featsel = layer.selectedFeatureCount()
                    capas.append(layer.name())
                # Capas sin geometría
                elif layer.wkbType() == QgsWkbTypes.NoGeometry:
                    feat = layer.featureCount()
                    featsel = layer.selectedFeatureCount()
                    capas.append(layer.name())

        return capas

    def cambiaTIPOCAPAS(self):
        # Controles de tipo de capas
        self.getCAPAS()
        
        pass

    def actualizarTipoDatos(self):
        tipoDatos = self.cbxTipoCampos.currentText()
        if tipoDatos == 'Datos Catastrales Protegidos XML':
            self.lblFichDatos.setEnabled(True)
            self.lneFichDatos.setEnabled(True)
            self.btnSeleccionfich.setEnabled(True)
        else:
            self.lblFichDatos.setEnabled(False)
            self.lneFichDatos.setEnabled(False)
            self.btnSeleccionfich.setEnabled(False)

    def cancela(self):
        self.close()
        pass

    def CreaCampos(self):
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        self.lblINFO.setText('INFO: - TRABAJANDO - ')
        # Obtener la capa a modificar
        layer_name = self.cbxCapaentrada.currentText()
        layers = QgsProject.instance().mapLayersByName(layer_name)
        if not layers:
            self.iface.messageBar().pushMessage("Error", f"No se encontró la capa: {layer_name}", level=Qgis.Critical)
            QApplication.restoreOverrideCursor()
            return
            
        layer = layers[0]
        
        if not self.verificar_editable(layer)[0]:
            mess = self.verificar_editable(layer)[1]
            self.fun.showMessageERR(mess)
            QApplication.restoreOverrideCursor()
            return
        
        # Modificar los campos
        result = self.camposCapaParcEXPRO(layer)
        if result != 'ERROR':
            self.ImportarDatos()

        self.lblINFO.setText('INFO:  -- TERMINADO --')
        QApplication.restoreOverrideCursor()

    def verificar_editable(self, layer):
        '''Verifica si la capa es editable'''
        if not layer.isEditable():
            try:
                # Intentar iniciar edición
                if not layer.startEditing():
                    return False, "La capa no es editable y no se pudo iniciar edición"
            except Exception as e:
                return False, f"No se pudo iniciar edición: {str(e)}"
        return True, "OK"

    def ajustar_campo_para_shp(self, field_def):
        '''Ajusta definiciones de campos para limitaciones de SHP'''
        # Los SHP tienen límite de 10 caracteres para nombres de campo
        if len(field_def['name']) > 10:
            field_def['name'] = field_def['name'][:10]
            print(f"Advertencia: Nombre de campo truncado a {field_def['name']} por limitaciones SHP")
        
        # Los SHP no soportan comentarios en campos
        if 'comment' in field_def:
            field_def['comment'] = ''
        
        return field_def

    def camposCapaParcEXPRO(self, layer):
        '''Rutina para crear los campos de las capas de parcelas de expropiaciones'''
        
        # Verificar que la capa es válida
        if not layer:
            self.iface.messageBar().pushCritical("Error", "No hay capa seleccionada")
            return "Error: Capa no válida"
            
        # Verificar si la capa es editable
        es_editable, mensaje_editable = self.verificar_editable(layer)
        if not es_editable:
            self.iface.messageBar().pushCritical("Error", mensaje_editable)
            return f"Error: {mensaje_editable}"
        
        # Obtener lista de campos desde configuración JSON
        tipoEquivDatos = self.cbxTipoCampos.currentText()
        fields_to_add = self.rutinaFields_to_add(tipoEquivDatos)
        if fields_to_add == 'ERROR':
            mess = f'NO HAY LISTA DE CAMPOS DISPONIBLE para: {tipoEquivDatos}'
            self.fun.showMessageERR(mess)
            return 'ERROR'

        # Detectar si es SHP para ajustar campos
        es_shp = layer.dataProvider().name().lower() == 'ogr' and layer.dataProvider().storageType().lower().find('shp') != -1
        
        # Comenzar edición
        layer.startEditing()

        # Obtener la lista de campos existentes (case-insensitive)
        existing_fields = [field.name().lower() for field in layer.fields()]
        existing_fields_original = {field.name().lower(): field.name() for field in layer.fields()}

        # Para cada campo en la lista
        numCampos = len(fields_to_add)
        numCampo = 0
        campos_creados = 0
        campos_actualizados = 0
        errores = []
        
        for field_def in fields_to_add:
            numCampo += 1
            self.lblINFO.setText('INFO:  Creando campos (%s/%s)' % (numCampo, numCampos))
            
            # Ajustar campo si es SHP
            if es_shp:
                field_def = self.ajustar_campo_para_shp(field_def)
            
            field_name_lower = field_def['name'].lower()
            
            if field_name_lower in existing_fields:
                # Si el campo existe, actualizar alias
                real_field_name = existing_fields_original[field_name_lower]
                idx = layer.fields().indexFromName(real_field_name)
                
                if idx >= 0:
                    current_alias = layer.fields().field(idx).alias()
                    if current_alias != field_def['alias']:
                        layer.setFieldAlias(idx, field_def['alias'])
                        campos_actualizados += 1
                    print(f"Campo {real_field_name} ya existe, alias actualizado: {field_def['alias']}")
                else:
                    print(f"Error: No se pudo encontrar el índice del campo {real_field_name}")

            else:
                # Si el campo no existe, añadirlo
                if field_def['type'] == QMetaType.Type.Double:
                    field = QgsField(
                        field_def['name'],
                        field_def['type'],
                        len=field_def.get('len', 10),
                        prec=field_def.get('precision', 2),
                        comment=field_def['comment'])
                else:
                    field = QgsField(
                        field_def['name'],
                        field_def['type'],
                        len=field_def.get('len', 255),
                        comment=field_def['comment'])
                
                # Añadir el campo
                if layer.addAttribute(field):
                    campos_creados += 1
                    print(f"Campo {field_def['name']} añadido exitosamente")
                    
                    # Establecer el alias
                    layer.updateFields()
                    idx = layer.fields().indexFromName(field_def['name'])
                    if idx >= 0:
                        layer.setFieldAlias(idx, field_def['alias'])
                        print(f"Alias establecido para {field_def['name']}: {field_def['alias']}")
                    else:
                        errores.append(f"No se pudo establecer alias para {field_def['name']}")
                else:
                    errores.append(f"Error al añadir campo {field_def['name']}")

        # Guardar cambios
        if layer.commitChanges():
            mensaje = f"Campos procesados: {campos_creados} creados, {campos_actualizados} actualizados"
            if errores:
                mensaje += f". Errores: {len(errores)}"
            self.iface.messageBar().pushSuccess("Éxito", mensaje)
            return mensaje
        else:
            error_msg = f"Error al guardar los cambios: {layer.commitErrors()}"
            if errores:
                error_msg += f". Otros errores: {errores}"
            self.iface.messageBar().pushCritical("Error", error_msg)
            return error_msg

    def rutinaFields_to_add(self, tipoEquivDatos):
        '''Obtiene la lista de campos desde el archivo JSON'''
        try:
            if hasattr(self, 'config_data') and 'listaDefinCampos' in self.config_data:
                for config in self.config_data['listaDefinCampos']:
                    if config['nameFields_to_add'] == tipoEquivDatos:
                        # Convertir tipos de string a QVariant
                        fields_converted = self._convertir_campos_qvariant(config['fields_to_add'])
                        print(f"Encontrada configuración para: {tipoEquivDatos} con {len(fields_converted)} campos")
                        return fields_converted
            
            print(f"No se encontró configuración para: {tipoEquivDatos}")
            return 'ERROR'
            
        except Exception as e:
            print(f"Error obteniendo campos desde JSON: {e}")
            return 'ERROR'

    def _convertir_campos_qvariant(self, fields_list):
        '''Convierte los tipos de campo de string a QVariant'''
        type_mapping = {
            'String': QMetaType.Type.QString,
            'Int': QMetaType.Type.Int,
            'Double': QMetaType.Type.Double,
            'Bool': QMetaType.Type.Bool,
            'Date': QMetaType.Type.QDate,
            'DateTime': QMetaType.Type.QDateTime
        }
        
        converted_fields = []
        for field in fields_list:
            field_copy = field.copy()
            if 'type' in field_copy and isinstance(field_copy['type'], str):
                field_type = field_copy['type']
                field_copy['type'] = type_mapping.get(field_type, QMetaType.Type.QString)
            converted_fields.append(field_copy)
        
        return converted_fields

    def equivalenciaDatos(self, tipoEquivDatos):
        '''Obtiene las equivalencias de datos desde el archivo JSON'''
        try:
            if hasattr(self, 'config_data') and 'listaEquivalenciaDatos' in self.config_data:
                for config in self.config_data['listaEquivalenciaDatos']:
                    if config['nameEquivalenciaDatos'] == tipoEquivDatos:
                        print(f"Encontradas equivalencias para: {tipoEquivDatos} con {len(config['equivalenciaDatos'])} reglas")
                        return config['equivalenciaDatos']
            
            print(f"No se encontraron equivalencias para: {tipoEquivDatos}")
            return []
            
        except Exception as e:
            print(f"Error obteniendo equivalencias desde JSON: {e}")
            return []

    def ImportarDatos(self):
        '''Rutina de incorporación de datos a campos creados según equivalencias - MEJORADA'''
        try:
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            self.lblINFO.setText('INFO: - IMPORTANDO DATOS - ')
            
            # Obtener capa y tipo de datos
            layer_name = self.cbxCapaentrada.currentText()
            layers = QgsProject.instance().mapLayersByName(layer_name)
            if not layers:
                self.iface.messageBar().pushMessage("Error", f"No se encontró la capa: {layer_name}", level=Qgis.Critical)
                return
                
            layer = layers[0]
            
            # VERIFICAR SI LA CAPA ES EDITABLE
            es_editable, mensaje_editable = self.verificar_editable(layer)
            if not es_editable:
                self.iface.messageBar().pushMessage("Error", mensaje_editable, level=Qgis.Critical)
                return
            
            tipoEquivDatos = self.cbxEquivDatos.currentText()
            
            # Obtener equivalencias
            equivalenciaDatos = self.equivalenciaDatos(tipoEquivDatos)
            if not equivalenciaDatos:
                self.iface.messageBar().pushMessage("Info", "No hay equivalencias definidas para este tipo", level=Qgis.Info)
                return
            
            # VERIFICAR CAMPOS DESTINO
            campos_destino = [equiv['campoNue'] for equiv in equivalenciaDatos]
            campos_faltantes = self.verificar_campos_existen(layer, campos_destino)
            
            if campos_faltantes:
                mensaje_campos = f"Campos destino no encontrados: {', '.join(campos_faltantes)}. No se realizarán cálculos para estos campos."
                self.iface.messageBar().pushMessage("Advertencia", mensaje_campos, level=Qgis.Warning)
                print(mensaje_campos)
            
            # Filtrar equivalencias para solo las que tienen campos destino existentes
            equivalenciaDatos_filtrada = [
                equiv for equiv in equivalenciaDatos 
                if equiv['campoNue'].lower() not in [campo.lower() for campo in campos_faltantes]
            ]
            
            if not equivalenciaDatos_filtrada:
                self.iface.messageBar().pushMessage("Error", "No hay campos destino válidos para importar datos", level=Qgis.Critical)
                return
            
            # Iniciar edición (ya verificamos que es posible)
            if not layer.isEditable():
                layer.startEditing()
            
            # Obtener información de campos (case-insensitive)
            fields = layer.fields()
            field_names_lower = {field.name().lower(): field.name() for field in fields}
            
            # Contadores para estadísticas
            total_features = layer.featureCount()
            features_procesadas = 0
            campos_actualizados = 0
            features_actualizadas = 0
            errores_por_feature = {}
            
            # Recorrer todas las features
            numFeats = layer.featureCount()
            numFeat = 0
            
            for feature in layer.getFeatures():
                numFeat += 1
                self.lblINFO.setText('INFO:  Calculando valores de cada registro (%s/%s)' % (numFeat, numFeats))
            
                cambios_feature = False
                feature_id = feature.id()
                errores_feature = []
                
                for equivalencia in equivalenciaDatos_filtrada:
                    campo_destino = equivalencia['campoNue']
                    
                    # Verificar si el campo destino existe (case-insensitive)
                    campo_destino_lower = campo_destino.lower()
                    if campo_destino_lower not in field_names_lower:
                        continue
                    
                    campo_destino_real = field_names_lower[campo_destino_lower]
                    field_idx = fields.indexOf(campo_destino_real)
                    
                    if field_idx == -1:
                        continue
                    
                    # Obtener tipo de campo destino
                    field_type = fields.field(field_idx).type()
                    
                    # Calcular nuevo valor según el tipo de equivalencia
                    try:
                        nuevo_valor = self._calcular_valor_por_tipo(equivalencia, feature, fields, field_type)
                        
                        # Si se calculó un valor válido, asignarlo
                        if nuevo_valor is not None:
                            valor_actual = feature[campo_destino_real]
                            
                            # Solo actualizar si el valor es diferente
                            if valor_actual != nuevo_valor:
                                feature.setAttribute(field_idx, nuevo_valor)
                                cambios_feature = True
                                campos_actualizados += 1
                                
                    except Exception as e:
                        error_msg = f"Error en {campo_destino}: {str(e)}"
                        errores_feature.append(error_msg)
                        print(error_msg)
                
                # Actualizar la feature si hubo cambios
                if cambios_feature:
                    try:
                        layer.updateFeature(feature)
                        features_actualizadas += 1
                    except Exception as e:
                        errores_feature.append(f"Error actualizando feature: {str(e)}")
                
                if errores_feature:
                    errores_por_feature[feature_id] = errores_feature
                
                features_procesadas += 1
                # Actualizar progreso cada 10 features o al final
                if features_procesadas % 10 == 0 or features_procesadas == total_features:
                    progreso = int((features_procesadas / total_features) * 100)
                    self.progressBar.setValue(progreso)
                    QApplication.processEvents()
            
            # Guardar cambios
            if layer.commitChanges():
                mensaje = f"Datos importados correctamente. {campos_actualizados} campos actualizados en {features_actualizadas} features."
                
                # Mostrar advertencias si hubo errores
                if errores_por_feature:
                    mensaje += f" Hubo errores en {len(errores_por_feature)} features."
                    print(f"Errores detallados: {errores_por_feature}")
                
                self.iface.messageBar().pushMessage("Éxito", mensaje, level=Qgis.Success)
                self.lblINFO.setText(f"INFO: {mensaje}")
            else:
                error_msg = f"Error al guardar cambios: {layer.commitErrors()}"
                layer.rollBack()
                self.iface.messageBar().pushMessage("Error", error_msg, level=Qgis.Critical)
                self.lblINFO.setText(f"INFO: {error_msg}")
                
        except Exception as e:
            if 'layer' in locals() and layer.isEditable():
                layer.rollBack()
            error_msg = f"Error durante la importación: {str(e)}"
            self.iface.messageBar().pushMessage("Error", error_msg, level=Qgis.Critical)
            self.lblINFO.setText(f"INFO: {error_msg}")
            import traceback
            print(f"Error detallado: {traceback.format_exc()}")
            
        finally:
            QApplication.restoreOverrideCursor()
            self.progressBar.setValue(0)
    
    def verificar_campos_existen(self, layer, campos_requeridos):
        '''Verifica si los campos requeridos existen en la capa'''
        campos_existentes = [field.name().lower() for field in layer.fields()]
        campos_faltantes = []
        
        for campo in campos_requeridos:
            if campo.lower() not in campos_existentes:
                campos_faltantes.append(campo)
        
        return campos_faltantes
    
    def _calcular_valor_por_tipo(self, equivalencia, feature, fields, field_type):
        '''Calcula el valor según el tipo de equivalencia'''
        tipo_equiv = equivalencia['tipoEQUIV']
        nuevo_valor = None
        
        try:
            if tipo_equiv == 'CAMPO':
                # Obtener valor de campo anterior
                campo_ant = equivalencia['campoANT']
                if campo_ant and campo_ant.strip():
                    field_names_lower = {field.name().lower(): field.name() for field in fields}
                    campo_ant_lower = campo_ant.lower()
                    
                    if campo_ant_lower in field_names_lower:
                        campo_ant_real = field_names_lower[campo_ant_lower]
                        valor_campo = feature[campo_ant_real]
                        nuevo_valor = self._convertir_tipo(valor_campo, field_type)
                    else:
                        print(f"Campo anterior no encontrado: {campo_ant}")
            
            elif tipo_equiv == 'VALOR':
                # Asignar valor fijo
                valor = equivalencia['valor']
                if valor is not None and str(valor).strip() != '':
                    nuevo_valor = self._convertir_tipo(valor, field_type)
            
            elif tipo_equiv == 'FORMULA':
                # Evaluar fórmula
                formula = equivalencia['formula']
                if formula and formula.strip():
                    nuevo_valor = self._evaluar_formula(formula, feature, fields, field_type)
        
        except Exception as e:
            print(f"Error calculando valor para {equivalencia['campoNue']}: {e}")
            nuevo_valor = None
        
        return nuevo_valor

    def _convertir_tipo(self, valor, field_type):
        '''Convierte un valor al tipo de campo adecuado'''
        if valor is None:
            return self._valor_por_defecto(field_type)
        
        try:
            # Convertir a string para verificar si está vacío
            str_valor = str(valor).strip()
            
            if str_valor in ('', 'NULL', 'None', 'null'):
                return self._valor_por_defecto(field_type)
            
            if field_type in (QMetaType.Type.QString, QMetaType.Type.QChar, QMetaType.Type.QDate, QMetaType.Type.QDateTime):
                return str_valor if str_valor not in ('', 's/d') else 's/d'
            
            elif field_type in (QMetaType.Type.Int, QMetaType.Type.UInt, QMetaType.Type.LongLong, QMetaType.Type.ULongLong):
                # Para campos enteros, convertir a int
                if str_valor in ('', '0', '0.0'):
                    return 0
                try:
                    return int(float(str_valor))
                except (ValueError, TypeError):
                    return 0
            
            elif field_type == QMetaType.Type.Double:
                # Para campos double, convertir a float
                if str_valor in ('', '0', '0.0'):
                    return 0.0
                try:
                    return float(str_valor)
                except (ValueError, TypeError):
                    return 0.0
            
            else:
                # Para otros tipos, devolver el valor original
                return valor
                
        except Exception as e:
            print(f"Error convirtiendo tipo: {valor} -> {field_type}: {e}")
            return self._valor_por_defecto(field_type)

    def _evaluar_formula(self, formula, feature, fields, field_type):
        '''Evalúa fórmulas que pueden incluir campos, textos y operaciones matemáticas'''
        try:
            # Reemplazar referencias a campos [campo] por sus valores
            formula_evaluar = formula
            
            # Buscar patrones [campo] en la fórmula
            import re
            patron_campo = r'\[([^\]]+)\]'
            campos_en_formula = re.findall(patron_campo, formula_evaluar)
            
            # Reemplazar cada campo encontrado
            for campo_nombre in campos_en_formula:
                campo_nombre_lower = campo_nombre.lower()
                field_names_lower = {field.name().lower(): field.name() for field in fields}
                
                if campo_nombre_lower in field_names_lower:
                    campo_real = field_names_lower[campo_nombre_lower]
                    valor_campo = feature[campo_real]
                    
                    # Convertir None a string vacío o 0 según contexto
                    if valor_campo is None:
                        # Determinar si es texto o número basado en el contexto
                        if "'" in formula_evaluar or '"' in formula_evaluar:
                            valor_reemplazo = "''"
                        else:
                            valor_reemplazo = "0"
                    else:
                        valor_reemplazo = str(valor_campo)
                        # Si es texto, poner entre comillas
                        if "'" in formula_evaluar or '"' in formula_evaluar:
                            valor_reemplazo = f"'{valor_reemplazo}'"
                    
                    formula_evaluar = formula_evaluar.replace(f'[{campo_nombre}]', valor_reemplazo)
                else:
                    # Campo no existe, reemplazar por valor por defecto
                    if "'" in formula_evaluar or '"' in formula_evaluar:
                        formula_evaluar = formula_evaluar.replace(f'[{campo_nombre}]', "''")
                    else:
                        formula_evaluar = formula_evaluar.replace(f'[{campo_nombre}]', "0")
            
            # Funciones especiales de geometría
            geometria = feature.geometry()
            if geometria and not geometria.isEmpty():
                if 'geometry().area()' in formula_evaluar:
                    area = geometria.area()
                    formula_evaluar = formula_evaluar.replace('geometry().area()', str(area))
                
                if 'geometry().centroid().x()' in formula_evaluar:
                    centroid = geometria.centroid()
                    if not centroid.isEmpty():
                        centroid_x = centroid.asPoint().x()
                        formula_evaluar = formula_evaluar.replace('geometry().centroid().x()', str(centroid_x))
                
                if 'geometry().centroid().y()' in formula_evaluar:
                    centroid = geometria.centroid()
                    if not centroid.isEmpty():
                        centroid_y = centroid.asPoint().y()
                        formula_evaluar = formula_evaluar.replace('geometry().centroid().y()', str(centroid_y))
            
            # Para fórmulas de texto, evaluar como concatenación
            if "'" in formula_evaluar or '"' in formula_evaluar:
                # Es una fórmula de texto, usar eval seguro
                try:
                    resultado = eval(formula_evaluar, {"__builtins__": {}}, {})
                    return str(resultado) if resultado is not None else ""
                except:
                    # Si falla eval, devolver la fórmula como está
                    return formula_evaluar.replace("''", "").replace('""', '')
            else:
                # Es una fórmula numérica
                resultado = eval(formula_evaluar, {"__builtins__": {}}, {
                    'sqrt': math.sqrt, 'pow': math.pow, 'round': round,
                    'abs': abs, 'min': min, 'max': max, 'int': int, 'float': float,
                    'math': math
                })
                return self._convertir_tipo(resultado, field_type)
                
        except Exception as e:
            print(f"Error evaluando fórmula: {formula} -> {formula_evaluar} - {e}")
            return self._valor_por_defecto(field_type)

    def _valor_por_defecto(self, field_type):
        '''Devuelve valor por defecto según el tipo de campo'''
        if field_type in (QMetaType.Type.QString, QMetaType.Type.QChar):
            return ""
        elif field_type in (QMetaType.Type.Int, QMetaType.Type.UInt, QMetaType.Type.LongLong, QMetaType.Type.ULongLong):
            return 0
        elif field_type == QMetaType.Type.Double:
            return 0.0
        else:
            return None