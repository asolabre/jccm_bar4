# -*- coding: utf-8 -*-
"""
/***************************************************************************
herrExpro_REMISION.py
                                 A QGIS4 plugin

                             -------------------
        begin                : 2020-05-23
        git sha              : $Format:%H$
        Codigo Original     : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from qgis.PyQt.QtGui import QIcon
# from PyQt5.QtGui import QIcon, QPixmap
from qgis.PyQt.QtWidgets import QDialog
# from PyQt5.QtWidgets import QDialog, QTableWidgetItem, QApplication
from qgis.PyQt.QtCore import QSettings
from qgis.PyQt import uic
# from qgis.core import QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsFeature, QgsField, QgsExpression, QgsFeatureRequest, QgsGeometry
from qgis.PyQt.QtCore import Qt, QDate

import os
import datetime
import time
import codecs

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

current_configuration = configuration()

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrExpro_infoexptes_REMISION.ui'))

# VARIABLES
srcVal = configuration().general["EPSG"]

# listINGENIERO = [
    # 'Agustín Solabre Suárez',
    # 'José Ignacio Alfaro Molina',
    # 'L.Antoliano Hernández García'
    # ]
# listMARGEN = [
    # 'Ambas',
    # 'Izquierda',
    # 'Derecha'
    # ]
# listCORREOELEC = [
    # ]
    
# listTIPOEXPTE = current_configuration.listTIPOEXPTE
listINGENIERO = current_configuration.listINGENIERO
listMARGEN = current_configuration.listMARGEN
listCORREOELEC = current_configuration.listCORREOELEC
listINTERESADO = current_configuration.listINTERESADO


class herrExpro_REMISION(QDialog, FORM_CLASS):
    def __init__(self, iface, listaVAL, parent=None):
        """Constructor."""
        super(herrExpro_REMISION, self).__init__(parent)
        self.current_configuration = configuration()
        self.setupUi(self)
        self.qs = QSettings()
        self.fun = Functions()
        self.iface = iface;
        
        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))
        
        self.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/jccm_EXPINFOREMISION.jpg'))

        # Acciones de los botones
        self.rellenaCamposFORM(listaVAL)
        self.btnCANCELA.clicked.connect(self.cancela)
        self.btnCREAEXPTE.clicked.connect(lambda: self.creaEXPTEyCLOSE(self))


    def creaEXPTEyCLOSE(self, menu):
        self.fun.creaEXPTE(self)
        self.close()
    

    def rellenaCamposFORM(self, listaVAL):
        # Se rellenan los combos
            ## ESTO SE DEBE HACER A PARTIR DEL FICHERO DE INFORMES O DE CONFIGURACIÓN
        listSOLICITANTE = ['Actuacíón de oficio']

        self.EX_MARGEN.clear()
        self.EX_MARGEN.addItems(listMARGEN)
        self.EX_INGENIERO.clear()
        self.EX_INGENIERO.addItems(listINGENIERO)
        # self.EX_TIPO_EXPEDIENTE.clear()
        # self.EX_TIPO_EXPEDIENTE.addItems(listTIPOEXPTE)
        self.EX_SOLICITANTE.clear()
        self.EX_SOLICITANTE.addItems(listSOLICITANTE)
        self.EX_INTERESADO.clear()
        self.EX_INTERESADO.addItems(listINTERESADO)
            
        # Se rellenan los campos traídos desde el dock de Info Exptes
        self.EX_NUMEXPRO.setText('EX-'+listaVAL[0])         # 00 NUMEXPRO;2020033
        self.EX_REGISTRO.setText(listaVAL[1])               # 01 REGISTRO;79945
        self.EX_FECHA.setDate(QDate.currentDate())          # 02 FECHA; Expte remisión; 01/01/2020
        # self.EX_SOLICITANTE.setText(listaVAL[3])            # 03 SOLICITANTE;FRANCISCO MANGANESO HELIO
        # self.EX_INTERESADO.setText(listaVAL[4])             # 04 INTERESADO;ARTURO SELENIO RUBIDIO
        self.EX_SOLICITANTE.setCurrentIndex(self.EX_SOLICITANTE.findText(listaVAL[3], Qt.MatchFlag.MatchFixedString))
        self.EX_INTERESADO.setCurrentIndex(self.EX_INTERESADO.findText(listaVAL[4], Qt.MatchFlag.MatchFixedString))

        
                                                            # 05 DNI;123456789
                                                            # 06 NOMBRE;HEREDEROS
                                                            # 07 DOMICILIO;C/ ELEMENTOS, 27
                                                            # 08 CODIGOPOST;02630
                                                            # 09 TLFNO;927654321
                                                            # 10 POBLACION;BONETE
        self.EX_CARRETERA.setText(listaVAL[11])             # 11 CARRETERA;CM3209
        self.EX_KILOMETRO.setText(listaVAL[12])             # 12 KILOMETRO;0
        self.EX_KILOMET2.setText(listaVAL[13])              # 13 KILOMET2;16124
        #               Selector en combo MARGEN            # 14 MARGEN;IZQDA
        if self.EX_MARGEN.findText(listaVAL[14], Qt.MatchFlag.MatchFixedString) != -1:
            self.EX_MARGEN.setCurrentIndex(self.EX_MARGEN.findText(listaVAL[14], Qt.MatchFlag.MatchFixedString))
        else:
            self.EX_MARGEN.addItem(listaVAL[14])
        self.EX_OBSERVAPK.setText(listaVAL[15])             # 15 OBSERVAPK;ESTE ES UN FICHERO DE PRUEBA
        self.EX_TIPO.setText(listaVAL[16])                  # 16 TIPO;Solicitud de comprobación de posible invasión de parcela catastral
                                                            # 17 ARCHIVO;PENDIENTE
                                                            # 18 IG;ASS
        #               Selector en combo INGENIERO         # 19 INGENIERO;Paco Quinto Rodriguez
        if self.EX_INGENIERO.findText(listaVAL[19], Qt.MatchFlag.MatchFixedString) != -1:
            self.EX_INGENIERO.setCurrentIndex(self.EX_INGENIERO.findText(listaVAL[19], Qt.MatchFlag.MatchFixedString))
        else:
            self.EX_INGENIERO.addItem(listaVAL[19])
        #               Selector en combo ADMIN             # 20 ADMIN;Mónica Aller Tovar
        if self.EX_ADMIN.findText(listaVAL[20], Qt.MatchFlag.MatchFixedString) != -1:
            self.EX_ADMIN.setCurrentIndex(self.EX_ADMIN.findText(listaVAL[20], Qt.MatchFlag.MatchFixedString))
        else:
            self.EX_ADMIN.addItem(listaVAL[20])
                                                            # 21 ESTAARCHIVADO;FALSO
        self.EX_FECHAARCHIVO.setDate(QDate.fromString(listaVAL[22], 'dd/MM/yyyy')) # 22 FECHAARCHIVO;02/01/2020
        self.EX_EXPTE_EXPROPIACION.setText(listaVAL[23])    # 23 EXPTE_EXPROPIACION;CN-AB-96/115
        self.EX_EXPTES_RELACIONADOS.setText(listaVAL[24])   # 24 EXPTES_RELACIONADOS;CN-AB-96/115-M
        self.EX_NOMBRE_TRAMO.setText(listaVAL[25])          # 25 NOMBRE_TRAMO;EjeManchuela_Villamalea_A31 (Tramo 2)
        self.EX_DECR_ACUERDO_RESOLUCION.setText(listaVAL[26])# 26 DECR_ACUERDO_RESOLUCION;30-OCTUBRE-06
        self.EX_ACTAS_PREVIAS.setText(listaVAL[27])         # 27 ACTAS_PREVIAS;jun-07
        self.EX_REMISION_CATASTRAL.setText(listaVAL[28])    # 28 REMISION_CATASTRAL;25/03/2019
        self.EX_NUMORDEN.setText(listaVAL[29])              # 29 NUMORDEN;73-131
        self.EX_POLIGONO.setText(listaVAL[30])              # 30 POLIGONO;4-3
        self.EX_PARCELAS.setText(listaVAL[31])              # 31 PARCELAS;583-376
        self.EX_TM.setText(listaVAL[32])                    # 32 TM;BONETE
        #               Selector en combo TIPO_EXPEDIENTE   # 33 TIPO_EXPEDIENTE;NO INVASION
        if self.EX_TIPO_EXPEDIENTE.findText(listaVAL[33], Qt.MatchFlag.MatchFixedString) != -1:
            self.EX_TIPO_EXPEDIENTE.setCurrentIndex(self.EX_TIPO_EXPEDIENTE.findText(listaVAL[33], Qt.MatchFlag.MatchFixedString))
        else:
            self.EX_TIPO_EXPEDIENTE.addItem(listaVAL[33])
                                                            # 34 FECHAINFORME;02/01/2020
        self.EX_TITULO_EXPROPIACION.setText(listaVAL[35])   # 35 TITULO_EXPROPIACION;ACONDICIONAMIENTO CTRA B-11 (CM-3209), P.K. 0 AL 16,124. MONTEALEGRE-BONETE-ESTACION DE BONETE
                                                            # 36 EX_EXPTE_OBRA_RELACIONADO;
        self.EX_REF_CATASTRAL.setText(listaVAL[37])         # 37 REF_CATASTRAL;400016BWJ9140S
        self.EX_FECHA_ULTIMO_TRAMITE.setDate(QDate.currentDate()) # 38 FECHA_ULTIMO_TRAMITE;04/09/2018
        self.EX_TRAMITE_EXPROPIACION.setText(listaVAL[39])  # 39 TRAMITE_EXPROPIACION;ARCHIVADO
        self.EX_CORREOELEC.setText(listaVAL[40])            # 40 CORREOELEC;COSA@VAINA.ES


    def cancela(self):
        self.close()
        pass

