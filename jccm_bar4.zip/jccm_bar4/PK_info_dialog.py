# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           PK_info_dialog.py
Purpose:

        --------------------------------------------------------------------
        begin                : 2019-09-03
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt, QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtWidgets import QAction, QApplication, QWidget, QPushButton, QMessageBox, QToolButton, QMenu, QFileDialog

from qgis.core import (QgsFeedback, QgsProject, QgsExpression, QgsFeatureRequest, QgsGeometry, QgsPointXY, QgsRectangle)

from qgis.PyQt import QtGui, QtCore, uic
from qgis.PyQt.QtWidgets import QDialog
from qgis.utils import iface

import os, glob, io, codecs
from osgeo import gdal, osr, ogr
import time

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .PK_info_panel import info_panel

QT_VERSION=5
os.environ['QT_API'] = 'pyqt5'

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/PK_info.ui'))
dw  = uic.loadUi( os.path.join(os.path.dirname(__file__), './menus/PK_dockGeometry.ui') )  ## LLAMADA INFO PANEL ##


class Form_PK_info(QDialog, FORM_CLASS):
    # def __init__(self, canvas, iface, parent=None):
    def __init__(self, canvas, iface, carretera_pk, parent=None):
        super(Form_PK_info, self).__init__(parent)
        # super(Form_PK_info(geometria), self).__init__(parent)
        self.setupUi(self)
        self.iface = iface
        self.fun = Functions()
        self.qs = QSettings()
        
        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        self.conf = configuration()
        geometry = carretera_pk[8]
        atributos = carretera_pk[4]
        ctra = atributos['Matricula_Plan']

        self.setFixedSize(540, 170)
        self.setWindowIcon(QIcon(':/plugins/jccm_bar4/iconos/logo_general.jpg'))


        self.botonDcha = 'R'
        self.botonAbajo = 'D'
        self.pkProx = 0
        self.intervalo = 10.00

        # Se localizan los datos de GEOMETRÍA y AFOROS EN LA GDB
        listGDB = [
            "V:\SIGCLM\APPJCCM\Datos\sig_reg_ctras.gdb",
            "V:\SIGCLM\APPJCCM\Datos\sig_reg_ctras_AB.gdb",
            "U:\SIGCLM\APPJCCM\Datos\sig_reg_ctras.gdb",
            "U:\SIGCLM\APPJCCM\Datos\sig_reg_ctras_AB.gdb"]
        # GDB = "U:\SIGCLM\APPJCCM\Datos\sig_reg_ctras_AB.gdb"
        GDBCLASS = "GEOMETRIA"
        GDB = self.fun.buscaUnidadesGDB(listGDB, GDBCLASS)

        # print ('GDB= ', GDB)   ## LLAMADA INFO PANEL ##

        if GDB == "":
            self.btnAbrirDcha.setVisible(0)
            pass

        self.btnAbrirDcha.clicked.connect(lambda: self.botonPanelDcha(GDB))     ## LLAMADA INFO PANEL ##
        # self.btnAbrirDcha.hide()                                              ## LLAMADA INFO PANEL ##
        self.btnAbrirAbajo.clicked.connect(lambda: self.botonAmpliarAbajo())
        self.btnVerCota.clicked.connect(lambda: self.botonVerCota())
        self.btnDescargaEje.clicked.connect(lambda: self.botonDescargaEje())
        self.btnLISTCOORD.clicked.connect(lambda: self.botonLISTCOORD(geometry))
        self.btnGuardaCSV.clicked.connect(lambda: self.botonGuardaCSV(geometry,ctra))
        self.btnGuardaSHP.clicked.connect(lambda: self.botonGuardaSHP(geometry,ctra))
        self.chkGuardarM.setChecked(False)
        self.btnGuardaSHP.hide()

        # self.chkGuardarM.hide()

        # dw.btnRetrocedePK.hide()
        # dw.btnAvanzaPK.hide()
        # dw.btnRetrocedePK.setEnabled(True)
        # dw.btnAvanzaPK.setEnabled(True)


    def botonAmpliarAbajo(self):
        XE =  float(self.XE.text())
        YE =  float(self.YE.text())

        if self.botonAbajo == 'D':
            self.setHistoricoCTRA(XE, YE)
            self.setFixedSize(540, 400)
            self.btnAbrirAbajo.setArrowType(Qt.ArrowType.UpArrow)
            self.botonAbajo = 'U'
        elif self.botonAbajo == 'U':
            self.setFixedSize(540, 170)
            self.btnAbrirAbajo.setArrowType(QtCore.Qt.ArrowType.DownArrow)
            self.botonAbajo = 'D'
            # self.btnAbrirDcha.setArrowType(QtCore.Qt.ArrowType.RightArrow)
            # self.botonDcha = 'R'


    def botonLISTCOORD(self, geometry):
        self.txbLISTGEOM.setHtml(self.fun.makeHtmlListCoord(geometry))
        self.setFixedSize(860, 400)
        self.btnAbrirAbajo.setArrowType(Qt.ArrowType.UpArrow)
        self.botonAbajo = 'U'


    def botonGuardaCSV(self, geometry, ctra):
        nom_fich_csv = u"C:/temp/" + ctra.replace('-','')+'_geom'
        ext = "*.csv"
        dirfile, tipofile = QFileDialog.getSaveFileName(self, "Fichero CSV de salida", nom_fich_csv, ext)
        if dirfile == None or dirfile == "":
            dirfile = nom_fich_csv
            self.fun.showMessage(u"No se guarda el fichero CSV")
            return
        # Comprobamos que existe el directorio y si no se crea
        if not os.path.exists(os.path.dirname(dirfile)):
            os.makedirs(os.path.dirname(dirfile))

        target  = open(dirfile, 'w+',encoding='utf-8')
        if self.chkGuardarM.isChecked():
            encabezado = u'"num";"x";"y";"pk";"dif"'
        else:
            encabezado = u'"num";"x";"y";"pk"'

        target.write(encabezado+"\n")

        paths = geometry["paths"]
        listCoord =''
        punto = 1
        pathNum=1
        Mant = None
        for path in paths:
            datoPath = 'TRAMO %s/%s (%s puntos)\n'%(str(pathNum),len(paths),len(path))
            target.write(datoPath)
            for point in path:
                if point[2] is not None:
                    if Mant is not None:
                        if self.chkGuardarM.isChecked():
                            listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+','+" %0.5f"%(point[2]-Mant)+'\n'
                        else:
                            listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+'\n'
                        target.write(listCoord)
                    else:
                        if self.chkGuardarM.isChecked():
                            listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+', 0.0'+'\n'
                        else:
                            listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+'\n'

                        target.write(listCoord)
                    Mant = point[2]
                else:
                    listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" None"+'\n'
                    target.write(listCoord)
                punto += 1
            pathNum +=1

        target.close()
        textInfo = u"GUARDADO CSV\n\n"+dirfile
        self.fun.showMessage(textInfo)


    def botonGuardaSHP(self, geometry):
        self.fun.showMessage(u"GUARDAMOS UN SHP")
        pass


    def botonPanelDcha(self, GDB):
        # if self.botonDcha == 'R':

        # bar = QProgressBar()    ## LLAMADA INFO PANEL ##

        text =u'La carga de datos desde fuentes externas.\n'
        text +=u'puede tardar varios minutos.\n\n'
        text +=u'               ¿DESEA CONTINUAR?'
        result = self.fun.showMessageYESNO(text,'',u'VER MÁS DATOS' )
        if result != 1024: # No e ha pulsado ACEPTAR
            return
        pass

        bar = QgsFeedback()    ## LLAMADA INFO PANEL ##
        # bar.setRange(0,0)
        bar.setProgress(0)
        iface.mainWindow().statusBar().clearMessage()
        iface.mainWindow().statusBar().showMessage('Cargando datos GEOMETRÍA...')
        # iface.mainWindow().statusBar().addWidget(bar)    ## LLAMADA INFO PANEL ##
        # ctraBUSQ  =  self.Matricula.text()
        # pk = float(self.Pk.text())

        self.botonDcha = 'L'
        self.botonAbajo = 'U'

        # iface.mainWindow().addDockWidget(Qt.RightDockWidgetArea, dw)

        self.pkGetGeometria(ctraBUSQ, pk, dw, GDB)
        self.pkGetAforos(ctraBUSQ, pk, dw, GDB)

        # iface.mainWindow().statusBar().removeWidget(bar)    ## LLAMADA INFO PANEL ##
        iface.mainWindow().statusBar().clearMessage()
        # self.fun.trabajando(u'--- CERRAR ---', busy)
        dw.show()
        dw.btnRetrocedePK.clicked.connect(lambda: self.RetrocedePK(GDB))
        dw.btnAvanzaPK.clicked.connect(lambda: self.AvanzaPK(GDB))


        # return pkProx


    def botonVerCota(self):
        # Zmdt = self.fun.Zmdt((float(self.XE),float(self.YE)), self.iface, pintar='NO')
        XE = float(self.XE.text())
        YE = float(self.YE.text())
        Zmdt = self.fun.Zmdt((XE,YE), self.iface, pintar='NO')
        # self.cotaEje.setText(str(round(Zmdt,3)))
        # self.ZE.setText(str(round(Zmdt,3)))
        if Zmdt == 'Error':
            self.cotaEje.setText('Error')
            self.ZE.setText('Error')
        else:
            self.cotaEje.setText(str(round(Zmdt,3)))
            self.ZE.setText(str(round(Zmdt,3)))


    def botonDescargaEje(self):
        # Descarga de EJE pinchado
        from .herrCTRAS_descargas import herrCTRAS_descargas
        
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        
        herrCTRAS_descargas = herrCTRAS_descargas(self.iface)
        valcbxTitularidad = '%'
        valcbxFuncionalidad = '%'
        valcbxProvincia = '%'
        valcbxMatricula = self.Matricula_plan.text()
        valMatr9000 = True
        SOLO2D = False 
        messLblINFO = False
        NOMcapa = u'CTRA %s EJE'%(valcbxMatricula)
        fichEstilo = '/Carreteras_CLM_WFS.qml'
        estiloCAPA = os.path.join(os.path.dirname(__file__), self.conf.general["carpeta_estilos"] + fichEstilo)
        # nomFich = u'C:/TEMP/%s_EJE.gpkg'%(valcbxMatricula)
        nomFich = u'C:/TEMP/%s.gpkg'%(valcbxMatricula)
        nomLayerPKS = u'CTRA %s PKS'%(valcbxMatricula)
        fichEstiloPKS = '/GEO_PKS_WFS.qml'
        nomFichPKS = 'C:/TEMP/%s_PKS.gpkg'%(valcbxMatricula)
        estiloCAPAPKS = os.path.join(os.path.dirname(__file__), self.conf.general["carpeta_estilos"] + fichEstiloPKS)

        # Descargamos el eje
        layerEJES2D = herrCTRAS_descargas.lecturaEJES(valcbxTitularidad, valcbxFuncionalidad,
                        valcbxProvincia, valcbxMatricula, valMatr9000, SOLO2D,
                        messLblINFO, NOMcapa, estiloCAPA, nomFich)

        # ## TODO priueba de ver si carga la M del eje
        # QgsProject.instance().addMapLayer(layerEJES2D) 
        # print ('AQUI SE CARGA LA CAPA PREVIAMENTE')
        # ## TODO priueba de ver si carga la M del eje

        # Escribimos en un fichero GPKG los ejes
        self.fun.cargaGPKGjson(layerEJES2D, nomFich, NOMcapa, NOMcapa, estiloCAPA, cargaVISTA=True)

        # Descargamos los Pks
        layerPKS = herrCTRAS_descargas.lecturaPKS(valcbxProvincia, valcbxMatricula,
                        messLblINFO, nomLayerPKS, nomFichPKS, estiloCAPAPKS)
                        # messLblINFO, nomLayerPKS, nomFich, estiloCAPAPKS)
                        
        # Escribimos en un fichero GPKG los pks
        self.fun.cargaGPKGjson(layerPKS, nomFichPKS, nomLayerPKS, nomLayerPKS, estiloCAPAPKS, cargaVISTA=True)
        # self.fun.cargaGPKGjson(layerPKS, nomFich, nomLayerPKS, nomLayerPKS, estiloCAPAPKS, cargaVISTA=True)


        QApplication.restoreOverrideCursor()
        text = u'FINALIZADA DESCARGA EJE %s'%(valcbxMatricula)
        self.fun.showMessage(text)
        
        return


    def setHistoricoCTRA(self, XE, YE):
        ###############################################################################################
        ####            METEMOS DATOS HISTÓRICOS            ###########################################
        ###############################################################################################

        GPKGCLASS = "CTRAS_HISTORICO"
        GPKG = "U:/cartografia/datos_Q/CAPAS/GDB_CARRETERAS.gpkg"
        #       U:/cartografia/datos_Q/CAPAS/GDB_CARRETERAS.gpkg|layername=CARRETERAS_AB_HISTORICO_EDICION
        TABLANOM = "CARRETERAS_AB_HISTORICO_EDICION"
        LAYNOM = GPKGCLASS
        LAYTIPE = "ogr"

        self.lvwCTRASHISTORICO.clear()
        ## DETECTAR SI EXISTE LA CAPA Y/O CARGARLA
        if self.qs.value(f"{self.nombre_plugin}/ACCESOEDITOR"):
            listHisto = [u'HISTÓRICO: No hay datos históricos']
            self.lvwCTRASHISTORICO.show()
            attrs = self.getHistoricoCTRA( XE, YE, GPKG, GPKGCLASS, LAYNOM, LAYTIPE, TABLANOM)

            if attrs[0] == 's/d' or not attrs[0][6]:
                # print ('NO SE LOCALIZAN DATOS')
                listHisto = [u'HISTÓRICO: No hay datos históricos']
            else:
                numAtt = 1
                listHisto = []
                for attr in attrs:
                    # print (attr)
                    try:
                        fecha = attr[11].toString('dd/MM/yy')
                    except:
                        fecha = ''
                    if attr[6]:
                        if attr[6] == 'NUEVO TRAZADO':
                            linAtt = u'NUEVO TRAZADO construido el %s. %s'%(fecha,attr[12])
                        elif attr[9] == attr[10]:
                            linAtt = u'Ant. %s CAMBIO NOMBRE el %s. %s'%(attr[6],fecha,attr[12])

                        else:
                            # print ('CTRA_ANT: ',attr[6],'DE: ',attr[9],'A: ',attr[10],'FECHA: ',attr[11],'Decreto: ',attr[12])
                            linAtt = u'Ant. %s. Transf. de  %s a %s el %s. %s'%(attr[6],attr[9],attr[10],fecha,attr[12])
                        listHisto.append(linAtt)
                        numAtt += 1
            self.lvwCTRASHISTORICO.addItems(listHisto)

        else:
            self.lvwCTRASHISTORICO.hide()

        pass


    def getHistoricoCTRA(self, XE, YE, GPKG, GPKGCLASS, LAYNOM, LAYTIPE, TABLANOM):

        # -----  DATOS HISTÓRICOS -----
        # LAYNOM = "GEOMETRIA"

        layerEXIST = QgsProject.instance().mapLayersByName(LAYNOM)
        if not layerEXIST:
            # print (GPKG)
            if not os.path.isfile(GPKG):
                print (u'No existe fichero %s'%(GPKG))
                return (['s/d'])

            layers = [l.GetName() for l in ogr.Open(GPKG)]
            if TABLANOM in layers:
                layer = iface.addVectorLayer(GPKG + "|layername=" + TABLANOM, LAYNOM, 'ogr')
                layer.setName(LAYNOM)
                QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(False)
                QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setExpanded(False)

            else:
                print('Error: no hay una capa llamada "{}" en {}!'.format(layer, gpkg))
                return (['s/d'])

        else:
            layer = layerEXIST[0]
            QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(False)
            QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setExpanded(False)

        # print (XE)
        # print (YE)

        radius = 1
        rect = QgsRectangle(XE - radius,
                            YE - radius,
                            XE + radius,
                            YE + radius)


        attrs = ['s/d']
        try:
            layer.selectByRect(rect, False)
            features = layer.selectedFeatures()

            attrs = []
            for feat in features:
                attrs.append(feat.attributes())
            if attrs == []:
                attrs = ['s/d']
        except:
            attrs = ['s/d']

        layer.removeSelection()
        return attrs


    def cancel(self):
        self.reject()


    def pkGetGeometria(self, ctraBUSQ, pk, dw, GDB):

        GDBCLASS = "GEOMETRIA"
        LAYNOM = "GEOMETRIA"
        LAYTIPE = "ogr"
        attrs = ['s/d']

        # Esto solo vale para buscar en un fichero SHP con la misma estructura que la GDB
        # filSHP = u'u:\BBDD AGENDA\CONSULTAS_BBDD208\GEOMETRIA_CTRA_TRA.shp'
        filSHP = ""

        if GDB == "" and filSHP == "":
            print (' LO SIENTO LA GDB o LA CLASE NO EXISTE ')
        else:
            if filSHP == "":
                QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
                attrs = self.fun.getGeomCTRA(ctraBUSQ, pk, GDB, GDBCLASS, LAYNOM, LAYTIPE)
                const = 0
                self.close()
            else:
                QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
                attrs = self.fun.getGeomCTRA_SHP(ctraBUSQ, pk, filSHP, LAYNOM, LAYTIPE)
                const = 0
                self.close()

        # if attrs[0] == 's/d':

        if attrs == {}:
            print ('NO SE LOCALIZAN DATOS')

            dw.G_nocarriles.setText("s/d")
            dw.G_Plataforma.setText("s/d")
            dw.G_ArcenI.setText("s/d")
            dw.G_CalzadaT.setText("s/d")
            dw.G_ArcenD.setText("s/d")
            dw.G_RadioC.setText("s/d")
            dw.G_Peralte.setText("s/d")
            dw.G_Pendiente.setText("s/d")
            dw.G_UTM_Z.setText("s/d")
            self.pkProx = pk


        else:
            # print 'CTRA= %s (%s) - PK= %s+%s' %(attrs[0],attrs[4], int(attrs[7]), int(attrs[8]))
            # print 'Plataforma= %s carriles, %s - %s - %s' %(int(attrs[13]),str(attrs[16]/10),str(attrs[18]/10),str(attrs[19]/10))
            # print 'IdSubred=%s - IdCtra=%s - idMatricula=%s - Tramo=%s' %(attrs[1],attrs[2],attrs[3],attrs[4])
            # print 'Radio=%s - Peralte=%s - Pendiente=%s - Alzado=%s - '%(attrs[20],attrs[21]/10,attrs[22]/10,attrs[23])
            # for att in attrs:
                # print att

            dw.G_nocarriles.setText(str(int(attrs['No_carrile'])))
            dw.G_Plataforma.setText(str(attrs['Plataforma']/10))
            dw.G_ArcenI.setText(str(attrs['Arcen_Izq']/10))
            dw.G_CalzadaT.setText(str(attrs['Calzada_To']/10))
            dw.G_ArcenD.setText(str(attrs['Arcen_Der']/10))
            dw.G_RadioC.setText(str(attrs['Radio_de_C']))
            dw.G_Peralte.setText(str(attrs['Peralte']/10))
            dw.G_Pendiente.setText(str(attrs['Pendiente']/10))
            dw.G_UTM_Z.setText(str(attrs['UTM_Z']))
            self.pkProx = attrs['PKHito']+attrs['PKDist']/1000



        dw.Carretera.setText('<font size = 5 color = black font-style = bold><p align="center">'+ctraBUSQ+'</p></font>')
        dw.Pk.setText('<font size = 5 color = black font-style = bold><p align="center">PK: '+self.fun.mostrarPK(self.pkProx,2)+'</p></font>')
        # Establecemos el color de la etiqueta
        '''
        values = "{r}, {g}, {b}, {a}".format(r = color.red(),
                                             g = color.green(),
                                             b = color.blue(),
                                             a = alpha
                                             )
        myLabel.setStyleSheet("QLabel { background-color: rgba("+values+"); }")
        '''
        # Establecemos el color de la etiqueta
        dw.Carretera.setStyleSheet("background-color: white")
        # dw.Carretera.setStyleSheet("background-color: rgba("255,255,255,255")")
        dw.Pk.setStyleSheet("background-color: white")

        QApplication.restoreOverrideCursor()
        # LISTADO DE ATRIBUTOS ( variable attrs)
        #Nombre: 0 Carretera
        #Nombre: 1 IdSubred
        #Nombre: 2 IdCtra
        #Nombre: 3 idMatricula
        #Nombre: 4 Tramo
        #Nombre: 5 A_Tramos_IdTramo
        #Nombre: 6 Geometria_IdTramo
        #Nombre: 7 PKHito
        #Nombre: 8 PKDist
        #Nombre: 9 Distancia
        #Nombre: 10 UTM_X
        #Nombre: 11 UTM_Y
        #Nombre: 12 UTM_Z
        #Nombre: 13 N_de_Carriles
        #Nombre: 14 Plataforma
        #Nombre: 15 Plataforma_total
        #Nombre: 16 Arcen_Izquierdo
        #Nombre: 17 Calzada
        #Nombre: 18 Calzada_Total
        #Nombre: 19 Arcen_Derecho
        #Nombre: 20 Radio_de_Curvatura
        #Nombre: 21 Peralte
        #Nombre: 22 Pendiente
        #Nombre: 23 Alzado
        #Nombre: 24 Visibilidad_Directa
        #Nombre: 25 Visibilidad_Inversa
        #Nombre: 26 IdtramoContrario
        #Nombre: 27 DistCalzadaContraria
        #Nombre: 28 Mediana
        #Nombre: 29 Galibo_izquierdo
        #Nombre: 30 Galibo_derecho
        #Nombre: 31 GLAT
        #Nombre: 32 GLON
        #Nombre: 33 PROVINCIA
        #Nombre: 34 FECHA
        #Nombre: 35 FUENTE
        #Nombre: 36 UTM_X
        #Nombre: 37 UTM_Y
        #Nombre: 38 UTM_Z

    def pkGetAforos(self, ctraBUSQ, pk, dw, GDB):

        GDBCLASS = "AFOROS_tramificacion"
        LAYNOM = "AFOROS"
        LAYTIPE = "ogr"
        attrs = ['s/d']

        filSHP = ""

        if GDB == "" and filSHP == "":
            print (' ¡LO SIENTO! LA GDB o LA CLASE NO EXISTE ')
        else:
            if filSHP == "":
                QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
                attrs = self.fun.getAforoCTRA(ctraBUSQ, pk, GDB, GDBCLASS, LAYNOM, LAYTIPE)
                const = 0
                self.close()
            else:
                QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
                attrs = self.fun.getGeomCTRA_SHP(ctraBUSQ, pk, filSHP, LAYNOM, LAYTIPE)
                const = 0
                self.close()


        if attrs[0] == 's/d':
            print ('NO SE LOCALIZAN DATOS')

            dw.A_IMD.setText("s/d")
            dw.A_porcPes.setText("s/d")
            pass

        else:
            dw.A_IMD.setText(str(attrs[8]))
            dw.A_porcPes.setText("{:.{}f}".format( attrs[9],3)+'%')
            pass

        QApplication.restoreOverrideCursor()

        # Nombre: 0 idEstacion
        # Nombre: 1 Provincia
        # Nombre: 2 EstacionTi
        # Nombre: 3 Carretera
        # Nombre: 4 Pk_estacio
        # Nombre: 5 Ubicacion
        # Nombre: 6 KMi
        # Nombre: 7 KMf
        # Nombre: 8 IMD17
        # Nombre: 9 PESADOS17
        # Nombre:10 Tramificac
        # Nombre:11 Shape_Length


    def setLabelColors(window, base):
        t = '<property name="palette"><palette><active>'
        t+= '<colorrole role="Base">  <brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>255</green><blue>255</blue></color></brush></colorrole>'
        t+= '<colorrole role="Window"><brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        t+= '</active><inactive>'
        t+= '<colorrole role="Base">  <brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>255</green><blue>255</blue></color></brush></colorrole>'
        t+= '<colorrole role="Window"><brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        t+= '</inactive><disabled>'
        t+= '<colorrole role="Base">  <brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        t+= '<colorrole role="Window"><brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        t+= '</disabled></palette></property>'
        return t


    def RetrocedePK(self, GDB):
        ctraBUSQ = self.fun.Extract_PlainText(dw.Carretera)
        #pk = self.fun.Extract_PlainText(dw.Pk).replace('PK: ','').replace('+','')
        pk = self.pkProx
        self.pkProx = pk - (self.intervalo/1000)
        print (u'RETROCEDE A CTRA %s - PK %s - INT %s'%(ctraBUSQ,self.pkProx, self.intervalo))
        self.pkGetGeometria(ctraBUSQ, self.pkProx, dw, GDB)
        # return pkBUSQ
        pass


    def AvanzaPK(self, GDB):
        ctraBUSQ = self.fun.Extract_PlainText(dw.Carretera)
        #pk = self.fun.Extract_PlainText(dw.Pk).replace('PK: ','').replace('+','')
        pk = self.pkProx
        self.pkProx = pk + (self.intervalo/1000)
        print (u'RETROCEDE A CTRA %s - PK %s - INT %s'%(ctraBUSQ,self.pkProx, self.intervalo))
        self.pkGetGeometria(ctraBUSQ, self.pkProx, dw, GDB)
        # return pkBUSQ
        pass