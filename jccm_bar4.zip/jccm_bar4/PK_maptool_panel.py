# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           PK_maptool_panel.py
Purpose:
                                 A QGIS4 plugin
        --------------------------------------------------------------------
        begin                : 2025-04-01
        validacion transfQG4 : 2026-10-22
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import QIcon, QColor, QCursor
from qgis.PyQt.QtCore import QVariant, Qt, QSettings, QTranslator, QCoreApplication, QMetaType
from qgis.PyQt.QtWidgets import QAction, QApplication, QWidget, QPushButton, QMessageBox, QToolButton, QMenu, QListView

from qgis.gui import QgsMapTool,QgsVertexMarker
from qgis.core import QgsProject, QgsVectorLayer, QgsField, QgsFeature, QgsGeometry, QgsExpression, QgsFeatureRequest, QgsCoordinateReferenceSystem

from qgis.utils import iface

import os, glob, codecs
from osgeo import ogr

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
# from .PK_info_dialog import Form_PK_info
from .PK_info_panelFlotante import PKInfoDockWidget
from .PK_balizas_carretera import balizas_carreteraDialog

nombre_plugin = os.path.basename(os.path.dirname(__file__))
# VARIABLES
srcVal = QSettings().value(f"{nombre_plugin}/GENERAL/EPSG")
if srcVal is None:
    srcVal = configuration.general['EPSG']
    QSettings().setValue(f"{nombre_plugin}/GENERAL/EPSG", srcVal)

# Obtener el sistema de referencia espacial
srs = QgsCoordinateReferenceSystem(srcVal)
##################################################
######     VER TEMA SRC       ####################
# Establecer el SRS en el lienzo del mapa
# iface.mapCanvas().setDestinationCrs(srs)
##################################################

# # Obtener el proyecto actual
# project = QgsProject.instance()
# # Establecer el SRS del proyecto
# project.setCrs(srs)

id_ctra_carreteras = QSettings().value(f"{nombre_plugin}/LRS/id_ctra_carreteras")
if id_ctra_carreteras is None:
    id_ctra_carreteras = configuration.lrs["identificador_carretera_carreteras"]
    QSettings().setValue(f"{nombre_plugin}/LRS/id_ctra_carreteras", id_ctra_carreteras)

dest_path = QSettings().value(f"{nombre_plugin}/LRS/bal_dest_path")
if dest_path is None:
    dest_path = configuration.lrs["bal_dest_path"]
    QSettings().setValue(f"{nombre_plugin}/LRS/bal_dest_path", dest_path)

nom_layer = QSettings().value(f"{nombre_plugin}/LRS/bal_nom_layer")
if nom_layer is None:
    nom_layer = configuration.lrs["bal_nom_layer"]
    QSettings().setValue(f"{nombre_plugin}/LRS/bal_nom_layer", nom_layer)

fich_estiloCAPA = QSettings().value(f"{nombre_plugin}/LRS/bal_estiloCAPA")
if fich_estiloCAPA is None:
    fich_estiloCAPA = configuration.lrs["bal_estiloCAPA"]
    QSettings().setValue(f"{nombre_plugin}/LRS/bal_estiloCAPA", fich_estiloCAPA)
estiloCAPA = os.path.join(os.path.dirname(__file__), fich_estiloCAPA)

tipo_consultaCAPA = QSettings().value(f"{nombre_plugin}/LRS/tipo_consultaCAPA")
if tipo_consultaCAPA is None:
    tipo_consultaCAPA = configuration.lrs["tipo_consultaCAPA"]
    QSettings().setValue(f"{nombre_plugin}/LRS/tipo_consultaCAPA", tipo_consultaCAPA)

ruta_geopackage = QSettings().value(f"{nombre_plugin}/LRS/ruta_geopackage")
if ruta_geopackage is None:
    ruta_geopackage = configuration.lrs["ruta_geopackage"]
    QSettings().setValue(f"{nombre_plugin}/LRS/ruta_geopackage", ruta_geopackage)

nombre_capa_ctras = QSettings().value(f"{nombre_plugin}/LRS/nombre_capa_ctras")
if nombre_capa_ctras is None:
    nombre_capa_ctras = configuration.lrs["nombre_capa_ctras"]
    QSettings().setValue(f"{nombre_plugin}/LRS/nombre_capa_ctras", nombre_capa_ctras)

nombre_capa_munis = QSettings().value(f"{nombre_plugin}/LRS/nombre_capa_munis")
if nombre_capa_munis is None:
    nombre_capa_munis = configuration.lrs["nombre_capa_munis"]
    QSettings().setValue(f"{nombre_plugin}/LRS/nombre_capa_munis", nombre_capa_munis)

dest_path = 'en memoria'


class PK_maptool_panel(QgsMapTool):





    def __init__(self,canvas,iface,action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.fun = Functions()
        self.qs = QSettings()

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        cursor = QCursor()
        cursor.setShape(Qt.CursorShape.CrossCursor)
        iface.mapCanvas().setCursor(cursor)

        self.PK_info = None  # Referencia única al panel

        QApplication.restoreOverrideCursor()

        self.iface = iface
        self.setAction(action)
        self.action = action

    def canvasReleaseEvent(self, event):
        #Get the click
        x = event.pos().x()
        y = event.pos().y()

        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        # print ('Punto pinchado: ', point )
        # print ('srs = ',srs)
        self.getPointPK(point,self.iface)

    def getPointPK(self, point, iface):
        # Obtener datos del elemento pinchado en la vista, desde URL o GPKG
        tipo_consultaCAPA = self.qs.value(f"{self.nombre_plugin}/LRS/tipo_consultaCAPA")
        ruta_geopackage = self.qs.value(f"{self.nombre_plugin}/LRS/ruta_geopackage")
        nombre_capa_ctras = self.qs.value(f"{self.nombre_plugin}/LRS/nombre_capa_ctras")
        nombre_capa_munis = self.qs.value(f"{self.nombre_plugin}/LRS/nombre_capa_munis")
        # print ('tipo_consultaCAPA: ', tipo_consultaCAPA, ' - tipo_consultaCAPA (QS): ', self.qs.value(f"{self.nombre_plugin}/LRS/tipo_consultaCAPA"))

        # Comprobamos tipo_consultaCAPA para hacer la consulta de carretera_pk en url o GPKG
        if tipo_consultaCAPA == 'url':
            carretera_pk = self.fun.pointToPK(point,iface,pintar='SI', no9000='NO')
            FuenteDatos = 'FUENTE: geoservicios web'
        else:
            carretera_pk = self.fun.pointToPK_GPKG(point,iface, 'SI', 'NO',  1, ruta_geopackage, nombre_capa_ctras)
            FuenteDatos = 'FUENTE: {} - {}'.format(ruta_geopackage, nombre_capa_ctras)
        # print ('tipo_consultaCAPA = ', tipo_consultaCAPA)

        # Comprobamos resultado de carretera_pk si tipo_consultaCAPA == 'url' y en caso negativo tiramos por tipo_consultaCAPA = 'GPKG'
        if carretera_pk is None and tipo_consultaCAPA == 'url':
            tipo_consultaCAPA = 'GPKG'
            self.qs.setValue(f"{self.nombre_plugin}/LRS/tipo_consultaCAPA", tipo_consultaCAPA)
            carretera_pk = self.fun.pointToPK_GPKG(point,iface, 'SI', 'NO',  1, ruta_geopackage, nombre_capa_ctras)
            FuenteDatos = 'FUENTE: {} - {}'.format(ruta_geopackage, nombre_capa_ctras)

        if carretera_pk is None:
            message = u"--- Se debe aproximar más a una carretera ---"

            if tipo_consultaCAPA == 'GPKG':
                tipo_consultaCAPA = 'url'
                self.qs.setValue(f"{self.nombre_plugin}/LRS/tipo_consultaCAPA", tipo_consultaCAPA)
            self.fun.showMessage( 'Identificador de Carreteras',message,'' )
            return None

        if tipo_consultaCAPA == 'url':

            MuniProv = self.fun.getJCCMMuniProv(carretera_pk[7], self.iface, pintar='NO')

        else:
            MuniProv = self.fun.getJCCMMuniProv_GPKG(carretera_pk[7], self.iface, 'NO', ruta_geopackage, nombre_capa_munis)


        Zmdt = 0

        pkBUSC =      carretera_pk[1]
        atributos =   carretera_pk[4]
        geometry =    carretera_pk[8]
        # DistPkPlaca = carretera_pk[11]

        ctraBUSQ = atributos[id_ctra_carreteras]
        if ctraBUSQ == '9000':
            ctraBUSQ = 'Vial sin Nombre'

        ## Control de atributos None
        if atributos['idMatricula'] is None:        atributos['idMatricula'] = 0
        if atributos['Matricula'] is None or atributos['Matricula'] == '9000':
                                                    atributos['Matricula'] =  'Vial sin Nombre'
        if atributos['Longitud'] is None:           atributos['Longitud'] = 0
        if atributos['PkINI'] is None:              atributos['PkINI'] = 0
        if atributos['PkFin'] is None:              atributos['PkFin'] = 0
        if atributos['Matricula_Plan'] is None:     atributos['Matricula_Plan'] =  's/d'
        if atributos['Titularidad'] is None:        atributos['Titularidad'] = 's/d'
        if atributos['Funcionalidad'] is None:      atributos['Funcionalidad'] = 's/d'
        if atributos['Tipologia_DobleC'] is None:   atributos['Tipologia_DobleC'] =  's/d'
        if atributos['Tipologia_UnaC'] is None:     atributos['Tipologia_UnaC'] =  's/d'
        if atributos['Denominacion'] is None:       atributos['Denominacion'] =  's/d'
        if atributos['Long_Km'] is None:            atributos['Long_Km'] = 0
        if atributos['idOrdenCtra'] is None:        atributos['idOrdenCtra'] = 0
        if atributos['Origen'] is None:             atributos['Origen'] =  's/d'
        if atributos['Destino'] is None:            atributos['Destino'] =  's/d'
        if atributos['Provincia'] is None:          atributos['Provincia'] =  's/d'


        # Se analiza si existe el panel y si no se crea en PK_info_panelFlotante.py > PKInfoDockWidget
        if not self.PK_info:
            print ('No se localiza el panel -PK_info- y se crea')
            self.PK_info = PKInfoDockWidget(self.iface.mapCanvas(), self.iface, carretera_pk, tipo_consultaCAPA)
            self.PK_info.setFloating(True)  # Forzar modo flotante
            self.PK_info.move(100, 50)  # Establecer posición
            self.PK_info.show()
        else:
            try:
                # print(f"Estado del panel - Flotante: {self.PK_info.isFloating()}, Posición: {self.PK_info.pos()}")
                self.PK_info.setFloating(True)  # Forzar modo flotante
                self.PK_info.show()
            except:
                self.PK_info = PKInfoDockWidget(self.iface.mapCanvas(), self.iface, carretera_pk, tipo_consultaCAPA)
                self.PK_info.setFloating(True)  # Forzar modo flotante
                self.PK_info.move(100, 50)  # Establecer posición
                self.PK_info.show()

        # Preparamos los datos que pasamos al panel
        panel_data = {
            'Matricula_plan': ctraBUSQ,
            'pk_pinchado':  self.fun.mostrarPK(pkBUSC,2),
            'distEje':      str(round(carretera_pk[5],2)),
            'acimEje':      str(round(carretera_pk[6],4)),
            'cotaEje':      str(round(Zmdt,3)),
            'pk_placa':     str(int(pkBUSC)) + "+" + "{:0{}.{}f}".format( carretera_pk[11], 4+2, 2 ),
            'Titularidad':  atributos['Titularidad'],
            'Funcionalidad':atributos['Funcionalidad'],
            'Provincia':    MuniProv[1],
            'tmunicipal':   MuniProv[0],
            'Idmatricula':  f" (Idmat: {str(atributos['idMatricula'])})",
            'FuenteDatos':  FuenteDatos,
            'Denominacion': atributos['Denominacion'],
            'PkINI':        self.fun.mostrarPK(atributos['PkINI'],2),
            'PkFin':        self.fun.mostrarPK(atributos['PkFin'],2),
            'Origen':       atributos['Origen'],
            'Destino':      atributos['Destino'],
            'Longitud':     str(round(atributos['Longitud'],2)) + " m.",
            'Long_Km':      str(round(atributos['Long_Km'],3)) + " Km.",
            'Long_FIN_INI': f"{str(round((atributos['PkFin']-atributos['PkINI'])*1000,2))} m.",
            'Tipologia_DobleC': atributos['Tipologia_DobleC'],
            'Tipologia_UnaC':   atributos['Tipologia_UnaC'],
            'idOrdenCtra':  str(atributos['idOrdenCtra']),
            'DistINI':      str(round(carretera_pk[9],3)),
            'DistFIN':      str(round(carretera_pk[10],3)),
            'XE':           str(round(carretera_pk[7][0],2)),
            'YE':           str(round(carretera_pk[7][1],2)),
            'ZE':           str(round(Zmdt,3)),
            'XP':           str(round(point[0],2)),
            'YP':           str(round(point[1],2)),
            }
        # Se agrega el dato de la geometría real
        try:
            panel_data['Long_Geom'] = str(round(geometry.length(),2)) + " m."
        except:
            if atributos['Shape.STLength()'] is None:
                panel_data['Long_Geom'] = 0
            else:
                panel_data['Long_Geom'] = f"{str(round(atributos['Shape.STLength()'],2))} m."

        # ---------------  TODO ---------------------------------------------
        if tipo_consultaCAPA != 'url':
            # self.PK_info.pk_placa.hide()
            # self.PK_info.lbl_DistAplaca.hide()
            panel_data['pk_placa'] = 's/d'
        # ---------------  TODO ---------------------------------------------

        # Configurar datos en el panel
        if not self.PK_info.set_data(panel_data):
            print("Error: No se pudieron configurar todos los datos en el panel")
            return

        # Mostrar el panel
        self.PK_info.show()


    def on_pk_info_closed(self):
        """Método que se ejecuta al cerrar el panel"""
        print("Panel PK info cerrado")
        # Limpiar referencia
        if hasattr(self, 'PK_info'):
            self.PK_info = None

