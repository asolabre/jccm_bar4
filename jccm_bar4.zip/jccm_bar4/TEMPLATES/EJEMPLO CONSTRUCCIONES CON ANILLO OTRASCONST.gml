<?xml version="1.0" encoding="ISO-8859-1"?>
<gml:FeatureCollection gml:id="ES.LOCAL.BU"  xmlns:ad="urn:x-inspire:specification:gmlas:Addresses:3.0" xmlns:base="urn:x-inspire:specification:gmlas:BaseTypes:3.2" xmlns:bu-base="http://inspire.jrc.ec.europa.eu/schemas/bu-base/3.0" xmlns:bu-core2d="http://inspire.jrc.ec.europa.eu/schemas/bu-core2d/2.0" xmlns:bu-ext2d="http://inspire.jrc.ec.europa.eu/schemas/bu-ext2d/2.0" xmlns:cp="urn:x-inspire:specification:gmlas:CadastralParcels:3.0" xmlns:el-bas="http://inspire.jrc.ec.europa.eu/schemas/el-bas/2.0" xmlns:el-cov="http://inspire.jrc.ec.europa.eu/schemas/el-cov/2.0" xmlns:el-tin="http://inspire.jrc.ec.europa.eu/schemas/el-tin/2.0" xmlns:el-vec="http://inspire.jrc.ec.europa.eu/schemas/el-vec/2.0" xmlns:gco="http://www.isotc211.org/2005/gco" xmlns:gmd="http://www.isotc211.org/2005/gmd" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:gmlcov="http://www.opengis.net/gmlcov/1.0" xmlns:gn="urn:x-inspire:specification:gmlas:GeographicalNames:3.0" xmlns:gsr="http://www.isotc211.org/2005/gsr" xmlns:gss="http://www.isotc211.org/2005/gss" xmlns:gts="http://www.isotc211.org/2005/gts" xmlns:swe="http://www.opengis.net/swe/2.0" xmlns:xlink="http://www.w3.org/1999/xlink"  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://inspire.jrc.ec.europa.eu/schemas/bu-ext2d/2.0 http://inspire.ec.europa.eu/draft-schemas/bu-ext2d/2.0/BuildingExtended2D.xsd">

  <!--Building.   OFICINAS-->
  <gml:featureMember>
   <bu-ext2d:Building gml:id="ES.LOCAL.BU.002005100WH48A_OFICINAS"> 
    <bu-core2d:beginLifespanVersion>2026-06-20T00:00:00</bu-core2d:beginLifespanVersion> 
	<bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction> 
	<bu-core2d:inspireId> 
	 <base:Identifier> 
	  <base:localId>002005100WH48A_OFICINAS</base:localId> 
	  <base:namespace>ES.LOCAL.BU</base:namespace> 
	 </base:Identifier> 
	</bu-core2d:inspireId> 
	<bu-ext2d:geometry> 
	 <bu-core2d:BuildingGeometry> 
	  <bu-core2d:geometry> 
	   <gml:Surface gml:id="Surface_ES.LOCAL.BU.002005100WH48A_OFICINAS" srsName="urn:ogc:def:crs:EPSG::25830">
	    <gml:patches> 
		 <gml:PolygonPatch> 
		  <gml:exterior> 
		   <gml:LinearRing> 
		    <gml:posList>  <!--Geometria EXTERIOR en sentido de las agujas del reloj-->  
543784.197 4280639.429   
543785.653 4280639.360   
543785.660 4280639.458   
543785.718 4280639.356   
543796.041 4280638.698   
543795.945 4280637.101   
543799.939 4280636.865   
543799.339 4280628.285   
543791.348 4280628.716   
543791.445 4280632.790   
543783.764 4280633.436   
543784.197 4280639.429
            </gml:posList> 
		   </gml:LinearRing> 
		  </gml:exterior> 
		 </gml:PolygonPatch> 
		</gml:patches> 
	   </gml:Surface> 
	  </bu-core2d:geometry> 
	  <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy> 
	  <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference> 
	  <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry> 
	 </bu-core2d:BuildingGeometry> 
	</bu-ext2d:geometry> 
	<bu-ext2d:numberOfFloorsAboveGround>1</bu-ext2d:numberOfFloorsAboveGround> 
   </bu-ext2d:Building> 
  </gml:featureMember>

  <!--Building.   NAVE_O-->
  <gml:featureMember>
   <bu-ext2d:Building gml:id="ES.LOCAL.BU.002005100WH48A_NAVE_O"> 
    <bu-core2d:beginLifespanVersion>2026-06-20T00:00:00</bu-core2d:beginLifespanVersion> 
	<bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction> 
	<bu-core2d:inspireId> 
	 <base:Identifier> 
	  <base:localId>002005100WH48A_NAVE_O</base:localId> 
	  <base:namespace>ES.LOCAL.BU</base:namespace> 
	 </base:Identifier> 
	</bu-core2d:inspireId>
	<bu-ext2d:geometry> 
	 <bu-core2d:BuildingGeometry> 
	  <bu-core2d:geometry> 
	   <gml:Surface gml:id="Surface_ES.LOCAL.BU.002005100WH48A_NAVE_O" srsName="urn:ogc:def:crs:EPSG::25830">
	    <gml:patches> 
		 <gml:PolygonPatch> 
		  <gml:exterior> 
		   <gml:LinearRing> 
		    <gml:posList>  <!--Geometria EXTERIOR en sentido de las agujas del reloj-->  
543785.310 4280656.580   
543785.530 4280660.460   
543791.930 4280660.010   
543797.288 4280659.638   
543796.041 4280638.698   
543785.718 4280639.356   
543785.660 4280639.458   
543786.644 4280655.101   
543785.234 4280655.230   
543785.310 4280656.580
            </gml:posList> 
		   </gml:LinearRing> 
		  </gml:exterior> 
		 </gml:PolygonPatch> 
		</gml:patches> 
	   </gml:Surface> 
	  </bu-core2d:geometry> 
	  <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy> 
	  <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference> 
	  <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry> 
	 </bu-core2d:BuildingGeometry> 
	</bu-ext2d:geometry> 
	<bu-ext2d:numberOfFloorsAboveGround>1</bu-ext2d:numberOfFloorsAboveGround> 
   </bu-ext2d:Building> 
  </gml:featureMember>

  <!--Building.   NAVE_E-->
  <gml:featureMember>
   <bu-ext2d:Building gml:id="ES.LOCAL.BU.002005100WH48A_NAVE_E"> 
    <bu-core2d:beginLifespanVersion>2026-06-20T00:00:00</bu-core2d:beginLifespanVersion> 
	<bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction> 
	<bu-core2d:inspireId> 
	 <base:Identifier> 
	  <base:localId>002005100WH48A_NAVE_E</base:localId> 
	  <base:namespace>ES.LOCAL.BU</base:namespace> 
	 </base:Identifier> 
	</bu-core2d:inspireId> 
	<bu-ext2d:geometry> 
	 <bu-core2d:BuildingGeometry> 
	  <bu-core2d:geometry> 
	   <gml:Surface gml:id="Surface_ES.LOCAL.BU.002005100WH48A_NAVE_E" srsName="urn:ogc:def:crs:EPSG::25830">
	    <gml:patches> 
		 <gml:PolygonPatch> 
		  <gml:exterior> 
		   <gml:LinearRing> 
		    <gml:posList>  <!--Geometria EXTERIOR en sentido de las agujas del reloj--> 
543837.727 4280664.607   
543835.101 4280626.113   
543826.900 4280626.568   
543827.486 4280634.777   
543829.541 4280665.237   
543837.727 4280664.607
            </gml:posList> 
		   </gml:LinearRing> 
		  </gml:exterior>
          <gml:interior>
           <gml:LinearRing>
            <gml:posList>  <!--Geometria INTERIOR en sentido contrario de las agujas del reloj--> 
543831.001 4280652.066   
543830.521 4280646.439   
543833.974 4280646.215   
543834.422 4280651.906   
543831.001 4280652.066
            </gml:posList>
           </gml:LinearRing>
          </gml:interior>          
		 </gml:PolygonPatch> 
		</gml:patches> 
	   </gml:Surface> 
	  </bu-core2d:geometry> 
	  <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy> 
	  <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference> 
	  <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry> 
	 </bu-core2d:BuildingGeometry> 
	</bu-ext2d:geometry> 
	<bu-ext2d:numberOfFloorsAboveGround>1</bu-ext2d:numberOfFloorsAboveGround> 
   </bu-ext2d:Building> 
  </gml:featureMember>

  <!--Building.   TRANSFORMADOR-->
  <gml:featureMember>
   <bu-ext2d:Building gml:id="ES.LOCAL.BU.002005100WH48A_TRANSFORMADOR"> 
    <bu-core2d:beginLifespanVersion>2026-06-20T00:00:00</bu-core2d:beginLifespanVersion> 
	<bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction> 
	<bu-core2d:inspireId> 
	 <base:Identifier> 
	  <base:localId>002005100WH48A_TRANSFORMADOR</base:localId> 
	  <base:namespace>ES.LOCAL.BU</base:namespace> 
	 </base:Identifier> 
	</bu-core2d:inspireId> 
	<bu-ext2d:geometry> 
	 <bu-core2d:BuildingGeometry> 
	  <bu-core2d:geometry> 
	   <gml:Surface gml:id="Surface_ES.LOCAL.BU.002005100WH48A_TRANSFORMADOR" srsName="urn:ogc:def:crs:EPSG::25830">
	    <gml:patches> 
		 <gml:PolygonPatch> 
		  <gml:exterior> 
		   <gml:LinearRing> 
		    <gml:posList >  <!--Geometria EXTERIOR en sentido de las agujas del reloj--> 
543836.613 4280625.988   
543842.823 4280625.632   
543843.075 4280628.901   
543836.865 4280629.258   
543836.613 4280625.988
            </gml:posList> 
		   </gml:LinearRing> 
		  </gml:exterior> 
		 </gml:PolygonPatch> 
		</gml:patches> 
	   </gml:Surface> 
	  </bu-core2d:geometry> 
	  <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy> 
	  <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference> 
	  <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry> 
	 </bu-core2d:BuildingGeometry> 
	</bu-ext2d:geometry> 
	<bu-ext2d:numberOfFloorsAboveGround>1</bu-ext2d:numberOfFloorsAboveGround> 
   </bu-ext2d:Building> 
  </gml:featureMember>
  
  <!--OTHERCONSTRUCTION.Cumplimentar solo en el caso de incluir piscinas u otras construcciones no edificio--> 
  <gml:featureMember>
   <bu-ext2d:OtherConstruction gml:id="ES.SDGC.BU.002005100WH48A_PISCINA"> 
    <bu-core2d:beginLifespanVersion>2026-06-20T00:00:00</bu-core2d:beginLifespanVersion> 
    <bu-core2d:conditionOfConstruction xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:conditionOfConstruction> 
    <bu-core2d:inspireId> 
     <base:Identifier> 
      <base:localId>002005100WH48A_PISCINA</base:localId> 
      <base:namespace>ES.SDGC.BU</base:namespace>   <!--Parece irrelevante ES.SDGC.BU o ES.LOCAL.BU--> 
     </base:Identifier> 
    </bu-core2d:inspireId> 
    <bu-ext2d:constructionNature>openAirPool</bu-ext2d:constructionNature> 
    <bu-ext2d:geometry> 
     <gml:Polygon gml:id="Polygon_ES.SDGC.BU.002005100WH48A_PISCINA" srsName="urn:ogc:def:crs:EPSG::25830"> 
      <gml:exterior> 
       <gml:LinearRing> 
        <gml:posList>
543812.618 4280650.179
543818.628 4280649.924
543818.117 4280643.018
543812.618 4280642.762
543812.618 4280650.179        
        </gml:posList> 
       </gml:LinearRing> 
      </gml:exterior> 
     </gml:Polygon> 
    </bu-ext2d:geometry> 
   </bu-ext2d:OtherConstruction> 
  </gml:featureMember>

</gml:FeatureCollection>