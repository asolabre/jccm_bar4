<!DOCTYPE html>

    <head>
        <meta charset="utf-8">
        <title>$title</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Plugin JCCM Carreteras para QGIS 3+">
        <style>$style</style>

    </head>

    <body>

        <dl class="floated">
        <table WIDTH="800">
            <th WIDTH="50" style="text-align:center;">
                $icono
            </th>
            <th WIDTH="650" style="text-align:left;font-size:15px;">
                <dd>$title</dd>
                <dt>$dt_abstract</dt>
                <dd>$abstract  $date</dd>
                <dt>$dt_info</dt>
                <dd>$info</dd>
            </th>
            <th WIDTH="100" style="text-align:left;font-size:8px;">
                <dt>$Campo1</dt>
                <dd>$linea1</dd>
                <dt>$Campo2</dt>
                <dd>$linea2</dd>
                <dt>$Campo3</dt>
                <dd>$linea3</dd>
                <dt>$Campo4</dt>
                <dd>$linea4</dd>
                <dt>$Campo5</dt>
                <dd>$linea5</dd>
                <dt>$Campo6</dt>
                <dd>$linea6</dd>
            </th>
        </table>
        </dl>

        <div>
$tbody
        <span style="float:right;">$totalPages</span>
        </div>
    </body>
    
    <body>
        
        <table WIDTH="500">
            <th WIDTH="650" style="text-align:left;font-size:12px;">
                <dd>- LEYENDA -</dd>
                <dd>Se indican solo los registros con datos erroneos</dd>
                <dd>En caso de error en un atributo, éste aparecerá sombreado en ROJO</dd>
                <dd> </dd>
                <dd>COLUMNA 'idMatr'   - Indica si está repetido el 'idmatricula' del elemento, anotando el número de veces</dd>
                <dd>COLUMNA 'ErrDENOM' - Indica si existen carreteras con la misma MATRÍCULA y distinta DENOMINACION </dd>
                <dd>COLUMNA 'calib_sentido' - Detecta diferentes errores de la calibración del elemento (valor de PK de los vértices)</dd>
                <dd>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; FaltaM   - Indica que todos o algún vértice no tiene valor M (PK) </dd>
                <dd>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; SenInv   - Indica que algún vértice tiene valor M menor que el anterior (no creciente)</dd>
                <dd>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; TramInv  - Detecta que los tramos del elemento no están ordenados en sentido creciente </dd>
                <dd>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Inversion- Se detecta que todo el elemento está invertido (no creciente)</dd>
                <dd>COLUMNA 'long_PI_PF_KM' - Indica si hay errores en los atributos 'Longitud', 'PkINI', 'PkFIN', 'LongKM'</dd>
                <dd>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Longitud   - si es errónea devuelve la longitud real del elemento</dd>
                <dd>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; PkINI      - si es erróneo devuelve el PK más bajo del elemento</dd>
                <dd>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; PkFIN      - si es erróneo devuelve el PK más alto del elemento</dd>
                <dd>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LongKM     - si es errónea devuelve la diferencia PkFIN - PkINI</dd>
                <dd>COLUMNA 'iniNegat' - Detecta si el PkINI del elemento es negativo</dd>
                <dd>COLUMNA 'ErrPksCONT' - PK de tramos contiguos que se deben corregir</dd>
				<dd>COLUMNA 'FALTA_PK' - Indica la lista de PPKK ausentes del elemento</dd>
            </th>
        </table>
        <footer>$dt_date - $date</footer>

    </body>

</html>


