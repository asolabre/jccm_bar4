<?xml version="1.0" encoding="ISO-8859-1"?>
<gml:FeatureCollection gml:id="ES.LOCAL.BU"  xmlns:ad="urn:x-inspire:specification:gmlas:Addresses:3.0" xmlns:base="urn:x-inspire:specification:gmlas:BaseTypes:3.2" xmlns:bu-base="http://inspire.jrc.ec.europa.eu/schemas/bu-base/3.0" xmlns:bu-core2d="http://inspire.jrc.ec.europa.eu/schemas/bu-core2d/2.0" xmlns:bu-ext2d="http://inspire.jrc.ec.europa.eu/schemas/bu-ext2d/2.0" xmlns:cp="urn:x-inspire:specification:gmlas:CadastralParcels:3.0" xmlns:el-bas="http://inspire.jrc.ec.europa.eu/schemas/el-bas/2.0" xmlns:el-cov="http://inspire.jrc.ec.europa.eu/schemas/el-cov/2.0" xmlns:el-tin="http://inspire.jrc.ec.europa.eu/schemas/el-tin/2.0" xmlns:el-vec="http://inspire.jrc.ec.europa.eu/schemas/el-vec/2.0" xmlns:gco="http://www.isotc211.org/2005/gco" xmlns:gmd="http://www.isotc211.org/2005/gmd" xmlns:gml="http://www.opengis.net/gml/3.2" xmlns:gmlcov="http://www.opengis.net/gmlcov/1.0" xmlns:gn="urn:x-inspire:specification:gmlas:GeographicalNames:3.0" xmlns:gsr="http://www.isotc211.org/2005/gsr" xmlns:gss="http://www.isotc211.org/2005/gss" xmlns:gts="http://www.isotc211.org/2005/gts" xmlns:swe="http://www.opengis.net/swe/2.0" xmlns:xlink="http://www.w3.org/1999/xlink"  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://inspire.jrc.ec.europa.eu/schemas/bu-ext2d/2.0 http://inspire.ec.europa.eu/draft-schemas/bu-ext2d/2.0/BuildingExtended2D.xsd">
  <gml:featureMember>
    <bu-ext2d:Building gml:id="ES.LOCAL.BU.02055A02209024">
    <gml:boundedBy>
      <gml:Envelope srsName="urn:ogc:def:crs:EPSG::25830">
         <gml:lowerCorner>560153.30 4222417.50</gml:lowerCorner>
         560153.3,4222417.5 : 560172.9,4222436.2
         <gml:upperCorner>560172.9 4222436.2</gml:upperCorner>
      </gml:Envelope>
    </gml:boundedBy>
      <bu-core2d:beginLifespanVersion></bu-core2d:beginLifespanVersion>
      <bu-core2d:conditionOfConstruction>functional</bu-core2d:conditionOfConstruction>
      <bu-core2d:dateOfConstruction>
        <bu-core2d:DateOfEvent>
          <bu-core2d:beginning></bu-core2d:beginning>
          <bu-core2d:end></bu-core2d:end>
        </bu-core2d:DateOfEvent>
      </bu-core2d:dateOfConstruction>
      <bu-core2d:endLifespanVersion xsi:nil="true" nilReason="other:unpopulated"></bu-core2d:endLifespanVersion>
      <bu-core2d:externalReference>
        <bu-core2d:ExternalReference>
          <bu-core2d:informationSystem></bu-core2d:informationSystem>
          <bu-core2d:informationSystemName></bu-core2d:informationSystemName>
          <bu-core2d:reference>02055A02209024</bu-core2d:reference>
        </bu-core2d:ExternalReference>
      </bu-core2d:externalReference>
      <bu-core2d:inspireId>
        <base:Identifier>
          <base:localId>02055A02209024_PL.1</base:localId>
          <base:namespace>ES.SDGC.BU</base:namespace>
        </base:Identifier>
      </bu-core2d:inspireId>
      <bu-ext2d:geometry>
       <bu-core2d:BuildingGeometry>
        <bu-core2d:geometry>
         <gml:Surface gml:id="Surface_ES.LOCAL.BU.02055A02209024" srsName="urn:ogc:def:crs:EPSG::25830">
           <gml:patches>
                <gml:PolygonPatch>
                <gml:exterior>
                    <gml:LinearRing>
                      <gml:posList srsDimension="2" count="5">
560153.79 4222423.34   
560158.42 4222435.55   
560172.44 4222430.39   
560167.82 4222418.18   
560153.79 4222423.34
                      </gml:posList>
                    </gml:LinearRing>
                </gml:exterior>
                </gml:PolygonPatch>
              </gml:patches>
            </gml:Surface>
        </bu-core2d:geometry>
          <bu-core2d:horizontalGeometryEstimatedAccuracy uom="m">0.1</bu-core2d:horizontalGeometryEstimatedAccuracy>
          <bu-core2d:horizontalGeometryReference>footPrint</bu-core2d:horizontalGeometryReference>
          <bu-core2d:referenceGeometry>true</bu-core2d:referenceGeometry>
       </bu-core2d:BuildingGeometry>
      </bu-ext2d:geometry>
        <bu-ext2d:currentUse></bu-ext2d:currentUse>
      <bu-ext2d:numberOfBuildingUnits>1</bu-ext2d:numberOfBuildingUnits>
      <bu-ext2d:numberOfDwellings>0</bu-ext2d:numberOfDwellings>
      <bu-ext2d:numberOfFloorsAboveGround>1</bu-ext2d:numberOfFloorsAboveGround>
      <bu-ext2d:document>
         <bu-ext2d:Document>
          <bu-ext2d:documentLink></bu-ext2d:documentLink>
          <bu-ext2d:format></bu-ext2d:format>
          <bu-ext2d:sourceStatus>NotOfficial</bu-ext2d:sourceStatus>
         </bu-ext2d:Document>
      </bu-ext2d:document>
      <bu-ext2d:officialArea>
         <bu-ext2d:OfficialArea>
          <bu-ext2d:officialAreaReference>grossFloorArea</bu-ext2d:officialAreaReference>
          <bu-ext2d:value uom="m2">195</bu-ext2d:value>
         </bu-ext2d:OfficialArea>
      </bu-ext2d:officialArea>
    </bu-ext2d:Building>
  </gml:featureMember>
</gml:FeatureCollection>
