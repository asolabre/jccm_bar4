# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:               puntoZ.py
Purpose:            Tools for plugin catastroesp

                                 A QGIS4 plugin

        --------------------------------------------------------------------
        begin                : 2019-09-11
        validacion transfQG4 : 2026-10-22
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtCore import Qt, QSize
from qgis.PyQt.QtWidgets import (QApplication, QTextEdit, QDockWidget, 
                                QVBoxLayout, QWidget, QLabel)
from qgis.PyQt.QtGui import QCursor, QIcon, QGuiApplication
from qgis.PyQt.QtCore import QRect

from qgis.gui import QgsMapTool, QgsDialog

import os

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

current_configuration = configuration()


# VARIABLES
srcVal = current_configuration.general["EPSG"]

class puntoZ(QgsMapTool):
    def __init__(self,canvas, iface, action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas    
        self.fun = Functions()
        
        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))
        
        cursor = QCursor()
        cursor.setShape(Qt.CursorShape.CrossCursor)
        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action
        
        # Inicializar el panel como None
        self.dock = None
        
        # Crear el panel de resultados
        self.create_results_panel()

    def create_results_panel(self):
        """Crea el panel de resultados flotante si no existe"""
        # Verificar si el panel ya existe
        if self.dock is None:
            # Crear el widget dockable
            self.dock = QDockWidget("Datos del Punto", self.iface.mainWindow())
            self.dock.setObjectName("puntoZ_panel")
            # self.dock.setAllowedAreas(Qt.DockWidgetArea)  # No permitir docking inicialmente
            
            # Crear widget contenido
            self.panel_widget = QWidget()
            self.layout = QVBoxLayout()
            
            # Añadir título
            self.title_label = QLabel("DATOS DEL PUNTO")
            self.title_label.setStyleSheet("font-weight: bold; font-size: 14px;")
            self.layout.addWidget(self.title_label)
            
            # Área de texto para mostrar resultados
            self.text_edit = QTextEdit()
            self.text_edit.setReadOnly(True)
            self.layout.addWidget(self.text_edit)
            
            # Establecer tamaño inicial del QDockWidget
            self.dock.setMinimumSize(QSize(350, 300))
            
            # Mensaje inicial
            txtINSTRUCCIONES = "PUEDE DESPLAZAR ESTE PANEL A OTRO PUNTO DE LA PANTALLA"
            txtINSTRUCCIONES += "\n\nHaga clic en el mapa para obtener datos del punto..."
            self.text_edit.setText(txtINSTRUCCIONES )
            
            # Configurar layout
            self.panel_widget.setLayout(self.layout)
            self.dock.setWidget(self.panel_widget)
            
            # Icono del panel
            self.dock.setWindowIcon(QIcon(f':/plugins/{self.nombre_plugin}/iconos/Z_icon.jpg'))
            
            # Configurar como flotante
            self.dock.setFloating(True)  # Hacerlo flotante
            # self.dock.setFeatures(QDockWidget.DockWidgetClosable | QDockWidget.DockWidgetMovable)
            self.dock.setFeatures( QDockWidget.DockWidgetFeature.DockWidgetClosable | QDockWidget.DockWidgetFeature.DockWidgetMovable )
            
            # Posicionar en esquina superior derecha
            # screen_geometry = QApplication.desktop().availableGeometry()
            screen = QGuiApplication.primaryScreen()
            screen_geometry = screen.availableGeometry() if screen else None
            
            dock_width = 350
            dock_height = 300
            x_pos = screen_geometry.width() - dock_width - 50  # 50px de margen
            y_pos = 50  # 50px desde el borde superior
            
            self.dock.setGeometry(x_pos, y_pos, dock_width, dock_height)
            
            # Mostrar el panel (no lo añadimos como dock widget todavía)
            self.dock.show()
        else:
            # Si el panel ya existe, simplemente lo mostramos
            self.dock.setFloating(True)
            self.dock.show()
    
    def update_results_panel(self, point, Zmdt, Result):
        """Actualiza el panel con los nuevos datos con formato de colores"""
        # Definimos estilos CSS para los diferentes elementos
        estilo_titulo = "color: #2c3e50; font-weight: bold;"
        estilo_valor = "color: #1039b6;"                            # Color AZUL
        estilo_error = "color: #e74c3c;"
        estilo_subtitulo = "color: #7f8c8d; font-style: italic;; font-size: small"
        # estilo_instrucciones = "color: #fb0408; font-size: small;"  # Color ROJO
        estilo_instrucciones = "color: #fb0408;"                    # Color ROJO
        
        if Zmdt == 'Error':
            elevacion = f'<span style="{estilo_error}">SIN DATOS</span>'
        else:
            elevacion = f'<span style="{estilo_valor}">{Zmdt:.3f}</span>'
        
        # Construimos el contenido HTML con estilos
        # <p style="{estilo_titulo}">Elevación: {elevacion}</p><p style="{estilo_subtitulo}">    (Modelo Digital del Terreno IGN 5 m.)</p>

        html_content = f"""
        <div style="font-family: Arial; font-size: 11pt;">
            <p style="{estilo_titulo}">Elevación: {elevacion}<style="{estilo_subtitulo}">    (Modelo Digital del Terreno IGN 5 m.)</p>
            
            <p style="{estilo_titulo}">X: <span style="{estilo_valor}">{point[0]:.3f}</span></p>
            <p style="{estilo_titulo}">Y: <span style="{estilo_valor}">{point[1]:.3f}</span></p>
            <p style="{estilo_subtitulo}">(UTM30-ETRS89)</p>
            
            <p style="{estilo_titulo}">Provincia: <span style="{estilo_valor}">{Result[1]}</span></p>
            <p style="{estilo_titulo}">Municipio: <span style="{estilo_valor}">{Result[0]}</span></p>
            <p style="{estilo_subtitulo}">FUENTE: {Result[7]}</p>
            
            <p style="{estilo_instrucciones}">Haga clic en el mapa para obtener datos del nuevo punto...</p>
        </div>
        """
        
        # Configuramos el QTextEdit para aceptar HTML
        self.text_edit.setHtml(html_content)


    def canvasReleaseEvent(self, event):
        """Evento al hacer click en el mapa"""
        x = event.pos().x()
        y = event.pos().y()
        
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
        Zmdt = self.fun.Zmdt(point, self.iface, pintar='NO')

        ResultMuniProv = self.fun.getUNIADMINMuniProv_WMS(point, self.iface, pintar='NO')
        
        self.update_results_panel(point, Zmdt, ResultMuniProv)
        QApplication.restoreOverrideCursor()
    
    def deactivate(self):
        """Se ejecuta al desactivar la herramienta"""
        # No hacemos nada con el panel al desactivar
        self.dock = None
        super().deactivate()
