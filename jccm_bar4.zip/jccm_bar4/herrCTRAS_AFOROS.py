# -*- coding: utf-8 -*-
"""
/***************************************************************************
 herrCTRAS_AFOROS.py
                                 A QGIS4 plugin
Plugin:     jccm_bar4
Purpose:    Carga capas de aforos
                             -------------------
        begin                : 2025-02-18
        git sha              : $Format:%H$
        copyright            : (C) 2025 by AGUSTÍN SOLABRE
        email                : asolabre@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.
 *
 *   Based in 'Quick Export' pluggin
 *                                                                         *
 ***************************************************************************/
"""

# from PyQt5.QtGui import QIcon, QPixmap
from qgis.PyQt.QtGui import (QIcon, QPixmap,
                            QFont, QColor, QPainter, QPainterPath, QFontMetrics)
# from PyQt5.QtCore import QSettings, QCoreApplication, QTranslator, qVersion, Qt
from qgis.PyQt.QtCore import (QSettings, QCoreApplication, QTranslator, qVersion, Qt,
                            QPoint, QRectF)
# from PyQt5.QtWidgets import (QApplication, QMessageBox, QToolButton, QMenu, QAction, QDialog, QCheckBox,
                        # QFileDialog, QComboBox)
from qgis.PyQt.QtWidgets import (QApplication, QMessageBox, QToolButton, QMenu, QAction, QDialog, QCheckBox,
                            QFileDialog, QComboBox)
from qgis.PyQt import uic

from qgis.gui import QgsMessageBar, QgsMapCanvasItem, QgsMapCanvas
from qgis.core import (QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsApplication, QgsFeature,
                        QgsGeometry, QgsVectorFileWriter, QgsLayerTreeGroup, QgsLayerTreeLayer, QgsRectangle,
                        QgsLayerDefinition, QgsExpressionContextUtils)
from qgis.utils import iface
from qgis.PyQt.QtPrintSupport import QPrinter

from datetime import datetime
from osgeo import ogr, osr
from time import sleep
from functools import partial

import os
import urllib
import json
import timeit
import io
import subprocess

from .jccm_bar_config_RT import jccm_bar_config

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .settings import Settings           # CLASE DE CONFIGURACIÓN DE VARIABLES GLOBALES

# from .functions4 import EtiquetaFija
current_configuration = configuration()

# VARIABLES
srcVal = current_configuration.general["EPSG"]

current_configuration = configuration()

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrCTRAS_AFOROS.ui'))


class herrCTRAS_AFOROS(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(herrCTRAS_AFOROS, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface;
        # Inicializa variables globales
        self.config = configuration()
        self.qs = QSettings()
        self.fun = Functions()

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        self.logo.setPixmap(QPixmap(f':/plugins/jccm_bar4/iconos/jccm.jpg'))
        self.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/jccm_aforos.jpg'))
 
        ###     VARIABLES    ###
        # file_AFOROS = 'u:/Aforos_Trafico/JCCM_DATOS_AFOROS.qlr'
        file_AFOROS = self.qs.value(f"{self.nombre_plugin}/AFOROS/file_AFOROS")
        if file_AFOROS is None:
            file_AFOROS = self.config.AFOROS["file_AFOROS"]
            self.qs.setValue(f"{self.nombre_plugin}/AFOROS/file_AFOROS", file_AFOROS)
        self.lne_file_AFOROS.setText(file_AFOROS)
        file_AFOROS = file_AFOROS
        
        self.capas_necesarias = ['AFOROS_ESTACIONES', 'AFOROS_TRAMIFICACION']

        self.cbx_NOZOOM.clicked.connect(self.cambiaNOZOOM)

        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)
        self.progressBar.setValue(0)
        self.lblINFO.setText('INFO:')

        # Colocar la lista de años en el comboBox
        año_actual = datetime.now().year
        self.cbxANO.clear()
        for año in range(2000, año_actual):
            self.cbxANO.addItem(str(año))
        self.cbxANO.setCurrentIndex(self.cbxANO.count()-1)

        self.btn_CARGAR.setText('CARGAR CAPAS')

        if self.comprobarGrupoAFOROS():
            self.btn_CARGAR.setText('MODIFICAR CAPAS')
            self.cbx_NOZOOM.setChecked(True)
            self.lblPROVINCIA.setEnabled(False)
            self.cbxPROVINCIA.setEnabled(False)

        self.lne_file_AFOROS.setText(file_AFOROS)
        self.tbt_file_AFOROS.clicked.connect(self.salida_file_grupoAforos_click)
        # self.tbt_carpeta_estilos.clicked.connect(self.salida_file_click)

        self.btn_ConfigAFOROS.setVisible(False)     ### TODO. QUITAR CONFIG
        # self.btn_ConfigAFOROS.clicked.connect(self.tbtConfigAFOROS_press

        # Función lista combo en una línea
        get_combo_items = lambda combo: [combo.itemText(i) for i in range(combo.count())]

        lista_ANO = get_combo_items(self.cbxANO)
        lastAforosAno = self.qs.value(f"{self.nombre_plugin}/last/lastAforosAno")
        if lastAforosAno in lista_ANO:
            self.cbxANO.setCurrentIndex(lista_ANO.index(lastAforosAno))

        lista_PROV = get_combo_items(self.cbxPROVINCIA)
        lastAforosProv = self.qs.value(f"{self.nombre_plugin}/last/lastAforosProv")
        if lastAforosProv in lista_PROV:
            self.cbxPROVINCIA.setCurrentIndex(lista_PROV.index(lastAforosProv))

        self.btn_VERPDFmapa.clicked.connect(self.verMapaPDF)
        self.btn_VERPDFinformes.clicked.connect(self.verInformePDF)
        self.btn_VERPDFdosier.clicked.connect(self.verDosierPDF)
        self.btn_VERcarpeta.clicked.connect(self.verCarpeta)
        
        self.btn_CARGAR.clicked.connect(self.CargaCapas)
        self.btn_DESCARGAR.clicked.connect(self.DescargaCapas)
        

    def cambiaNOZOOM(self):
        if self.cbx_NOZOOM.isChecked():
            self.lblPROVINCIA.setEnabled(False)
            self.cbxPROVINCIA.setEnabled(False)
        else:
            self.lblPROVINCIA.setEnabled(True)
            self.cbxPROVINCIA.setEnabled(True)
        pass


    def CargaCapas(self):
        # Tomamos los valores del menú
        fichGrupoAFOROS = self.lne_file_AFOROS.text()
        AFORO = self.cbxANO.currentText()
        prov = self.cbxPROVINCIA.currentText()

        self.qs.setValue(f"{self.nombre_plugin}/last/lastAforosAno", self.cbxANO.currentText())
        self.qs.setValue(f"{self.nombre_plugin}/last/lastAforosProv", self.cbxPROVINCIA.currentText())

        # Cargar el grupo de capas desde el archivo .qlr
        nomGRUPO = 'AFOROS'
        root = QgsProject.instance().layerTreeRoot()
        grupo = root.findGroup(nomGRUPO)

        if not grupo:
            if os.path.exists(fichGrupoAFOROS): # Existen el fichero de grupo de capas de aforos 'fichGrupoAFOROS'
                result=QgsLayerDefinition().loadLayerDefinition(fichGrupoAFOROS, QgsProject.instance(), root)
                if result[0]==False:
                    QgsMessageLog.logMessage( "Fallo al cargar el grupo: " + nomGRUPO)
            else:
                text =f'No existe el fichero de Grupo de Capas de AFOROS'
                text += f'\n\n     {fichGrupoAFOROS}'
                self.fun.showMessageERR(text)
                return                

        # Comprobar que el grupo contiene las capas necesarias
        for capa_nombre in self.capas_necesarias:
            capa = QgsProject.instance().mapLayersByName(capa_nombre)
            if not capa:
                self.DescargaCapas()
                text = f'La capa {capa_nombre} no se encuentra en el grupo AFOROS.'
                self.fun.showMessageERR(text)
                return
            # Verificar que la capa sea válida
            for capa0 in capa:
                if not capa0.isValid():
                    self.DescargaCapas()
                    text = f'La capa {capa_nombre} no es válida.'
                    self.fun.showMessageERR(text)
                    return

        # Comprobar que las capas contienen los campos necesarios
        campos_necesarios = [f'{AFORO}_IMD', f'{AFORO}_PORCP']
        for capa_nombre in self.capas_necesarias:
            capa = QgsProject.instance().mapLayersByName(capa_nombre)[0]
            campos = [field.name() for field in capa.fields()]
            for campo in campos_necesarios:
                if campo not in campos:
                    self.DescargaCapas()
                    text =f'El campo {campo} no se encuentra en la capa {capa_nombre}.'
                    self.fun.showMessageERR(text)
                    return

        # Comprobar y establecer la variable de capa 'AFORO'
        for capa_nombre in self.capas_necesarias:
            capas = QgsProject.instance().mapLayersByName(capa_nombre)
            if not capas:
                continue
            capa = capas[0]

            # Borrar la propiedad 'AFORO' si existe
            if capa.customProperty('AFORO') is not None:
                capa.removeCustomProperty('AFORO')

        # Asignar la variable 'AFORO' a las capas para que sea accesible en expresiones
        for capa_nombre in self.capas_necesarias:
            # Verificar si la capa existe en el proyecto
            capa = QgsProject.instance().mapLayersByName(capa_nombre)[0]  # Tomamos la primera capa encontrada con ese nombre

            # Asignar la variable 'AFORO' a la capa para que sea accesible en expresiones
            QgsExpressionContextUtils.setLayerVariable(capa, 'AFORO', AFORO)

        # Comprobar que hay datos en las estaciones de cada año
        for capa_nombre in self.capas_necesarias:
            capa = QgsProject.instance().mapLayersByName(capa_nombre)[0]
            if capa.featureCount() == 0:
                text =f'No hay datos en la capa {capa_nombre} para el año {AFORO}.'
                self.fun.showMessageERR(text)
                return

        # Mover el grupo sobre la primera capa raster
        # self.moverGrupoArribaDePrimerRasterOWMS(nomGRUPO) #### TODO, NO FUNCIONA. ver si se cargan sobre el primer raster
        self.moverGrupoArribaALT(nomGRUPO)

        if not self.cbx_NOZOOM.isChecked():
            # Hacer zoom a la provincia conforme al bounding box especificado en listMarc
            listMarc = {
                    'CASTILLA LA MANCHA - CM': [25830, 192000, 4209000, 784500, 4576000],
                    'ALBACETE - AB':            [25830, 505872, 4202584, 685531, 4370727],
                    'CIUDAD REAL - CR':         [25830, 311168, 4241505, 542660, 4385049],
                    'CUENCA - CU':              [25830, 436896, 4337604, 707436, 4505361],
                    'GUADALAJARA - GU':         [25830, 428872, 4441654, 649725, 4578601],
                    'TOLEDO - TO':              [25830, 289007, 4335563, 513324, 4474658]
                    }
            if prov in listMarc:
                marc = listMarc[prov]
                rectangle = QgsRectangle(marc[1],marc[2],marc[3],marc[4])
                self.iface.mapCanvas().zoomToFeatureExtent(rectangle)
                self.iface.mapCanvas().refresh()

            else:
                text =f'El código de provincia {prov} no es válido.'
                self.fun.showMessageERR(text)
                return
        else:
            self.iface.mapCanvas().refresh()

        self.eliminarEtiquetasAFORO()   # Eliminamos todas las etiquetas
        self.ponerEtiquetaAFORO(AFORO)  # Colocamos una etiqueta con el año del aforo
        self.iface.mapCanvas().refresh()
        self.close()


    def comprobarGrupoAFOROS(self):
        # Comprobar si existe el grupo 'AFOROS'
        # DEVUELVE, False, si el grupo NO EXISTE
        # DEVUELVE, True , si el grupo EXISTE

        nomGRUPO = 'AFOROS'
        root = QgsProject.instance().layerTreeRoot()
        grupo = root.findGroup(nomGRUPO)

        if not grupo:
            return (False)

        # Comprobar que el grupo contiene las capas necesarias
        for capa_nombre in self.capas_necesarias:
            capa = QgsProject.instance().mapLayersByName(capa_nombre)
            if not capa:
                text =f'La capa {capa_nombre} no se encuentra en el grupo AFOROS.'
                self.fun.showMessageERR(text)
                return (False)
            else:
                AFORO = QgsExpressionContextUtils.layerScope(capa[0]).variable('AFORO')
                print (f'Detectado valor de aforo: {AFORO}')
                # Buscar el índice del valor en el combo
                index = self.cbxANO.findText(str(AFORO))
                # Si el valor existe en el combo, seleccionarlo
                if index != -1:
                    self.cbxANO.setCurrentIndex(index)
                else:
                    self.cbxANO.setCurrentIndex(self.cbxANO.count()-1)

        return (True)


    def moverGrupoArribaDePrimerRasterOWMS_ant(self, nomGRUPO):
        # Obtener la raíz del árbol de capas
        root = QgsProject.instance().layerTreeRoot()

        # Buscar el grupo 'AFOROS'
        grupo_aforos = root.findGroup(nomGRUPO)

        # Si el grupo no existe, salir
        if not grupo_aforos:
            print(f'El grupo {nomGRUPO} no existe.')
            return

        # Buscar la primera capa ráster, WMS o WMTS en el árbol de capas
        primera_capa = None
        for layer in root.children():
            if isinstance(layer, QgsLayerTreeLayer):
                # Obtener la capa subyacente
                qgis_layer = layer.layer()
                print(f"Procesando capa: {qgis_layer.name()} | Tipo: {qgis_layer.type()} | Proveedor: {qgis_layer.providerType()}")

                # Verificar si es una capa ráster
                if qgis_layer.type() == QgsMapLayer.RasterLayer:
                    print(f"Capa ráster detectada: {qgis_layer.name()}")
                    primera_capa = layer
                    break

                # Verificar si es una capa WMS o WMTS
                provider_type = qgis_layer.providerType().lower() if qgis_layer.providerType() else ""
                if provider_type in ('wms', 'wmts'):
                    print(f"Capa WMS/WMTS detectada: {qgis_layer.name()}")
                    primera_capa = layer
                    break

        # Si no se encuentra ninguna capa válida, salir
        if not primera_capa:
            print("No se encontró ninguna capa ráster, WMS o WMTS.")
            return

        # Mover el grupo 'AFOROS' por encima de la primera capa encontrada
        print(f"Moviendo el grupo 'AFOROS' por encima de la capa: {primera_capa.layer().name()}")
        root.insertChildNode(root.indexOfChild(primera_capa), grupo_aforos.clone())
        root.removeChildNode(grupo_aforos)


    def moverGrupoArribaALT(self, nomGRUPO):
        # Ponemos el grupo arriba (1)
        root = QgsProject.instance().layerTreeRoot()
        myGrp = root.findGroup(nomGRUPO)
        parent = myGrp.parent()
        myGrpclone = myGrp.clone()
        root.insertChildNode(0, myGrpclone)
        try:
            parent.removeChildNode(myGrp)
        except:
            print ('parent - ', parent.name(), type(parent), '   IMPOSIBLE BORRAR')


    def moverGrupoArribaDePrimerRasterOWMS(self, nomGRUPO):
        ### TODO - ESTO NO FUNCIONA ###

        # Obtener la raíz del árbol de capas
        root = QgsProject.instance().layerTreeRoot()

        # Buscar el grupo 'AFOROS'
        grupo_aforos = root.findGroup(nomGRUPO)

        # Si el grupo no existe, salir
        if not grupo_aforos:
            print(f'El grupo {nomGRUPO} no existe.')
            return

        # Buscar la primera capa válida (ráster, WMS o WMTS) en todo el árbol de capas
        primera_capa = self.buscarPrimeraCapaValida(root)

        # Si no se encuentra ninguna capa válida, salir
        if not primera_capa:
            print("No se encontró ninguna capa ráster, WMS o WMTS.")
            return

        # Mover el grupo 'AFOROS' por encima de la primera capa encontrada
        print(f"Moviendo el grupo 'AFOROS' por encima de la capa: {primera_capa.layer().name()}")
        root.insertChildNode(root.indexOfChild(primera_capa), grupo_aforos.clone())
        root.removeChildNode(grupo_aforos)

    def buscarPrimeraCapaValida(self, node):
        ### TODO - ESTO NO FUNCIONA ###

        """
        Función recursiva para buscar la primera capa válida (ráster, WMS o WMTS) en el árbol de capas.
        """
        for child in node.children():
            if isinstance(child, QgsLayerTreeLayer):
                # Obtener la capa subyacente
                qgis_layer = child.layer()
                print(f"Procesando capa: {qgis_layer.name()} | Tipo: {qgis_layer.type()} | Proveedor: {qgis_layer.providerType()}")

                # Verificar si es una capa ráster
                if qgis_layer.type() == QgsMapLayer.RasterLayer:
                    print(f"Capa ráster detectada: {qgis_layer.name()}")
                    return child

                # Verificar si es una capa WMS o WMTS
                provider_type = qgis_layer.providerType().lower() if qgis_layer.providerType() else ""
                if provider_type in ('wms', 'wmts'):
                    print(f"Capa WMS/WMTS detectada: {qgis_layer.name()}")
                    return child

            elif isinstance(child, QgsLayerTreeGroup):
                # Si es un grupo, buscar recursivamente en sus hijos
                resultado = self.buscarPrimeraCapaValida(child)
                if resultado:
                    return resultado

        # Si no se encuentra ninguna capa válida, retornar None
        return None


    def salida_file_grupoAforos_click(self):
        dirFile = self.lne_file_AFOROS.text()
        ext = "*.qlr"
        filename, tipofile = QFileDialog.getOpenFileName(self, "Fichero GML de salida", dirFile, ext)
        if filename != None and filename != "":
            self.lne_file_AFOROS.setText(filename)
        else:
            filename = dirFile
            self.lne_file_AFOROS.setText(filename)


    def tbtConfigAFOROS_press(self):
        ### TODO. QUITAR CONFIG
        self.fun.showWorkin()
        return


    def verMapaPDF(self):
        # Obtener el año y la provincia desde los combobox
        AFORO = self.cbxANO.currentText()
        prov = self.cbxPROVINCIA.currentText()
        fichGrupoAFOROS = self.lne_file_AFOROS.text()

        self.qs.setValue(f"{self.nombre_plugin}/last/lastAforosAno", self.cbxANO.currentText())
        self.qs.setValue(f"{self.nombre_plugin}/last/lastAforosProv", self.cbxPROVINCIA.currentText())

        # Obtener la ruta general de los aforos a partir del archivo QLR
        dirGralAFOROS = os.path.dirname(fichGrupoAFOROS)  # Extrae 'u:/Aforos_Trafico/'
        
        # Modificar el nombre de la provincia para que coincida con el formato del archivo PDF
        provMOD = prov.split(' - ')[0].title()  # Ej: 'ALBACETE - AB' -> 'Albacete'
        if prov == 'CASTILLA LA MANCHA - CM':
            provMOD = 'CLM'
        
        # Construir la ruta completa del archivo PDF
        dirAFOROS = os.path.join(dirGralAFOROS, f'Datos_{AFORO}')
        mapaAFOROS = os.path.join(dirAFOROS, 'Planos', f'{provMOD}_{AFORO}.pdf')
        
        # Verificar si el archivo PDF existe
        if os.path.exists(mapaAFOROS):
            try:
                # Abrir el archivo PDF con el programa predeterminado del sistema operativo
                if os.name == 'nt':  # Windows
                    self.close()
                    os.startfile(mapaAFOROS)
                elif os.name == 'posix':  # macOS o Linux
                    self.close()
                    subprocess.run(['open', mapaAFOROS] if os.uname().sysname == 'Darwin' else ['xdg-open', mapaAFOROS])
                else:
                    txt = "Sistema operativo no soportado."
                    self.fun.showMessageERR(txt)
            except Exception as e:
                txt = f"Error al intentar abrir el archivo PDF: {e}"
                self.fun.showMessageERR(txt)
        else:
            txt = f"El archivo PDF no existe en la ruta especificada: \n\n{mapaAFOROS}"
            self.fun.showMessageERR(txt)


    def verInformePDF(self):
        # Obtener el año y la provincia desde los combobox
        AFORO = self.cbxANO.currentText()
        prov = self.cbxPROVINCIA.currentText()
        fichGrupoAFOROS = self.lne_file_AFOROS.text()

        self.qs.setValue(f"{self.nombre_plugin}/last/lastAforosAno", self.cbxANO.currentText())
        self.qs.setValue(f"{self.nombre_plugin}/last/lastAforosProv", self.cbxPROVINCIA.currentText())

        # Obtener la ruta general de los aforos a partir del archivo QLR
        dirGralAFOROS = os.path.dirname(fichGrupoAFOROS)  # Extrae 'u:/Aforos_Trafico/'
        
        # Modificar el nombre de la provincia para que coincida con el formato del archivo PDF
        provMOD = prov.split(' - ')[0].title()  # Ej: 'ALBACETE - AB' -> 'Albacete'
        if prov == 'CASTILLA LA MANCHA - CM':
            provMOD = 'CLM'
        
        # Construir la ruta completa del archivo PDF
        dirAFOROS = os.path.join(dirGralAFOROS, f'Datos_{AFORO}')
        mapaAFOROS = os.path.join(dirAFOROS, 'Informes', f'{provMOD}_IMD_{AFORO}T.pdf')   # EJ: Albacete_IMD_2023T.pdf
        
        # Verificar si el archivo PDF existe
        if os.path.exists(mapaAFOROS):
            try:
                # Abrir el archivo PDF con el programa predeterminado del sistema operativo
                if os.name == 'nt':  # Windows
                    self.close()
                    os.startfile(mapaAFOROS)
                elif os.name == 'posix':  # macOS o Linux
                    self.close()
                    subprocess.run(['open', mapaAFOROS] if os.uname().sysname == 'Darwin' else ['xdg-open', mapaAFOROS])
                else:
                    txt = "Sistema operativo no soportado."
                    self.fun.showMessageERR(txt)
            except Exception as e:
                txt = f"Error al intentar abrir el INFORME PDF: {e}"
                self.fun.showMessageERR(txt)
        else:
            txt = f"El archivo PDF no existe en la ruta especificada: \n\n{mapaAFOROS}"
            self.fun.showMessageERR(txt)

            
    def verCarpeta(self):
        
        self.qs.setValue(f"{self.nombre_plugin}/last/lastAforosAno", self.cbxANO.currentText())
        self.qs.setValue(f"{self.nombre_plugin}/last/lastAforosProv", self.cbxPROVINCIA.currentText())

        pass
    
            
    def verDosierPDF(self):
        # Obtener el año y la provincia desde los combobox
        AFORO = self.cbxANO.currentText()
        fichGrupoAFOROS = self.lne_file_AFOROS.text()

        # Obtener la ruta general de los aforos a partir del archivo QLR
        dirGralAFOROS = os.path.dirname(fichGrupoAFOROS)  # Extrae 'u:/Aforos_Trafico/'
        
        # Construir la ruta completa del archivo PDF
        dirAFOROS = os.path.join(dirGralAFOROS, f'Datos_{AFORO}')
        dossierAFOROS = os.path.join(dirAFOROS, 'Dossier', f'Dossier_IMD_{AFORO}.pdf')
        
        # Verificar si el archivo PDF existe
        if os.path.exists(dossierAFOROS):
            try:
                # Abrir el archivo PDF con el programa predeterminado del sistema operativo
                if os.name == 'nt':  # Windows
                    self.close()
                    os.startfile(dossierAFOROS)
                elif os.name == 'posix':  # macOS o Linux
                    self.close()
                    subprocess.run(['open', dossierAFOROS] if os.uname().sysname == 'Darwin' else ['xdg-open', dossierAFOROS])
                else:
                    txt = "Sistema operativo no soportado."
                    self.fun.showMessageERR(txt)
            except Exception as e:
                txt = f"Error al intentar abrir el archivo PDF: {e}"
                self.fun.showMessageERR(txt)
        else:
            txt = f"El archivo PDF no existe en la ruta especificada: \n\n{dossierAFOROS}"
            self.fun.showMessageERR(txt)


        
    def ponerEtiquetaAFORO(self, aforo):
        # Crear el texto de la etiqueta
        texto = f'AFORO {aforo}'

        # Crear la etiqueta fija
        etiqueta = EtiquetaFija(self.iface.mapCanvas(), texto)

        # Posicionar la etiqueta en la esquina superior izquierda
        posx, posy = 2, 2  # Margen izquierdo y superior
        etiqueta.setPos(posx, posy)

        # Guardar la etiqueta en una lista para poder eliminarla después
        if not hasattr(self.iface.mapCanvas(), 'etiquetas_fijas'):
            self.iface.mapCanvas().etiquetas_fijas = []
        self.iface.mapCanvas().etiquetas_fijas.append(etiqueta)

        # Forzar la actualización del mapa
        self.iface.mapCanvas().refresh()


    def eliminarEtiquetasAFORO(self):
        if hasattr(self.iface.mapCanvas(), 'etiquetas_fijas'):
            for etiqueta in self.iface.mapCanvas().etiquetas_fijas:
                self.iface.mapCanvas().scene().removeItem(etiqueta)
            self.iface.mapCanvas().etiquetas_fijas = []
            self.iface.mapCanvas().refresh()
            print("Todas las etiquetas han sido eliminadas.")
        else:
            print("No hay etiquetas para eliminar.")


    def DescargaCapas(self):
        # Itera sobre todas las capas en el proyecto
        for layer in QgsProject.instance().mapLayers().values():
            layer_name = layer.name()
            
            # Verifica si la capa está en la lista de capas necesarias
            if layer_name in self.capas_necesarias:
                # Elimina la capa del proyecto
                QgsProject.instance().removeMapLayer(layer.id())
                print(f"Capas eliminadas: {layer_name}")

        # Elimina el grupo 'AFOROS' si existe
        root = QgsProject.instance().layerTreeRoot()
        grupo_aforos = root.findGroup('AFOROS')
        if grupo_aforos:
            root.removeChildNode(grupo_aforos)
            print("Grupo 'AFOROS' eliminado.")

       
        # Eliminar las etiquetas
        if hasattr(iface.mapCanvas(), 'etiquetas_fijas'):
            for etiqueta in iface.mapCanvas().etiquetas_fijas:
                iface.mapCanvas().scene().removeItem(etiqueta)
            iface.mapCanvas().etiquetas_fijas = []
            iface.mapCanvas().refresh()
            print("Todas las etiquetas han sido eliminadas.")
        else:
            print("No hay etiquetas para eliminar.")

        self.btn_CARGAR.setText('CARGAR CAPAS')
        self.close()


class EtiquetaFija(QgsMapCanvasItem):
    # CLASE PARA COLOCAR UNA ETIQUETA ARRIBA A LA IZQUIERDA ARRIBA
    #   TEXTO : "Arial", 15px
    #   COLOR : ROJO QColor(255, 0, 0)
    #   BUFFER: BLANCO QColor(255, 255, 255), ancho = 2px
        
    def __init__(self, canvas, texto):
        super().__init__(canvas)
        self.texto = texto
        
        # CONFIGURACIÓN
        self.font = QFont("Arial", 15)
        self.color_texto = QColor(255, 0, 0)  # Rojo
        self.color_buffer = QColor(255, 255, 255)  # Blanco (color del buffer)
        self.buffer_ancho = 2  # Ancho del buffer en píxeles
        self.margen = 2  # Margen alrededor del texto

    def paint(self, painter, option, widget):
        # Configurar el painter
        painter.setFont(self.font)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)  # Suavizado de bordes

        # Calcular el tamaño del texto
        metrics = painter.fontMetrics()
        ancho_texto = metrics.horizontalAdvance(self.texto)
        alto_texto = metrics.height()

        # Crear un QPainterPath para el texto
        path = QPainterPath()
        path.addText(QPoint(self.margen, self.margen + alto_texto), self.font, self.texto)

        # Dibujar el buffer (contorno) en todas las direcciones
        painter.setPen(self.color_buffer)  # Color del buffer
        painter.setBrush(self.color_buffer)  # Relleno del buffer
        for i in range(1, self.buffer_ancho + 1):
            # Desplazamientos en todas las direcciones
            offsets = [
                (-i, -i),  # Arriba-izquierda
                (-i, i),   # Abajo-izquierda
                (i, -i),   # Arriba-derecha
                (i, i)     # Abajo-derecha
            ]
            for dx, dy in offsets:
                offset_path = QPainterPath()
                offset_path.addText(QPoint(self.margen + dx, self.margen + alto_texto + dy), self.font, self.texto)
                painter.drawPath(offset_path)

        # Dibujar el texto sobre el buffer
        painter.setPen(self.color_texto)
        painter.setBrush(self.color_texto)
        painter.drawPath(path)

    def boundingRect(self):
        # Calcular el tamaño del texto
        metrics = QFontMetrics(self.font)
        ancho_texto = metrics.horizontalAdvance(self.texto)
        alto_texto = metrics.height()

        # Devolver el rectángulo que contiene el texto y el margen
        return QRectF(0, 0, ancho_texto + 2 * self.margen, alto_texto + 2 * self.margen)


