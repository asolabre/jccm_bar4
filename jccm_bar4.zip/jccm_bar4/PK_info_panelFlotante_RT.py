# -*- coding: utf-8 -*-
"""
/***************************************************************************
                                 A QGIS4 plugin
Name:           PK_info_panelFlotante_RT.py
Purpose:        Panel flotante de información PK para QGIS
Version:        2.0
        --------------------------------------------------------------------
        begin                : 2025-03-30
        copyright            : (C) 2025 by Agustín Solabre
        email                : asolabre@jccm.es
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt, QSettings, QTranslator, QCoreApplication, pyqtSignal, QUrl
from qgis.PyQt.QtWidgets import (QAction, QApplication, QWidget, QPushButton,
                                QMessageBox, QToolButton, QMenu, QFileDialog,
                                QDockWidget, QVBoxLayout, QLineEdit)

from qgis.core import (QgsFeedback, QgsProject, QgsExpression, QgsFeatureRequest,
                      QgsGeometry, QgsPointXY, QgsRectangle)

from qgis.PyQt import QtGui, QtCore, uic
from qgis.PyQt.QtWidgets import QDialog
from qgis.utils import iface

import os, glob, io, codecs
from osgeo import gdal, osr, ogr
import time

from .config import configuration
from .functions4 import Functions
# from .PK_info_panel import info_panel             ##########   TODO - PANEL SECUNDARIO PENDIENTE ##########

QT_VERSION=5
os.environ['QT_API'] = 'pyqt5'

DOCK_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/PK_dockGeometry.ui'))
# dw  = uic.loadUi( os.path.join(os.path.dirname(__file__), './menus/PK_dockGeometry.ui') )  ## LLAMADA INFO PANEL ##


class PKInfoDockWidget(QDockWidget):

    def __init__(self, canvas, iface, carretera_pk, tipo_consultaCAPA='url', parent=None):
        super(PKInfoDockWidget, self).__init__(parent)

        # Configuración inicial del dock
        self.setWindowTitle("Identificador de carreteras")
        # self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.setFeatures(QDockWidget.DockWidgetFeature.DockWidgetMovable | QDockWidget.DockWidgetFeature.DockWidgetFloatable | QDockWidget.DockWidgetFeature.DockWidgetClosable | QDockWidget.DockWidgetFeature.DockWidgetVerticalTitleBar)
        self.tipo_consultaCAPA=tipo_consultaCAPA

        # Crear widget contenedor
        self.panelPK = QWidget()
        self.setWidget(self.panelPK)

        # Cargar la interfaz UI
        uic.loadUi(os.path.join(os.path.dirname(__file__), './menus/PK_info_panel_RT.ui'), self.panelPK)

        # CONFIGURAR ATRIBUTOS INICIALES DEL PANEL
        self._setup_attributes(canvas, iface, carretera_pk)

        # Configurar conexiones
        self._setup_connections()

        # Establecer tamaño inicial
        self.panelPK.setFixedSize(540, 190)

        # Conectar evento de click en el mapa
        self.canvasClickedConnection = None

        ##########   TODO - PANEL SECUNDARIO PENDIENTE ##########
        self.panelPK.btnAbrirDcha.hide() ########## TODO. DE MOMENTO ESCONDEMOS EL BOTÓN    ##########
        # Configurar panel secundario
        # self.dockGeometry = DockGeometryWidget(self.iface, self)
        # self.dockGeometry.setVisible(False)
        # Condicionar ciertos widgets
        ##########   TODO - PANEL SECUNDARIO PENDIENTE ##########

    def _setup_attributes(self, canvas, iface, carretera_pk):
        """Configura los atributos iniciales"""
        self.iface = iface
        self.canvas = canvas
        self.fun = Functions()
        self.qs = QSettings()
        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        self.conf = configuration()

        geometry = carretera_pk[8]
        atributos = carretera_pk[4]
        self.ctra = atributos['nombre']
        self.geometry_data = geometry

        self.botonDcha = 'R'
        self.botonAbajo = 'D'
        self.pkProx = 0
        self.intervalo = 10.00


    def closeEvent(self, event):
        """Maneja el cierre del panel de forma segura"""
        # Desconectar todas las señales primero
        if hasattr(self, 'canvasClickedConnection') and self.canvas:
            try:
                self.canvas.xyCoordinates.disconnect(self.canvasClickedConnection)
            except:
                pass

        # Cerrar el panel de geometría si existe
        if hasattr(self, 'dockGeometry'):
            self.dockGeometry.close()
            # self.dockGeometry.deleteLater()

        # Limpiar referencias
        self.canvas = None
        self.iface = None

        # Cerrar el panel
        super().closeEvent(event)

    def close_panel(self):
        """Cierra el panel de forma segura"""
        # Desconectar la señal del canvas primero
        if hasattr(self, 'canvasClickedConnection') and self.canvas:
            try:
                self.canvas.xyCoordinates.disconnect(self.canvasClickedConnection)
            except Exception as e:
                print(f"Error al desconectar señal: {str(e)}")

        # Cerrar el panel
        self.close()

        # Opcional: eliminar la referencia si es necesario
        # self.deleteLater()

    def cancel(self):
        """Cierra el panel de forma segura"""
        # Desconectar la señal del canvas primero
        if hasattr(self, 'canvasClickedConnection') and self.canvas:
            try:
                self.canvas.xyCoordinates.disconnect(self.canvasClickedConnection)
            except Exception as e:
                print(f"Error al desconectar señal: {str(e)}")

        # Cerrar el panel
        self.close()

        # Opcional: eliminar la referencia si es necesario
        # self.deleteLater()
        self.reject()



    def _setup_connections(self):
        """Configura las conexiones de señales"""
        # if hasattr(self.panelPK, 'btnAbrirDcha'):             ##########   TODO - PANEL SECUNDARIO PENDIENTE ##########
            # self.panelPK.btnAbrirDcha.clicked.connect(self.toggle_dock_geometry)
        if hasattr(self.panelPK, 'btnAbrirAbajo'):
            self.panelPK.btnAbrirAbajo.clicked.connect(self.botonAmpliarAbajo)
        if hasattr(self.panelPK, 'btnVerCota'):
            self.panelPK.btnVerCota.clicked.connect(self.botonVerCota)
        if hasattr(self.panelPK, 'btnDescargaEje'):
            self.panelPK.btnDescargaEje.clicked.connect(self.botonDescargaEje)
        if hasattr(self.panelPK, 'btnLISTCOORD'):
            self.panelPK.btnLISTCOORD.clicked.connect(lambda: self.botonLISTCOORD(self.geometry_data))
        if hasattr(self.panelPK, 'btnGuardaCSV'):
            self.panelPK.btnGuardaCSV.clicked.connect(lambda: self.botonGuardaCSV(self.geometry_data, self.ctra))
        if hasattr(self.panelPK, 'btnCLOSE'):
            self.panelPK.btnCLOSE.clicked.connect(self.close_panel)
        if hasattr(self.panelPK, 'csvGuardado'):
            self.panelPK.csvGuardado.setOpenExternalLinks(True)
            self.panelPK.csvGuardado.setTextInteractionFlags(
                Qt.TextInteractionFlag.LinksAccessibleByMouse |
                Qt.TextInteractionFlag.TextSelectableByMouse
            )
            
        # Ocultar botones no necesarios
        if hasattr(self.panelPK, 'btnGuardaSHP'):
            self.panelPK.btnGuardaSHP.hide()
        if hasattr(self.panelPK, 'chkGuardarM'):
            self.panelPK.chkGuardarM.setChecked(False)


    def set_data(self, data):
        """Método seguro para establecer datos en los campos del panel"""
        try:
            if not hasattr(self, 'panelPK'):
                print("Error: No se encontró el panel principal")
                return False

            # Asignar valores solo si los widgets existen
            # Lista de campos especiales que usan setPlainText en lugar de setText
            CAMPOS_ESPECIALES = {'txbLISTGEOM'}

            # Asignar valores solo si los widgets existen
            for key, value in data.items():
                if hasattr(self.panelPK, key):
                    widget = getattr(self.panelPK, key)
                    if key in CAMPOS_ESPECIALES:
                        widget.setPlainText(str(value))
                    else:
                        widget.setText(str(value))
                else:
                    # print(f"Advertencia: No se encontró el campo {key} en el panel")
                    pass

            # Cambiamos el color del fondo si los datos son de GPKG ######## TODO. REVISAR tipo_consultaCAPA ########
            if self.tipo_consultaCAPA != 'url':
                self.panelPK.setStyleSheet('background-color: rgb(235, 255, 255);')

            ######## TODO. REVISAR COLORES DE FONDO DE ALGUNOS WIDGETS ########
            # Establecemos el color de la etiqueta CARRETERA
            # COLORES CARRETERAS
            color_morado  = '255,0,255'
            color_naranja = '255,127,0'
            color_verde   = '0,255,0'
            color_amarillo= '255,255,0'
            color_blanco  = '255,255,255'
            color_azul    = '1,103,200'
            color_rojo    = '255,50,50'
            color_negro   = '0,0,0'

            colorF = color_blanco
            colorT = color_negro
            if data['titular'] == '(2) Comunidad Autónoma' and data['orden'] == '(P) Principal':
                colorF = color_morado
                colorT = color_negro
            elif data['titular'] == '(2) Comunidad Autónoma' and data['orden'] == '(1) Primer orden':
                colorF = color_naranja
                colorT = color_negro
            elif data['titular'] == '(2) Comunidad Autónoma' and data['orden'] == '(2) Segundo orden':
                colorF = color_verde
                colorT = color_negro
            elif data['titular'] == '(2) Comunidad Autónoma' and data['orden'] == '(3) Tercer orden':
                colorF = color_amarillo
                colorT = color_negro
            # elif data['titular'] == '(2) Comunidad Autónoma' and data['orden'] == 'Travesía':
                # colorF = color_amarillo
                # colorT = color_negro
            # elif data['titular'] == '(2) Comunidad Autónoma' and data['orden'] == 'Ramal':
                # colorF = color_amarillo
                # colorT = color_negro
            elif data['titular'] == '(1) Administración General del Estado' and data['orden'] == '(P) Principal':
                colorF = color_azul
                colorT = color_blanco
            elif data['titular'] == '(1) Administración General del Estado' and data['orden'] == '(1) Primer orden':
                colorF = color_rojo
                colorT = color_blanco

            self.panelPK.Matricula_plan.setStyleSheet(f"background-color: rgb({colorF}); border: 2px solid black; color: rgb({colorT}); border-radius: 7px;")
            self.panelPK.pk_pinchado.setStyleSheet("background-color: rgb(255, 255, 255); border: 1px solid black; border-radius: 7px;")

            return True

        except Exception as e:
            print(f"Error crítico al establecer datos: {str(e)}")
            return False



    # Métodos originales adaptados
    def botonAmpliarAbajo(self):
        if hasattr(self.panelPK, 'XE') and hasattr(self.panelPK, 'YE'):
            XE = float(self.panelPK.XE.text())
            YE = float(self.panelPK.YE.text())

            if self.botonAbajo == 'D':
                self.setHistoricoCTRA(XE, YE)
                self.panelPK.setFixedSize(540, 520)
                self.panelPK.btnAbrirAbajo.setArrowType(Qt.ArrowType.UpArrow)
                self.botonAbajo = 'U'
            elif self.botonAbajo == 'U':
                self.panelPK.setFixedSize(540, 190)
                self.panelPK.btnAbrirAbajo.setArrowType(QtCore.Qt.ArrowType.DownArrow)
                self.botonAbajo = 'D'

    def botonLISTCOORD(self, geometry):
        if hasattr(self.panelPK, 'txbLISTGEOM') and hasattr(self.panelPK, 'btnAbrirAbajo'):
            self.panelPK.txbLISTGEOM.setHtml(self.fun.makeHtmlListCoord(geometry))
            self.panelPK.setFixedSize(860, 520)
            self.panelPK.btnAbrirAbajo.setArrowType(Qt.ArrowType.UpArrow)
            self.botonAbajo = 'U'


    def botonGuardaCSV(self, geometry, ctra):
        nom_fich_csv = u"C:/temp/" + ctra.replace('-','')+'_geom'
        ext = "*.csv"
        dirfile, tipofile = QFileDialog.getSaveFileName(self, "Fichero CSV de salida", nom_fich_csv, ext)
        if dirfile == None or dirfile == "":
            dirfile = nom_fich_csv+'.csv'
            self.fun.showMessage(u"No se guarda el fichero CSV")
            return
        # Comprobamos que existe el directorio y si no se crea
        if not os.path.exists(os.path.dirname(dirfile)):
            os.makedirs(os.path.dirname(dirfile))

        target  = open(dirfile, 'w+',encoding='utf-8')
        if self.panelPK.chkGuardarM.isChecked():
            encabezado = u'"num";"x";"y";"pk";"dif"'
        else:
            encabezado = u'"num";"x";"y";"pk"'

        target.write(encabezado+"\n")

        # paths = geometry["paths"]
        if isinstance(geometry, dict) and "paths" in geometry:
            paths = geometry["paths"]                     # formato REST antiguo
        elif isinstance(geometry, QgsGeometry):
            paths = self.fun._qgsgeom_to_paths(geometry)  # formato RT (QgsGeometry)
        else:
            self.fun.showMessage(u"Tipo de geometría no soportado en guardarCSV")
            target.close()
            return

        listCoord =''
        punto = 1
        pathNum=1
        Mant = None
        for path in paths:
            datoPath = 'TRAMO %s/%s (%s puntos)\n'%(str(pathNum),len(paths),len(path))
            target.write(datoPath)
            for point in path:
                if point[2] is not None:
                    if Mant is not None:
                        if self.panelPK.chkGuardarM.isChecked():
                            listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+','+" %0.5f"%(point[2]-Mant)+'\n'
                        else:
                            listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+'\n'
                        target.write(listCoord)
                    else:
                        if self.panelPK.chkGuardarM.isChecked():
                            listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+', 0.0'+'\n'
                        else:
                            listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" %0.5f"%(point[2])+'\n'

                        target.write(listCoord)
                    Mant = point[2]
                else:
                    listCoord = str(punto)+','+" %0.2f"%(point[0])+','+" %0.2f"%(point[1])+','+" None"+'\n'
                    target.write(listCoord)
                punto += 1
            pathNum +=1

        target.close()
        textInfo = u"GUARDADO CSV\n\n"+dirfile

        url_csv = QUrl.fromLocalFile(dirfile).toString()
        self.panelPK.csvGuardado.setText(
            u'<a href="{url}">{txt}</a>'.format(url=url_csv, txt=dirfile)
        )

        self.fun.showMessage(textInfo)

    def botonVerCota(self):
        # Zmdt = self.fun.Zmdt((float(self.XE),float(self.YE)), self.iface, pintar='NO')
        XE = float(self.panelPK.XE.text())
        YE = float(self.panelPK.YE.text())
        Zmdt = self.fun.Zmdt((XE,YE), self.iface, pintar='NO')

        if Zmdt == 'Error':
            self.panelPK.cotaEje.setText('Error')
            self.panelPK.ZE.setText('Error')
        else:
            self.panelPK.cotaEje.setText(str(round(Zmdt,3)))
            self.panelPK.ZE.setText(str(round(Zmdt,3)))

    def botonDescargaEje(self):
        # Descarga de EJE pinchado
        from .herrCTRAS_descargas import herrCTRAS_descargas

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        herrCTRAS_descargas = herrCTRAS_descargas(self.iface)
        valcbxTitularidad = '%'
        valcbxFuncionalidad = '%'
        valcbxProvincia = '%'
        valcbxMatricula = self.panelPK.Matricula_plan.text()
        valMatr9000 = True
        SOLO2D = False
        messLblINFO = False
        NOMcapa = u'CTRA %s EJE'%(valcbxMatricula)
        fichEstilo = '/Carreteras_CLM_WFS.qml'
        estiloCAPA = os.path.join(os.path.dirname(__file__), self.conf.general["carpeta_estilos"] + fichEstilo)
        nomFich = u'C:/TEMP/%s.gpkg'%(valcbxMatricula)
        nomLayerPKS = u'CTRA %s PKS'%(valcbxMatricula)
        fichEstiloPKS = '/GEO_PKS_WFS.qml'
        nomFichPKS = 'C:/TEMP/%s_PKS.gpkg'%(valcbxMatricula)
        estiloCAPAPKS = os.path.join(os.path.dirname(__file__), self.conf.general["carpeta_estilos"] + fichEstiloPKS)

        # Descargamos el eje
        layerEJES2D = herrCTRAS_descargas.lecturaEJES(valcbxTitularidad, valcbxFuncionalidad,
                        valcbxProvincia, valcbxMatricula, valMatr9000, SOLO2D,
                        messLblINFO, NOMcapa, estiloCAPA, nomFich)

        # ## TODO priueba de ver si carga la M del eje
        # QgsProject.instance().addMapLayer(layerEJES2D)
        # print ('AQUI SE CARGA LA CAPA PREVIAMENTE')
        # ## TODO prueba de ver si carga la M del eje

        # Escribimos en un fichero GPKG los ejes
        self.fun.cargaGPKGjson(layerEJES2D, nomFich, NOMcapa, NOMcapa, estiloCAPA, cargaVISTA=True)

        # Descargamos los Pks
        layerPKS = herrCTRAS_descargas.lecturaPKS(valcbxProvincia, valcbxMatricula,
                        messLblINFO, nomLayerPKS, nomFichPKS, estiloCAPAPKS)

        # Escribimos en un fichero GPKG los pks
        self.fun.cargaGPKGjson(layerPKS, nomFichPKS, nomLayerPKS, nomLayerPKS, estiloCAPAPKS, cargaVISTA=True)

        QApplication.restoreOverrideCursor()
        text = u'FINALIZADA DESCARGA EJE %s'%(valcbxMatricula)
        self.fun.showMessage(text)

        return

    def botonGuardaSHP(self, geometry): ##########      TODO - ESTO ESTÁ PENDIENTE     ##########
        self.fun.showMessage(u"GUARDAMOS UN SHP")
        pass



    def setHistoricoCTRA(self, XE, YE):
        ###############################################################################################
        ####            METEMOS DATOS HISTÓRICOS            ###########################################
        ###############################################################################################

        GPKGCLASS = "CTRAS_HISTORICO"
        GPKG = "U:/cartografia/datos_Q/CAPAS/GDB_CARRETERAS.gpkg"
        #       U:/cartografia/datos_Q/CAPAS/GDB_CARRETERAS.gpkg|layername=CARRETERAS_AB_HISTORICO_EDICION
        TABLANOM = "CARRETERAS_AB_HISTORICO_EDICION"
        LAYNOM = GPKGCLASS
        LAYTIPE = "ogr"

        self.panelPK.lvwCTRASHISTORICO.clear()
        ## DETECTAR SI EXISTE LA CAPA Y/O CARGARLA
        if self.qs.value(f"{self.nombre_plugin}/ACCESOEDITOR"):
            listHisto = [u'HISTÓRICO: No hay datos históricos']
            self.panelPK.lvwCTRASHISTORICO.show()
            attrs = self.getHistoricoCTRA( XE, YE, GPKG, GPKGCLASS, LAYNOM, LAYTIPE, TABLANOM)

            if attrs[0] == 's/d' or not attrs[0][6]:
                # print ('NO SE LOCALIZAN DATOS')
                listHisto = [u'HISTÓRICO: No hay datos históricos']
            else:
                numAtt = 1
                listHisto = []
                for attr in attrs:
                    # print (attr)
                    try:
                        fecha = attr[11].toString('dd/MM/yy')
                    except:
                        fecha = ''
                    if attr[6]:
                        if attr[6] == 'NUEVO TRAZADO':
                            linAtt = u'NUEVO TRAZADO construido el %s. %s'%(fecha,attr[12])
                        elif attr[9] == attr[10]:
                            linAtt = u'Ant. %s CAMBIO NOMBRE el %s. %s'%(attr[6],fecha,attr[12])

                        else:
                            # print ('CTRA_ANT: ',attr[6],'DE: ',attr[9],'A: ',attr[10],'FECHA: ',attr[11],'Decreto: ',attr[12])
                            linAtt = u'Ant. %s. Transf. de  %s a %s el %s. %s'%(attr[6],attr[9],attr[10],fecha,attr[12])
                        listHisto.append(linAtt)
                        numAtt += 1
            self.panelPK.lvwCTRASHISTORICO.addItems(listHisto)

        else:
            self.panelPK.lvwCTRASHISTORICO.hide()

        pass


    def getHistoricoCTRA(self, XE, YE, GPKG, GPKGCLASS, LAYNOM, LAYTIPE, TABLANOM):

        # -----  DATOS HISTÓRICOS -----
        # LAYNOM = "GEOMETRIA"

        layerEXIST = QgsProject.instance().mapLayersByName(LAYNOM)
        if not layerEXIST:
            # print (GPKG)
            if not os.path.isfile(GPKG):
                print (u'No existe fichero %s'%(GPKG))
                return (['s/d'])

            layers = [l.GetName() for l in ogr.Open(GPKG)]
            if TABLANOM in layers:
                layer = iface.addVectorLayer(GPKG + "|layername=" + TABLANOM, LAYNOM, 'ogr')
                layer.setName(LAYNOM)
                QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(False)
                QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setExpanded(False)

            else:
                print('Error: no hay una capa llamada "{}" en {}!'.format(layer, gpkg))
                return (['s/d'])

        else:
            layer = layerEXIST[0]
            QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(False)
            QgsProject.instance().layerTreeRoot().findLayer(layer.id()).setExpanded(False)

        # print (XE)
        # print (YE)

        radius = 1
        rect = QgsRectangle(XE - radius,
                            YE - radius,
                            XE + radius,
                            YE + radius)


        attrs = ['s/d']
        try:
            layer.selectByRect(rect, False)
            features = layer.selectedFeatures()

            attrs = []
            for feat in features:
                attrs.append(feat.attributes())
            if attrs == []:
                attrs = ['s/d']
        except:
            attrs = ['s/d']

        layer.removeSelection()
        return attrs




    ###########################################################################################
    ###########################################################################################
    ##########                                                                       ##########
    ##########                   TODO - PANEL SECUNDARIO PENDIENTE                   ##########
    ##########                                                                       ##########
    ###########################################################################################
    ###########################################################################################

    # def toggle_dock_geometry(self):             ##########   TODO - PANEL SECUNDARIO PENDIENTE ##########
        # """Muestra/oculta el panel de geometría"""
        # if self.dockGeometry.isVisible():
            # # self.dockGeometry.setVisible(False)
            # # self.panelPK.btnAbrirDcha.setArrowType(Qt.RightArrow)
            # self.botonDcha = 'R'
        # else:
            # self.load_geometry_data()
            # # self.dockGeometry.setVisible(True)
            # # self.panelPK.btnAbrirDcha.setArrowType(Qt.LeftArrow)
            # self.botonDcha = 'L'

    def botonPanelDcha(self, GDB):
        # if self.botonDcha == 'R':

        # bar = QProgressBar()    ## LLAMADA INFO PANEL ##

        text =u'La carga de datos desde fuentes externas.\n'
        text +=u'puede tardar varios minutos.\n\n'
        text +=u'               ¿DESEA CONTINUAR?'
        result = self.fun.showMessageYESNO(text,'',u'VER MÁS DATOS' )
        if result != 1024: # No e ha pulsado ACEPTAR
            return
        pass

        bar = QgsFeedback()    ## LLAMADA INFO PANEL ##
        # bar.setRange(0,0)
        bar.setProgress(0)
        iface.mainWindow().statusBar().clearMessage()
        iface.mainWindow().statusBar().showMessage('Cargando datos GEOMETRÍA...')
        # iface.mainWindow().statusBar().addWidget(bar)    ## LLAMADA INFO PANEL ##
        # ctraBUSQ  =  self.Matricula.text()
        # pk = float(self.Pk.text())

        self.botonDcha = 'L'
        self.botonAbajo = 'U'

        # iface.mainWindow().addDockWidget(Qt.RightDockWidgetArea, dw)

        self.pkGetGeometria(ctraBUSQ, pk, dw, GDB)
        self.pkGetAforos(ctraBUSQ, pk, dw, GDB)

        # iface.mainWindow().statusBar().removeWidget(bar)    ## LLAMADA INFO PANEL ##
        iface.mainWindow().statusBar().clearMessage()
        # self.fun.trabajando(u'--- CERRAR ---', busy)
        self.dockGeometry.show()
        self.dockGeometry.btnRetrocedePK.clicked.connect(lambda: self.RetrocedePK(GDB))
        self.dockGeometry.btnAvanzaPK.clicked.connect(lambda: self.AvanzaPK(GDB))


        # return pkProx

    def load_geometry_data(self):
        """Carga los datos en el panel de geometría"""
        text = u'La carga de datos desde fuentes externas.\npuede tardar varios minutos.\n\n¿DESEA CONTINUAR?'
        result = self.fun.showMessageYESNO(text, '', u'VER MÁS DATOS')

        if result != 1024:  # No se ha pulsado ACEPTAR
            return

        # Localizar la GDB
        listGDB = [
            "V:\SIGCLM\APPJCCM\Datos\sig_reg_ctras.gdb",
            "V:\SIGCLM\APPJCCM\Datos\sig_reg_ctras_AB.gdb",
            "U:\SIGCLM\APPJCCM\Datos\sig_reg_ctras.gdb",
            "U:\SIGCLM\APPJCCM\Datos\sig_reg_ctras_AB.gdb"]

        GDBCLASS = "GEOMETRIA"
        GDB = self.fun.buscaUnidadesGDB(listGDB, GDBCLASS)

        if GDB == "":
            self.fun.showMessage(u"No se encontró la base de datos de geometría")
            return

        # Obtener datos de geometría y aforos
        ctraBUSQ = self.panelPK.Matricula_plan.text()
        pk = float(self.panelPK.Pk.text()) if hasattr(self.panelPK, 'Pk') else 0

        self.pkGetGeometria(ctraBUSQ, pk, self.dockGeometry, GDB)
        self.pkGetAforos(ctraBUSQ, pk, self.dockGeometry, GDB)

        # Conectar botones de navegación PK
        self.dockGeometry.btnRetrocedePK.clicked.connect(lambda: self.RetrocedePK(GDB))
        self.dockGeometry.btnAvanzaPK.clicked.connect(lambda: self.AvanzaPK(GDB))

    def pkGetGeometria(self, ctraBUSQ, pk, dw, GDB):

        GDBCLASS = "GEOMETRIA"
        LAYNOM = "GEOMETRIA"
        LAYTIPE = "ogr"
        attrs = ['s/d']

        # Esto solo vale para buscar en un fichero SHP con la misma estructura que la GDB
        # filSHP = u'u:\BBDD AGENDA\CONSULTAS_BBDD208\GEOMETRIA_CTRA_TRA.shp'
        filSHP = ""

        if GDB == "" and filSHP == "":
            print (' LO SIENTO LA GDB o LA CLASE NO EXISTE ')
        else:
            if filSHP == "":
                QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
                attrs = self.fun.getGeomCTRA(ctraBUSQ, pk, GDB, GDBCLASS, LAYNOM, LAYTIPE)
                const = 0
                self.close()
            else:
                QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
                attrs = self.fun.getGeomCTRA_SHP(ctraBUSQ, pk, filSHP, LAYNOM, LAYTIPE)
                const = 0
                self.close()

        # if attrs[0] == 's/d':

        if attrs == {}:
            print ('NO SE LOCALIZAN DATOS')

            self.dockGeometry.G_nocarriles.setText("s/d")
            self.dockGeometry.G_Plataforma.setText("s/d")
            self.dockGeometry.G_ArcenI.setText("s/d")
            self.dockGeometry.G_CalzadaT.setText("s/d")
            self.dockGeometry.G_ArcenD.setText("s/d")
            self.dockGeometry.G_RadioC.setText("s/d")
            self.dockGeometry.G_Peralte.setText("s/d")
            self.dockGeometry.G_Pendiente.setText("s/d")
            self.dockGeometry.G_UTM_Z.setText("s/d")
            self.pkProx = pk


        else:
            # print 'CTRA= %s (%s) - PK= %s+%s' %(attrs[0],attrs[4], int(attrs[7]), int(attrs[8]))
            # print 'Plataforma= %s carriles, %s - %s - %s' %(int(attrs[13]),str(attrs[16]/10),str(attrs[18]/10),str(attrs[19]/10))
            # print 'IdSubred=%s - IdCtra=%s - idMatricula=%s - Tramo=%s' %(attrs[1],attrs[2],attrs[3],attrs[4])
            # print 'Radio=%s - Peralte=%s - Pendiente=%s - Alzado=%s - '%(attrs[20],attrs[21]/10,attrs[22]/10,attrs[23])
            # for att in attrs:
                # print att

            self.dockGeometry.G_nocarriles.setText(str(int(attrs['No_carrile'])))
            self.dockGeometry.G_Plataforma.setText(str(attrs['Plataforma']/10))
            self.dockGeometry.G_ArcenI.setText(str(attrs['Arcen_Izq']/10))
            self.dockGeometry.G_CalzadaT.setText(str(attrs['Calzada_To']/10))
            self.dockGeometry.G_ArcenD.setText(str(attrs['Arcen_Der']/10))
            self.dockGeometry.G_RadioC.setText(str(attrs['Radio_de_C']))
            self.dockGeometry.G_Peralte.setText(str(attrs['Peralte']/10))
            self.dockGeometry.G_Pendiente.setText(str(attrs['Pendiente']/10))
            self.dockGeometry.G_UTM_Z.setText(str(attrs['UTM_Z']))
            self.pkProx = attrs['PKHito']+attrs['PKDist']/1000



        self.dockGeometry.Carretera.setText('<font size = 5 color = black font-style = bold><p align="center">'+ctraBUSQ+'</p></font>')
        self.dockGeometry.Pk.setText('<font size = 5 color = black font-style = bold><p align="center">PK: '+self.fun.mostrarPK(self.pkProx,2)+'</p></font>')
        # Establecemos el color de la etiqueta
        '''
        values = "{r}, {g}, {b}, {a}".format(r = color.red(),
                                             g = color.green(),
                                             b = color.blue(),
                                             a = alpha
                                             )
        myLabel.setStyleSheet("QLabel { background-color: rgba("+values+"); }")
        '''
        # Establecemos el color de la etiqueta
        self.dockGeometry.Carretera.setStyleSheet("background-color: white")
        # self.dockGeometry.Carretera.setStyleSheet("background-color: rgba("255,255,255,255")")
        self.dockGeometry.Pk.setStyleSheet("background-color: white")

        QApplication.restoreOverrideCursor()
        # LISTADO DE ATRIBUTOS ( variable attrs)
        #Nombre: 0 Carretera
        #Nombre: 1 IdSubred
        #Nombre: 2 IdCtra
        #Nombre: 3 idMatricula
        #Nombre: 4 Tramo
        #Nombre: 5 A_Tramos_IdTramo
        #Nombre: 6 Geometria_IdTramo
        #Nombre: 7 PKHito
        #Nombre: 8 PKDist
        #Nombre: 9 Distancia
        #Nombre: 10 UTM_X
        #Nombre: 11 UTM_Y
        #Nombre: 12 UTM_Z
        #Nombre: 13 N_de_Carriles
        #Nombre: 14 Plataforma
        #Nombre: 15 Plataforma_total
        #Nombre: 16 Arcen_Izquierdo
        #Nombre: 17 Calzada
        #Nombre: 18 Calzada_Total
        #Nombre: 19 Arcen_Derecho
        #Nombre: 20 Radio_de_Curvatura
        #Nombre: 21 Peralte
        #Nombre: 22 Pendiente
        #Nombre: 23 Alzado
        #Nombre: 24 Visibilidad_Directa
        #Nombre: 25 Visibilidad_Inversa
        #Nombre: 26 IdtramoContrario
        #Nombre: 27 DistCalzadaContraria
        #Nombre: 28 Mediana
        #Nombre: 29 Galibo_izquierdo
        #Nombre: 30 Galibo_derecho
        #Nombre: 31 GLAT
        #Nombre: 32 GLON
        #Nombre: 33 PROVINCIA
        #Nombre: 34 FECHA
        #Nombre: 35 FUENTE
        #Nombre: 36 UTM_X
        #Nombre: 37 UTM_Y
        #Nombre: 38 UTM_Z

    def pkGetAforos(self, ctraBUSQ, pk, dw, GDB):

        GDBCLASS = "AFOROS_tramificacion"
        LAYNOM = "AFOROS"
        LAYTIPE = "ogr"
        attrs = ['s/d']

        filSHP = ""

        if GDB == "" and filSHP == "":
            print (' ¡LO SIENTO! LA GDB o LA CLASE NO EXISTE ')
        else:
            if filSHP == "":
                QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
                attrs = self.fun.getAforoCTRA(ctraBUSQ, pk, GDB, GDBCLASS, LAYNOM, LAYTIPE)
                const = 0
                self.close()
            else:
                QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
                attrs = self.fun.getGeomCTRA_SHP(ctraBUSQ, pk, filSHP, LAYNOM, LAYTIPE)
                const = 0
                self.close()


        if attrs[0] == 's/d':
            print ('NO SE LOCALIZAN DATOS')

            self.dockGeometry.A_IMD.setText("s/d")
            self.dockGeometry.A_porcPes.setText("s/d")
            pass

        else:
            self.dockGeometry.A_IMD.setText(str(attrs[8]))
            self.dockGeometry.A_porcPes.setText("{:.{}f}".format( attrs[9],3)+'%')
            pass

        QApplication.restoreOverrideCursor()

        # Nombre: 0 idEstacion
        # Nombre: 1 Provincia
        # Nombre: 2 EstacionTi
        # Nombre: 3 Carretera
        # Nombre: 4 Pk_estacio
        # Nombre: 5 Ubicacion
        # Nombre: 6 KMi
        # Nombre: 7 KMf
        # Nombre: 8 IMD17
        # Nombre: 9 PESADOS17
        # Nombre:10 Tramificac
        # Nombre:11 Shape_Length


    def setLabelColors(window, base):
        t = '<property name="palette"><palette><active>'
        t+= '<colorrole role="Base">  <brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>255</green><blue>255</blue></color></brush></colorrole>'
        t+= '<colorrole role="Window"><brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        t+= '</active><inactive>'
        t+= '<colorrole role="Base">  <brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>255</green><blue>255</blue></color></brush></colorrole>'
        t+= '<colorrole role="Window"><brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        t+= '</inactive><disabled>'
        t+= '<colorrole role="Base">  <brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        t+= '<colorrole role="Window"><brush brushstyle="SolidPattern"><color alpha="255"><red>255</red><green>170</green><blue>000</blue></color></brush></colorrole>'
        t+= '</disabled></palette></property>'
        return t


    def RetrocedePK(self, GDB):
        ctraBUSQ = self.fun.Extract_PlainText(self.dockGeometry.Carretera)
        #pk = self.fun.Extract_PlainText(self.dockGeometry.Pk).replace('PK: ','').replace('+','')
        pk = self.pkProx
        self.pkProx = pk - (self.intervalo/1000)
        print (u'RETROCEDE A CTRA %s - PK %s - INT %s'%(ctraBUSQ,self.pkProx, self.intervalo))
        self.pkGetGeometria(ctraBUSQ, self.pkProx, dw, GDB)
        # return pkBUSQ
        pass


    def AvanzaPK(self, GDB):
        ctraBUSQ = self.fun.Extract_PlainText(self.dockGeometry.Carretera)
        #pk = self.fun.Extract_PlainText(self.dockGeometry.Pk).replace('PK: ','').replace('+','')
        pk = self.pkProx
        self.pkProx = pk + (self.intervalo/1000)
        print (u'RETROCEDE A CTRA %s - PK %s - INT %s'%(ctraBUSQ,self.pkProx, self.intervalo))
        self.pkGetGeometria(ctraBUSQ, self.pkProx, dw, GDB)
        # return pkBUSQ
        pass


class DockGeometryWidget(QDockWidget, DOCK_CLASS):
    ##########   TODO - PANEL SECUNDARIO PENDIENTE ##########

    """Panel secundario para mostrar información de geometría"""
    def __init__(self, iface, parent=None):
        super(DockGeometryWidget, self).__init__(parent)
        self.setupUi(self)

        self.iface = iface
        self.parent = parent

        # Configuración del dock widget
        self.setWindowTitle("Geometría PK")
        self.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea)
        self.setFeatures(QDockWidget.DockWidgetFeature.DockWidgetMovable | QDockWidget.DockWidgetFeature.DockWidgetFloatable)

        self.setWindowIcon(QIcon(':/plugins/jccm_bar4/iconos/logo_general.jpg'))


    def closeEvent(self, event):
        """Maneja el cierre del panel"""
        if self.parent:
            # self.parent.widget.btnAbrirDcha.setArrowType(Qt.RightArrow)
            # self.parent.botonDcha = 'R'
            pass
        event.accept()