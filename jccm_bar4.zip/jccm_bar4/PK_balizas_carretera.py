# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           PK_balizas_carretera.py
Purpose:

        --------------------------------------------------------------------
        begin                : 2019-09-03
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import Qt, QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtWidgets import QAction, QApplication, QWidget, QPushButton, QMessageBox, QToolButton, QMenu

from qgis.PyQt import QtGui, uic
from qgis.PyQt.QtWidgets import QDialog
    # PyQt5.QtWidgets - https://doc.qt.io/qt-5/qtwidgets-module.html


import os
from osgeo import ogr, osr

import urllib
import json
from time import sleep


from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/PK_balizas_carretera.ui'))

# class balizas_carreteraDialog(QtGui.QDialog, FORM_CLASS):
class balizas_carreteraDialog(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        super(balizas_carreteraDialog, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface;
        
        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        self.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/senal_ctra.jpg'))
        self.fun = Functions()

    def encode(self,text):
        """
        For printing unicode characters to the console.
        """
        return text.encode('utf-8')
        
    def cancel(self):
        return 'CANCEL'