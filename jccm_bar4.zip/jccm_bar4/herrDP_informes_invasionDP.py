# -*- coding: utf-8 -*-
"""
/***************************************************************************
herrDP_informes_invasionDP.py
                                 A QGIS4 plugin

                             -------------------
        begin                : 2019-02-11
        git sha              : $Format:%H$
        Codigo Original     : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/
# Script de gestión de análisis de INVASIÓN CATASTRAL de las parcelas de DOMINIO PÚBLICO (DP) por EXPROPIACIONES o DESLINDES
    Trabaja con los siguientes ficheros:
        - Capa de límites de dominios públicos
        - Capa de parcelas informadas
        - Excel de datos de parcelas informadas para combinar con modelos de informes word 
            (alternativamente se migra a fichero de intercambio para access)
        - Directorio de repositorio de expedientes de informes cronológicos (por años y nº expte)
    El objetivo principal es la carga de parcelas catastrales para su análisis geométrico contra la linea de DP, con vistas a 
    emitir informes por colindancia, estudiando si se produce una INVASIÓN u otra circunstancia.
    En paralelo permite analizar contra una geometría alternativa a la catastral. Por otra parte permite genear informes genéricos por colindancia
        
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

#### TODO ####

# ANALIZAR SI SE ASIGNA NUEVO EXPEDIENTE DESDE LA ULTIMA CAPETA XTE O DESDE EL VALOR MAS ALTO DE LA EXCEL
# ADVERTIR DE SI EXCEL ESTÁ ABIERTO, AHORA DA ERROR
# SI EXCEL NO EXISTE SE BUSCA O SE CREA
# CREACIÓN NUMEXPRO DESDE EXCEL O DESDE GPKG

# ELMINAR DUPLICIDADES DE ME´TODOS ENTRE intersectParcelas() y asignarTIPO_EXPTE()
#   1. Búsqueda del perímetro más próximo
#   2. Cálculo de PKs
#   3. Actualización de tabla de resultados

# INFORMAR DE SI EXISTE OTRO EXPEDIENTE PARA ESA RC Y RELACIONARLO
# METER DATOS DEL EXPEDIENTE DE EXPROPIACIONES EN CASOS DE NO INVASION
# METER DATOS DE PARCELA EXPROPIADA COLINDANTE SI LOS HAY
# ANÁLISIS DE INVASIÓN DEL D.P. POR FICHERO ALTERNATIVO
# ANALISIS DE CORTES MULTIPLES BAJO TOLERANCIA
# CREACION DE GML

from qgis.PyQt.QtGui import QIcon, QPixmap
from qgis.PyQt.QtWidgets import QDialog, QTableWidgetItem, QApplication, QListWidgetItem,  QMessageBox

# from PyQt5.QtCore import QSettings, QVariant
from qgis.PyQt.QtCore import QSettings, QVariant, QTimer, QMetaType

from qgis.PyQt import uic
from qgis.core import (QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsFeature, QgsPointXY,
                QgsField, QgsExpression, QgsFeatureRequest, QgsGeometry, QgsWkbTypes, QgsExpressionContextUtils,
                QgsCoordinateReferenceSystem, QgsCoordinateTransform)

from qgis.PyQt.QtCore import Qt, QDate

from datetime import datetime
import os
from osgeo import ogr, osr, gdal
from xml.etree import cElementTree as ElementTree
import urllib
import tempfile

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

# from .herrExpro_generaGML import herrExpro_generaGML
from .catastro_generaGML import catastro_generaGML

from .jccm_bar_config_RT import jccm_bar_config


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrDP_informes_invasionDPdlg.ui'))

tipoCARGA = 'CAPAPAR'
        # tipoCARGA = 'CAPAPAR' # tipoCARGA = 'CAPAPAR' - Carga las parcelas en una capa única
        # tipoCARGA = 'CAPAIND' # tipoCARGA = 'CAPAIND' - Carga las parcelas en capas individuales

current_configuration = configuration()

# VARIABLES
srcVal = current_configuration.general["EPSG"]
nomLayerINT = 'Zonas invadidas'
layerPARCnom = 'PARCELAS CATASTRALES'

listINGENIERO = current_configuration.listINGENIERO
listMARGEN = current_configuration.listMARGEN
listCORREOELEC = current_configuration.listCORREOELEC
listINTERESADO = current_configuration.listINTERESADO
listSOLICITANTE = current_configuration.listSOLICITANTE
# listTIPEXPTE    = current_configuration.listTIPOEXPTE
listArticuloLey = current_configuration.listArticuloLey

class herrDP_informes_invasionDP(QDialog, FORM_CLASS):
    
    # Constantes de la clase
    PRECISION_PUNTO_INACCESIBLE = 0.01      # Precisión para obtener el poleOfInaccessibility
    TOLERANCIA_SUPERFICIE_MINIMA = 1.00     # Tolerancia en metros cuadrados, bajo la cual se considera NO INVASIÓN
    DISTANCIA_MINIMA_COLINDANCIA = 20.00    # Distancia mínima para considerar 'colindante' una parcela a un DP
    NOMBRE_CAPA_RESULTADOS = 'Zonas invadidas'

    def __init__(self, iface, tipoDP, parent=None):
        """Constructor."""
        super(herrDP_informes_invasionDP, self).__init__(parent)

        self.fun = Functions()
        self.iface = iface;
        self.setupUi(self)

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        self.qs = QSettings()
        self.conf = configuration()

        # Bandera para controlar si debemos continuar
        self.continue_initialization = True
        
        #######################################################################
        #######################################################################

        # VARIABLE DE CONTROL DE TIPO DE MENÚ
        self.tipoDP = tipoDP

        #######################################################################
        #######################################################################

        self.setFixedSize(810, 590) # Tamaño general del Cuadro de diálogo

        #######################################################################
        ###         TODO OCULTAR PESTAÑAS PROVISIONALES                     ###
        self.tabWidget.tabBar().setTabVisible(0, False)  # Oculta la pestaña 4 (índice 0)
        self.tabWidget.tabBar().setTabVisible(1, False)  # Oculta la pestaña 5 (índice 1)
        ###         TODO OCULTAR PESTAÑAS PROVISIONALES                     ###
        #######################################################################

        
        if self.tipoDP != 'MUNICIPAL':
            self.logo.setPixmap(QPixmap(f":/plugins/jccm_bar4/iconos/jccm.jpg"))
            self.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/jccm_EXPR_INF.jpg'))
            self.logo.setFixedSize(110, 70)
            self.logo.move(10,10)
            self.prefEXPTE = u'EX-'
            self.campoTIPO = "ex_tipoinv"

        else:
            self.logo.setPixmap(QPixmap(f":/plugins/jccm_bar4/iconos/logo_general.jpg"))
            self.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/logo_general.jpg'))
            self.logo.setFixedSize(60, 80)
            self.logo.move(35,10)
            self.prefEXPTE = u'DP-'
            self.campoTIPO = "dp_tipoinv"


        #  SE ESTUDIA SI NO ESTÁN LAS VARIABLES DE LIMITES DE EXPROPIACION
        proviEXPRO = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPprovincia")
        if proviEXPRO is None:
            proviEXPRO = self.conf.expropiacion["EXPprovincia"]
        layerLIMInom = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPlayerLIMEXPRO")
        if layerLIMInom is None:
            layerLIMInom = self.conf.expropiacion["EXPlayerLIMEXPRO"]
        self.layerINFEXPnom = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPlayerINFOEXPRO")
        if self.layerINFEXPnom is None:
            self.layerINFEXPnom = self.conf.expropiacion["EXPlayerINFOEXPRO"]

        # EXCEL - Archivo de expedientes
        self.ExcelInfEXPRO = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPFichExcelInfEXPRO")
        if self.ExcelInfEXPRO is None:
            self.ExcelInfEXPRO = self.conf.expropiacion["EXPFichExcelInfEXPRO"]
        # print(f"Archivo Excel configurado: {self.ExcelInfEXPRO}")  # Para debug


        #  SE ESTUDIA SI NO ESTÁN LAS CAPAS LIMITES DE EXPROPIACION Y NOTIF. COLINDANCIA
        if len(QgsProject.instance().mapLayersByName(layerLIMInom))==0 or  len(QgsProject.instance().mapLayersByName(self.layerINFEXPnom))==0:
            # Obtener los valores de las capas
            lim_expro = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPlayerLIMEXPRO")
            info_expro = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPlayerINFOEXPRO")

            text = (
                "<html>"
                "<body>"
                f"<h1 style='font-size:10pt; color:#34495E;'><b>INVESTIGACIÓN DE INVASIÓN DE 'DOMINIOS PÚBLICOS'</b></h1>"
                "<br>"
                f"<h2 style='color:#E74C3C;'>No están cargadas las capas configuradas:</h2>"
                "<br>"
                f"<p><b style='font-size:9pt;'>EXP capa LIM. EXPRO:</b> <span style='color:#16A085; font-weight:bold;'>{lim_expro}</span></p>"
                f"<p><b style='font-size:9pt;'>EXP capa INFO.EXPRO:</b> <span style='color:#16A085; font-weight:bold;'>{info_expro}</span></p>"
                "</body>"
                "</html>"
            )
            text2 = (
                "<html>"
                "<body style='text-align: center;'>"  # 👈 Centra todo el contenido del body
                f"<h1 style='font-size:10pt; color:#34495E;'><b>DEBE CARGAR EN LA VISTA LAS CAPAS CONFIGURADAS</b></h1>"
                "</body>"
                "</html>"
            )
            self.fun.showMessageERR(text, text2, tittle="JCCM")
            self.continue_initialization = False
            self.close()
            return

        self.btnAbrirAbajo.setArrowType(Qt.ArrowType.UpArrow)
        self.tabWidget.setCurrentIndex(4)
        self.tabWidget.setFixedSize(800, 500)
        self.lblINFOSUP.setText(u'Paso '+self.tabWidget.tabText(self.tabWidget.currentIndex()))
        self.btnANTERIOR.setVisible(1)
        self.btnSIGUIENTE.setVisible(1)
        self.lblINFOSUP.setVisible(1)

        self.lblCapaLIMEXPRO.setText(u'CAPA LIM.DOM.PUBLICO:  %s'%(layerLIMInom))
        self.lblCapaINFOEXPRO.setText(u'CAPA NOTIF. COLINDANCIA:  %s'%(self.layerINFEXPnom))

        # Control de cambios de TABS
        self.tabWidget.currentChanged.connect(self.onChange)

        self.btnANTERIOR.clicked.connect(lambda: self.botonAntSig(1))
        self.btnSIGUIENTE.clicked.connect(lambda: self.botonAntSig(2))
        self.btnSelectCapasTRAB.clicked.connect(self.herrDP_CONFIG)

        # RÓTULO DE 'NO RESPONDE CATASTRO'
        self.lblNOCATASTRO.setVisible(0)

        self.fechaACT = QDate.currentDate().toString('yyyy_MM_dd')
               
        # HISTÓRICO. Restos de controloes de actuaciones para minimizar el menú
        self.btnAbrirAbajo.setVisible(0)
        self.btnAbrirAbajo.clicked.connect(lambda: self.botonAmpliarAbajo())
        self.botonAbajo = 'U'
        
        QApplication.restoreOverrideCursor()


        #----------------------------------------------------------------------------------------------------
        #       PASO 1. Buscador de parcelas catastrales
        #       CONTROLES
        #----------------------------------------------------------------------------------------------------
        # Controlamos el estado de los radiobutton
        self.cambiaWIDGETStipoPOLIG()
        self.rbt_PAR_CATAST.toggled.connect(self.cambiaWIDGETStipoPOLIG)
        self.rbt_FICHERO_POL.toggled.connect(self.cambiaWIDGETStipoPOLIG)

        lista_provincias, lista_cpine = self.fun.getProvinciasCatastro()
        self.combo_provincia.clear()
        if lista_provincias is not None and lista_provincias != 'nocat':
            self.combo_provincia.addItems(lista_provincias)
            lastProvSelect = self.qs.value(f"{self.nombre_plugin}/last/lastProvSelect")
            if lastProvSelect in lista_provincias:
                self.combo_provincia.setCurrentIndex(lista_provincias.index(lastProvSelect))
        else:
            self.lblNOCATASTRO.show()
            return None

        # Se colocan los valores por defecto con el último valor tecleado
        #----------------------------------------------------------------------
        lastRC14Select = self.qs.value(f"{self.nombre_plugin}/last/lastRC14Select")
        self.ref_catastral.setText(lastRC14Select)
        lastIdufirSelect = self.qs.value(f"{self.nombre_plugin}/last/lastIdufirSelect")
        self.idufirREGISTRO.setText(lastIdufirSelect)
        lastNPOLSelect = self.qs.value(f"{self.nombre_plugin}/last/lastNPOLSelect")
        self.poligono.setText(lastNPOLSelect)
        lastNPARSelect = self.qs.value(f"{self.nombre_plugin}/last/lastNPARSelect")
        self.parcela.setText(lastNPARSelect)

        self.fun.updateCombos(self) # Actualiza el combo Municipios a los de la Provincia

        # self.addParcCatastrales()   # Añade las parcelas catastrales seleccionadas desde fichero si existe
        QTimer.singleShot(500, self.addParcCatastrales)

        self.addToListRCButton.clicked.connect(lambda: self.fun.addRCtoListClicked(self))
        self.addToListRusticaButton.clicked.connect(lambda: self.fun.addToListRusticaButtonClicked(self))
        self.zoomYCerrarButton.clicked.connect(lambda: self.cargarParcelas())
        self.quitarItemButton.clicked.connect(lambda: self.fun.quitarSelectedItemsList(self, 'INF'))
        self.limpiarListaButton.clicked.connect(lambda: self.fun.limpiarListaClicked(self))
        self.btnBUSCRegistro.clicked.connect(lambda: self.fun.BUSCRegistro(self))

        self.combo_provincia.currentIndexChanged.connect(lambda: self.fun.updateCombos(self))

        # Acciones con ENTER en textlines
        self.ref_catastral.returnPressed.connect(lambda: self.fun.addRCtoListClicked(self))
        self.parcela.returnPressed.connect(lambda: self.fun.addToListRusticaButtonClicked(self))

        # Acciones para el caso de ANÁLISIS CONTRA CAPA DE POLÍGONOS
        lista_CAPAS = self.getCAPAS()
        self.cbxCapaentrada.currentIndexChanged.connect(self.actualizarCampos) # ACTUALIZA CAMPOS SI CAMBIAS LA TABLA SELECCIONADA

        self.cbxCapaentrada.clear()
        self.cbxCapaentrada.addItems(lista_CAPAS)
        
        # ========== NUEVO: Conectar señal de cambio en listaRCs ==========
        self.listaRCs.itemChanged.connect(self.on_listaRCs_changed)
        self.listaRCs.model().rowsInserted.connect(self.on_listaRCs_changed)
        self.listaRCs.model().rowsRemoved.connect(self.on_listaRCs_changed)
        
        # Inicializar estado de controles según listaRCs al inicio
        QTimer.singleShot(100, self.actualizar_estado_controles)


        #----------------------------------------------------------------------------------------------------
        #       PASO 2. Geoproceso
        #       CONTROLES
        #----------------------------------------------------------------------------------------------------
        if self.tipoDP != 'MUNICIPAL':
            # Expediente de expropiaciones de caarreteras de la JCCM
            self.tablaRefCatResult.setHorizontalHeaderLabels([
                'EX-NUM', 'RefCat', 'RESULTADO', 'Expte.Expro', 'CTRA', 'PKini', 'PKfin', 'T.Municipal', 'Inv.Max', 'SupInv'
                ])
            # ANCHO 650
            self.tablaRefCatResult.setColumnWidth(0, 100)   # 0 EX-NUM
            self.tablaRefCatResult.setColumnWidth(1, 95)    # 1 RefCat
            self.tablaRefCatResult.setColumnWidth(2, 85)    # 2 RESULTADO
            self.tablaRefCatResult.setColumnWidth(3, 85)    # 3 Expte.Expro
            self.tablaRefCatResult.setColumnWidth(4, 65)    # 4 CTRA
            self.tablaRefCatResult.setColumnWidth(5, 45)    # 5 PKini
            self.tablaRefCatResult.setColumnWidth(6, 45)    # 6 PKfin
            self.tablaRefCatResult.setColumnWidth(7, 130)   # 7 T.Municipal
            self.tablaRefCatResult.setColumnWidth(8, 40)    # 8 Invasión Máxima
            self.tablaRefCatResult.setColumnWidth(9, 40)    # 9 Sup. Invasión

        else:
            # Expediente de Dominio Público municipal
            self.tablaRefCatResult.setHorizontalHeaderLabels([
                'EXPEDIENTE', 'REF_CAT', 'RESULTADOS', 'ID_CAMINO', 'NOMBRE', 'Inv.Max', 'ANCHO', 'DAT02', 'DAT03', 'DAT04'
                ])
            # ANCHO 650
            self.tablaRefCatResult.setColumnWidth(0, 90)    # 0 EXPEDIENTE
            self.tablaRefCatResult.setColumnWidth(1, 100)   # 1 REF_CAT
            self.tablaRefCatResult.setColumnWidth(2, 100)   # 2 RESULTADOS
            self.tablaRefCatResult.setColumnWidth(3, 80)    # 3 ID_CAMINO
            self.tablaRefCatResult.setColumnWidth(4, 190)   # 4 NOMBRE
            self.tablaRefCatResult.setColumnWidth(5, 55)    # 5 Inv.Max
            self.tablaRefCatResult.setColumnWidth(6, 25)    # 6 ANCHO
            self.tablaRefCatResult.setColumnWidth(7, 15)    # 7 DAT02
            self.tablaRefCatResult.setColumnWidth(8, 40)
            self.tablaRefCatResult.setColumnWidth(9, 40)

        self.le_manual_expte = None  # Valor de linea de num expediente manual

        self.cambiaWIDGETStipoEXPTE()
        self.rbt_CrearExpediente.toggled.connect(self.cambiaWIDGETStipoEXPTE)
        self.rbt_AnalizarColindancia.toggled.connect(self.cambiaWIDGETStipoEXPTE)

        self.btnAnalisisCOLINDANCIA.clicked.connect(lambda: self.intersectParcelas(proviEXPRO, layerPARCnom, layerLIMInom, self.layerINFEXPnom))
        self.btnASIGNAR_EXPTE.clicked.connect(lambda: self.asignarTIPO_EXPTE(proviEXPRO, layerPARCnom, layerLIMInom, self.layerINFEXPnom))

        # Rellenar combo Asignar Tipo EXPTE
        self.dictTIPOEXPTE = current_configuration.dictTIPOEXPTE
        self.listTIPOEXPTE = current_configuration.listTIPOEXPTE
        self.cbx_AsignarTipoEXPTE.clear()
        self.cbx_AsignarTipoEXPTE.addItems(self.listTIPOEXPTE)

        self. qleExpteByDIRECT.setEnabled(False)

        self.btnASIGNAEXPTE.clicked.connect(self.asignaExptes)
        self.chbRESTOPARC.setEnabled(True)
        self.btnASIGNAEXPTE.setEnabled(False)
        self.chbASIGNATODOENUNO.setEnabled(False)
        self.chbASIGNATODOENUNO.setChecked(True)

        # Calculamos ambos números de expediente y configuramos la UI
        self.configurar_asignacion_exptes()

        # Conectar la señal de los radiobuttons para actualizar el line edit activo
        self.rbtAsignaByDIRECT.toggled.connect(self.actualizar_lineedit_activo)
        self.rbtAsignaByEXCEL.toggled.connect(self.actualizar_lineedit_activo)

        # Añadir tooltips para claridad
        self.rbtAsignaByDIRECT.setToolTip("Usar el último expediente encontrado en la estructura de directorios.")
        self.rbtAsignaByEXCEL.setToolTip("Usar el último expediente encontrado en el archivo Excel.")

        self.chbASIGNATODOENUNO.clicked.connect(self.cambiaASIGNATODOENUNO)
        self.lblINFO.hide()
        self.progressBar.hide()


        #----------------------------------------------------------------------------------------------------
        #       PASO 3. CAMBIA ATRIBUTOS
        #       CONTROLES
        #----------------------------------------------------------------------------------------------------
        self.gpbDATOSEXPRO.setEnabled(False)
        self.gpbDATOSDP.setEnabled(False)
        self.btnCREAEXPTE.setEnabled(False)
        self.btnGENERAGML.setEnabled(False)
        self.spbINFORMES.setEnabled(False)

        if self.tipoDP != 'MUNICIPAL':
            self.gpbDATOSEXPRO.show()
            self.gpbDATOSDP.hide()
        else:
            self.gpbDATOSEXPRO.hide()
            self.gpbDATOSDP.show()

        self.spbINFORMES.setMinimum(1)
        self.spbINFORMES.setMaximum(1)
        self.spbINFORMES.valueChanged.connect(lambda: self.colocaAtributosExpte())
        self.EX_ESTAARCHIVADO.hide()    # Se esconden estos controles innecesarios
        self.EX_FECHAARCHIVO.hide()     # Se esconden estos controles innecesarios
        self.btnCREAEXPTE.clicked.connect(lambda: self.creaEXPTE(proviEXPRO, layerLIMInom, self.layerINFEXPnom))
        self.btnGENERAGML.clicked.connect(lambda: self.generaGML(self.layerINFEXPnom))


        #----------------------------------------------------------------------------------------------------
        #       PASO 4. GENERA PLANO
        #       CONTROLES
        #----------------------------------------------------------------------------------------------------
        self.projectLayoutManager = QgsProject.instance().layoutManager()

        # Añade todos los diseñadores en el proyecto
        Layouts = self.projectLayoutManager.layouts()
        for layout in Layouts:
            # print (u'Diseñador - titulo- ='+layout.name())
            QListWidgetItem(layout.name(), self.Layout_list)
        self.Layout_list.setCurrentRow(0)
        if len(self.Layout_list) != 0:
            self.cambiaComposer(Layouts[self.Layout_list.currentRow()])
            self.cbxVARMAPA.setEnabled(True)
            # self.lneVARMAPA.setEnabled(True)
        else:
            self.cbxVARMAPA.setEnabled(False)
            # self.lneVARMAPA.setEnabled(False)

        # Controla el tipo y datos del LAYOUT
        self.Layout_list.currentItemChanged.connect(self.cambiaComposer)
        self.btnPresentation.clicked.connect(lambda: self.get_salidaPRESEN(iface, 'Presen'))

        # Se desactivan Botones De La Impresion
        self.Layout_list.setEnabled(False)
        self.cbxVARMAPA.setEnabled(False)
        self.lneVARMAPA.setEnabled(False)
        self.lneTITULO.setEnabled(False)
        self.lneESCALA.setEnabled(False)
        self.btnPresentation.setEnabled(False)

    #----------------------------------------------------------------------------------------------------
    # ***    FUNCIONES GENÉRICAS     ***
    #----------------------------------------------------------------------------------------------------
    def exec(self):
        """Sobrescribir exec_ para verificar si debemos continuar."""
        if not self.continue_initialization:
            return QDialog.DialogCode.Rejected
        return super().exec()


    def cambiaWIDGETStipoPOLIG(self):
        if self.rbt_PAR_CATAST.isChecked():
            self.frame_BUSQ_CATASTRAL.setEnabled(True)
            self.frame_BUSQ_FICHPOLI.setEnabled(False)
        else:
            self.frame_BUSQ_CATASTRAL.setEnabled(False)
            self.frame_BUSQ_FICHPOLI.setEnabled(True)
        return


    def cambiaWIDGETStipoEXPTE(self):
        if self.rbt_AnalizarColindancia.isChecked():
            self.btnAnalisisCOLINDANCIA.setEnabled(True)
            self.chbRESTOPARC.setEnabled(True)
            self.lbl_TolInv.setEnabled(True)
            self.qleTOLINV.setEnabled(True)
            # self.btnASIGNAEXPTE.setEnabled(False)
            # self.chbASIGNATODOENUNO.setEnabled(False)
            # self. qleExpteByDIRECT.setEnabled(False)
            self.btnASIGNAR_EXPTE.setEnabled(False)
            self.cbx_AsignarTipoEXPTE.setEnabled(False)
        else:
            self.btnAnalisisCOLINDANCIA.setEnabled(False)
            self.chbRESTOPARC.setEnabled(False)
            self.lbl_TolInv.setEnabled(False)
            self.qleTOLINV.setEnabled(False)
            # self.btnASIGNAEXPTE.setEnabled(True)
            # self.chbASIGNATODOENUNO.setEnabled(True)
            # self. qleExpteByDIRECT.setEnabled(True)
            self.btnASIGNAR_EXPTE.setEnabled(True)
            self.cbx_AsignarTipoEXPTE.setEnabled(True)
        return


    def getCAPAS(self):
        capas = []
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == QgsMapLayer.VectorLayer:
                if layer.wkbType() == QgsWkbTypes.Polygon:
                    feat=layer.featureCount()
                    featsel=layer.selectedFeatureCount()
                    capas.append(layer.name())
                if layer.wkbType() == QgsWkbTypes.MultiPolygon:
                    feat=layer.featureCount()
                    featsel=layer.selectedFeatureCount()
                    capas.append(layer.name())
        return capas


    def actualizarCampos(self):
        layername = self.cbxCapaentrada.currentText()
        if layername == "":
            self.fun.showMessage("Debes cargar una capa (SHP o GPKG) de POLÍGONOS en la tabla de contenidos")
            return None
        selected_table = self.fun.getLayerByName(layername)
        fields = selected_table.fields()
        text_fields = []
        numeric_fields = [""]
        for field in fields:
            text_fields.append(field.name())

        self.cbx_campos.clear()
        self.cbx_campos.addItems(text_fields)

        campoLOCALIDtipo = 'RC14'
        if campoLOCALIDtipo in text_fields or campoLOCALIDtipo.lower() in text_fields:
            try:
                self.cbx_campos.setCurrentIndex(text_fields.index(campoLOCALIDtipo))
            except:
                self.cbx_campos.setCurrentIndex(text_fields.index(campoLOCALIDtipo.lower()))


    def onChange(self,i): #changed!
        tabname = self.tabWidget.tabText(i)
        self.lblINFOSUP.setText('Paso '+tabname)
        # print ("Actual Tab: %d %s" % (i, tabname))
        if i==3:                # 3.Análisis Resultados
            self.addParcCatastralesANALISIS()
            pass


    def botonAntSig(self,sentido):
        # Sentido = 1 > ANTERIOR
        # Sentido = 2 > SIGUIENTE
        actIndex = self.tabWidget.currentIndex()
        # print ('Pestaña actual:', actIndex, self.tabWidget.tabText(actIndex))
        self.btnANTERIOR.setEnabled(True)
        self.btnSIGUIENTE.setEnabled(True)

        if sentido == 1:
            self.tabWidget.setCurrentIndex(actIndex+1)
        elif actIndex>2:
            self.tabWidget.setCurrentIndex(actIndex-1)

        self.lblINFOSUP.setText(u'Paso '+self.tabWidget.tabText(self.tabWidget.currentIndex()))
        self.logo.setVisible(1)
        self.setFixedSize(810, 590)
        self.btnAbrirAbajo.setArrowType(Qt.ArrowType.UpArrow)
        self.botonAbajo = 'U'


    def botonAmpliarAbajo(self):
        if self.botonAbajo == 'D':
            self.logo.setVisible(1)
            self.setFixedSize(810, 590)
            self.btnAbrirAbajo.setArrowType(Qt.ArrowType.UpArrow)
            self.botonAbajo = 'U'
        elif self.botonAbajo == 'U':
            self.logo.setVisible(1)
            self.setFixedSize(810, 75)
            self.btnAbrirAbajo.setArrowType(Qt.ArrowType.DownArrow)
            self.botonAbajo = 'D'

    def actualizar_contador_registros(self):
        """
        Actualiza el contador de registros en formato "nnnnn de mmmmm"
        """
        total = len(self.registros_excel) if hasattr(self, 'registros_excel') else 0
        
        if self.filtro_pendientes and hasattr(self, 'registros_filtrados'):
            # Si hay filtro activo, usar el índice filtrado
            indice_mostrar = self.indice_filtrado_actual + 1 if self.indice_filtrado_actual >= 0 else 0
            total_mostrar = len(self.registros_filtrados)
        else:
            # Sin filtro, usar el índice normal
            indice_mostrar = self.indice_excel_actual + 1 if self.indice_excel_actual >= 0 else 0
            total_mostrar = total
        
        # Formatear el texto
        if total_mostrar > 0:
            texto = f"{indice_mostrar} de {total_mostrar}"
        else:
            texto = "0 de 0"
        
        self.numElementos.setText(texto)
        
        # Opcional: cambiar color si hay filtro activo
        if self.filtro_pendientes:
            self.numElementos.setStyleSheet("background-color: #FFF3CD; color: #856404;")  # Amarillo suave
        else:
            self.numElementos.setStyleSheet("")  # Restaurar estilo por defecto


    def tbtSelectFileDir_clicked(self, line_edit, is_file=True, file_filter=None, title=None):
        """
        Método unificado para seleccionar archivos o directorios.
        
        :param line_edit: QLineEdit donde se mostrará la ruta seleccionada
        :param is_file: True para seleccionar archivo, False para seleccionar directorio
        :param file_filter: Filtro para archivos (ej: "*.gpkg", "*.qml", "*.txt")
        :param title: Título personalizado para el diálogo
        """
        try:
            # Obtener la ruta actual del line_edit
            current_path = line_edit.text().strip()
            
            # Determinar el directorio inicial
            if current_path and os.path.exists(current_path):
                if is_file:
                    initial_dir = os.path.dirname(current_path)
                else:
                    initial_dir = current_path
            else:
                # Usar el último directorio guardado según el tipo
                last_dir_key = f"{self.nombre_plugin}/last/{'Fichero' if is_file else 'Carpeta'}Busq"
                initial_dir = self.qs.value(last_dir_key, "")
            
            # Título por defecto
            if not title:
                title = self.tr("Seleccionar {}").format("archivo" if is_file else "directorio")
            
            if is_file:
                # Filtro por defecto
                if not file_filter:
                    file_filter = self.tr("Todos los archivos (*.*)")
                
                file_path, _ = QFileDialog.getOpenFileName(
                    self,
                    title,
                    initial_dir,
                    file_filter
                )
                
                if file_path:
                    # Guardar el directorio para próxima vez
                    self.qs.setValue(f"{self.nombre_plugin}/last/FicheroBusq", 
                                     os.path.dirname(file_path))
                    line_edit.setText(file_path)
                    
            else:
                dir_path = QFileDialog.getExistingDirectory(
                    self,
                    title,
                    initial_dir,
                    QFileDialog.Option.ShowDirsOnly | QFileDialog.Option.DontResolveSymlinks
                )
                
                if dir_path:
                    self.qs.setValue(f"{self.nombre_plugin}/last/CarpetaBusq", dir_path)
                    line_edit.setText(dir_path)
                    
        except Exception as e:
            from qgis.core import Qgis
            self.iface.messageBar().pushMessage(
                self.tr("Error"),
                self.tr(f"Error al seleccionar: {str(e)}"),
                level=Qgis.Critical,
                duration=3
            )

    def closeEvent(self, event):
        QApplication.restoreOverrideCursor()
        self.close()

    def get_layer_seguro(self, nombre_capa):
        """Obtiene una capa de forma segura, retorna None si no existe"""
        capas = QgsProject.instance().mapLayersByName(nombre_capa)
        if not capas:
            self.fun.showMessageERR(f"La capa '{nombre_capa}' no está cargada en el proyecto")
            return None
        return capas[0]
    
    
    #----------------------------------------------------------------------------------------------------
    #           PASO 1. Buscador de parcelas catastrales
    #----------------------------------------------------------------------------------------------------
    # Esta parte es similar al buscador CATASTRAL del plugin
    # Se unifican las funciones para no repetirlas
    # ***************************************************************************/
      
    def cargarParcelas(self):
        self.fun.zoomToCurrentList(False, tipoCARGA, self)
        self.addParcCatastrales()
        # NUEVO: Actualizar estado después de cargar parcelas
        self.actualizar_estado_controles()
        pass

    def addParcCatastrales(self):
        """
        Añade a la lista de RCs todas las referencias catastrales 
        que existen en la capa 'PARCELAS CATASTRALES'
        """
        layerPARCnom = 'PARCELAS CATASTRALES'

        # Verificar si la capa existe
        if len(QgsProject.instance().mapLayersByName(layerPARCnom)) == 0:
            print("addParcCatastrales: La capa 'PARCELAS CATASTRALES' no existe")
            return

        layerPARC = self.get_layer_seguro(layerPARCnom)
        if not layerPARC:
            return

        # Limpiar la lista actual antes de añadir (para evitar duplicados)
        self.listaRCs.clear()
        
        # Obtener features (seleccionados o todos)
        countlayerPARC = layerPARC.selectedFeatureCount()
        if countlayerPARC > 0:
            featureslayerPARC = layerPARC.selectedFeatures()
        else:
            featureslayerPARC = layerPARC.getFeatures()

        countFeat = 0
        for featLayerPARC in featureslayerPARC:
            RC14 = featLayerPARC["RC14"]
            if RC14:
                # Asegurar que no haya duplicados en la lista
                rc_text = RC14[:14]
                if len(self.listaRCs.findItems(rc_text, Qt.MatchFlag.MatchExactly)) == 0:
                    self.listaRCs.addItem(rc_text)
                    countFeat += 1

        self.lblListaREFS.setText(u'Lista de REF CAT (%s)' % (countFeat))
        print(f"addParcCatastrales: Se añadieron {countFeat} RCs a la lista")
        
        # Actualizar estado de controles después de cargar la lista
        self.actualizar_estado_controles()


    def addParcCatastralesANALISIS(self):
        if self.rbt_PAR_CATAST.isChecked():
            # Caso de parcelas catastrales
            layerPARCnom = 'PARCELAS CATASTRALES'
            if len(QgsProject.instance().mapLayersByName(layerPARCnom))==0:
                return
            # layerPARC = QgsProject.instance().mapLayersByName(layerPARCnom)[0]
            layerPARC = self.get_layer_seguro(layerPARCnom)
            if not layerPARC:
                return
                        
            countlayerPARC = layerPARC.selectedFeatureCount()
            featureslayerPARC = layerPARC.getFeatures()
            if countlayerPARC > 0:
                featureslayerPARC = layerPARC.selectedFeatures()

            for featLayerPARC in featureslayerPARC:      #Cada elemento de la capa PARCELAS. Se llamará featLayerPARC
                RC14 = featLayerPARC["RC14"]
                if RC14:
                    flag = False
                    # Comprobamos si está ya metida la RC14 en tablaRefCatResult
                    for row in range(self.tablaRefCatResult.rowCount()):
                        if RC14 == self.tablaRefCatResult.item(row,1).text():
                            flag = True
                    if flag == False:
                        # Añadimos una fila de análisis
                        rowPosition = self.tablaRefCatResult.rowCount()
                        self.tablaRefCatResult.insertRow(rowPosition)
                        self.tablaRefCatResult.setItem(rowPosition , 1, QTableWidgetItem(RC14[:14]))
            self.btnAnalisisCOLINDANCIA.setEnabled(True)
        else:
            ### TODO ANÁLISIS DE INVASIÓN DEL D.P. POR FICHERO ALTERNATIVO
            text = 'ESTAMOS TRABAJANDO EN EL CÁLCULO DE INVASIONES DE POLÍGONOS'
            text +='\n\n -- DE MOMENTO NO FUNCIONA --'
            # print (text)
            self.fun.showMessage(u'ANÁLISIS DE INVASIÓN DEL D.P. POR FICHERO ALTERNATIVO', text)
            QApplication.restoreOverrideCursor()
            self.btnAnalisisCOLINDANCIA.setEnabled(False)

    def buscaRegistroProp(self, idufir):
        # https://geoportal.registradores.org/geoportal/index.html?idVisor=2&idufir=02009000992832
        idufir = '02008000768300'
        return

    # ======================================================================
    # MÉTODOS PARA CONTROL DE ESTADO DE CONTROLES SEGÚN listaRCs
    # ======================================================================

    def on_listaRCs_changed(self, *args):
        """Callback cuando cambia la lista de RCs (se añade o elimina elemento)"""
        self.actualizar_estado_controles()

    def actualizar_estado_controles(self):
        """
        Actualiza el estado de los botones y pestañas según:
        1. Si listaRCs está vacío -> desactivar botón CARGAR y todas las pestañas excepto la 1ª
        2. Si hay RCs -> activar todas las pestañas
        3. Estado del botón CARGAR según si todas las RCs ya están cargadas
        """
        # Obtener todas las RCs de la lista
        rcs_en_lista = [self.listaRCs.item(i).text() for i in range(self.listaRCs.count())]
        
        # 1. Control del botón zoomYCerrarButton (CARGAR)
        self.actualizar_estado_boton_cargar(rcs_en_lista)
        
        # 2. Control de pestañas del tabWidget
        self.actualizar_estado_pestanas(rcs_en_lista)

    def actualizar_estado_boton_cargar(self, rcs_en_lista):
        """
        Actualiza el estado y estilo del botón zoomYCerrarButton.
        - Desactivado y rojo: si lista vacía O todas las RCs están cargadas
        - Activado y verde: si alguna RC NO está cargada en la capa
        """
        btn = self.zoomYCerrarButton
        
        if not rcs_en_lista:
            # Lista vacía: desactivar
            self._set_boton_cargar_estado(btn, False, 'rojo')
            return
        
        # Verificar qué RCs están cargadas en la capa
        rcs_cargadas = self._obtener_rcs_cargadas_en_capa()
        
        # Comprobar si todas las RCs de la lista están cargadas
        todas_cargadas = all(rc in rcs_cargadas for rc in rcs_en_lista)
        
        if todas_cargadas:
            # Todas están cargadas: desactivar botón (rojo)
            self._set_boton_cargar_estado(btn, False, 'rojo')
        else:
            # Alguna no está cargada: activar botón (verde)
            self._set_boton_cargar_estado(btn, True, 'verde')

    def _set_boton_cargar_estado(self, btn, habilitado, color):
        """Establece estado y estilo del botón CARGAR"""
        btn.setEnabled(habilitado)
        
        if color == 'rojo':
            # Rojo pálido
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #ffcccc;
                    color: #8b0000;
                    border: 1px solid #cc0000;
                    border-radius: 3px;
                }
                QPushButton:disabled {
                    background-color: #ffcccc;
                    color: #8b0000;
                }
            """)
        else:  # verde
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #ccffcc;
                    color: #006400;
                    border: 1px solid #00aa00;
                    border-radius: 3px;
                }
                QPushButton:enabled {
                    background-color: #ccffcc;
                }
                QPushButton:hover:enabled {
                    background-color: #aaffaa;
                }
            """)

    def actualizar_estado_pestanas(self, rcs_en_lista):
        """
        Actualiza qué pestañas están habilitadas.
        Todas las pestañas excepto la 1ª se habilitan solo si hay RCs en la lista.
        """
        tiene_rcs = len(rcs_en_lista) > 0
        
        # Recorrer todas las pestañas
        for i in range(self.tabWidget.count()):
            tab_text = self.tabWidget.tabText(i)
            
            if tab_text == '1.Buscador de Parcelas':
                # La primera pestaña siempre habilitada (índice actual depende)
                self.tabWidget.setTabEnabled(i, True)
            else:
                # Las demás pestañas solo se habilitan si hay RCs
                self.tabWidget.setTabEnabled(i, tiene_rcs)

    def _obtener_rcs_cargadas_en_capa(self):
        """
        Obtiene el conjunto de RCs (campo RC14) que existen en la capa 'PARCELAS CATASTRALES'.
        Returns:
            set: Conjunto de referencias catastrales cargadas
        """
        rcs_cargadas = set()
        
        layerPARCnom = 'PARCELAS CATASTRALES'
        
        # Verificar si la capa existe
        capas = QgsProject.instance().mapLayersByName(layerPARCnom)
        if not capas:
            print("_obtener_rcs_cargadas_en_capa: Capa no encontrada")
            return rcs_cargadas
        
        layerPARC = capas[0]
        
        # Obtener features (seleccionados o todos)
        if layerPARC.selectedFeatureCount() > 0:
            features = layerPARC.selectedFeatures()
        else:
            features = layerPARC.getFeatures()
        
        for feat in features:
            rc = feat["RC14"]
            if rc:
                rcs_cargadas.add(rc[:14] if len(rc) >= 14 else rc)
        
        print(f"_obtener_rcs_cargadas_en_capa: {len(rcs_cargadas)} RCs encontradas en la capa")
        return rcs_cargadas


    #----------------------------------------------------------------------------------------------------
    #           PASO 2. Analisis de Resultados
    #----------------------------------------------------------------------------------------------------
    # *** FUNCIONES ***
    # intersectParcelas()
    # asignaExptes()

    def intersectParcelas(self, proviEXPRO, layerPARCnom, layerLIMInom, layerINFEXPnom):
        #----------------------------------------------------------------------------------------------------
        # --- CAMPOS DE BD EXPLOTACIÓN ---
        #----------------------------------------------------------------------------------------------------
        # EX_NUM,                                         # 00 NUMEXPRO
        # '',                                             # 01 REGISTRO
        # QDate.currentDate(),                            # 02 FECHA          --- VER ESTA ---
        # '',                                             # 03 SOLICITANTE
        # '',                                             # 04 INTERESADO
        # '',                                             # 05 DNI
        # '',                                             # 06 NOMBRE
        # '',                                             # 07 DOMICILIO
        # '',                                             # 08 CODIGOPOST
        # '',                                             # 09 TLFNO
        # '',                                             # 10 POBLACION
        # self.tablaRefCatResult.item(numOrden,4).text(), # 11 CARRETERA
        # self.tablaRefCatResult.item(numOrden,5).text(), # 12 KILOMETRO
        # self.tablaRefCatResult.item(numOrden,6).text(), # 13 KILOMET2
        # 'Ambas',                                        # 14 MARGEN
        # '',                                             # 15 OBSERVAPK
        # txtTIPO,                                        # 16 TIPO
        # '',                                             # 17 ARCHIVO
        # '',                                             # 18 IG
        # '',                                             # 19 INGENIERO
        # '',                                             # 20 ADMIN
        # '',                                             # 21 ESTAARCHIVADO
        # '',                                             # 22 FECHAARCHIVO       --- VER ESTA ---
        # self.tablaRefCatResult.item(numOrden,3).text(), # 23 EXPTE_EXPROPIACION
        # '',                                             # 24 EXPTES_RELACIONADOS
        # NOM_TRAMO,                                      # 25 NOMBRE_TRAMO
        # '',                                             # 26 DECR_ACUERDO_RESOLUCION
        # '',                                             # 27 ACTAS_PREVIAS
        # CAT_REMISI,                                     # 28 REMISION_CATASTRAL --- VER ESTA ---
        # '',                                             # 29 NUMORDEN
        # '',                                             # 30 POLIGONO
        # '',                                             # 31 PARCELAS
        # TM,                                             # 32 TM
        # TIPO_EXPEDIENTE,                                # 33 TIPO_EXPEDIENTE
        # QDate.currentDate(),                            # 34 FECHAINFORME        --- VER ESTA ---
        # NOM_PROYEC,                                     # 35 TITULO_EXPROPIACION
        # '',                                             # 36 EX_EXPTE_OBRA_RELACIONADO
        # RC14,                                           # 37 REF_CATASTRAL
        # QDate.currentDate(),                            # 38 FECHA_ULTIMO_TRAMITE --- VER ESTA ---
        # 'Entrada Solicitud',                            # 39 TRAMITE_EXPROPIACION
        # ''                                              # 40 CORREOELEC
        # ''                                              # 41 PROTOCOLO COMUNICACIÓN REGISTRO
        # 'S/D'                                           # 42 ART_LEY

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)   # Cursor TRABAJANDO

        # Validaciones iniciales
        if self.listaRCs.count() == 0:
            msg = u'NO HAY PARCELAS CATASTRALES PARA ANALIZAR'
            self.fun.showMessage(u'ANÁLISIS DE INVASIÓN DEL D.P.', msg)
            QApplication.restoreOverrideCursor()
            return
            
        # Obtener capas
        layerPARC = self.get_layer_seguro(layerPARCnom)
        layerLIMI = self.get_layer_seguro(layerLIMInom)
        if not layerPARC or not layerLIMI:
            QApplication.restoreOverrideCursor()
            return
        
        # Configurar UI
        self.lblINFO.show()
        self.progressBar.show()
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)
        self.progressBar.setValue(0)
        
        # Transformación de coordenadas
        sourceCrsAUTH = layerPARC.crs().authid()
        destCrsAUTH = layerLIMI.crs().authid()
        sourceCrs = QgsCoordinateReferenceSystem(sourceCrsAUTH)
        destCrs = QgsCoordinateReferenceSystem(destCrsAUTH)
        trPARC = QgsCoordinateTransform(sourceCrs, destCrs, QgsProject.instance())
        
        # CREAR CAPA DE RESULTADOS (AHORA ES UNA LÍNEA)
        result, fieldsLayerINT, fieldsLayerPARC, fieldsLayerLIMI = self.crear_capa_zonas_invadidas(layerPARC, layerLIMI)

        # Se detectan los elementos seleccionados
        feats = []
        countlayerPARC = layerPARC.selectedFeatureCount()
        featureslayerPARC = layerPARC.getFeatures()
        if countlayerPARC > 0:
            featureslayerPARC = layerPARC.selectedFeatures()
        else:
            countlayerPARC = layerPARC.featureCount()

        # Limpiamos la tabla de resultados
        self.tablaRefCatResult.setRowCount(0);

        # Se escribe un fichero de resultados
        # testfile = open('C:\Temp\IntersectTest.txt', 'w')
        temp_dir = tempfile.gettempdir()
        testfile_path = os.path.join(temp_dir, f"invasiones_{datetime.now():%Y%m%d_%H%M%S}.txt")
        testfile = open(testfile_path, 'w', encoding='utf-8')

        # Análisis de invasiones
        countINV = 1
        countParc = 1
        parcINVADIDAS = []

        # Tolerancia máxima de INVASIÓN
        tolmax = float(self.qleTOLINV.text())

        # HISTÓRICO - Variables que en versiones anteriores se usaba para seguimiento
        # parcelas_analizadas=[]                          # Declara la lista de polígonos 1
        # limites_relacionados=[]                         # Declara la lista de polígonos 2

        for featLayerPARC in featureslayerPARC:      #Cada elemento de la capa PARCELAS. Se llamará featLayerPARC
            TMUNIC = featLayerPARC["NOM_MUNI"]
            if featLayerPARC["RC14"]:
                RC14 = featLayerPARC["RC14"][:14]
                txtINFO = u'INFO: ANALIZANDO - '+ RC14 + '  ('+str(countParc)+'/'+str(countlayerPARC)+')'
                self.lblINFO.setText(txtINFO)
                self.iface.mainWindow().statusBar().showMessage(txtINFO)

                ### TODO ESTUDIAR PROGRESSBAR                       ### 
                # countParc += 1
                # self.progressBar.setValue(100*countParc/countlayerPARC)

                tipoINV='NO INVASION'
                countLayerLIMI = layerLIMI.selectedFeatureCount()
                featuresLayerLIMI = layerLIMI.getFeatures()

                precision = self.PRECISION_PUNTO_INACCESIBLE        # Precisión para obtener el poleOfInaccessibility
                tolmaxSup = self.TOLERANCIA_SUPERFICIE_MINIMA       # Tolerancia en metros cuadrados, bajo la cual se considera NO INVASIÓN
                distMinFeat = self.DISTANCIA_MINIMA_COLINDANCIA     # Distancia mínima para considerar 'colindante' una parcela a un DP

                # trPARC = QgsCoordinateTransform(sourceCrs, destCrs, QgsProject.instance())
                geomParc = featLayerPARC.geometry()
                geomParc.transform(trPARC)

                dataDICT ={}
                maxINV = 0
                perimetroProx = [100000, None]
                for featLayerLIMI in featuresLayerLIMI:
                    # Calculamos la min dist entre featLayerLIMI (LIMITES) y featLayerPARC (PARCELAS)
                    disFeats = QgsGeometry.distance(featLayerLIMI.geometry(), geomParc)
                    if disFeats <= distMinFeat:     # Cogemos el featLayerLIMI si disFeats <= distMinFeat
                        if disFeats < perimetroProx[0]: # Metemos el featLayerLIMI con la minima distancia a Parcela
                            perimetroProx = [disFeats, featLayerLIMI]

                    #Comprobamos si featLayerLIMI (LIMITES) y featLayerPARC (PARCELAS) intersectan
                    if featLayerLIMI.geometry().intersects(geomParc):
                        #----------------------------------------------------------------------------------------------------
                        #   - INVASIÓN -
                        #----------------------------------------------------------------------------------------------------
                        intersection = featLayerLIMI.geometry().intersection(geomParc)
                        # print (f'La intersección corta con {featLayerLIMI['EXPTE1']}')
                        multiparte = False
                        if intersection.isMultipart():
                            # Convertir multiparteMonoparte
                            print (f'La intersección de {RC14} es multiparte')
                            
                            ############     TODO. Analisis MultiPoligono       ############
                            # listGEOM = self.INVmultiparteMonoparte(intersection)
                            # message = f'La parcela {RC14} INVADE el DP en {str(len(listGEOM))} partes'
                            # intersection = listGEOM
                            ############     TODO. Analisis MultiPoligono       ############
                        
                            message = f'La parcela {RC14} INVADE el DP en varias partes'
                            QApplication.restoreOverrideCursor()
                            self.fun.showMessageERR( message,'','INVESTIGACIÓN DE INTERSECCIÓN' )
                            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)   # Cursor TRABAJANDO


                        try:
                            # Calculamos el polo de inaccesibilidad
                            resultINT = intersection.poleOfInaccessibility(precision)
                            maxINV = resultINT[1]*2
                        except:
                            txt = f'Algo falla en la intersección de la {RC14}\n\n'
                            txt+= self.fun.PrintException()
                            self.fun.showMessageERR(txt)
                            tipoINV='INT.ERRONEA'
                            resultINT = [0,0]
                            continue


                        # Calculamos CTRA y PK desde el poleOfInaccessibility
                        if self.tipoDP != 'MUNICIPAL':
                            # ctra, pkini, pkfin, distEJE, pointMin, pointMax = self.fun.poligToPKINIPKFIN(featLayerPARC.geometry(), self.iface,'NO')
                            ctra, pkini, pkfin, distEJE, pointMin, pointMax = self.fun.poligToPKINIPKFIN_RT(geomParc, self.iface,'NO')
                            # print ('ctra, pkini, pkfin, distEJE , tipoINV, pointMin, pointMax ', ctra, pkini, pkfin, distEJE, tipoINV, pointMin, pointMax)
                            if ctra is None:
                                QApplication.restoreOverrideCursor()
                                msg = 'ERROR INDETERMINADO'
                                self.fun.showMessage(u'ANÁLISIS DE INVASIÓN DEL D.P.', msg)
                                ctra = 's/d'
                                pkini = 0
                                pkfin = 0
                                distEJE = 0
                                QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)   # Cursor TRABAJANDO
                                # return ('Error')


                        # Analizamos si el diámetro desde el poleOfInaccessibility es mayor que la tolerancia
                        if resultINT[1]*2 < tolmax or intersection.area() < tolmaxSup :
                            ### TODO. VER ESTE ASUNTO
                            # if maxINV < tolmax or intersection.area() < tolmaxSup :
                            msg = 'La parcela  ' + RC14 + u'\n'
                            msg += 'INVASION con un polígono de '+ str(round(resultINT[1],3)) +u' m. máximo\n\n     SE IGNORA'
                            # self.fun.showMessage('ANÁLISIS DE POLIGONOS INVADIDOS', msg)

                        else:
                            tipoINV = 'INVASION'
                            # TMUNIC = featLayerPARC["NOM_MUNI"]

                            if self.tipoDP != 'MUNICIPAL':
                                # CASO DE DOMINIO PUBLICO CARRETERAS
                                # Hay que analizar el tipo de DP invadido
                                FUNCIONALI = featLayerLIMI['FUNCIONALI']
                                if FUNCIONALI == "DP" or FUNCIONALI == "CAMINO" or FUNCIONALI == "RESTOS":
                                    tipoINV = 'INVASION'
                                elif FUNCIONALI == "ARISTA":
                                    tipoINV = 'INVASION AEE'
                                elif FUNCIONALI == "PATRIMONIAL":
                                    tipoINV = 'INVASION BBPP'
                                elif FUNCIONALI == "DPREV" or FUNCIONALI == "OTRAS" or FUNCIONALI == "REVERTIDO":
                                    tipoINV = 'SIN CLASIFICAR'
                                elif ctra[3] != 'CM-':
                                    tipoINV = 'NO COLIND CTRA JCCM'
                                else:
                                    tipoINV = 'SIN CLASIFICAR'

                                parcINVADIDAS.append(featLayerPARC['RC14'][:14])

                                # Agregamos todos los ATRIBUTOS  de layerPARC y layerLIMI
                                textINF = u'Informe sobre INVASIÓN del Dominio Público de la parcela catastral RC %s del T.M de %s'%(RC14,TMUNIC)

                                dataDICT ={
                                  "fid"           : 999999999,                            # fid
                                  "rc14"          : RC14+'_01',                           # RC14
                                  "ex_num"        : tipoINV+str(countINV),                # EX_NUM
                                  "ex_tmunic"     : TMUNIC,                               # EX_TMUNIC
                                  "ex_textinf"    : textINF,                              # EX_TEXTINF
                                  "ex_supexpr"    : 0,                                    # EX_SUPEXPR
                                  "ex_supinf"     : format(intersection.area(), '.1f'),   # EX_SUPINF
                                  "ex_tipoinv"    : tipoINV,                              # EX_TIPOINV
                                  "ex_margen"     : 'Ambas',                              # ex_margen
                                  "ex_registro"   : '',                                   # ex_registro
                                  "ex_fecha"      : '',                                   # ex_fecha
                                  "ex_solicitante": '',                                   # ex_solicitante
                                  "ex_interesado" : '',                                   # ex_interesado
                                  "ex_nombre"     : '',                                   # ex_nombre
                                  "ex_dni"        : '',                                   # ex_dni
                                  "ex_tlfno"      : '',                                   # ex_tlfno
                                  "ex_correoelec" : '',                                   # ex_correoelec
                                  "ex_maxinv"     : format(maxINV, '.2f'),                # dp_maxinv
                                  "cat_nmspc"     : 'ES.LOCAL.CP',                        # CAT_NMSPC
                                  "ex_protocolo"  : '',                                   # ex_protocolo
                                  "ex_art_ley"    : 'S/D'                                 # ex_art_ley
                                }
                            else:
                                # CASO DE DOMINIO PUBLICO MUNICIPAL
                                parcINVADIDAS.append(featLayerPARC['RC14'][:14])

                                # Agregamos todos los ATRIBUTOS  de layerPARC y layerLIMI
                                textINF = u'Informe sobre posible invasión del Dominio Público de la parcela catastral RC %s'%(RC14)

                                dataDICT ={
                                  "fid"           : 999999999,                            # fid
                                  "expediente"    : tipoINV+str(countINV),                # expediente
                                  "dp_textinf"    : textINF,                              # dp_textinf
                                  "dp_supinf"     : format(intersection.area(), '.1f'),   # dp_supinf
                                  "dp_tipoinv"    : tipoINV,                              # dp_tipoinv
                                  "dp_registro"   : '',                                   # dp_registro
                                  "dp_fecha"      : '',                                   # dp_fecha
                                  "dp_solicitante": '',                                   # dp_solicitante
                                  "dp_interesado" : '',                                   # dp_interesado
                                  "dp_correoelec" : '',                                   # dp_correoelec
                                  "dp_maxinv"     : format(maxINV, '.2f'),                # dp_maxinv
                                  "cat_nmspc"     : 'ES.LOCAL.CP'                         # CAT_NMSPC
                                }

                            # Se agregan los atributos de la capa de PARCELAS
                            for field in fieldsLayerPARC:
                                if field.name().lower() != 'rc14':  # No se agrega RC14 pues ya se habrá agregado antes
                                    dataDICT[field.name().lower()] = featLayerPARC[field.name()]

                            # Se agregan los atributos de la capa de LIMITES DE DP
                            for field in fieldsLayerLIMI:
                                if field.name() == 'fid':
                                    dataDICT[field.name().lower()+'_E'] = featLayerLIMI['fid']
                                else:
                                    dataDICT[field.name().lower()] = featLayerLIMI[field.name()]

                            # Se calculan y alteran PKINI, PKFIN y margen
                            if self.tipoDP != 'MUNICIPAL':
                                # print ('pkini:', pkini, type(pkini), 'pkfin', pkfin, type(pkfin))
                                if ('pkini' in dataDICT) and ((type(pkini) == int) or (type(pkini) == float)):
                                    dataDICT['pkini'] = int(pkini*1000)
                                if ('pkfin' in dataDICT) and ((type(pkfin) == int) or (type(pkfin) == float)):
                                    dataDICT['pkfin'] = int(pkfin*1000)

                                # print ('ctra, pkini, pkfin, distEJE , tipoINV ', ctra, pkini, pkfin, distEJE, tipoINV)

                                if distEJE < 0:
                                    dataDICT['ex_margen'] = 'Izquierda'
                                else:
                                    dataDICT['ex_margen'] = 'Derecha'

                                # limites_relacionados.append(featLayerLIMI['EXPTE1'])    #Get the Name in Attribute Column 0
                            else:
                                # limites_relacionados.append(featLayerLIMI['id_camino'])    #Get the Name in Attribute Column 0
                                pass

                            # parcelas_analizadas.append(featLayerPARC['RC14'][:14])  #Put those into the Lists

                            # Se agrega la geometría de la interseccion
                            print(format(intersection.area(), '.1f'),'\n',intersection )
                            featINV = QgsFeature(fieldsLayerINT)
                            featINV.setGeometry(intersection)

                            for field in fieldsLayerINT:
                                featINV[field.name()] = dataDICT[field.name()]

                            # Se agrega el elemento a los elementos futuros del fichero nomLayerINT= 'Zonas invadidas'
                            feats.append(featINV)
                            countINV += 1


                if tipoINV == 'NO INVASION' or tipoINV == 'SIN CLASIFICAR':
                    #----------------------------------------------------------------------------------------------------
                    #  - NO INVASION -
                    #----------------------------------------------------------------------------------------------------
                    # En Caso de que la parcela sea NO INVASION, hay que agregar la parcela catastral en bruto
                    # Agregamos todos los ATRIBUTOS  de layerPARC

                    #### TODO ESTO NO FUNCIONA  ####
                    print ('tipoINV = ', tipoINV)
                    
                    # centroids = featLayerPARC.geometry().centroid().asPoint()
                    centroids = geomParc.centroid().asPoint()
                    if self.tipoDP != 'MUNICIPAL':
                        # ctra, pkini, pkfin, distEJE, pointMin, pointMax = self.fun.poligToPKINIPKFIN(featLayerPARC.geometry(), self.iface,'NO')
                        ctra, pkini, pkfin, distEJE, pointMin, pointMax = self.fun.poligToPKINIPKFIN_RT(geomParc, self.iface,'NO')
                        if isinstance(pkini, str):
                            pkini = 0
                        if isinstance(pkfin, str):
                            pkfin = 0
                        # print ('ctra, pkini, pkfin, distEJE , tipoINV, pointMin, pointMax ', ctra, pkini, pkfin, distEJE, tipoINV, pointMin, pointMax)

                        # Encontramos el feature en featuresLayerLIMI de la position
                        if pointMin != 0 and pointMin != None:
                            qpntMin = QgsGeometry.fromPointXY(QgsPointXY(pointMin.x(),pointMin.y()))

                            for featLayerLIMI in featuresLayerLIMI:
                                if qpntMin.intersects(featLayerLIMI.geometry()):
                                    feature = featLayerLIMI
                                    dataDICT['expte1'] = feature['expte1']
                                    continue

                        if ctra is None or ctra == 's/d' or ctra[:2] != 'CM':
                            # tipoINV = 'NO COLIND CTRA JCCM'
                            tipoINV = 'NO COLIND CTRA JCCM'
                            textINF = u'Informe de NO COLINDANCIA A CTRA. DE LA JCCM de la parcela catastral RC %s del T.M de %s'%(RC14,TMUNIC)
                            ctra= 'DESCONOCIDA'
                            pkini = 0
                            pkfin = 0
                            distEJE = 0
                        else:
                            textINF = u'Informe de notificación por colindancia de la parcela catastral RC %s del T.M de %s'%(RC14,TMUNIC)

                        dataDICT ={
                          "fid"         : 999999999,                # fid
                          "ex_num"      : tipoINV+str(countINV),    # EX_NUM
                          "ex_tmunic"   : TMUNIC,                   # EX_TMUNIC
                          "ex_textinf"  : textINF,                  # EX_TEXTINF
                          "ex_supexpr"  : 0,                        # EX_SUPEXPR
                          "ex_supinf"   : 0,                        # EX_SUPINF
                          "ex_tipoinv"  : tipoINV,                  # EX_TIPOINV
                          "ex_margen"   : 'Ambas',                  # ex_margen
                          "ex_registro" : '',                       # ex_registro
                          "ex_fecha"    : '',                       # ex_fecha
                          "ex_solicitante": '',                     # ex_solicitante
                          "ex_interesado" : '',                     # ex_interesado
                          "ex_correoelec" : '',                     # ex_correoelec
                          "ex_nombre"     : '',                     # ex_nombre
                          "ex_dni"        : '',                     # ex_dni
                          "ex_tlfno"      : '',                     # ex_tlfno                          
                          "ex_maxinv"     : format(maxINV, '.2f'),  # dp_maxinv
                          "cat_nmspc"   : 'ES.SDGC.CP',             # CAT_NMSPC
                          "ex_protocolo"  : '' ,                    # ex_protocolo
                          "ex_art_ley"    : 'S/D'                   # ex_art_ley
                        }

                        # Asignamos los atributos del featLimit más próximo
                        
                        if perimetroProx[1] and perimetroProx[0]!=-1:
                            print (')perimetroProx[1]:',perimetroProx[1], ' perimetroProx[0]:', perimetroProx[0])
                            # print (u'fid=%s CTRA=%s EXPTE=%s DIST=%s'%(str(perimetroProx[1]['fid']), perimetroProx[1]['ctra'], perimetroProx[1]['expte1'], str(perimetroProx[0])))
                            dataDICT['expte1']            = perimetroProx[1]['expte1']
                            dataDICT['nom_tramo']         = perimetroProx[1]['nom_tramo']
                            dataDICT['nom_proyec']        = perimetroProx[1]['nom_proyec']
                            dataDICT['cat-remisi']        = perimetroProx[1]['cat-remisi']
                            try:
                                dataDICT['lee_decr_acue_reso']= perimetroProx[1]['lee_decr_acue_reso']
                                dataDICT['lee_actas previas'] = perimetroProx[1]['lee_actas previas']
                            except:
                                dataDICT['lee_decr_acue_reso']= 's/d'
                                dataDICT['lee_actas previas'] = 's/d'
                        else:
                            dataDICT['expte1']            = 's/d'
                            dataDICT['nom_tramo']         = 's/d'
                            dataDICT['nom_proyec']        = 's/d'
                            dataDICT['cat-remisi']        = 's/d'
                            dataDICT['lee_decr_acue_reso']= 's/d'
                            dataDICT['lee_actas previas'] = 's/d'

                        if tipoINV == 'NO COLIND CTRA JCCM':
                            dataDICT['expte1']            = 's/d'
                            dataDICT['nom_tramo']         = 's/d'
                            dataDICT['nom_proyec']        = 's/d'
                            dataDICT['cat-remisi']        = 's/d'

                            
                        #### TODO ESTO NO FUNCIONA  ####
                        print ('EXPTE A ASOCIAR:', dataDICT['expte1'])
                        #### TODO ESTO NO FUNCIONA  ####
                            

                        # Se alteran 'ctra' 'pkini' 'pkfin' y margen
                        dataDICT['ctra'] = ctra
                        dataDICT['pkini'] = int(pkini*1000)
                        dataDICT['pkfin'] = int(pkfin*1000)
                        # print ("dataDICT['ctra']=",dataDICT['ctra']," dataDICT['pkini']=",dataDICT['pkini']," dataDICT['pkfin']=",dataDICT['pkfin'])

                        if distEJE < 0:
                            dataDICT['ex_margen'] = 'Izquierda'
                        else:
                            dataDICT['ex_margen'] = 'Derecha'

                    else:   # self.tipoDP = 'MUNICIPAL':
                        # Agregamos todos los ATRIBUTOS  de layerPARC y layerLIMI
                        textINF = u'Informe sobre NO INVASIÓN del Dominio Público de la parcela catastral RC %s'%(RC14)

                        dataDICT ={
                          "fid"           : 999999999,                            # fid
                          "expediente"    : tipoINV+str(countINV),                # expediente
                          "dp_textinf"    : textINF,                              # dp_textinf
                          "dp_supinf"     : 0,                                    # dp_supinf
                          "dp_tipoinv"    : tipoINV,                              # dp_tipoinv
                          "dp_registro"   : '',                                   # dp_registro
                          "dp_fecha"      : '',                                   # dp_fecha
                          "dp_solicitante": '',                                   # dp_solicitante
                          "dp_interesado" : '',                                   # dp_interesado
                          "dp_correoelec" : '',                                   # dp_correoelec
                          "dp_maxinv"     : format(maxINV, '.1f'),                # dp_maxinv
                          # "cat_nmspc"     : 'ES.LOCAL.CP'                         # CAT_NMSPC
                          "cat_nmspc"     : 'ES.SDGC.CP'                          # CAT_NMSPC
                        }

                    # Se agregan los atributos de la capa de PARCELAS
                    for field in fieldsLayerPARC:
                        key = field.name().lower()
                        if key not in dataDICT or not dataDICT[key]:  # Verifica si la clave no existe o si su valor está vacío
                            dataDICT[key] = featLayerPARC[field.name()]

                    # Se agrega la geometría completa de la parcela original
                    featNOINV = QgsFeature(fieldsLayerINT)
                    # featNOINV.setGeometry(featLayerPARC.geometry())
                    featNOINV.setGeometry(geomParc)
                    for field in dataDICT.keys():
                        # print (field.lower()+': '+ str(dataDICT[field]))
                        try:
                            featNOINV.setAttribute(field.lower(), dataDICT[field])
                        except:
                            pass

                    featNOINV.setAttribute("cat_nmspc", 'ES.SDGC.CP')  # CAT_NMSPC

                    feats.append(featNOINV)

                # Ponemos los resultados del análisis en su fila en la tabla del menú
                rowPosition = self.tablaRefCatResult.rowCount()

                if self.tipoDP != 'MUNICIPAL':
                    dataEXPTE = 's/d'
                    if 'expte1' in dataDICT:
                        dataEXPTE = dataDICT['expte1']
                    # else:
                        # dataEXPTE = 's/d'
                    if 'ctra' in dataDICT:
                        dataCTRA = dataDICT['ctra']
                    else:
                        dataCTRA = 's/d'
                        dataDICT['pkini'] = 0
                        dataDICT['pkfin'] = 0
                    if 'ex_tmunic' in dataDICT:
                        dataMUNI = dataDICT['ex_tmunic']
                    else:
                        dataMUNI = 's/d'

                    # print ('ctra = ',dataCTRA)

                    self.tablaRefCatResult.insertRow(rowPosition)
                    self.tablaRefCatResult.setItem(rowPosition , 0, QTableWidgetItem(u'EX-2020/XXX-1'))
                    # self.tablaRefCatResult.setItem(rowPosition , 1, QTableWidgetItem(dataDICT['rc14']))
                    self.tablaRefCatResult.setItem(rowPosition , 1, QTableWidgetItem(RC14))
                    self.tablaRefCatResult.setItem(rowPosition , 2, QTableWidgetItem(dataDICT['ex_tipoinv']))
                    self.tablaRefCatResult.setItem(rowPosition , 3, QTableWidgetItem(dataEXPTE))
                    self.tablaRefCatResult.setItem(rowPosition , 4, QTableWidgetItem(dataCTRA))
                    # self.tablaRefCatResult.setItem(rowPosition , 4, QTableWidgetItem(dataDICT['ctra']))
                    self.tablaRefCatResult.setItem(rowPosition , 5, QTableWidgetItem(str(dataDICT['pkini'])))
                    self.tablaRefCatResult.setItem(rowPosition , 6, QTableWidgetItem(str(dataDICT['pkfin'])))
                    self.tablaRefCatResult.setItem(rowPosition , 7, QTableWidgetItem(dataMUNI))
                    self.tablaRefCatResult.setItem(rowPosition , 8, QTableWidgetItem(dataDICT['ex_maxinv']))
                    self.tablaRefCatResult.setItem(rowPosition , 9, QTableWidgetItem(dataDICT['ex_supinf']))

                    # Ponemos los valores en el fichero de texto
                    txtDATA =  dataDICT['rc14'] + ', '
                    txtDATA += dataDICT['ex_tipoinv'] + ', '
                    txtDATA += dataEXPTE + ', '
                    txtDATA += dataMUNI + ', '
                    # txtDATA += dataCTRA + ', '
                    txtDATA += dataDICT['ctra'] + ', '
                    txtDATA += str(dataDICT['pkini']) + ', '
                    txtDATA += str(dataDICT['pkfin']) + ', '
                    # txtDATA += dataCTRA + ', '
                    txtDATA += str(dataDICT['ex_maxinv']) + ', '
                    txtDATA += str(dataDICT['ex_supinf']) + ', '
                else:
                    if dataDICT['id_camino']:
                        dataIDCAMINO = dataDICT['id_camino']
                    else:
                        dataIDCAMINO = 's/d'
                    if dataDICT['nombre']:
                        dataNOMCAMINO = dataDICT['nombre']
                    else:
                        dataNOMCAMINO = 's/d'

                    self.tablaRefCatResult.insertRow(rowPosition)
                    self.tablaRefCatResult.setItem(rowPosition , 0, QTableWidgetItem(u'noExpte-1'))
                    self.tablaRefCatResult.setItem(rowPosition , 1, QTableWidgetItem(dataDICT['rc14']))
                    self.tablaRefCatResult.setItem(rowPosition , 2, QTableWidgetItem(dataDICT['dp_tipoinv']))
                    self.tablaRefCatResult.setItem(rowPosition , 3, QTableWidgetItem(dataIDCAMINO))
                    self.tablaRefCatResult.setItem(rowPosition , 4, QTableWidgetItem(dataNOMCAMINO))
                    self.tablaRefCatResult.setItem(rowPosition , 5, QTableWidgetItem(str(dataDICT['dp_maxinv'])))
                    self.tablaRefCatResult.setItem(rowPosition , 6, QTableWidgetItem('-'))
                    self.tablaRefCatResult.setItem(rowPosition , 7, QTableWidgetItem('-'))

                    # Ponemos los valores en el fichero de texto
                    txtDATA =  dataDICT['rc14'] + ', '
                    txtDATA += dataDICT['dp_tipoinv'] + ', '
                    txtDATA += dataIDCAMINO + ', '
                    txtDATA += dataNOMCAMINO + ', '
                    txtDATA += str(dataDICT['dp_maxinv']) + ', '
                    txtDATA += '-, '
                    txtDATA += '-, '
                    txtDATA += '-, '


                countParc += 1
                self.progressBar.setValue(int(100 * countParc/countlayerPARC))

                testfile.write(txtDATA + '\n')
                # testfile.write(x + ', ' + limites_relacionados[i] + '\n')

        self.spbINFORMES.setMaximum(self.tablaRefCatResult.rowCount())

        ##  ANÁLISIS DE 'RESTOS'
        # Se deben disolver todos los elementos invadidos en uno solo antes de analizar los restos
        if self.chbRESTOPARC.isChecked():
            geomDissolve = None
            countFeatsINVADEN = 1
            for currentFeature in feats:
                # print ('FEAT %s: %s area parc- %s'%(RC14, str(currentFeature.geometry().area()), str(countFeatsINVADEN)))
                if geomDissolve == None:
                    geomDissolve = currentFeature.geometry()
                else:
                    geomDissolve = geomDissolve.combine( currentFeature.geometry() )

                # print ('Area geomDissolve =', format(geomDissolve.area(), '.1f'))

            # Calculamos los restos para cada parcela que invade
            countlayerPARC = layerPARC.selectedFeatureCount()
            featureslayerPARC = layerPARC.getFeatures()
            if countlayerPARC > 0:
                featureslayerPARC = layerPARC.selectedFeatures()
            else:
                countlayerPARC = layerPARC.featureCount()

            for featLayerPARC in featureslayerPARC:
                if featLayerPARC["RC14"]:
                    RC14 = featLayerPARC["RC14"][:14]
                    TMUNIC = featLayerPARC["NOM_MUNI"]
                    self.lblINFO.setText(u'INFO: CALCULANDO RESTO -  parcela %s'%(RC14))
                    # print (u'INFO: CALCULANDO RESTO -  parcela %s'%(RC14))
                    geomParc = featLayerPARC.geometry()
                    geomParc.transform(trPARC)

                    if RC14 in parcINVADIDAS:
                        # print ('Diff - '+RC14)
                        # difference = featLayerPARC.geometry().difference(geomDissolve)
                        difference = geomParc.difference(geomDissolve)
                        if self.tipoDP != 'MUNICIPAL':
                            dataDICTR ={
                              "fid"         : 999999999,                        # fid
                              "RC14"        : RC14,                             # RC14
                              "ex_num"      : RC14+'-R',                        # EX_NUM
                              "ex_tmunic"   : TMUNIC,                           # EX_TMUNIC
                              "ex_textinf"  : 'Resto Parcela '+RC14,            # EX_TEXTINF
                              "ex_supexpr"  : 0,                                # EX_SUPEXPR
                              "ex_supinf"   : format(difference.area(), '.1f'), # EX_SUPINF
                              "ex_tipoinv"  : 'RESTO',                          # EX_TIPOINV
                              "ex_margen"   : '',                               # ex_margen
                              "ex_registro" : '',                               # ex_registro
                              "ex_fecha"    : '',                               # ex_fecha
                              "ex_solicitante": '',                             # ex_solicitante
                              "ex_interesado" : '',                             # ex_interesado
                              "ex_correoelec" : '',                             # ex_correoelec
                              "ex_nombre"     : '',                             # ex_nombre
                              "ex_dni"        : '',                             # ex_dni
                              "ex_tlfno"      : '',                             # ex_tlfno
                              "cat_nmspc"   : 'ES.SDGC.CP',                     # CAT_NMSPC
                              "ex_protocolo"  : '' ,                            # ex_protocolo
                              "ex_art_ley"    : 'S/D'                           # ex_art_ley
                            }
                        else:
                            dataDICTR ={
                              "fid"           : 999999999,                            # fid
                              "RC14"          : RC14,                                 # RC14
                              "expediente"    : tipoINV+str(countINV),                # EXPEDIENTE
                              "dp_textinf"    : 'RESTO',                              # dp_textinf
                              "dp_supinf"     : format(intersection.area(), '.1f'),   # dp_supinf
                              "dp_tipoinv"    : 'RESTO',                              # dp_tipoinv
                              "dp_registro"   : '',                                   # dp_registro
                              "dp_fecha"      : '',                                   # dp_fecha
                              "dp_solicitante": '',                                   # dp_solicitante
                              "dp_interesado" : '',                                   # dp_interesado
                              "dp_correoelec" : '',                                   # dp_correoelec
                              "cat_nmspc"     : 'ES.LOCAL.CP'                         # CAT_NMSPC
                            }

                        for field in fieldsLayerPARC:
                            dataDICTR[field.name().lower()] = featLayerPARC[field.name()]

                        # Se agrega la geometría de la diferencia
                        featR = QgsFeature(fieldsLayerINT)
                        featR.setGeometry(difference)
                        for field in fieldsLayerINT:
                            try:
                                featR.setAttribute(field.name(), dataDICTR[field.name()])
                            except:
                                pass

                        feats.append(featR)
        
        result.dataProvider().addFeatures(feats)
        result.commitChanges()
        QgsProject.instance().addMapLayer(result)

        # Desactivamos visibilidad de capa intersección
        QgsProject.instance().layerTreeRoot().findLayer(result.id()).setItemVisibilityChecked(False)

        # Se cierra el fichero de resultados
        testfile.close()

        # Desactivamos el botón una vez hechas las intersecciones
        self.btnAnalisisCOLINDANCIA.setEnabled(False)
        self.chbRESTOPARC.setEnabled(False)

        # Activamos botones de trabajo
        self.btnASIGNAEXPTE.setEnabled(True)

        if self.tablaRefCatResult.rowCount() > 1:
            self.chbASIGNATODOENUNO.setEnabled(True)
            self.chbASIGNATODOENUNO.setChecked(True)
            self.spbINFORMES.setVisible(1)
        else:
            self.spbINFORMES.setVisible(0)


        txtINFO = u'INFO: ANALIZADAS -  %s parcelas'%(countlayerPARC)
        self.lblINFO.setText(txtINFO)
        self.iface.mainWindow().statusBar().showMessage(txtINFO)

        QApplication.restoreOverrideCursor()

    def crear_capa_zonas_invadidas(self, layerPARC, layerLIMI):
        """
        Crea la capa 'Zonas invadidas' con la estructura unificada.
        
        Args:
            layerPARC: Capa de parcelas catastrales
            layerLIMI: Capa de límites de dominio público
        
        Returns:
            tuple: (capa_resultado, fields_layer_int, fields_layer_parc, fields_layer_limi)
        """
        estiloCAPAINT = os.path.join(
            os.path.dirname(__file__), 
            self.conf.catastro_tool["dir_estilos_catastro"] + u'/ZONAS_INVADIDAS.qml'
        )
        
        # Eliminar capa existente si la hay
        layerEXIST = QgsProject.instance().mapLayersByName(self.NOMBRE_CAPA_RESULTADOS)
        if layerEXIST:
            for layer0 in layerEXIST:
                QgsProject.instance().removeMapLayer(layer0.id())
        
        # Definición base de campos (comunes a ambos tipos)
        campos_base = (
            '&field=fid:integer' +
            '&field=rc14:String(25)' +
            '&field=cat_nmspc:String(25)'
        )
        
        # Campos específicos según tipo de dominio
        if self.tipoDP != 'MUNICIPAL':
            # Caso carreteras JCCM
            campos_especificos = (
                '&field=ex_num:String(20)' +
                '&field=ex_tmunic:String(100)' +
                '&field=ex_textinf:String(252)' +
                '&field=ex_supexpr:Real(10,2)' +
                '&field=ex_supinf:Real(10,2)' +
                '&field=ex_tipoinv:String(50)' +
                '&field=ex_margen:String(20)' +
                '&field=ex_registro:String(50)' +
                '&field=ex_fecha:String(50)' +
                '&field=ex_solicitante:String(200)' +
                '&field=ex_interesado:String(200)' +
                '&field=ex_correoelec:String(200)' +
                '&field=ex_nombre:String(200)' +
                '&field=ex_dni:String(200)' +
                '&field=ex_tlfno:String(200)' +
                '&field=ex_maxinv:Real(10,2)' +
                '&field=ex_protocolo:String(50)' +
                '&field=ex_art_ley:String(50)'
            )
        else:
            # Caso municipal
            campos_especificos = (
                '&field=expediente:String(25)' +
                '&field=dp_textinf:String(252)' +
                '&field=dp_supinf:Real(10,2)' +
                '&field=dp_tipoinv:String(50)' +
                '&field=dp_registro:String(50)' +
                '&field=dp_fecha:String(50)' +
                '&field=dp_solicitante:String(200)' +
                '&field=dp_interesado:String(200)' +
                '&field=dp_correoelec:String(200)' +
                '&field=dp_maxinv:Real(10,2)'
            )
        
        # Crear la capa
        result = QgsVectorLayer(
            f'Polygon?crs=EPSG:{srcVal}{campos_base}{campos_especificos}',
            self.NOMBRE_CAPA_RESULTADOS,
            'memory'
        )
        
        # Aplicar estilo
        result.loadNamedStyle(estiloCAPAINT)
        
        # Añadir campos de las capas origen
        prov = result.dataProvider()
        result.startEditing()
        
        attributes = []
        
        # Campos de la capa de parcelas (excepto RC14)
        fieldsLayerPARC = layerPARC.fields()
        for field in fieldsLayerPARC:
            if field.name() != 'RC14':
                attributes.append(QgsField(field.name().lower(), field.type()))
        
        # Campos de la capa de límites
        fieldsLayerLIMI = layerLIMI.fields()
        for field in fieldsLayerLIMI:
            if field.name() == 'fid':
                attributes.append(QgsField(field.name().lower() + '_E', field.type()))
            else:
                attributes.append(QgsField(field.name().lower(), field.type()))
        
        prov.addAttributes(attributes)
        result.updateFields()
        result.commitChanges()
        
        return result, prov.fields(), fieldsLayerPARC, fieldsLayerLIMI

        
    def INVmultiparteMonoparte(self, intersection):
        """
        Convierte una geometría multiparte en una lista de geometrías monoparte válidas.
        
        Args:
            intersection: QgsGeometry multipolígono a analizar
            
        Returns:
            Lista de QgsGeometry con cada parte válida del multipolígono original
        """
        valid_geometries = []
        
        if not intersection.isMultipart():
            # Si ya es monoparte, verificar si es válida y devolverla en una lista
            if intersection.isGeosValid():
                return [intersection]
            else:
                # Intentar reparar la geometría si no es válida
                repaired = intersection.makeValid()
                if repaired.isGeosValid():
                    return [repaired]
                return []
        
        # Para geometrías multiparte
        parts = intersection.asGeometryCollection()
        
        for part in parts:
            if not part.isEmpty():
                if part.isGeosValid():
                    valid_geometries.append(part)
                else:
                    # Intentar reparar la parte si no es válida
                    repaired_part = part.makeValid()
                    if not repaired_part.isEmpty() and repaired_part.isGeosValid():
                        # Asegurarse que la parte reparada es un polígono
                        if repaired_part.type() == QgsWkbTypes.PolygonGeometry:
                            valid_geometries.append(repaired_part)
        
        return valid_geometries


    def asignarTIPO_EXPTE(self, proviEXPRO, layerPARCnom, layerLIMInom, layerINFEXPnom):
        # ASIGNAMOS EL TIPO DE EXPEDIENTE SELECCIONADO A LAS PARCELAS
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)   # Cursor TRABAJANDO

        # Validaciones iniciales. Comprobamos si hay parcelas en listaRCs
        if self.listaRCs.count() == 0:
            msg = u'NO HAY PARCELAS CATASTRALES PARA ANALIZAR'
            self.fun.showMessage(u'ANÁLISIS DE INVASIÓN DEL D.P.', msg)
            QApplication.restoreOverrideCursor()
            return

        # Obtener capas
        layerPARC = self.get_layer_seguro(layerPARCnom)
        layerLIMI = self.get_layer_seguro(layerLIMInom)
        if not layerPARC or not layerLIMI:
            QApplication.restoreOverrideCursor()
            return

        # Configurar UI
        self.lblINFO.show()
        self.progressBar.show()
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)
        self.progressBar.setValue(0)

        # CREAR CAPA DE RESULTADOS (AHORA ES UNA LÍNEA)
        result, fieldsLayerINT, fieldsLayerPARC, fieldsLayerLIMI = self.crear_capa_zonas_invadidas(layerPARC, layerLIMI)

        # Se detectan los elementos seleccionados
        feats = []
        countlayerPARC = layerPARC.selectedFeatureCount()
        featureslayerPARC = layerPARC.getFeatures()
        if countlayerPARC > 0:
            featureslayerPARC = layerPARC.selectedFeatures()
        else:
            countlayerPARC = layerPARC.featureCount()

        countLayerLIMI = layerLIMI.selectedFeatureCount()
        featuresLayerLIMI = layerLIMI.getFeatures()
        # TODO QUITAR
        # precision = 0.01 # Precisión para obtener el poleOfInaccessibility
        # tolmaxSup = 1.00 # Tolerancia en metros cuadrados, bajo la cual se considera NO INVASIÓN
        # TODO SACAR A VARIABLES GENERALES EN INIT
        distMinFeat= 20.00 # Distancia mínima para considerar 'colindante' una parcela a un DP


        # Limpiamos la tabla de resultados
        self.tablaRefCatResult.setRowCount(0);

        # Se escribe un fichero de resultados        # TODO SACAR A VARIABLES GENERALES EN INIT
        testfile = open('C:\Temp\IntersectTest.txt', 'w')

        countINV = 1
        countParc = 1
        dataDICT ={}

        for featLayerPARC in featureslayerPARC:      #Cada elemento de la capa PARCELAS. Se llamará featLayerPARC
            TMUNIC = featLayerPARC["NOM_MUNI"]
            if featLayerPARC["RC14"]:
                RC14 = featLayerPARC["RC14"][:14]
                TMUNIC = featLayerPARC["NOM_MUNI"]
                geomParc = featLayerPARC.geometry()
                centroids = geomParc.centroid().asPoint()

                # Buscamos el perimetro de expropaciones más próximo par asignar un EXPTE
                perimetroProx = [100000, None]
                for featLayerLIMI in featuresLayerLIMI:
                    # Calculamos la min dist entre featLayerLIMI (LIMITES) y featLayerPARC (PARCELAS)
                    disFeats = QgsGeometry.distance(featLayerLIMI.geometry(), geomParc)
                    if disFeats <= distMinFeat:     # Cogemos el featLayerLIMI si disFeats <= distMinFeat
                        if disFeats < perimetroProx[0]: # Metemos el featLayerLIMI con la minima distancia a Parcela
                            perimetroProx = [disFeats, featLayerLIMI]

                ##############################################################################
                ###################       TODO ANALIZAR        ###############################
                ##############################################################################
                # Asignamos los atributos del featLimit más próximo
                if perimetroProx[1]:
                    # print (u'fid=%s CTRA=%s EXPTE=%s DIST=%s'%(str(perimetroProx[1]['fid']), perimetroProx[1]['ctra'], perimetroProx[1]['expte1'], str(perimetroProx[0])))
                    dataDICT['expte1']            = perimetroProx[1]['expte1']
                    dataDICT['nom_tramo']         = perimetroProx[1]['nom_tramo']
                    dataDICT['nom_proyec']        = perimetroProx[1]['nom_proyec']
                    dataDICT['cat-remisi']        = perimetroProx[1]['cat-remisi']
                    try:
                        dataDICT['lee_decr_acue_reso']= perimetroProx[1]['lee_decr_acue_reso']
                        dataDICT['lee_actas previas'] = perimetroProx[1]['lee_actas previas']
                    except:
                        dataDICT['lee_decr_acue_reso']= 's/d'
                        dataDICT['lee_actas previas'] = 's/d'
                else:
                    dataDICT['expte1']            = 's/d'
                    dataDICT['nom_tramo']         = 's/d'
                    dataDICT['nom_proyec']        = 's/d'
                    dataDICT['cat-remisi']        = 's/d'
                    dataDICT['lee_decr_acue_reso']= 's/d'
                    dataDICT['lee_actas previas'] = 's/d'

                # Se agregan los atributos de la capa de PARCELAS
                for field in fieldsLayerPARC:
                    if field.name().lower() != 'rc14':  # No se agrega RC14 pues ya se habrá agregado antes
                        dataDICT[field.name().lower()] = featLayerPARC[field.name()]

                ctra, pkini, pkfin, distEJE, pointMin, pointMax = self.fun.poligToPKINIPKFIN_RT(geomParc, self.iface,'NO')
                if ctra is None:
                    ctra = 's/d'
                if isinstance(pkini, str) or pkini is None:
                    pkini = 0
                if isinstance(pkfin, str) or pkfin is None:
                    pkfin = 0
                if isinstance(distEJE, str) or distEJE is None:
                    distEJE = 0
                if isinstance(pointMin, str) or pointMin is None:
                    pointMin = 0
                if isinstance(pointMax, str) or pointMax is None:
                    pointMax = 0
                # print ('ctra, pkini, pkfin, distEJE , tipoINV, pointMin, pointMax ', ctra, pkini, pkfin, distEJE, tipoINV, pointMin, pointMax)

                tipoINV = self.cbx_AsignarTipoEXPTE.currentText()
                if tipoINV == 'REMISION CATASTRAL':
                    textINF = self.dictTIPOEXPTE[tipoINV].format(dataDICT['expte1'], TMUNIC)
                elif tipoINV not in self.listTIPOEXPTE:
                    textINF = 'Informe de {},  parcelas RC {} del T.M de {}'.format(tipoINV, RC14, TMUNIC)
                else:
                    textINF = self.dictTIPOEXPTE[tipoINV].format(RC14, TMUNIC)

                dataDICT ={
                  "fid"         : 999999999,                # fid
                  "rc14"        : RC14,                     # RC14
                  "ex_num"      : tipoINV+str(countINV),    # EX_NUM
                  "ex_tmunic"   : TMUNIC,                   # EX_TMUNIC
                  "ex_textinf"  : textINF,                  # EX_TEXTINF
                  "ex_supexpr"  : 0,                        # EX_SUPEXPR
                  "ex_supinf"   : 0,                        # EX_SUPINF
                  "ex_tipoinv"  : tipoINV,                  # EX_TIPOINV
                  "ex_margen"   : '',                       # ex_margen
                  "ex_registro" : '',                       # ex_registro
                  "ex_fecha"    : '',                       # ex_fecha
                  "ex_solicitante": '',                     # ex_solicitante
                  "ex_interesado" : '',                     # ex_interesado
                  "ex_correoelec" : '',                     # ex_correoelec
                  "ex_nombre"     : '',                     # ex_nombre
                  "ex_dni"        : '',                     # ex_dni
                  "ex_tlfno"      : '',                     # ex_tlfno
                  "ex_maxinv"     : 0,                      # dp_maxinv
                  "cat_nmspc"    : 'ES.SDGC.CP',            # CAT_NMSPC
                  "ex_protocolo"  : '' ,                    # ex_protocolo
                  "ex_art_ley"    : 'S/D'                   # ex_art_ley
                }

                # Se alteran 'ctra' 'pkini' 'pkfin' y margen
                dataDICT['ctra'] = ctra
                dataDICT['pkini'] = int(pkini*1000)
                dataDICT['pkfin'] = int(pkfin*1000)
                # print ("dataDICT['ctra']=",dataDICT['ctra']," dataDICT['pkini']=",dataDICT['pkini']," dataDICT['pkfin']=",dataDICT['pkfin'])

                if distEJE < 0:
                    dataDICT['ex_margen'] = 'Izquierda'
                else:
                    dataDICT['ex_margen'] = 'Derecha'

                # Ponemos los resultados del análisis en su fila en la tabla del menú
                rowPosition = self.tablaRefCatResult.rowCount()

                if self.tipoDP != 'MUNICIPAL':
                    dataEXPTE = 's/d'
                    if 'expte1' in dataDICT:
                        dataEXPTE = dataDICT['expte1']
                    # else:
                        # dataEXPTE = 's/d'
                    if 'ctra' in dataDICT:
                        dataCTRA = dataDICT['ctra']
                    else:
                        dataCTRA = 's/d'
                        dataDICT['pkini'] = 0
                        dataDICT['pkfin'] = 0
                    if 'ex_tmunic' in dataDICT:
                        dataMUNI = dataDICT['ex_tmunic']
                    else:
                        dataMUNI = 's/d'

                    # print ('ctra = ',dataCTRA)

                    self.tablaRefCatResult.insertRow(rowPosition)
                    self.tablaRefCatResult.setItem(rowPosition , 0, QTableWidgetItem(u'EX-2020/XXX-1'))
                    # self.tablaRefCatResult.setItem(rowPosition , 1, QTableWidgetItem(dataDICT['rc14']))
                    self.tablaRefCatResult.setItem(rowPosition , 1, QTableWidgetItem(RC14))
                    self.tablaRefCatResult.setItem(rowPosition , 2, QTableWidgetItem(dataDICT['ex_tipoinv']))
                    self.tablaRefCatResult.setItem(rowPosition , 3, QTableWidgetItem(dataEXPTE))
                    self.tablaRefCatResult.setItem(rowPosition , 4, QTableWidgetItem(dataCTRA))
                    # self.tablaRefCatResult.setItem(rowPosition , 4, QTableWidgetItem(dataDICT['ctra']))
                    self.tablaRefCatResult.setItem(rowPosition , 5, QTableWidgetItem(str(dataDICT['pkini'])))
                    self.tablaRefCatResult.setItem(rowPosition , 6, QTableWidgetItem(str(dataDICT['pkfin'])))
                    self.tablaRefCatResult.setItem(rowPosition , 7, QTableWidgetItem(dataMUNI))
                    self.tablaRefCatResult.setItem(rowPosition , 8, QTableWidgetItem(dataDICT['ex_maxinv']))
                    self.tablaRefCatResult.setItem(rowPosition , 9, QTableWidgetItem(dataDICT['ex_supinf']))

                    # Ponemos los valores en el fichero de texto
                    txtDATA =  dataDICT['rc14'] + ', '
                    txtDATA += dataDICT['ex_tipoinv'] + ', '
                    txtDATA += dataEXPTE + ', '
                    txtDATA += dataMUNI + ', '
                    # txtDATA += dataCTRA + ', '
                    txtDATA += dataDICT['ctra'] + ', '
                    txtDATA += str(dataDICT['pkini']) + ', '
                    txtDATA += str(dataDICT['pkfin']) + ', '
                    # txtDATA += dataCTRA + ', '
                    txtDATA += str(dataDICT['ex_maxinv']) + ', '
                    txtDATA += str(dataDICT['ex_supinf']) + ', '
                else:
                    if dataDICT['id_camino']:
                        dataIDCAMINO = dataDICT['id_camino']
                    else:
                        dataIDCAMINO = 's/d'
                    if dataDICT['nombre']:
                        dataNOMCAMINO = dataDICT['nombre']
                    else:
                        dataNOMCAMINO = 's/d'

                    self.tablaRefCatResult.insertRow(rowPosition)
                    self.tablaRefCatResult.setItem(rowPosition , 0, QTableWidgetItem(u'noExpte-1'))
                    self.tablaRefCatResult.setItem(rowPosition , 1, QTableWidgetItem(dataDICT['rc14']))
                    self.tablaRefCatResult.setItem(rowPosition , 2, QTableWidgetItem(dataDICT['dp_tipoinv']))
                    self.tablaRefCatResult.setItem(rowPosition , 3, QTableWidgetItem(dataIDCAMINO))
                    self.tablaRefCatResult.setItem(rowPosition , 4, QTableWidgetItem(dataNOMCAMINO))
                    self.tablaRefCatResult.setItem(rowPosition , 5, QTableWidgetItem(str(dataDICT['dp_maxinv'])))
                    self.tablaRefCatResult.setItem(rowPosition , 6, QTableWidgetItem('-'))
                    self.tablaRefCatResult.setItem(rowPosition , 7, QTableWidgetItem('-'))

                    # Ponemos los valores en el fichero de texto
                    txtDATA =  dataDICT['rc14'] + ', '
                    txtDATA += dataDICT['dp_tipoinv'] + ', '
                    txtDATA += dataIDCAMINO + ', '
                    txtDATA += dataNOMCAMINO + ', '
                    txtDATA += str(dataDICT['dp_maxinv']) + ', '
                    txtDATA += '-, '
                    txtDATA += '-, '
                    txtDATA += '-, '


                countParc += 1
                self.progressBar.setValue(int(100 * countParc/countlayerPARC))

                testfile.write(txtDATA + '\n')

                # Se agregan los atributos de la capa de PARCELAS
                for field in fieldsLayerPARC:
                    key = field.name().lower()
                    if key not in dataDICT or not dataDICT[key]:  # Verifica si la clave no existe o si su valor está vacío
                        dataDICT[key] = featLayerPARC[field.name()]

                # Se agrega la geometría de la interseccion
                featINV = QgsFeature(fieldsLayerINT)
                featINV.setGeometry(geomParc)
                for field in dataDICT.keys():
                    try:
                        featINV.setAttribute(field.lower(), dataDICT[field])
                    except:
                        pass

                featINV.setAttribute("cat_nmspc", 'ES.SDGC.CP')  # CAT_NMSPC

                # Se agrega el elemento a los elementos futuros del fichero nomLayerINT= 'Zonas invadidas'
                feats.append(featINV)
                countINV += 1

        result.dataProvider().addFeatures(feats)
        result.commitChanges()
        QgsProject.instance().addMapLayer(result)

        # Desactivamos visibilidad de capa intersección
        QgsProject.instance().layerTreeRoot().findLayer(result.id()).setItemVisibilityChecked(False)

        # Se cierra el fichero de resultados
        testfile.close()

        # Desactivamos el botón una vez hechas las intersecciones
        self.btnAnalisisCOLINDANCIA.setEnabled(False)
        self.chbRESTOPARC.setEnabled(False)

        # Activamos botones de trabajo
        self.btnASIGNAEXPTE.setEnabled(True)

        if self.tablaRefCatResult.rowCount() > 1:
            self.chbASIGNATODOENUNO.setEnabled(True)
            self.chbASIGNATODOENUNO.setChecked(True)
            self.spbINFORMES.setVisible(1)
        else:
            self.spbINFORMES.setVisible(0)

        txtINFO = u'INFO: ANALIZADAS -  %s parcelas'%(countlayerPARC)
        self.lblINFO.setText(txtINFO)
        self.iface.mainWindow().statusBar().showMessage(txtINFO)

        QApplication.restoreOverrideCursor()

    #######################################################################
    #######################################################################
    #######################################################################
    ###   TODO REVISAR ASIGNAR EXPEDIENTE                               ###
    #######################################################################
    
    # def asignaExptes(self):
        # """
        # Asigna números de expediente a las parcelas analizadas.
        # Ofrece elegir entre el último expediente del sistema de archivos, del Excel,
        # o introducir uno manualmente.
        # """
        # # Obtener el último expediente del sistema de archivos
        # dirINFEXPRO = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPlayerINFOEXPROexptes")
        # if dirINFEXPRO is None:
            # dirINFEXPRO = configuration().expropiacion["EXPlayerINFOEXPROexptes"]
        
        # expte_directorio = self.busquedaDirNuevoEXPTE(dirINFEXPRO)
        
        # # Obtener el último expediente del Excel
        # expte_excel = self.obtener_ultimo_expte_excel()
        # print(f'Excel - último expediente: {expte_excel}')
        
        # # Mostrar diálogo de selección
        # resultado = self.mostrar_dialogo_seleccion_expte(expte_directorio, expte_excel)
        
        # if resultado[0] is None:
            # return  # Usuario canceló
        
        # source, ExpteNUM, recordar = resultado
        
        # # Guardar preferencia si se solicita
        # if recordar:
            # self.qs.setValue(f"{self.nombre_plugin}/last/lastExpteSource", source)
            # if source == "manual":
                # self.qs.setValue(f"{self.nombre_plugin}/last/lastExpteManual", ExpteNUM)
        
        # print(f"Usando expediente: {ExpteNUM} (fuente: {source})")
        
        # # Asegurarnos de que ExpteNUM tiene el formato correcto
        # if ExpteNUM and len(ExpteNUM) == 7:
            # # Continuar con la asignación normal
            # pass
        # else:
            # QMessageBox.warning(self, "Error", "No se pudo determinar un número de expediente válido.")
            # return
        
        # # El resto del código sigue igual...
        # if self.tablaRefCatResult.rowCount() <= 1:
            # self.spbINFORMES.hide()
        # else:
            # if self.chbASIGNATODOENUNO.isChecked():
                # self.spbINFORMES.show()

        # # Trasladamos los valores al panel de ANÁLISIS DE RESULTADOS
        # rowNumber = self.tablaRefCatResult.rowCount()
        # valSubExpte = 1
        # listaExptesInforme = []

        # for row in range(rowNumber):
            # if not self.chbASIGNATODOENUNO.isChecked():
                # ExNumDato = self.prefEXPTE + ExpteNUM[:4] + ExpteNUM[4:]
                # self.tablaRefCatResult.setItem(row, 0, QTableWidgetItem(ExNumDato))
                # ExpteNUM = str(int(ExpteNUM) + 1)
            # else:
                # if rowNumber > 1:
                    # ExNumDato = self.prefEXPTE + ExpteNUM[:4] + ExpteNUM[4:] + '-' + str(valSubExpte)
                # else:
                    # ExNumDato = self.prefEXPTE + ExpteNUM[:4] + ExpteNUM[4:]
                # self.tablaRefCatResult.setItem(row, 0, QTableWidgetItem(ExNumDato))
                # valSubExpte += 1

            # RC14 = self.tablaRefCatResult.item(row, 1).text()
            # Result = self.tablaRefCatResult.item(row, 2).text()
            # listaExptesInforme.append({ExNumDato, RC14, Result})

            # # Meter los datos en la capa 'Zonas Invadidas'
            # layers = QgsProject.instance().mapLayersByName(nomLayerINT)
            # if layers:
                # vl = layers[0]
                # vl.startEditing()
                # expr = QgsExpression(f'"RC14" LIKE \'{RC14}%\'')
                # it = vl.getFeatures(QgsFeatureRequest(expr))
                # for feat in it:
                    # if feat[self.campoTIPO] == 'RESTO':
                        # vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_num'), ExNumDato + '-R')
                    # else:
                        # vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_num'), ExNumDato)
                # vl.commitChanges()

        # # Rellenamos el primer grupo de datos
        # self.colocaAtributosExpte()

        # # Activamos los dos paneles de datos
        # self.gpbDATOSEXPRO.setEnabled(True)
        # self.gpbDATOSDP.setEnabled(True)

        # self.btnCREAEXPTE.setEnabled(True)


    # def asignaExptes(self):
        # """
        # Asigna números de expediente a las parcelas analizadas.
        # Ofrece elegir entre el último expediente del sistema de archivos o del Excel.
        # """
        # # Obtener el último expediente del sistema de archivos
        # dirINFEXPRO = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPlayerINFOEXPROexptes")
        # if dirINFEXPRO is None:
            # dirINFEXPRO = configuration().expropiacion["EXPlayerINFOEXPROexptes"]
        
        # expte_directorio = self.busquedaDirNuevoEXPTE(dirINFEXPRO)
        
        # # Obtener el último expediente del Excel
        # expte_excel = self.obtener_ultimo_expte_excel()
        # print ('expte_excel: ', expte_excel)
        
        # # Preparar mensaje para el usuario
        # msg = "Seleccione el origen para el próximo número de expediente:\n\n"
        # msg += f"📁 Desde directorios: {expte_directorio}\n"
        # if expte_excel:
            # msg += f"📊 Desde Excel:      {expte_excel}\n"
        # else:
            # msg += "📊 Desde Excel:      (no hay registros)\n"
            # expte_excel = expte_directorio  # Si no hay Excel, usar directorio
        
        # msg += "\n¿Qué desea utilizar?"

        # # Crear diálogo personalizado
        # dlg = QMessageBox(self)
        # dlg.setWindowTitle("Seleccionar origen de expediente")
        # dlg.setText(msg)
        
        # btn_directorio = dlg.addButton("Usar desde directorios", QMessageBox.ActionRole)
        # btn_excel = dlg.addButton("Usar desde Excel", QMessageBox.ActionRole)
        # btn_cancel = dlg.addButton("Cancelar", QMessageBox.RejectRole)
        
        # dlg.exec_()
        
        # if dlg.clickedButton() == btn_directorio:
            # ExpteNUM = expte_directorio
            # self.qs.setValue(f"{self.nombre_plugin}/last/lastExpteSource", "directorio")
        # elif dlg.clickedButton() == btn_excel:
            # ExpteNUM = expte_excel
            # self.qs.setValue(f"{self.nombre_plugin}/last/lastExpteSource", "excel")
        # else:
            # return  # Cancelar
        
        # # Guardar la elección del usuario como preferencia para futuras ocasiones
        # last_source = self.qs.value(f"{self.nombre_plugin}/last/lastExpteSource", "directorio")
        
        # # También podríamos ofrecer una opción "Recordar mi elección"
        # remember = QMessageBox.question(
            # self,
            # "Recordar elección",
            # "¿Recordar esta elección para futuras ocasiones?",
            # QMessageBox.Yes | QMessageBox.No
        # )
        # if remember == QMessageBox.Yes:
            # self.qs.setValue(f"{self.nombre_plugin}/last/lastExpteSource", 
                            # "directorio" if dlg.clickedButton() == btn_directorio else "excel")
       
        # # Asegurarnos de que ExpteNUM tiene el formato correcto
        # if ExpteNUM and len(ExpteNUM) == 7:
            # # Continuar con la asignación normal
            # pass
        # else:
            # QMessageBox.warning(self, "Error", "No se pudo determinar un número de expediente válido.")
            # return
        
        # # El resto del código sigue igual
        # if self.tablaRefCatResult.rowCount() <= 1:
            # self.spbINFORMES.hide()
        # else:
            # if self.chbASIGNATODOENUNO.isChecked():
                # self.spbINFORMES.show()

        # # Trasladamos los valores al panel de ANÁLISIS DE RESULTADOS
        # rowNumber = self.tablaRefCatResult.rowCount()
        # valSubExpte = 1
        # listaExptesInforme = []

        # for row in range(rowNumber):
            # if not self.chbASIGNATODOENUNO.isChecked():
                # ExNumDato = self.prefEXPTE + ExpteNUM[:4] + ExpteNUM[4:]
                # self.tablaRefCatResult.setItem(row, 0, QTableWidgetItem(ExNumDato))
                # ExpteNUM = str(int(ExpteNUM) + 1)
            # else:
                # if rowNumber > 1:
                    # ExNumDato = self.prefEXPTE + ExpteNUM[:4] + ExpteNUM[4:] + '-' + str(valSubExpte)
                # else:
                    # ExNumDato = self.prefEXPTE + ExpteNUM[:4] + ExpteNUM[4:]
                # self.tablaRefCatResult.setItem(row, 0, QTableWidgetItem(ExNumDato))
                # valSubExpte += 1

            # # ... resto del bucle igual ...
            # RC14 = self.tablaRefCatResult.item(row, 1).text()
            # Result = self.tablaRefCatResult.item(row, 2).text()
            # listaExptesInforme.append({ExNumDato, RC14, Result})

            # # Meter los datos en la capa 'Zonas Invadidas'
            # layers = QgsProject.instance().mapLayersByName(nomLayerINT)
            # if layers:
                # vl = layers[0]
                # vl.startEditing()
                # expr = QgsExpression(f'"RC14" LIKE \'{RC14}%\'')
                # it = vl.getFeatures(QgsFeatureRequest(expr))
                # for feat in it:
                    # if feat[self.campoTIPO] == 'RESTO':
                        # vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_num'), ExNumDato + '-R')
                    # else:
                        # vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_num'), ExNumDato)
                # vl.commitChanges()

        # # Rellenamos el primer grupo de datos
        # self.colocaAtributosExpte()

        # # Activamos los dos paneles de datos
        # self.gpbDATOSEXPRO.setEnabled(True)
        # self.gpbDATOSDP.setEnabled(True)

        # self.btnCREAEXPTE.setEnabled(True)

    #######################################################################
    ###   TODO REVISAR ASIGNAR EXPEDIENTE                               ###
    #######################################################################
    #######################################################################
    #######################################################################

    def asignaExptes(self):
        """
        Asigna números de expediente a las parcelas analizadas.
        Usa el valor del QLineEdit asociado al QRadioButton seleccionado.
        """
        # 1. Obtener el número de expediente base según el radiobutton activo
        if self.rbtAsignaByDIRECT.isChecked():
            ExpteNUM_base = self.qleExpteByDIRECT.text()
            print(f"Asignando expedientes desde directorio: {ExpteNUM_base}")
        elif self.rbtAsignaByEXCEL.isChecked():
            ExpteNUM_base = self.qleExpteByEXCEL.text()
            print(f"Asignando expedientes desde Excel: {ExpteNUM_base}")
        else:
            # Si por alguna razón ninguno está seleccionado, mostrar error
            QMessageBox.warning(self, "Error", "Seleccione una fuente para el número de expediente.")
            return

        # Validación básica del número base
        if not ExpteNUM_base or ExpteNUM_base in ["ERROR", "NO HAY DATOS"] or len(ExpteNUM_base) != 7:
            QMessageBox.warning(self, "Error", f"El número de expediente base '{ExpteNUM_base}' no es válido.")
            return

        # Asegurarnos de que ExpteNUM_base es tratado como entero para las operaciones
        try:
            # Para incrementar, necesitamos la parte numérica como entero
            # El formato es AAAAnnn (ej: 2026001). Lo separamos para mantener el año.
            anno_base = ExpteNUM_base[:4]
            numero_base = int(ExpteNUM_base[4:]) # Parte numérica de 3 dígitos
        except ValueError:
            QMessageBox.warning(self, "Error", f"Formato de número de expediente '{ExpteNUM_base}' incorrecto (debe ser AAAAnnn).")
            return

        # 2. Lógica de asignación (similar a la que ya tenías, pero usando ExpteNUM_base)
        if self.tablaRefCatResult.rowCount() <= 1:
            self.spbINFORMES.hide()
        else:
            if self.chbASIGNATODOENUNO.isChecked():
                self.spbINFORMES.show()

        rowNumber = self.tablaRefCatResult.rowCount()
        valSubExpte = 1
        listaExptesInforme = []

        # Variable para llevar la cuenta del número de expediente actual
        # Empezamos con el año y número base
        anno_actual = anno_base
        num_actual = numero_base

        for row in range(rowNumber):
            if not self.chbASIGNATODOENUNO.isChecked():
                # Un expediente por cada fila
                # Formato: EX-AAAAnnn (o DP-AAAAnnn)
                ExNumDato = f"{self.prefEXPTE}{anno_actual}{num_actual:03d}"
                self.tablaRefCatResult.setItem(row, 0, QTableWidgetItem(ExNumDato))
                # Incrementar para la siguiente fila
                num_actual += 1
                # Si num_actual sobrepasa 999, necesitaríamos gestionar el cambio de año, pero es poco probable
            else:
                # Un expediente para todas las filas, con subexpedientes
                if rowNumber > 1:
                    ExNumDato = f"{self.prefEXPTE}{anno_actual}{num_actual:03d}-{valSubExpte}"
                else:
                    ExNumDato = f"{self.prefEXPTE}{anno_actual}{num_actual:03d}"
                self.tablaRefCatResult.setItem(row, 0, QTableWidgetItem(ExNumDato))
                valSubExpte += 1

            RC14 = self.tablaRefCatResult.item(row, 1).text()
            Result = self.tablaRefCatResult.item(row, 2).text()
            listaExptesInforme.append({ExNumDato, RC14, Result})

            # Meter los datos en la capa 'Zonas Invadidas' (código existente)
            layers = QgsProject.instance().mapLayersByName(nomLayerINT)
            if layers:
                vl = layers[0]
                vl.startEditing()
                expr = QgsExpression(f'"RC14" LIKE \'{RC14}%\'')
                it = vl.getFeatures(QgsFeatureRequest(expr))
                for feat in it:
                    if feat[self.campoTIPO] == 'RESTO':
                        vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_num'), ExNumDato + '-R')
                    else:
                        vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_num'), ExNumDato)
                vl.commitChanges()

        # Rellenamos el primer grupo de datos
        self.colocaAtributosExpte()

        # Activamos los dos paneles de datos
        self.gpbDATOSEXPRO.setEnabled(True)
        self.gpbDATOSDP.setEnabled(True)
        self.btnCREAEXPTE.setEnabled(True)

    # def asignaExptes(self):
        # ## IDENTIFICAMOS EL´SIGUIENTE EXPEDIENTE A CREAREXPTE
        # #### TODO ANALIZAR SI SE ASIGNA NUEVO EXPEDIENTE DESDE LA ULTIMA CAPETA XTE O DESDE EL VALOR MAS ALTO DE LA EXCEL
        # ExpteNUM = self. qleExpteByDIRECT.text()

        # if self.tablaRefCatResult.rowCount() <= 1:
            # self.spbINFORMES.hide()
        # else:
            # if self.chbASIGNATODOENUNO.isChecked():
                # self.spbINFORMES.show()

        # # Trasladamos loa valores al panel de ANÁLISIS DE RESULTADOS
        # rowNumber = self.tablaRefCatResult.rowCount()
        # valSubExpte = 1
        # listaExptesInforme = []

        # for row in range(rowNumber):
            # if not self.chbASIGNATODOENUNO.isChecked():
                # ExNumDato = self.prefEXPTE+ ExpteNUM[:4]+ExpteNUM[4:]
                # self.tablaRefCatResult.setItem(row , 0, QTableWidgetItem(ExNumDato))
                # ExpteNUM = str(int(ExpteNUM)+1)
            # else:
                # if rowNumber > 1:
                    # ExNumDato = self.prefEXPTE+ ExpteNUM[:4]+ExpteNUM[4:]+'-'+str(valSubExpte)
                # else:
                    # ExNumDato = self.prefEXPTE+ ExpteNUM[:4]+ExpteNUM[4:]
                # self.tablaRefCatResult.setItem(row , 0, QTableWidgetItem(ExNumDato))
                # valSubExpte += 1

            # # Poner el valor en la tabla de la capa 'Zonas invadidas'
            # RC14 = self.tablaRefCatResult.item(row,1).text()
            # Result = self.tablaRefCatResult.item(row,2).text()
            # listaExptesInforme.append({ExNumDato, RC14, Result})

            # # Meter los datos en la capa 'Zonas Invadidas' modificando los existentes
            # layers = QgsProject.instance().mapLayersByName(nomLayerINT)

            # vl = layers[0]
            # it = vl.getFeatures()
            # vlFields = vl.fields()

            # vl.startEditing()
            # expr = QgsExpression(f'"RC14" LIKE \'{RC14}%\'')
            # it = vl.getFeatures( QgsFeatureRequest( expr ) )
            # data = []
            # for feat in it:
                # if feat[self.campoTIPO]== 'RESTO':
                    # vl.changeAttributeValue(feat.id(), vlFields.indexFromName('ex_num'), ExNumDato+'-R')

                # else:
                    # vl.changeAttributeValue(feat.id(), vlFields.indexFromName('ex_num'), ExNumDato)
                    # data = feat.attributes()
            # vl.commitChanges()


        # # Rellenamos el primer grupo de datos
        # self.colocaAtributosExpte()

        # # Activamos los dos paneles de datos
        # self.gpbDATOSEXPRO.setEnabled(True)
        # self.gpbDATOSDP.setEnabled(True)

        # self.btnCREAEXPTE.setEnabled(True)

    def busquedaDirNuevoEXPTE(self, dirINFEXPRO):
        """
        Busca el ÚLTIMO número de expediente en la estructura de directorios.
        Returns:
            str: Último expediente en formato AAAAnnn, o None si no hay.
        """
        anoLast = 2000
        expteLast = 0
        currentYear = datetime.now().year

        # Si el directorio no existe, no podemos buscar
        if not os.path.exists(dirINFEXPRO):
            print(f"busquedaDirNuevoEXPTE: Directorio no existe: {dirINFEXPRO}")
            return None

        # Busca el último año en los subdirectorios
        for subdir1 in self.listdirs(dirINFEXPRO):
            if subdir1[:3] == 'Año' and subdir1[-4:].isnumeric():
                if int(subdir1[-4:]) > anoLast:
                    anoLast = int(subdir1[-4:])

        # Si no hay años, empezar con el año actual
        if anoLast == 2000:
            anoLast = currentYear
            # No hay expedientes previos, devolvemos None para indicar que no hay último
            print(f"busquedaDirNuevoEXPTE: No hay años previos")
            return None

        # Buscar el último expediente en el último año encontrado
        dirExpteAno = os.path.join(dirINFEXPRO, f'Año_{anoLast}')
        if not os.path.exists(dirExpteAno):
            print(f"busquedaDirNuevoEXPTE: Directorio de año no existe: {dirExpteAno}")
            return None

        for subdir2 in self.listdirs(dirExpteAno):
            if subdir2[:3] == self.prefEXPTE and subdir2[-3:].isnumeric():
                # Extraer solo la parte numérica (después de EX-)
                num_expte = subdir2[3:]  # Quitar "EX-"
                if num_expte.isdigit() and len(num_expte) == 7:
                    if int(num_expte[-3:]) > expteLast:
                        expteLast = int(num_expte[-3:])
                        ultimo_completo = num_expte
                else:
                    # Formato antiguo? Intentar extraer año y número
                    try:
                        año_expte = int(subdir2[3:7])  # EX-2023...
                        num_expte = int(subdir2[-3:])
                        if año_expte == anoLast and num_expte > expteLast:
                            expteLast = num_expte
                            ultimo_completo = f"{anoLast}{num_expte:03d}"
                    except:
                        continue

        if expteLast > 0:
            # Devolvemos el último expediente encontrado
            ultimo = f"{anoLast}{expteLast:03d}"
            print(f"busquedaDirNuevoEXPTE: Último expediente encontrado: {ultimo}")
            return ultimo
        else:
            # No hay expedientes en el último año
            print(f"busquedaDirNuevoEXPTE: No hay expedientes en año {anoLast}")
            return None

    # def busquedaDirNuevoEXPTE(self, dirINFEXPRO):
        # # Búsqueda de directorio nuevo de expte
        # anoLast = 2000
        # expteLast = 0
        # currentYear = datetime.now().year  # Obtén el año actual

        # # Busca el último año en los subdirectorios
        # for subdir1 in self.listdirs(dirINFEXPRO):
            # if subdir1[:3] == u'Año' and subdir1[-4:].isnumeric():
                # if int(subdir1[-4:]) > anoLast:
                    # anoLast = int(subdir1[-4:])

        # # Si el último año detectado es menor al año actual, preguntar si se debe crear uno nuevo
        # if anoLast < currentYear:
            # reply = QMessageBox.question(None, 'Crear nuevo directorio de año',
                                         # # f'El último año detectado es {anoLast}. \n\n¿Deseas crear el directorio para {currentYear} y el expediente EX{currentYear}001?',
                                         # f'El último año detectado es {anoLast}. \n\n¿Deseas crear el directorio para {currentYear}?',
                                         # QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

            # if reply == QMessageBox.Yes:
                # # Crear el nuevo directorio para el año actual
                # newDirAno = os.path.join(dirINFEXPRO, f'Año_{currentYear}')
                # print ('dirINFEXPRO: ',dirINFEXPRO, 'newDirAno: ', newDirAno)
                # try:
                    # os.makedirs(newDirAno, exist_ok=True)  # Crea el directorio si no existe
                # except Exception as e:
                    # self.fun.showMessageERR(f"No se pudo crear el directorio {dirExpte}: {str(e)}")
                    # return 'ERROR'
                # # except:
                    # # txt = f'No se puede crear el directorio\n{newDirAno}\n\n'
                    # # txt+= self.fun.PrintException()
                    # # self.fun.showMessageERR(txt)
                # ExpteNUM = f'{currentYear}001'  # El primer expediente del nuevo año
                # return ExpteNUM
            # else:
                # # Si el usuario elige no crear el nuevo directorio, devolvemos None o algún valor especial
                # return None

        # # Si el año detectado es el año actual o no se crea un nuevo directorio
        # dirExpteAno = os.path.join(dirINFEXPRO, f'Año_{anoLast}')
        # for subdir2 in self.listdirs(dirExpteAno):
            # if subdir2[:3] == self.prefEXPTE and subdir2[-3:].isnumeric():
                # if int(subdir2[-3:]) > expteLast:
                    # expteLast = int(subdir2[-3:])

        # # Genera el número del nuevo expediente
        # ExpteNUM = str(anoLast) + self.fun.completarCeros(str(expteLast + 1), 3)
        # return ExpteNUM

    def obtener_ultimo_expte_excel(self):
        """
        Obtiene el ÚLTIMO número de expediente del Excel (no el siguiente).
        Returns:
            str: Último expediente en formato AAAAnnn, o None si no hay.
        """
        try:
            import pandas as pd
            
            if not hasattr(self, 'ExcelInfEXPRO') or not self.ExcelInfEXPRO:
                print("obtener_ultimo_expte_excel: ExcelInfEXPRO no definido")
                return None

            if not os.path.exists(self.ExcelInfEXPRO):
                print(f"obtener_ultimo_expte_excel: Archivo no encontrado: {self.ExcelInfEXPRO}")
                return None

            df = pd.read_excel(self.ExcelInfEXPRO)
            if df.empty:
                print("obtener_ultimo_expte_excel: Excel vacío")
                return None

            # Buscar columna de expediente
            columna_numexpro = None
            posibles_nombres = ['NUMEXPRO', 'Expediente', 'NUM_EXP', 'N_EXPEDIENTE']
            for col in df.columns:
                if str(col).strip().upper() in [n.upper() for n in posibles_nombres]:
                    columna_numexpro = col
                    break

            if columna_numexpro is None:
                print(f"obtener_ultimo_expte_excel: No se encuentra columna. Columnas: {list(df.columns)}")
                return None

            # Recolectar números válidos
            numeros = []
            for val in df[columna_numexpro].dropna():
                try:
                    # Convertir a string y limpiar
                    num_str = str(val).strip()
                    # Quitar prefijos
                    if num_str.startswith('EX-') or num_str.startswith('DP-'):
                        num_str = num_str[3:]
                    
                    # Intentar convertir a entero
                    num_int = int(float(num_str))
                    num_str_limpio = str(num_int)
                    
                    # Verificar longitud 7
                    if len(num_str_limpio) == 7:
                        numeros.append(num_str_limpio)
                        print(f"  -> Número válido: {num_str_limpio}")
                        
                except (ValueError, TypeError):
                    continue

            if numeros:
                max_num = max(numeros)
                print(f"obtener_ultimo_expte_excel: Último encontrado: {max_num}")
                return max_num
            
            print("obtener_ultimo_expte_excel: No hay números válidos")
            return None

        except ImportError:
            print("obtener_ultimo_expte_excel: pandas no instalado")
            return None
        except Exception as e:
            print(f"obtener_ultimo_expte_excel: Error: {e}")
            return None

    # def obtener_ultimo_expte_excel(self):
        # """
        # Obtiene el ÚLTIMO número de expediente del Excel (no el siguiente).
        # Busca en la columna NUMEXPRO (o variantes) números de 7 dígitos (AAAAnnn).
        # Returns:
            # str: Número de expediente en formato AAAAnnn o None si no hay registros válidos.
        # """
        # try:
            # import pandas as pd
            # # 1. Verificar que la ruta del Excel está configurada y existe
            # if not hasattr(self, 'ExcelInfEXPRO') or not self.ExcelInfEXPRO:
                # print("obtener_ultimo_expte_excel: self.ExcelInfEXPRO no está definido.")
                # return None

            # if not os.path.exists(self.ExcelInfEXPRO):
                # print(f"obtener_ultimo_expte_excel: Archivo Excel no encontrado en {self.ExcelInfEXPRO}")
                # return None

            # # 2. Leer el Excel
            # df = pd.read_excel(self.ExcelInfEXPRO)
            # if df.empty:
                # print("obtener_ultimo_expte_excel: El Excel está vacío.")
                # return None

            # # 3. Buscar la columna de número de expediente (flexible)
            # columna_numexpro = None
            # posibles_nombres = ['NUMEXPRO', 'Expediente', 'NUM_EXP', 'N_EXPEDIENTE']
            # for col in df.columns:
                # if str(col).strip().upper() in [nombre.upper() for nombre in posibles_nombres]:
                    # columna_numexpro = col
                    # break

            # if columna_numexpro is None:
                # print(f"obtener_ultimo_expte_excel: No se encuentra columna de expediente. Columnas: {list(df.columns)}")
                # return None

            # # 4. Filtrar y obtener el máximo número válido
            # numeros = []
            # for val in df[columna_numexpro].dropna():
                # try:
                    # # Convertir a string y limpiar
                    # num_str = str(val).strip()
                    # # Quitar posibles prefijos como 'EX-'
                    # if num_str.startswith('EX-'):
                        # num_str = num_str[3:]
                    # elif num_str.startswith('DP-'):
                        # num_str = num_str[3:]

                    # # Intentar convertir a entero para validar que es numérico
                    # num_int = int(float(num_str))
                    # num_str_limpio = str(num_int)

                    # # Verificar longitud de 7 dígitos (AAAA+NNN)
                    # if len(num_str_limpio) == 7:
                        # numeros.append(num_str_limpio)
                        # print(f"  -> Número válido encontrado en Excel: {num_str_limpio}")
                    # else:
                        # print(f"  -> Valor '{val}' no tiene 7 dígitos después de limpiar.")

                # except (ValueError, TypeError):
                    # # Ignorar valores que no se pueden convertir a número
                    # continue

            # if numeros:
                # max_num = max(numeros)
                # print(f"obtener_ultimo_expte_excel: Último expediente encontrado en Excel: {max_num}")
                # return max_num
            # else:
                # print("obtener_ultimo_expte_excel: No se encontraron números de expediente válidos (7 dígitos).")
                # return None

        # except ImportError:
            # print("obtener_ultimo_expte_excel: Librería 'pandas' no instalada.")
            # return None
        # except Exception as e:
            # print(f"obtener_ultimo_expte_excel: Error inesperado: {e}")
            # import traceback
            # traceback.print_exc()
            # return None

    #######################################################################
    #######################################################################
    #######################################################################
    ###   TODO REVISAR POSIBLE DETECCIÓN ÚLTIMO EXPEDIENTE              ###
    #######################################################################
    
    # def obtener_ultimo_expte_excel(self):
        # """
        # Obtiene el último número de expediente del Excel.
        # Busca en la columna NUMEXPRO y extrae números de 7 dígitos (AAAAnnn).
        # Returns:
            # str: Número de expediente en formato AAAAnnn o None si no hay registros
        # """
        # try:
            # import pandas as pd
            # if not hasattr(self, 'ExcelInfEXPRO') or not self.ExcelInfEXPRO:
                # print("ERROR: self.ExcelInfEXPRO no está definido")
                # # Intentar cargarlo de nuevo por si acaso
                # self.ExcelInfEXPRO = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPFichExcelInfEXPRO")
                # if self.ExcelInfEXPRO is None:
                    # self.ExcelInfEXPRO = self.conf.expropiacion["EXPFichExcelInfEXPRO"]
            
            # if not os.path.exists(self.ExcelInfEXPRO):
                # print(f"Archivo Excel no encontrado: {self.ExcelInfEXPRO}")
                # return None
                

            # # def obtener_ultimo_expte_excel(self):
                # # """
                # # Obtiene el último número de expediente del Excel.
                # # Busca en la columna NUMEXPRO y extrae números de 7 dígitos (AAAAnnn).
                # # Returns:
                    # # str: Número de expediente en formato AAAAnnn o None si no hay registros
                # # """
                # # try:
                    # # import pandas as pd
                    # # if not os.path.exists(self.ExcelInfEXPRO):
                        # # print(f"Archivo Excel no encontrado: {self.ExcelInfEXPRO}")
                        # # return None
                
            # # Leer el Excel
            # df = pd.read_excel(self.ExcelInfEXPRO)
            # print(f"Columnas encontradas: {list(df.columns)}")
            
            # # Buscar columna NUMEXPRO (puede estar en mayúsculas o minúsculas)
            # columna_numexpro = None
            # for col in df.columns:
                # if col.upper() == 'NUMEXPRO':
                    # columna_numexpro = col
                    # break
            
            # if columna_numexpro is None:
                # print("No se encuentra la columna NUMEXPRO en el Excel")
                # return None
                
            # print(f"Usando columna: {columna_numexpro}")
            
            # # Convertir a string y filtrar valores válidos
            # numeros = []
            # for val in df[columna_numexpro].dropna():
                # try:
                    # # Convertir a entero y luego a string para eliminar decimales
                    # if isinstance(val, (int, float)):
                        # num = str(int(val))
                    # else:
                        # # Si es string, limpiar
                        # num = str(val).strip()
                        # # Quitar posibles prefijos EX-
                        # if num.startswith('EX-'):
                            # num = num[3:]
                    
                    # # Verificar que sea numérico y de 7 dígitos
                    # if num.isdigit() and len(num) == 7:
                        # numeros.append(num)
                        # # print(f"  -> Número válido encontrado: {num}")
                    # else:
                        # # print(f"  -> Número inválido (longitud {len(num)}): {num}")
                        # pass
                        
                # except Exception as e:
                    # print(f"Error procesando valor {val}: {e}")
                    # continue
                        
            # if numeros:
                # max_num = max(numeros)
                # print(f"Máximo número encontrado en Excel: {max_num}")
                # return max_num
            
            # print("No se encontraron números válidos en el Excel")
            # return None
                
        # except Exception as e:
            # print(f"Error leyendo Excel: {e}")
            # import traceback
            # traceback.print_exc()
            # return None

    #######################################################################
    ###   TODO REVISAR POSIBLE DETCCIÓN ÚLTIMO EXPEDIENTE               ###
    #######################################################################
    #######################################################################
    #######################################################################

    # def obtener_ultimo_expte_excel(self):
        # """
        # Obtiene el último número de expediente del Excel.
        # Returns:
            # str: Número de expediente en formato AAAAnnn o None si no hay registros
        # """
        # try:
            # import pandas as pd
            # if not os.path.exists(self.ExcelInfEXPRO):
                # return None
                
            # df = pd.read_excel(self.ExcelInfEXPRO)
            # if 'NUMEXPRO' not in df.columns:
                # return None
                
            # # Convertir a string y filtrar valores válidos
            # numeros = []
            # for val in df['NUMEXPRO'].dropna():
                # try:
                    # num = str(int(val))
                    # if len(num) == 7:  # Formato AAAAnnn
                        # numeros.append(num)
                # except:
                    # continue
                    
            # if numeros:
                # return max(numeros)
            # return None
            
        # except Exception as e:
            # print(f"Error leyendo Excel: {e}")
            # return None

    def mostrar_dialogo_seleccion_expte(self, expte_directorio, expte_excel):
        """
        Muestra un diálogo para seleccionar el origen del expediente.
        Permite elegir entre directorio, Excel o entrada manual.
        """
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                                     QRadioButton, QButtonGroup, QPushButton, 
                                     QLineEdit, QGroupBox)
        
        dlg = QDialog(self)
        dlg.setWindowTitle("Seleccionar número de expediente")
        dlg.setMinimumWidth(500)
        dlg.setMinimumHeight(250)
        
        layout = QVBoxLayout()
        
        # Mensaje informativo
        lbl_info = QLabel("El próximo número de expediente puede determinarse desde varias fuentes:")
        lbl_info.setWordWrap(True)
        layout.addWidget(lbl_info)
        
        # Grupo de opciones
        group_box = QGroupBox("Origen del número de expediente")
        group_layout = QVBoxLayout()
        
        # Opción 1: Desde directorios
        rb_directorio = QRadioButton(f"📁 Desde directorios del sistema")
        rb_directorio.setToolTip(f"Último expediente encontrado: {expte_directorio}")
        group_layout.addWidget(rb_directorio)
        
        lbl_dir_info = QLabel(f"  → {expte_directorio}")
        lbl_dir_info.setStyleSheet("color: gray; font-size: 9pt;")
        group_layout.addWidget(lbl_dir_info)
        
        # Opción 2: Desde Excel
        rb_excel = QRadioButton(f"📊 Desde el archivo Excel")
        if expte_excel:
            rb_excel.setToolTip(f"Último expediente encontrado: {expte_excel}")
            lbl_excel_info = QLabel(f"  → {expte_excel}")
            lbl_excel_info.setStyleSheet("color: gray; font-size: 9pt;")
        else:
            rb_excel.setEnabled(False)
            rb_excel.setToolTip("No hay registros en el Excel o el archivo no existe")
            lbl_excel_info = QLabel("  → (sin datos)")
            lbl_excel_info.setStyleSheet("color: gray; font-size: 9pt;")
        group_layout.addWidget(lbl_excel_info)
        
        # Opción 3: Manual
        rb_manual = QRadioButton("✏️ Introducir manualmente")
        rb_manual.setToolTip("Escriba el número de expediente en formato AAAAnnn (ej: 2026001)")
        group_layout.addWidget(rb_manual)
        
        # Campo para entrada manual
        manual_layout = QHBoxLayout()
        manual_layout.addSpacing(20)
        lbl_manual = QLabel("Número:")
        self.le_manual_expte = QLineEdit()
        self.le_manual_expte.setPlaceholderText("ej: 2026001")
        self.le_manual_expte.setEnabled(False)
        manual_layout.addWidget(lbl_manual)
        manual_layout.addWidget(self.le_manual_expte)
        group_layout.addLayout(manual_layout)
        
        # Conectar el radio button manual para habilitar/deshabilitar el campo
        rb_manual.toggled.connect(self.le_manual_expte.setEnabled)
        
        # Seleccionar por defecto la opción que tenga datos
        if expte_excel:
            rb_excel.setChecked(True)
        else:
            rb_directorio.setChecked(True)
        
        group_box.setLayout(group_layout)
        layout.addWidget(group_box)
        
        # Opción para recordar (simplificada)
        from qgis.PyQt.QtWidgets import QCheckBox
        self.chk_recordar = QCheckBox("Recordar mi elección para futuras ocasiones")
        layout.addWidget(self.chk_recordar)
        
        # Botones
        btn_layout = QHBoxLayout()
        btn_ok = QPushButton("Aceptar")
        btn_ok.setDefault(True)
        btn_cancel = QPushButton("Cancelar")
        btn_layout.addStretch()
        btn_layout.addWidget(btn_ok)
        btn_layout.addWidget(btn_cancel)
        layout.addLayout(btn_layout)
        
        dlg.setLayout(layout)
        
        # Conectar botones
        def on_aceptar():
            if rb_manual.isChecked() and not self.le_manual_expte.text().strip():
                QMessageBox.warning(dlg, "Error", "Debe introducir un número de expediente")
                return
            dlg.accept()
        
        btn_ok.clicked.connect(on_aceptar)
        btn_cancel.clicked.connect(dlg.reject)
        
        if dlg.exec() == QDialog.DialogCode.Accepted:
            if rb_directorio.isChecked():
                return "directorio", expte_directorio, self.chk_recordar.isChecked()
            elif rb_excel.isChecked():
                return "excel", expte_excel, self.chk_recordar.isChecked()
            else:
                # Validar formato manual
                manual_num = self.le_manual_expte.text().strip()
                if not manual_num.isdigit() or len(manual_num) != 7:
                    QMessageBox.warning(self, "Error", 
                                       "El número debe tener 7 dígitos (formato AAAAnnn)")
                    return None, None, False
                return "manual", manual_num, self.chk_recordar.isChecked()
        
        return None, None, False


    def listdirs(self, path):
        # print (path)
        if os.path.exists(path):
            return [d for d in os.listdir(path) if os.path.isdir(os.path.join(path, d))]
        else:
            return ('NO EXISTE DIRECTORIO')


    def cambiaASIGNATODOENUNO(self):
        if self.chbASIGNATODOENUNO.isChecked():
            # self.spbINFORMES.setVisible(False)
            self.spbINFORMES.setMaximum(1)
        else:
            self.spbINFORMES.setMaximum(self.tablaRefCatResult.rowCount())
            self.spbINFORMES.show()

    def configurar_asignacion_exptes(self):
        """
        Configura los radiobuttons y lineedits para la asignación de expedientes.
        LOS LINEEDITS MUESTRAN EL SIGUIENTE EXPEDIENTE DISPONIBLE (último + 1).
        """
        # 1. Obtener los valores base (ÚLTIMOS expedientes)
        dirINFEXPRO = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPlayerINFOEXPROexptes")
        if dirINFEXPRO is None:
            dirINFEXPRO = self.conf.expropiacion["EXPlayerINFOEXPROexptes"]

        # Obtener los últimos expedientes
        ultimo_directorio_str = self.busquedaDirNuevoEXPTE(dirINFEXPRO)
        ultimo_excel_str = self.obtener_ultimo_expte_excel()
        
        print(f"configurar: Último directorio: {ultimo_directorio_str}")
        print(f"configurar: Último Excel: {ultimo_excel_str}")

        # 2. Calcular el SIGUIENTE expediente para cada fuente
        siguiente_directorio_str = self.calcular_siguiente_expte(ultimo_directorio_str)
        siguiente_excel_str = self.calcular_siguiente_expte(ultimo_excel_str)

        # 3. Asignar los valores a los line edits (MOSTRAMOS EL SIGUIENTE)
        self.qleExpteByDIRECT.setText(siguiente_directorio_str)
        self.qleExpteByEXCEL.setText(siguiente_excel_str)

        # 4. Lógica de selección y visibilidad (COMPARAMOS LOS ÚLTIMOS)
        if ultimo_directorio_str and ultimo_excel_str and ultimo_directorio_str == ultimo_excel_str:
            # Los últimos son iguales -> Ocultamos la opción de Excel completamente
            print("INFO: Últimos expedientes por directorio y Excel coinciden.")
            
            # Ocultar todo el grupo de Excel
            self.rbtAsignaByEXCEL.setVisible(False)
            self.label_ByEXCEL.setVisible(False)  # Necesitas crear este label en el UI
            self.qleExpteByEXCEL.setVisible(False)
            
            # Seleccionar Directorio por defecto
            self.rbtAsignaByDIRECT.setChecked(True)
            self.rbtAsignaByDIRECT.setEnabled(True)
            
            # Asegurar que el line edit de Directorio está visible y habilitado
            self.qleExpteByDIRECT.setVisible(True)
            self.qleExpteByDIRECT.setEnabled(True)
            
        else:
            # Son diferentes o uno no existe -> Mostramos ambas opciones
            print("INFO: Últimos expedientes por directorio y Excel NO coinciden o falta uno.")
            
            # Asegurar que ambos grupos están visibles
            self.rbtAsignaByEXCEL.setVisible(True)
            self.label_ByEXCEL.setVisible(True)
            self.qleExpteByEXCEL.setVisible(True)
            self.rbtAsignaByDIRECT.setVisible(True)
            self.label_ByDIRECT.setVisible(True)
            self.qleExpteByDIRECT.setVisible(True)
            
            # Si solo uno es válido, seleccionar ese y desactivar el otro
            if not ultimo_excel_str:
                # Solo Directorio es válido
                self.rbtAsignaByEXCEL.setEnabled(False)
                self.qleExpteByEXCEL.setEnabled(False)
                self.rbtAsignaByDIRECT.setChecked(True)
                self.rbtAsignaByDIRECT.setEnabled(True)
                self.qleExpteByDIRECT.setEnabled(True)
                
            elif not ultimo_directorio_str:
                # Solo Excel es válido
                self.rbtAsignaByDIRECT.setEnabled(False)
                self.qleExpteByDIRECT.setEnabled(False)
                self.rbtAsignaByEXCEL.setChecked(True)
                self.rbtAsignaByEXCEL.setEnabled(True)
                self.qleExpteByEXCEL.setEnabled(True)
                
            else:
                # Ambos son válidos pero diferentes
                self.rbtAsignaByDIRECT.setEnabled(True)
                self.rbtAsignaByEXCEL.setEnabled(True)
                self.qleExpteByDIRECT.setEnabled(True)
                self.qleExpteByEXCEL.setEnabled(True)
                
                # Por defecto, seleccionar Directorio (como solicitaste)
                self.rbtAsignaByDIRECT.setChecked(True)

        # Llamar a la función para establecer el estilo inicial del line edit activo
        self.actualizar_lineedit_activo()

    # def configurar_asignacion_exptes(self):
        # """
        # Configura los radiobuttons y lineedits para la asignación de expedientes.
        # LOS LINEEDITS MUESTRAN EL SIGUIENTE EXPEDIENTE DISPONIBLE (último + 1).
        # """
        # # 1. Obtener los valores base (ÚLTIMOS expedientes)
        # dirINFEXPRO = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPlayerINFOEXPROexptes")
        # if dirINFEXPRO is None:
            # dirINFEXPRO = self.conf.expropiacion["EXPlayerINFOEXPROexptes"]

        # # Obtener los últimos expedientes
        # ultimo_directorio_str = self.busquedaDirNuevoEXPTE(dirINFEXPRO)
        # ultimo_excel_str = self.obtener_ultimo_expte_excel()
        
        # print(f"configurar: Último directorio: {ultimo_directorio_str}")
        # print(f"configurar: Último Excel: {ultimo_excel_str}")

        # # 2. Calcular el SIGUIENTE expediente para cada fuente
        # siguiente_directorio_str = self.calcular_siguiente_expte(ultimo_directorio_str)
        # siguiente_excel_str = self.calcular_siguiente_expte(ultimo_excel_str)

        # # 3. Asignar los valores a los line edits (MOSTRAMOS EL SIGUIENTE)
        # self.qleExpteByDIRECT.setText(siguiente_directorio_str)
        # self.qleExpteByDIRECT.setEnabled(True)
        # self.rbtAsignaByDIRECT.setEnabled(True)
        
        # self.qleExpteByEXCEL.setText(siguiente_excel_str)
        # self.qleExpteByEXCEL.setEnabled(True)
        # self.rbtAsignaByEXCEL.setEnabled(True)

        # # 4. Lógica de selección y visibilidad (COMPARAMOS LOS ÚLTIMOS)
        # if ultimo_directorio_str and ultimo_excel_str and ultimo_directorio_str == ultimo_excel_str:
            # # Los últimos son iguales -> Ocultamos la opción de Excel y seleccionamos Directorio
            # print("INFO: Últimos expedientes por directorio y Excel coinciden.")
            # self.rbtAsignaByEXCEL.setVisible(False)
            # self.qleExpteByEXCEL.setVisible(False)
            # self.rbtAsignaByDIRECT.setChecked(True)
        # else:
            # # Son diferentes o uno no existe -> Mostramos ambas opciones
            # print("INFO: Últimos expedientes por directorio y Excel NO coinciden o falta uno.")
            # self.rbtAsignaByEXCEL.setVisible(True)
            # self.qleExpteByEXCEL.setVisible(True)
            
            # # Si solo uno es válido, seleccionar ese
            # if not ultimo_excel_str:
                # self.rbtAsignaByDIRECT.setChecked(True)
            # elif not ultimo_directorio_str:
                # self.rbtAsignaByEXCEL.setChecked(True)
            # else:
                # # Ambos válidos pero diferentes -> seleccionamos Directorio por defecto
                # self.rbtAsignaByDIRECT.setChecked(True)

        # # Llamar a la función para establecer el estilo inicial del line edit activo
        # self.actualizar_lineedit_activo()

    # def configurar_asignacion_exptes(self):
        # """
        # Configura los radiobuttons y lineedits para la asignación de expedientes.
        # Calcula los valores desde directorio y Excel y decide la interfaz a mostrar.
        # LOS LINEEDITS MUESTRAN EL SIGUIENTE EXPEDIENTE DISPONIBLE (último + 1).
        # """
        # # 1. Obtener los valores base (últimos expedientes)
        # dirINFEXPRO = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPlayerINFOEXPROexptes")
        # if dirINFEXPRO is None:
            # dirINFEXPRO = self.conf.expropiacion["EXPlayerINFOEXPROexptes"]

        # ultimo_directorio_str = self.busquedaDirNuevoEXPTE(dirINFEXPRO)  # Devuelve el último usado
        # ultimo_excel_str = self.obtener_ultimo_expte_excel()             # Devuelve el último usado

        # # 2. Calcular el SIGUIENTE expediente para cada fuente
        # siguiente_directorio_str = self.calcular_siguiente_expte(ultimo_directorio_str)
        # siguiente_excel_str = self.calcular_siguiente_expte(ultimo_excel_str)

        # # 3. Asignar los valores a los line edits (MOSTRAMOS EL SIGUIENTE)
        # if siguiente_directorio_str:
            # self.qleExpteByDIRECT.setText(siguiente_directorio_str)
            # print(f"configurar: SIGUIENTE por directorio: {siguiente_directorio_str}")
        # else:
            # self.qleExpteByDIRECT.setText("ERROR")
            # self.qleExpteByDIRECT.setEnabled(False)
            # self.rbtAsignaByDIRECT.setEnabled(False)

        # if siguiente_excel_str:
            # self.qleExpteByEXCEL.setText(siguiente_excel_str)
            # print(f"configurar: SIGUIENTE por Excel: {siguiente_excel_str}")
        # else:
            # self.qleExpteByEXCEL.setText("NO HAY DATOS")
            # self.qleExpteByEXCEL.setEnabled(False)
            # self.rbtAsignaByEXCEL.setEnabled(False)

        # # 4. Lógica de selección y visibilidad (COMPARAMOS LOS ÚLTIMOS, no los siguientes)
        # if ultimo_directorio_str and ultimo_excel_str and ultimo_directorio_str == ultimo_excel_str:
            # # Los últimos son iguales -> Ocultamos la opción de Excel y seleccionamos Directorio
            # print("INFO: Últimos expedientes por directorio y Excel coinciden.")
            # self.rbtAsignaByEXCEL.setVisible(False)
            # self.qleExpteByEXCEL.setVisible(False)
            # self.rbtAsignaByDIRECT.setChecked(True)
            # self.rbtAsignaByDIRECT.setEnabled(True)
        # else:
            # # Son diferentes o uno no existe -> Mostramos ambas opciones
            # print("INFO: Últimos expedientes por directorio y Excel NO coinciden o falta uno.")
            # self.rbtAsignaByEXCEL.setVisible(True)
            # self.qleExpteByEXCEL.setVisible(True)

            # # Si solo uno es válido, seleccionar ese y desactivar el otro
            # if not ultimo_excel_str:
                # self.rbtAsignaByEXCEL.setEnabled(False)
                # self.qleExpteByEXCEL.setEnabled(False)
                # self.rbtAsignaByDIRECT.setChecked(True)
            # elif not ultimo_directorio_str or ultimo_directorio_str == 'ERROR':
                # self.rbtAsignaByDIRECT.setEnabled(False)
                # self.qleExpteByDIRECT.setEnabled(False)
                # self.rbtAsignaByEXCEL.setChecked(True)
            # else:
                # # Ambos son válidos pero diferentes. Activamos ambos y seleccionamos Directorio por defecto
                # self.rbtAsignaByDIRECT.setChecked(True)
                # self.rbtAsignaByDIRECT.setEnabled(True)
                # self.rbtAsignaByEXCEL.setEnabled(True)
                # self.qleExpteByDIRECT.setEnabled(True)
                # self.qleExpteByEXCEL.setEnabled(True)

        # # Llamar a la función para establecer el estilo inicial del line edit activo
        # self.actualizar_lineedit_activo()

    def actualizar_lineedit_activo(self):
        """
        Actualiza el aspecto de los QLineEdit para indicar cuál está activo
        según el radiobutton seleccionado.
        """
        # Estilo para el line edit activo (fondo blanco, borde azul)
        estilo_activo = "QLineEdit { background-color: white; border: 2px solid #3498db; }"
        # Estilo para el line edit inactivo (fondo gris claro, borde normal)
        estilo_inactivo = "QLineEdit { background-color: #f0f0f0; border: 1px solid gray; }"

        if self.rbtAsignaByDIRECT.isChecked():
            self.qleExpteByDIRECT.setStyleSheet(estilo_activo)
            self.qleExpteByEXCEL.setStyleSheet(estilo_inactivo)
        elif self.rbtAsignaByEXCEL.isChecked():
            self.qleExpteByDIRECT.setStyleSheet(estilo_inactivo)
            self.qleExpteByEXCEL.setStyleSheet(estilo_activo)

    def calcular_siguiente_expte(self, ultimo_expte_str):
        """
        Calcula el siguiente número de expediente a partir del último.
        
        Args:
            ultimo_expte_str (str): Último expediente en formato AAAAnnn (ej. "2026001")
                                    o None si no hay expedientes previos.
            
        Returns:
            str: Siguiente expediente en formato AAAAnnn.
            Si no hay expedientes previos, devuelve el primero del año actual.
        """
        currentYear = datetime.now().year
        
        # Si no hay expediente previo, devolver el primero del año actual
        if not ultimo_expte_str:
            print(f"calcular_siguiente_expte: No hay último expediente. Usando {currentYear}001")
            return f"{currentYear}001"
        
        try:
            # Validar formato (debe tener 7 dígitos)
            if len(ultimo_expte_str) != 7 or not ultimo_expte_str.isdigit():
                print(f"calcular_siguiente_expte: Formato inválido '{ultimo_expte_str}'. Usando {currentYear}001")
                return f"{currentYear}001"
            
            anno = int(ultimo_expte_str[:4])
            numero = int(ultimo_expte_str[4:])
            
            # Incrementar el número
            numero += 1
            
            # Si el número supera 999, pasar al siguiente año
            if numero > 999:
                anno += 1
                numero = 1
                
            # Formatear: año (4 dígitos) + número (3 dígitos con ceros)
            siguiente = f"{anno}{numero:03d}"
            print(f"calcular_siguiente_expte: Último='{ultimo_expte_str}' -> Siguiente='{siguiente}'")
            return siguiente
            
        except (ValueError, TypeError) as e:
            print(f"calcular_siguiente_expte: Error procesando '{ultimo_expte_str}': {e}")
            return f"{currentYear}001"

    # def calcular_siguiente_expte(self, ultimo_expte_str):
        # """
        # Calcula el siguiente número de expediente a partir del último.
        
        # Args:
            # ultimo_expte_str (str): Último expediente en formato AAAAnnn (ej. "2026001")
            
        # Returns:
            # str: Siguiente expediente en formato AAAAnnn, o None si la entrada es inválida.
        # """
        # if not ultimo_expte_str or ultimo_expte_str in ["ERROR", "NO EXISTE DIRECTORIO", "NO HAY DATOS"]:
            # return None
        
        # try:
            # # Validar formato (debe tener 7 dígitos)
            # if len(ultimo_expte_str) != 7 or not ultimo_expte_str.isdigit():
                # print(f"calcular_siguiente_expte: Formato inválido '{ultimo_expte_str}'")
                # return None
            
            # anno = int(ultimo_expte_str[:4])
            # numero = int(ultimo_expte_str[4:])
            
            # # Incrementar el número
            # numero += 1
            
            # # Si el número supera 999, pasar al siguiente año
            # if numero > 999:
                # anno += 1
                # numero = 1
                
            # # Formatear: año (4 dígitos) + número (3 dígitos con ceros)
            # siguiente = f"{anno}{numero:03d}"
            # print(f"calcular_siguiente_expte: Último='{ultimo_expte_str}' -> Siguiente='{siguiente}'")
            # return siguiente
            
        # except (ValueError, TypeError) as e:
            # print(f"calcular_siguiente_expte: Error procesando '{ultimo_expte_str}': {e}")
            # return None

    def herrDP_CONFIG(self):
        self.herrDP_CONFIGdlg_expInvDP = jccm_bar_config(
            self.iface, 
            tabConfig=0,
            tabName = 'DOM.PUBLICO'  # 👈 Usamos el nombre
        )
        result = self.herrDP_CONFIGdlg_expInvDP.exec()
        return result


    #----------------------------------------------------------------------------------------------------
    #           PASO 3.Cambiar atributos
    #----------------------------------------------------------------------------------------------------

    # *** FUNCIONES ***
    # colocaAtributosExpte()

    #----------------------------------------------------------------------------------------------------
        
    def colocaAtributosExpte(self):
        """
        Coloca los atributos del expediente en la interfaz.
        Para múltiples parcelas, determina el tipo prevalente y combina los TMs.
        """
        numOrden = self.spbINFORMES.value() - 1
        
        # ======================================================================
        # 1. RECOPILAR DATOS DE TODAS LAS PARCELAS DEL EXPEDIENTE
        # ======================================================================
        parcelas_datos = []
        tm_set = set()  # Usamos set para evitar duplicados
        
        # Determinar qué filas pertenecen al mismo expediente
        if self.chbASIGNATODOENUNO.isChecked():
            # Todas las filas son del mismo expediente
            filas_procesar = range(self.tablaRefCatResult.rowCount())
        else:
            # Solo la fila actual
            filas_procesar = [numOrden]
        
        # Recopilar datos de todas las filas relevantes
        for fila in filas_procesar:
            rc14 = self.tablaRefCatResult.item(fila, 1).text()
            tipo = self.tablaRefCatResult.item(fila, 2).text()
            tm = self.tablaRefCatResult.item(fila, 7).text()
            expte_expro = self.tablaRefCatResult.item(fila, 3).text()
            
            # Añadir TM al conjunto (para luego combinarlos)
            if tm and tm != 's/d':
                tm_set.add(tm)
            
            # Buscar datos adicionales en la capa 'Zonas invadidas'
            datos_capa = self.buscarDatosEnCapaInvasiones(rc14, tipo)
            
            parcelas_datos.append({
                'rc14': rc14,
                'tipo': tipo,
                'tm': tm,
                'expte_expro': expte_expro,
                'nom_tramo': datos_capa.get('nom_tramo', 's/d'),
                'nom_proyec': datos_capa.get('nom_proyec', 's/d'),
                'cat_remisi': datos_capa.get('cat-remisi', ''),
                'textinf': datos_capa.get('ex_textinf', ''),
                'margen': datos_capa.get('ex_margen', 'Ambas'),
                'actas_previas': datos_capa.get('lee_actas previas', 'S/D'),
                'decr_acuerdo': datos_capa.get('lee_decr_acue_reso', 'S/D')
            })
        
        # ======================================================================
        # 2. DETERMINAR EL TIPO PREVALENTE
        # ======================================================================
        listTIPOEXPTEord = [
            'INVASION',
            'INVASION AEE',
            'INVASION BBPP',
            'BIENES PATRIMONIALES',
            'NO INVASION',
            'NO INVASION, URBANO',
            'NO COLIND CTRA JCCM',
            'REMISION CATASTRAL',
            'ACLAR RECT.CATASTRAL',
            'PERMUTA',
            'REVERSION',
            'CORRECCIÓN CATASTRAL',
            'SIN CLASIFICAR'
        ]
        
        # Inicializar variables
        tipo_prevalente = 'SIN CLASIFICAR'
        min_indice = len(listTIPOEXPTEord)
        datos_principales = None  # Inicializar explícitamente
        
        # Buscar el tipo con mayor prioridad
        for parcela in parcelas_datos:
            tipo = parcela['tipo']
            if tipo in listTIPOEXPTEord:
                indice = listTIPOEXPTEord.index(tipo)
                if indice < min_indice:
                    min_indice = indice
                    tipo_prevalente = tipo
                    datos_principales = parcela  # Guardar datos de la parcela prevalente
        
        # CASO 1: Se encontró un tipo en la lista
        if datos_principales is not None:
            # Ya tenemos los datos principales de la parcela prevalente
            pass
        
        # CASO 2: No se encontró ningún tipo en la lista (tipos personalizados)
        elif parcelas_datos:
            # Usar la primera parcela como principal
            datos_principales = parcelas_datos[0]
            tipo_prevalente = datos_principales['tipo']
            print(f"INFO: Tipo '{tipo_prevalente}' no está en la lista de prioridades. Se usa como prevalente.")
        
        # CASO 3: No hay parcelas (no debería ocurrir, pero por seguridad)
        else:
            # Crear datos por defecto
            datos_principales = {
                'rc14': '',
                'tipo': 'SIN CLASIFICAR',
                'tm': 's/d',
                'expte_expro': '',
                'nom_tramo': 's/d',
                'nom_proyec': 's/d',
                'cat_remisi': '',
                'textinf': '',
                'margen': 'Ambas',
                'actas_previas': 'S/D',
                'decr_acuerdo': 'S/D'
            }
        
        # ======================================================================
        # 3. COMBINAR TÉRMINOS MUNICIPALES
        # ======================================================================
        tm_combinado = ', '.join(sorted(tm_set)) if tm_set else 's/d'
        
        # ======================================================================
        # 4. COMBINAR REFERENCIAS CATASTRALES
        # ======================================================================
        if self.chbASIGNATODOENUNO.isChecked() and len(parcelas_datos) > 1:
            rc14_combinadas = [p['rc14'] for p in parcelas_datos]
            
            if len(rc14_combinadas) <= 2:
                rc14_texto = ' y '.join(rc14_combinadas)
            else:
                ultima = rc14_combinadas.pop()
                rc14_texto = ', '.join(rc14_combinadas) + ' y ' + ultima
        else:
            rc14_texto = datos_principales['rc14']
        
        
        # def colocaAtributosExpte(self):
            # """
            # Coloca los atributos del expediente en la interfaz.
            # Para múltiples parcelas, determina el tipo prevalente y combina los TMs.
            # """
            # numOrden = self.spbINFORMES.value() - 1
            
            # # ======================================================================
            # # 1. RECOPILAR DATOS DE TODAS LAS PARCELAS DEL EXPEDIENTE
            # # ======================================================================
            # parcelas_datos = []
            # tm_set = set()  # Usamos set para evitar duplicados
            
            # # Determinar qué filas pertenecen al mismo expediente
            # if self.chbASIGNATODOENUNO.isChecked():
                # # Todas las filas son del mismo expediente
                # filas_procesar = range(self.tablaRefCatResult.rowCount())
            # else:
                # # Solo la fila actual
                # filas_procesar = [numOrden]
            
            # # Recopilar datos de todas las filas relevantes
            # for fila in filas_procesar:
                # rc14 = self.tablaRefCatResult.item(fila, 1).text()
                # tipo = self.tablaRefCatResult.item(fila, 2).text()
                # tm = self.tablaRefCatResult.item(fila, 7).text()
                # expte_expro = self.tablaRefCatResult.item(fila, 3).text()
                
                # # Añadir TM al conjunto (para luego combinarlos)
                # if tm and tm != 's/d':
                    # tm_set.add(tm)
                
                # # Buscar datos adicionales en la capa 'Zonas invadidas'
                # datos_capa = self.buscarDatosEnCapaInvasiones(rc14, tipo)
                
                # parcelas_datos.append({
                    # 'rc14': rc14,
                    # 'tipo': tipo,
                    # 'tm': tm,
                    # 'expte_expro': expte_expro,
                    # 'nom_tramo': datos_capa.get('nom_tramo', 's/d'),
                    # 'nom_proyec': datos_capa.get('nom_proyec', 's/d'),
                    # 'cat_remisi': datos_capa.get('cat-remisi', ''),
                    # 'textinf': datos_capa.get('ex_textinf', ''),
                    # 'margen': datos_capa.get('ex_margen', 'Ambas'),
                    # 'actas_previas': datos_capa.get('lee_actas previas', 'S/D'),
                    # 'decr_acuerdo': datos_capa.get('lee_decr_acue_reso', 'S/D')
                # })
            
            # # ======================================================================
            # # 2. DETERMINAR EL TIPO PREVALENTE
            # # ======================================================================
            # listTIPOEXPTEord = [
                # 'INVASION',
                # 'INVASION AEE',
                # 'INVASION BBPP',
                # 'BIENES PATRIMONIALES',
                # 'NO INVASION',
                # 'NO INVASION, URBANO',
                # 'NO COLIND CTRA JCCM',
                # 'REMISION CATASTRAL',
                # 'ACLAR RECT.CATASTRAL',
                # 'PERMUTA',
                # 'REVERSION',
                # 'CORRECCIÓN CATASTRAL',
                # 'SIN CLASIFICAR'
            # ]
            
            # # Encontrar el tipo con mayor prioridad (menor índice)
            # tipo_prevalente = 'SIN CLASIFICAR'
            # min_indice = len(listTIPOEXPTEord)
            
            # for parcela in parcelas_datos:
                # tipo = parcela['tipo']
                # if tipo in listTIPOEXPTEord:
                    # indice = listTIPOEXPTEord.index(tipo)
                    # if indice < min_indice:
                        # min_indice = indice
                        # tipo_prevalente = tipo
                        # # Guardamos los datos de esta parcela como los principales
                        # datos_principales = parcela
            
            # # Si no se encontró en la lista, usar el primero
            # if not datos_principales and parcelas_datos:
                # datos_principales = parcelas_datos[0]
                # tipo_prevalente = datos_principales['tipo']
            
            # # ======================================================================
            # # 3. COMBINAR TÉRMINOS MUNICIPALES
            # # ======================================================================
            # tm_combinado = ', '.join(sorted(tm_set)) if tm_set else 's/d'
            
            # # ======================================================================
            # # 4. COMBINAR REFERENCIAS CATASTRALES
            # # ======================================================================
            # if self.chbASIGNATODOENUNO.isChecked() and len(parcelas_datos) > 1:
                # rc14_combinadas = []
                # for p in parcelas_datos:
                    # rc14_combinadas.append(p['rc14'])
                
                # if len(rc14_combinadas) <= 2:
                    # rc14_texto = ' y '.join(rc14_combinadas)
                # else:
                    # ultima = rc14_combinadas.pop()
                    # rc14_texto = ', '.join(rc14_combinadas) + ' y ' + ultima
            # else:
                # rc14_texto = datos_principales['rc14'] if datos_principales else ''
        
        # ======================================================================
        # 5. DETERMINAR MARGEN (si hay diferentes, poner 'Ambas')
        # ======================================================================
        margenes = set(p['margen'] for p in parcelas_datos if p['margen'])
        if len(margenes) > 1:
            margen_final = 'Ambas'
        elif margenes:
            margen_final = next(iter(margenes))
        else:
            margen_final = 'Ambas'
        
        # ======================================================================
        # 6. OBTENER DATOS DEL EXPEDIENTE ACTUAL
        # ======================================================================
        EX_NUM = self.tablaRefCatResult.item(numOrden, 0).text()[3:] if numOrden >= 0 else ''
        
        # Quitar el sufijo si es múltiple (-1, -2, etc.)
        if '-' in EX_NUM:
            EX_NUM = EX_NUM.split('-')[0]
        
        # ======================================================================
        # 7. PREPARAR LISTA DE VALORES PARA EL CASO CARRETERAS
        # ======================================================================
        if self.tipoDP != 'MUNICIPAL':
            # Obtener datos de la fila actual para valores específicos de carretera
            if numOrden >= 0:
                carretera = self.tablaRefCatResult.item(numOrden, 4).text()
                pk_ini = self.tablaRefCatResult.item(numOrden, 5).text()
                pk_fin = self.tablaRefCatResult.item(numOrden, 6).text()
                inv_max = self.tablaRefCatResult.item(numOrden, 8).text()
                sup_inv = self.tablaRefCatResult.item(numOrden, 9).text()
            else:
                carretera = pk_ini = pk_fin = inv_max = sup_inv = ''
                
            # Limpiar y rellenar combos con las opciones de configuración
            self.EX_MARGEN.clear()
            self.EX_MARGEN.addItems(listMARGEN)
            
            self.EX_INGENIERO.clear()
            self.EX_INGENIERO.addItems(listINGENIERO)
            
            self.EX_TIPO_EXPEDIENTE.clear()
            self.EX_TIPO_EXPEDIENTE.addItems(self.listTIPOEXPTE)
            
            self.EX_SOLICITANTE.clear()
            self.EX_SOLICITANTE.addItems(listSOLICITANTE)
            
            self.EX_INTERESADO.clear()
            self.EX_INTERESADO.addItems(listINTERESADO)
            
            self.EX_ART_LEY.clear()
            self.EX_ART_LEY.addItems(listArticuloLey)
        
            listaVAL = [
                EX_NUM,                                         # 00 NUMEXPRO
                '',                                             # 01 REGISTRO
                QDate.currentDate(),                            # 02 FECHA
                '',                                             # 03 SOLICITANTE
                '',                                             # 04 INTERESADO
                '',                                             # 05 DNI
                '',                                             # 06 NOMBRE
                '',                                             # 07 DOMICILIO
                '',                                             # 08 CODIGOPOST
                '',                                             # 09 TLFNO
                '',                                             # 10 POBLACION
                carretera,                                      # 11 CARRETERA
                pk_ini,                                         # 12 KILOMETRO
                pk_fin,                                         # 13 KILOMET2
                margen_final,                                   # 14 MARGEN
                '',                                             # 15 OBSERVAPK
                datos_principales.get('textinf', ''),          # 16 TIPO
                '',                                             # 17 ARCHIVO
                '',                                             # 18 IG
                '',                                             # 19 INGENIERO
                '',                                             # 20 ADMIN
                '',                                             # 21 (vacío)
                '',                                             # 22 ESTAARCHIVADO
                '',                                             # 23 FECHAARCHIVO
                datos_principales.get('expte_expro', ''),      # 24 EXPTE_EXPROPIACION
                '',                                             # 25 EXPTES_RELACIONADOS
                datos_principales.get('nom_tramo', 's/d'),     # 26 NOMBRE_TRAMO
                datos_principales.get('decr_acuerdo', 'S/D'),  # 27 DECR_ACUERDO_RESOLUCION
                datos_principales.get('actas_previas', 'S/D'), # 28 ACTAS_PREVIAS
                datos_principales.get('cat_remisi', ''),       # 29 REMISION_CATASTRAL
                '',                                             # 30 NUMORDEN
                '',                                             # 31 POLIGONO
                '',                                             # 32 PARCELAS
                tm_combinado,                                   # 33 TM
                tipo_prevalente,                                # 34 TIPO_EXPEDIENTE
                QDate.currentDate(),                            # 35 FECHAINFORME
                datos_principales.get('nom_proyec', 's/d'),    # 36 TITULO_EXPROPIACION
                '',                                             # 37 EX_EXPTE_OBRA_RELACIONADO
                rc14_texto,                                     # 38 REF_CATASTRAL
                QDate.currentDate(),                            # 39 FECHA_ULTIMO_TRAMITE
                'Entrada Solicitud',                            # 40 TRAMITE_EXPROPIACION
                '',                                             # 41 CORREOELEC
                '',                                             # 42 PROTOCOLO REGISTRO
                ''                                              # 43 ART_LEY
            ]
            
            # Aplicar valores a la interfaz
            self.aplicarValoresInterfazCarreteras(listaVAL)
        
        else:
            # ======================================================================
            # CASO MUNICIPAL
            # ======================================================================
            
            # Limpiar y rellenar combos municipales
            self.DP_INGENIERO.clear()
            self.DP_INGENIERO.addItems(listINGENIERO)
            self.DP_INGENIERO.addItem('')
            
            self.DP_TIPO_EXPEDIENTE.clear()
            self.DP_TIPO_EXPEDIENTE.addItems(self.listTIPOEXPTE)
            
            self.DP_SOLICITANTE.clear()
            self.DP_SOLICITANTE.addItems(listSOLICITANTE)
            self.DP_SOLICITANTE.addItem('')
            
            self.DP_INTERESADO.clear()
            self.DP_INTERESADO.addItems(listINTERESADO)
            self.DP_INTERESADO.addItem('')
            
            listaVAL = [
                EX_NUM,                                         # 00 EXPEDIENTE
                '',                                             # 01 REGISTRO
                QDate.currentDate(),                            # 02 FECHA
                '',                                             # 03 SOLICITANTE
                '',                                             # 04 INTERESADO
                '',                                             # 05 DNI
                '',                                             # 06 NOMBRE
                '',                                             # 07 DOMICILIO
                '',                                             # 08 CODIGOPOST
                '',                                             # 09 TLFNO
                '',                                             # 10 POBLACION
                '',                                             # 11 CARRETERA
                0,                                              # 12 KILOMETRO
                0,                                              # 13 KILOMET2
                '',                                             # 14 MARGEN
                '',                                             # 15 OBSERVAPK
                datos_principales.get('textinf', ''),          # 16 TIPO
                '',                                             # 17 ARCHIVO
                '',                                             # 18 IG
                '',                                             # 19 INGENIERO
                '',                                             # 20 ADMIN
                '',                                             # 21 ESTAARCHIVADO
                '',                                             # 22 FECHAARCHIVO
                '',                                             # 23 EXPTE_EXPROPIACION
                '',                                             # 24 EXPTES_RELACIONADOS
                '',                                             # 25 NOMBRE_TRAMO
                '',                                             # 26 DECR_ACUERDO_RESOLUCION
                '',                                             # 27 ACTAS_PREVIAS
                '',                                             # 28 REMISION_CATASTRAL
                '',                                             # 29 NUMORDEN
                '',                                             # 30 POLIGONO
                '',                                             # 31 PARCELAS
                tm_combinado,                                   # 32 TM
                tipo_prevalente,                                # 33 TIPO_EXPEDIENTE
                QDate.currentDate(),                            # 34 FECHAINFORME
                '',                                             # 35 TITULO_EXPROPIACION
                '',                                             # 36 EX_EXPTE_OBRA_RELACIONADO
                rc14_texto,                                     # 37 REF_CATASTRAL
                QDate.currentDate(),                            # 38 FECHA_ULTIMO_TRAMITE
                '',                                             # 39 TRAMITE_EXPROPIACION
                ''                                              # 40 CORREOELEC
            ]
            
            self.aplicarValoresInterfazMunicipal(listaVAL)

    def buscarDatosEnCapaInvasiones(self, rc14, tipo):
        """
        Busca datos adicionales en la capa 'Zonas invadidas' para una parcela.
        """
        datos = {}
        try:
            layer = QgsProject.instance().mapLayersByName(self.NOMBRE_CAPA_RESULTADOS)
            if not layer:
                return datos
            
            layer = layer[0]
            expr = QgsExpression(f'"RC14" LIKE \'{rc14}%\' AND "ex_tipoinv" = \'{tipo}\'')
            features = layer.getFeatures(QgsFeatureRequest(expr))
            
            for feat in features:
                # Extraer campos relevantes
                for campo in ['nom_tramo', 'nom_proyec', 'cat-remisi', 
                             'ex_textinf', 'ex_margen', 'lee_actas previas', 
                             'lee_decr_acue_reso']:
                    if campo in feat.fields().names():
                        valor = feat[campo]
                        if valor and str(valor).strip() and str(valor).strip().lower() != 's/d':
                            datos[campo] = valor
                break  # Tomamos el primer feature que encuentre
        
        except Exception as e:
            print(f"Error buscando datos en capa invasiones: {e}")
        
        return datos


    def aplicarValoresInterfazCarreteras(self, listaVAL):
        """
        Aplica los valores a la interfaz para el caso de carreteras.
        """
        self.EX_NUMEXPRO.setText('EX-' + listaVAL[0])
        self.EX_REGISTRO.setText(listaVAL[1])
        self.EX_FECHA.setDate(QDate.currentDate())
        
        # SOLICITANTE
        idx = self.EX_SOLICITANTE.findText(listaVAL[3], Qt.MatchFlag.MatchFixedString)
        self.EX_SOLICITANTE.setCurrentIndex(idx if idx >= 0 else -1)
        
        # INTERESADO
        idx = self.EX_INTERESADO.findText(listaVAL[4], Qt.MatchFlag.MatchFixedString)
        self.EX_INTERESADO.setCurrentIndex(idx if idx >= 0 else -1)
        
        self.EX_CARRETERA.setText(listaVAL[11])
        self.EX_KILOMETRO.setText(listaVAL[12])
        self.EX_KILOMET2.setText(listaVAL[13])
        
        # MARGEN
        idx = self.EX_MARGEN.findText(listaVAL[14], Qt.MatchFlag.MatchFixedString)
        if idx >= 0:
            self.EX_MARGEN.setCurrentIndex(idx)
        else:
            self.EX_MARGEN.addItem(listaVAL[14])
            self.EX_MARGEN.setCurrentIndex(self.EX_MARGEN.count() - 1)
        
        self.EX_OBSERVAPK.setText(listaVAL[15])
        self.EX_TIPO.setText(listaVAL[16])
        
        # INGENIERO
        idx = self.EX_INGENIERO.findText(listaVAL[19], Qt.MatchFlag.MatchFixedString)
        if idx >= 0:
            self.EX_INGENIERO.setCurrentIndex(idx)
        else:
            self.EX_INGENIERO.addItem(listaVAL[19])
        
        self.EX_EXPTE_EXPROPIACION.setText(listaVAL[24])
        self.EX_EXPTES_RELACIONADOS.setText(listaVAL[25])
        self.EX_NOMBRE_TRAMO.setText(listaVAL[26])
        self.EX_DECR_ACUERDO_RESOLUCION.setText(listaVAL[27])
        self.EX_ACTAS_PREVIAS.setText(listaVAL[28])
        self.EX_REMISION_CATASTRAL.setText(listaVAL[29])
        self.EX_NUMORDEN.setText(listaVAL[30])
        self.EX_POLIGONO.setText(listaVAL[31])
        self.EX_PARCELAS.setText(listaVAL[32])
        self.EX_TM.setText(listaVAL[33])
        
        # TIPO_EXPEDIENTE
        idx = self.EX_TIPO_EXPEDIENTE.findText(listaVAL[34], Qt.MatchFlag.MatchFixedString)
        if idx >= 0:
            self.EX_TIPO_EXPEDIENTE.setCurrentIndex(idx)
        else:
            self.EX_TIPO_EXPEDIENTE.addItem(listaVAL[34])
            self.EX_TIPO_EXPEDIENTE.setCurrentIndex(self.EX_TIPO_EXPEDIENTE.count() - 1)
        
        self.EX_TITULO_EXPROPIACION.setText(listaVAL[36])
        self.EX_REF_CATASTRAL.setText(listaVAL[38])
        self.EX_FECHA_ULTIMO_TRAMITE.setDate(QDate.currentDate())
        self.EX_TRAMITE_EXPROPIACION.setText(listaVAL[40])
        self.EX_CORREOELEC.setText(listaVAL[41])
        self.EX_PROTOCOLO_REGISTRO.setText(listaVAL[42])
        
        # ART_LEY
        idx = self.EX_ART_LEY.findText(listaVAL[43], Qt.MatchFlag.MatchFixedString)
        self.EX_ART_LEY.setCurrentIndex(idx if idx >= 0 else -1)


    def aplicarValoresInterfazMunicipal(self, listaVAL):
        """
        Aplica los valores a la interfaz para el caso municipal.
        """
        self.DP_NUMEXPRO.setText(listaVAL[0])
        self.DP_FECHA.setDate(QDate.currentDate())
        self.DP_REF_CATASTRAL.setText(listaVAL[37])
        self.DP_TM.setText(listaVAL[32])
        
        # TIPO_EXPEDIENTE
        idx = self.DP_TIPO_EXPEDIENTE.findText(listaVAL[33], Qt.MatchFlag.MatchFixedString)
        if idx >= 0:
            self.DP_TIPO_EXPEDIENTE.setCurrentIndex(idx)
        else:
            self.DP_TIPO_EXPEDIENTE.addItem(listaVAL[33])
            self.DP_TIPO_EXPEDIENTE.setCurrentIndex(self.DP_TIPO_EXPEDIENTE.count() - 1)
        
        self.DP_TEXTINF.setText(listaVAL[16])



    def creaEXPTE(self, proviEXPRO, layerLIMInom, layerINFEXPnom):
        # Se crea el directorio y el fichero TXT del expediente
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        color_rojo  = '255,200,200'

        if self.tipoDP != 'MUNICIPAL':
            if self.EX_SOLICITANTE.currentText() == '' or self.EX_INTERESADO.currentText() == '' or self.EX_REGISTRO.text() == '':
                if self.EX_SOLICITANTE.currentText() == '':
                    self.EX_SOLICITANTE.setStyleSheet("background: rgb(" +color_rojo+');')
                if self.EX_INTERESADO.currentText() == '':
                    self.EX_INTERESADO.setStyleSheet("background: rgb(" +color_rojo+');')
                if self.EX_REGISTRO.text() == '':
                    self.EX_REGISTRO.setStyleSheet("background: rgb(" +color_rojo+');')
                QApplication.restoreOverrideCursor()
                text = 'Se deben completar los datos señalados en rojo'
                self.fun.showMessageERR(text,"",tittle="ERROR: FALTAN DATOS",)
                return

        resul = self.creaEXPTEDIR(self)

        if resul == 'ERROR':
            return
        self.dirExpte = resul

        # Metemos los valores del menú al fichero de invasiones
        layers = QgsProject.instance().mapLayersByName(nomLayerINT)

        vl = layers[0]
        it = vl.getFeatures()

        vl.startEditing()

        rowNumber = self.tablaRefCatResult.rowCount()
        valSubExpte = 1
        listaExptesInforme = []
        for row in range(rowNumber):
            # Poner el valor en la tabla de la capa 'Zonas invadidas'
            RC14 = self.tablaRefCatResult.item(row,1).text()

            expr = QgsExpression( u'"RC14" = \''+RC14+'\'' )
            it = vl.getFeatures( QgsFeatureRequest( expr ) )
            data = []
            for feat in it:
                ## AQUÍ METEMOS LOS VALORES DESDE EL MENÚ
                VALENMENU = 's/d'
                if self.tipoDP != 'MUNICIPAL':
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_registro'),   self.EX_REGISTRO.text())
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_fecha'),      self.EX_FECHA.date().toString('dd/MM/yyyy'))
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_solicitante'),self.EX_SOLICITANTE.currentText())
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_interesado'), self.EX_INTERESADO.currentText())
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_correoelec'), self.EX_CORREOELEC.toPlainText())
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_nombre'),     self.EX_NOMBRE.text())
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_dni'),        self.EX_DNI.text())
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_tlfno'),      self.EX_TLFNO.text())
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_protocolo'),  self.EX_PROTOCOLO_REGISTRO.text())
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('ex_art_ley'),    self.EX_ART_LEY.currentText())
                else:
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('dp_registro'),   self.DP_REGISTRO.text())
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('dp_fecha'),      self.DP_FECHA.date().toString('dd/MM/yyyy'))
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('dp_solicitante'),self.DP_SOLICITANTE.currentText())
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('dp_interesado'), self.DP_INTERESADO.currentText())
                    vl.changeAttributeValue(feat.id(), vl.fields().indexFromName('dp_correoelec'), self.DP_CORREOELEC.toPlainText())

        vl.commitChanges()

        # print ('ACABAMOS DE METER LOS ÚLTIMOS VALORES EN LA CAPA ', nomLayerINT)


        # Se copian los elementos de ZONAS INVADIDAS a INFORMES DE EXPROPIACIONES
        sourceLYR = QgsProject.instance().mapLayersByName(nomLayerINT)[0]       # Capa origen ZONAS INVADIDAS
        destLYR = QgsProject.instance().mapLayersByName(self.layerINFEXPnom)[0] # Capa destino INFORMES DE EXPROPIACIONES
        pr = destLYR.dataProvider()
        destLYR.startEditing()

        # Obtenemos el máximo valor de fid de la capa INFORMES DE EXPROPIACIONES
        values = []
        for feat in destLYR.getFeatures():
           attrs = feat.attributes()
           values.append(attrs[0])
        if len(values) > 0:
            newIndex = max(values) + 1
        else:
            newIndex = 1

        # Se añaden los elementos y atributos de ZONAS INVADIDAS a la capa de INFORMES DE EXPROPIACIONES
        for feature in sourceLYR.getFeatures():
            fet = QgsFeature(destLYR.fields())
            fet.setGeometry(  feature.geometry())
            for field in destLYR.fields():
                if field.name() == 'fid':
                    fet.setAttribute('fid', newIndex)
                    newIndex += 1
                    continue

                # Comprueba si el campo existe en la capa de origen
                idx = sourceLYR.fields().indexFromName(field.name().lower())
                if idx != -1:
                    valor_atributo = feature[field.name().lower()]

                    # Obtén el tipo de campo
                    tipo_campo_destino = field.type()
                    tipo_valor_atributo = type(valor_atributo)

                    # Mapea los tipos de campo en QGIS con los tipos de Python
                    if tipo_campo_destino == QMetaType.Type.Int:
                        if tipo_valor_atributo is int:
                            fet.setAttribute(field.name(), valor_atributo)
                        else:
                            try:
                                # Intentar convertir a entero
                                valor_convertido = int(valor_atributo)
                                fet.setAttribute(field.name(), valor_convertido)
                            except (ValueError, TypeError):
                                print(f"No se pudo convertir {valor_atributo} a int para el campo {field.name()}")
                    elif tipo_campo_destino == QMetaType.Type.Double:
                        if tipo_valor_atributo is float:
                            fet.setAttribute(field.name(), valor_atributo)
                        else:
                            try:
                                # Intentar convertir a flotante
                                valor_convertido = float(valor_atributo)
                                fet.setAttribute(field.name(), valor_convertido)
                            except (ValueError, TypeError):
                                print(f"No se pudo convertir {valor_atributo} a float para el campo {field.name()}")
                    elif tipo_campo_destino == QMetaType.Type.QString:
                        if tipo_valor_atributo is str:
                            fet.setAttribute(field.name(), valor_atributo)
                        else:
                            # Convertir a string si no lo es
                            fet.setAttribute(field.name(), str(valor_atributo))
                    elif tipo_campo_destino == QMetaType.Type.QDate:
                        if isinstance(valor_atributo, QDate):
                            fet.setAttribute(field.name(), valor_atributo)
                        else:
                            try:
                                # Intentar convertir una cadena a QDate (si tiene el formato adecuado)
                                # fecha_convertida = QDate.fromString(valor_atributo, 'yyyy-MM-dd')
                                fecha_convertida = QDate.fromString(valor_atributo, 'dd/MM/yyyy')
                                if fecha_convertida.isValid():
                                    fet.setAttribute(field.name(), fecha_convertida)
                                else:
                                    print(f"Fecha inválida: {valor_atributo} para el campo {field.name()}")
                                    pass
                            except (ValueError, TypeError):
                                print(f"No se pudo convertir {valor_atributo} a fecha para el campo {field.name()}")
                    else:
                        print(f"Tipos incompatibles: {field.name()} -> {tipo_campo_destino} != {tipo_valor_atributo}")

            pr.addFeatures( [ fet ] )

        destLYR.updateExtents()
        destLYR.commitChanges()
        # PROBLEMAS EN LOS CAMPOS
            # fid:      Se debe asignar el último de la capa
            # ex_num:   Se debe estudiar si poner / o no

        valTM = self.EX_TM.text().replace(', ', '_')
        valTM = valTM.replace(' y ', '_')
        if self.tipoDP != 'MUNICIPAL':
            self.gml_nomCAPA = self.fechaACT+ '_' +self.EX_NUMEXPRO.text()+ '_' + valTM + '_' + RC14
        else:
            self.gml_nomCAPA = self.fechaACT+ '_' +self.DP_NUMEXPRO.text()+ '_' + RC14
        self.gml_salida_file = self.dirExpte


        # Mensaje final
        QApplication.restoreOverrideCursor()
        text = 'Se ha creado un fichero de intercambio en el directorio:\n\n'
        text += self.dirExpte +'\n\n'
        self.fun.showMessageERR(text,"",tittle="JCCM",)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        # Se pasan datos a la composición y se activa la opción del GML
        # self.TABLA_DATOS = self.layerINFEXPnom
        QgsProject.instance().layerTreeRoot().findLayer(destLYR.id()).setItemVisibilityChecked(True)
        if self.tipoDP != 'MUNICIPAL':
            # if self.EX_TIPO_EXPEDIENTE.currentText() == 'INVASION' or self.EX_TIPO_EXPEDIENTE.currentText() == 'INVASION AEE' or self.EX_TIPO_EXPEDIENTE.currentText() == 'INVASION BBPP' or self.EX_TIPO_EXPEDIENTE.currentText() == 'BIENES PATRIMONIALES':
            if self.EX_TIPO_EXPEDIENTE.currentText() == 'INVASION' or self.EX_TIPO_EXPEDIENTE.currentText() == 'INVASION AEE' or self.EX_TIPO_EXPEDIENTE.currentText() == 'INVASION BBPP':
                self.btnGENERAGML.setEnabled(True)
            self.VAR_DATO = ''
            self.CAMPO_ID = ''

        else:
            if self.DP_TIPO_EXPEDIENTE.currentText() == 'INVASION' or self.DP_TIPO_EXPEDIENTE.currentText() == 'INVASION AEE':
                self.btnGENERAGML.setEnabled(True)

        # Se Activan Botones De La Impresion
        self.Layout_list.setEnabled(True)
        self.cbxVARMAPA.setEnabled(True)
        self.lneVARMAPA.setEnabled(True)
        self.lneTITULO.setEnabled(True)
        self.lneESCALA.setEnabled(True)
        self.btnPresentation.setEnabled(True)

        # Se desactiva el bton de crear expediente
        self.btnCREAEXPTE.setEnabled(False)
        
        QApplication.restoreOverrideCursor()



    def creaEXPTEDIR(self, menu):
        ## SE CREA EL EXPEDIENTE A PARTIR DE DATOS EXISTENTES EN 'MENU'

        # Directorio de trabajo de Informes de expropiaciones
        dirINFEXPRO = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPlayerINFOEXPROexptes")
        if dirINFEXPRO is None:
            dirINFEXPRO=configuration().expropiacion["EXPlayerINFOEXPROexptes"]

        ###### TODO ###   DATOS DE LA HOJA EXCEL DE REGISTROS                    ####################
        print ('En creaEXPTEDIR dirINFEXPRO:',dirINFEXPRO)
        # archivo =  'e:\cartografia\datos_Q_pluggin\scripts\INFORMES_EXPROPIACIONES.xls'
        archivoXCL = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPFichExcelInfEXPRO")
        if archivoXCL is None:
            archivoXCL=configuration().expropiacion["EXPFichExcelInfEXPRO"]
        
        hojaXCL    = 'EXPROPIACIONES'
        print ('En creaEXPTEDIR archivoXCL:',archivoXCL)
        #############################################################################################


        # print (Expte,anoLast.isnumeric(), Expte[-3:], Expte[-3:].isnumeric(), Expte[:2], len(Expte))
        if self.tipoDP != 'MUNICIPAL':
            #  Datos de expediente y directorios
            Expte = menu.EX_NUMEXPRO.text()
            anoLast = Expte[3:7]
            if not anoLast.isnumeric() or not Expte[-3:].isnumeric() or Expte[:3] != 'EX-' or len(Expte) != 10:
                text = 'El valor de expediente ' + Expte + ' es incorrecto.\n\n'
                text +='Debe ser del tipo EX-AAAAnnn\n'
                text +='    AAAA es el año (p.e. 2020)\n'
                text +='    nnn es el n de expte. (p.e. 023)'
                QApplication.restoreOverrideCursor()
                self.fun.showMessageERR(text,"",tittle="JCCM",)
                return ('ERROR')
        else:
            #  Datos de expediente y directorios
            Expte = menu.DP_NUMEXPRO.text()[:10]
            anoLast = Expte[3:7]
            # if not anoLast.isnumeric() or not Expte[-3:].isnumeric() or Expte[:3] != 'DP-' or len(Expte) != 10:
            if not anoLast.isnumeric() or Expte[:3] != 'DP-':
                text = 'El valor de expediente ' + Expte + ' es incorrecto.\n\n'
                text +='Debe ser del tipo DP-AAAAnnn\n'
                text +='    AAAA es el año (p.e. 2020)\n'
                text +='    nnn es el n de expte. (p.e. 023)'
                QApplication.restoreOverrideCursor()
                self.fun.showMessageERR(text,"",tittle="JCCM",)
                return ('ERROR')

        dirExpteAno = dirINFEXPRO + u'Año_' + str(anoLast)
        dirExpte = dirExpteAno + u'/' + Expte

        QApplication.restoreOverrideCursor()
        text = u'¿Crear directorio para el expediente - ' + Expte +' ?\n\n'+ dirExpte
        result = self.fun.showMessageYESNO(text, '', 'JCCM')

        if result != 1024:       # Se ha pulsado CANCELAR
            QApplication.restoreOverrideCursor()
            return ('ERROR')
        else:
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        # Creación del directorio
        if not os.path.exists(dirExpte) and result == 1024:
            try:
                os.makedirs(dirExpte)
            except:
                QApplication.restoreOverrideCursor()
                text = u'ES IMPOSIBLE CREAR EL DIRECTORIO:\n'+dirExpte
                result = self.fun.showMessageYESNO(text,"",tittle="JCCM",)
                if result != 1024:
                    uniproy = QgsProject.instance().fileName()[0:2].lower()  # Asume que la unidad es el primer carácter seguido de ':'
                    # Reemplazar la unidad en el path completo
                    dirExpteNue = unidad_proyecto + dirExpteNue[2:]
                    print ('dirExpteNue: ', dirExpteNue)
                    os.makedirs(dirExpteNue)
                else:
                    return ('ERROR')

        # Creación del fichero de intercambio
        self.fun.creaFICHintercambio(dirExpte, menu)

        ######   TODO   #############################################################################
        # Creación del REGISTRO DEL FICHERO EXCEL
        self.creaRegInformesExcel(archivoXCL, menu)
        #############################################################################################

        return dirExpte


    def creaRegInformesExcel(self, archivoXCL, menu):
        """
        Crea o actualiza un registro en el archivo Excel con los datos del expediente.
        Busca las columnas por su nombre y respeta los tipos de datos.
        
        :param archivoXCL: Ruta al archivo Excel
        :param menu: Objeto del menú con los datos del expediente
        """
        try:
            import openpyxl
            from openpyxl import load_workbook, Workbook
        except ImportError:
            QMessageBox.critical(
                self,
                self.tr("Error"),
                self.tr("La librería 'openpyxl' no está instalada.\n\n"
                        "Instálela con: pip install openpyxl")
            )
            return

        # Verificar que el directorio del archivo existe
        dir_excel = os.path.dirname(archivoXCL)
        if dir_excel and not os.path.exists(dir_excel):
            try:
                os.makedirs(dir_excel)
            except Exception as e:
                self.fun.showMessageERR(
                    f"No se puede crear el directorio:\n{dir_excel}\n\nError: {str(e)}",
                    "",
                    "JCCM"
                )
                return

        # Diccionario con los valores del expediente (clave: nombre del campo, valor: dato)
        valores = {}

        # NUMEXPRO (debe ser número)
        try:
            valores['NUMEXPRO'] = int(menu.EX_NUMEXPRO.text()[3:10])
        except (ValueError, IndexError):
            valores['NUMEXPRO'] = 0

        # REGISTRO (texto)
        valores['REGISTRO'] = self.datoTextVacio(menu.EX_REGISTRO.text())

        # FECHA (fecha)
        valores['FECHA'] = menu.EX_FECHA.date().toPyDate()

        # SOLICITANTE (texto)
        valores['SOLICITANTE'] = self.datoTextVacio(menu.EX_SOLICITANTE.currentText())

        # INTERESADO (texto)
        valores['INTERESADO'] = self.datoTextVacio(menu.EX_INTERESADO.currentText())

        # DNI (texto)
        valores['DNI'] = '-'

        # NOMBRE (texto)
        valores['NOMBRE'] = '-'

        # DOMICILIO (texto)
        valores['DOMICILIO'] = '-'

        # CODIGOPOST (texto)
        valores['CODIGOPOST'] = '-'

        # TLFNO (texto)
        valores['TLFNO'] = '-'

        # POBLACION (texto)
        valores['POBLACION'] = '-'

        # CARRETERA (texto)
        valores['CARRETERA'] = self.datoTextVacio(menu.EX_CARRETERA.text())

        # KILOMETRO (número)
        try:
            valores['KILOMETRO'] = int(self.datoNumVacio(menu.EX_KILOMETRO.text()))
        except ValueError:
            valores['KILOMETRO'] = 0

        # KILOMET2 (número)
        try:
            valores['KILOMET2'] = int(self.datoNumVacio(menu.EX_KILOMET2.text()))
        except ValueError:
            valores['KILOMET2'] = 0

        # MARGEN (texto)
        valores['MARGEN'] = self.datoTextVacio(menu.EX_MARGEN.currentText())

        # OBSERVAPK (texto)
        valores['OBSERVAPK'] = self.datoTextVacio(menu.EX_OBSERVAPK.text())

        # TIPO (texto)
        valores['TIPO'] = self.datoTextVacio(menu.EX_TIPO.toPlainText())

        # ARCHIVO (texto)
        valores['ARCHIVO'] = '-'

        # IG (texto)
        valores['IG'] = self.datoINICIALES(menu.EX_INGENIERO.currentText())

        # INGENIERO (texto)
        valores['INGENIERO'] = self.datoTextVacio(menu.EX_INGENIERO.currentText())

        # ADMIN (texto)
        valores['ADMIN'] = '-'

        # ESTAARCHIVADO (texto)
        valores['ESTAARCHIVADO'] = self.datochbTOSINO(menu.EX_ESTAARCHIVADO)

        # FECHAARCHIVO (texto/fecha)
        valores['FECHAARCHIVO'] = '-'

        # EXPTE_EXPROPIACION (texto)
        valores['EXPTE_EXPROPIACION'] = self.datoTextVacio(menu.EX_EXPTE_EXPROPIACION.text())

        # EXPTES_RELACIONADOS (texto)
        valores['EXPTES_RELACIONADOS'] = self.datoTextVacio(menu.EX_EXPTES_RELACIONADOS.text())

        # NOMBRE_TRAMO (texto)
        valores['NOMBRE_TRAMO'] = self.datoTextVacio(menu.EX_NOMBRE_TRAMO.text())

        # DECR_ACUERDO_RESOLUCION (texto)
        valores['DECR_ACUERDO_RESOLUCION'] = self.datoTextVacio(menu.EX_DECR_ACUERDO_RESOLUCION.text())

        # ACTAS_PREVIAS (texto)
        valores['ACTAS_PREVIAS'] = self.datoTextVacio(menu.EX_ACTAS_PREVIAS.text())

        # REMISION_CATASTRAL (texto)
        valores['REMISION_CATASTRAL'] = self.datoTextVacio(menu.EX_REMISION_CATASTRAL.text())

        # NUMORDEN (texto)
        valores['NUMORDEN'] = self.datoTextVacio(menu.EX_NUMORDEN.text())

        # POLIGONO (texto)
        valores['POLIGONO'] = self.datoTextVacio(menu.EX_POLIGONO.text())

        # PARCELAS (texto)
        valores['PARCELAS'] = self.datoTextVacio(menu.EX_PARCELAS.text())

        # TM (texto)
        valores['TM'] = self.datoTextVacio(menu.EX_TM.text())

        # TIPO_EXPEDIENTE (texto)
        valores['TIPO_EXPEDIENTE'] = self.datoTextVacio(menu.EX_TIPO_EXPEDIENTE.currentText())

        # FECHAINFORME (texto)
        valores['FECHAINFORME'] = '-'

        # TITULO_EXPROPIACION (texto)
        valores['TITULO_EXPROPIACION'] = self.datoTextVacio(menu.EX_TITULO_EXPROPIACION.toPlainText())

        # EX_EXPTE_OBRA_RELACIONADO (texto)
        valores['EX_EXPTE_OBRA_RELACIONADO'] = '-'

        # REF_CATASTRAL (texto)
        valores['REF_CATASTRAL'] = self.datoTextVacio(menu.EX_REF_CATASTRAL.text())

        # FECHA_ULTIMO_TRAMITE (fecha)
        valores['FECHA_ULTIMO_TRAMITE'] = menu.EX_FECHA_ULTIMO_TRAMITE.date().toPyDate()

        # TRAMITE_EXPROPIACION (texto)
        valores['TRAMITE_EXPROPIACION'] = self.datoTextVacio(menu.EX_TRAMITE_EXPROPIACION.text())

        # CORREOELEC (texto)
        valores['CORREOELEC'] = self.datoTextVacio(menu.EX_CORREOELEC.toPlainText())

        # NOMBRE (texto)
        valores['NOMBRE'] = self.datoTextVacio(menu.EX_NOMBRE.text())

        # DNI (texto)
        valores['DNI'] = self.datoTextVacio(menu.EX_DNI.text())

        # TLFNO (texto)
        valores['TLFNO'] = self.datoTextVacio(menu.EX_TLFNO.text())        

        # PROTOCOLO_REGISTRO (texto)
        valores['PROTOCOLO_REGISTRO'] = self.datoTextVacio(menu.EX_PROTOCOLO_REGISTRO.text())

        # ART_LEY (texto)
        valores['ART_LEY'] = self.datoTextVacio(menu.EX_ART_LEY.currentText())

        try:
            # Cargar o crear el libro de Excel
            if os.path.exists(archivoXCL):
                wb = load_workbook(archivoXCL)
                # Usar la hoja activa o crear una si no existe
                if 'EXPROPIACIONES' in wb.sheetnames:
                    ws = wb['EXPROPIACIONES']
                else:
                    ws = wb.active
                    ws.title = 'EXPROPIACIONES'
            else:
                wb = Workbook()
                ws = wb.active
                ws.title = 'EXPROPIACIONES'
                # No escribimos encabezados aquí, asumimos que el Excel ya los tiene

            # Obtener los encabezados de la primera fila
            headers = {}
            for col in range(1, ws.max_column + 1):
                header_value = ws.cell(row=1, column=col).value
                if header_value:
                    headers[header_value] = col

            # Si no hay encabezados, no podemos continuar
            if not headers:
                self.fun.showMessageERR(
                    f"El archivo Excel no tiene encabezados en la primera fila:\n{archivoXCL}",
                    "",
                    "JCCM"
                )
                return

            # Buscar si el expediente ya existe (por NUMEXPRO)
            expediente_num = valores['NUMEXPRO']
            row_to_update = None

            if 'NUMEXPRO' in headers:
                numexpro_col = headers['NUMEXPRO']
                for row in range(2, ws.max_row + 1):
                    cell_value = ws.cell(row=row, column=numexpro_col).value
                    try:
                        if int(cell_value) == expediente_num:
                            row_to_update = row
                            break
                    except (ValueError, TypeError):
                        continue

            if row_to_update:
                # Actualizar fila existente
                for campo, valor in valores.items():
                    if campo in headers:
                        col = headers[campo]
                        ws.cell(row=row_to_update, column=col, value=valor)
                msg = f"Expediente {menu.EX_NUMEXPRO.text()} actualizado en Excel."
            else:
                # Añadir nueva fila
                new_row = ws.max_row + 1
                for campo, valor in valores.items():
                    if campo in headers:
                        col = headers[campo]
                        ws.cell(row=new_row, column=col, value=valor)
                msg = f"Expediente {menu.EX_NUMEXPRO.text()} añadido a Excel."

            # Guardar el archivo
            wb.save(archivoXCL)

            # Mensaje informativo
            print(msg)
            from qgis.core import Qgis
            self.iface.messageBar().pushMessage(
                self.tr("Información"),
                self.tr(msg),
                level=Qgis.Info,
                duration=2
            )

        except PermissionError:
            self.fun.showMessageERR(
                f"Error de permisos al escribir en:\n{archivoXCL}\n\n"
                "Asegúrese de que el archivo no está abierto en otro programa.",
                "",
                "JCCM"
            )
        except Exception as e:
            self.fun.showMessageERR(
                f"Error al crear/actualizar el Excel:\n{archivoXCL}\n\n{str(e)}",
                "",
                "JCCM"
            )
            import traceback
            traceback.print_exc()

    def datoTextVacio(self, texto):
        """Devuelve el texto o '-' si está vacío"""
        return texto if texto and texto.strip() else '-'

    def datoNumVacio(self, numero):
        """Devuelve el número o 0 si está vacío"""
        try:
            return int(numero) if numero and numero.strip() else 0
        except ValueError:
            return 0

    def datochbTOSINO(self, checkbox):
        """Convierte checkbox a SI/NO"""
        return 'SI' if checkbox.isChecked() else 'NO'

    def datoINICIALES(self, nombre_completo):
        """Extrae las iniciales de un nombre completo"""
        if not nombre_completo:
            return '-'
        palabras = nombre_completo.split()
        if len(palabras) >= 2:
            return (palabras[0][0] + palabras[1][0]).upper()
        elif len(palabras) == 1:
            return palabras[0][:2].upper()
        return '-'


    #----------------------------------------------------------------------------------------------------
    #           PASO 3.1 Generar GML                #### TODO ####
    #----------------------------------------------------------------------------------------------------
    def generaGML(self, layerINFEXPnom):
        if self.tipoDP != 'MUNICIPAL':
            valDATA = self.EX_NUMEXPRO.text()
            exprDATA = "ex_num LIKE '"+valDATA+"%' AND ex_tipoinv != 'NO INVASION' "
            # exprDATA = f'"ex_num" LIKE \'{valDATA}%\' AND "ex_tipoinv" != \'NO INVASION\''

        else:
            valDATA = self.DP_NUMEXPRO.text()
            exprDATA = "EXPEDIENTE LIKE '"+valDATA+"%' "

        msg = u'Creamos el GML desde Capa %s - NºEXPTE %s '%(self.layerINFEXPnom, valDATA)
        self.fun.showMessage(u'CREACIÓN DEL GML', msg)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        layer_origen = QgsProject.instance().mapLayersByName(self.layerINFEXPnom)
        layer = layer_origen[0]
        # consulta = u'"ex_num" LIKE \''+valDATA+'%\''
        # print (consulta)
        # features = layer.getFeatures( QgsFeatureRequest( QgsExpression( consulta ) ) )
        layer.setSubsetString(exprDATA)

        self.gml_salida_file = self.dirExpte+'/'+self.gml_nomCAPA+'.gml'
        self.fun.crea_gmlfile(layer_origen, self.gml_nomCAPA, self.gml_salida_file, '25830', '')
        layer.setSubsetString("")
        QApplication.restoreOverrideCursor()

        # Se desactiva el bton de generar GML
        self.btnGENERAGML.setEnabled(False)

        msg = u'Creado el GML desde Capa %s - NºEXPTE %s \n%s'%(self.layerINFEXPnom, valDATA, self.gml_salida_file)
        self.fun.showMessage(u'CREACIÓN DEL GML', msg)


    # def generaGML_ant(self, layerINFEXPnom):
        # if self.tipoDP != 'MUNICIPAL':
            # valDATA = self.EX_NUMEXPRO.text()
            # exprDATA = "ex_num LIKE '"+valDATA+"%' AND ex_tipoinv != 'NO INVASION' "
            # # exprDATA = f'"ex_num" LIKE \'{valDATA}%\' AND "ex_tipoinv" != \'NO INVASION\''

        # else:
            # valDATA = self.DP_NUMEXPRO.text()
            # exprDATA = "EXPEDIENTE LIKE '"+valDATA+"%' "

        # msg = u'Creamos el GML desde Capa %s - NºEXPTE %s '%(self.layerINFEXPnom, valDATA)
        # self.fun.showMessage(u'CREACIÓN DEL GML', msg)
        # QApplication.setOverrideCursor(Qt.WaitCursor)

        # layer_origen = QgsProject.instance().mapLayersByName(self.layerINFEXPnom)
        # layer = layer_origen[0]
        # # consulta = u'"ex_num" LIKE \''+valDATA+'%\''
        # # print (consulta)
        # # features = layer.getFeatures( QgsFeatureRequest( QgsExpression( consulta ) ) )
        # layer.setSubsetString(exprDATA)

        # self.gml_salida_file = self.dirExpte+'/'+self.gml_nomCAPA+'.gml'
        # self.fun.crea_gmlfile(layer_origen, self.gml_nomCAPA, self.gml_salida_file, '25830', '')
        # layer.setSubsetString("")
        # QApplication.restoreOverrideCursor()

        # # Se desactiva el bton de generar GML
        # self.btnGENERAGML.setEnabled(False)

        # msg = u'Creado el GML desde Capa %s - NºEXPTE %s \n%s'%(self.layerINFEXPnom, valDATA, self.gml_salida_file)
        # self.fun.showMessage(u'CREACIÓN DEL GML', msg)


    #----------------------------------------------------------------------------------------------------
    #           PASO 4 Generar PLANO INFORME                #### TODO ####
    #----------------------------------------------------------------------------------------------------
    def cambiaComposer(self, i):
        # TABLA_DATOS - Contiene el nombre de la capa que contiene el campo CAMPO_ID
        # CAMPO_ID    - Contiene el nombre del campo que contendrá el CAMPO_ID que conforma el informe
        # VAR_DATO    - Contiene el valor de CAMPO_ID a imprimir

        Layouts = self.projectLayoutManager.layouts()
        layoutSelect = Layouts[self.Layout_list.currentRow()]
        if layoutSelect is None:
            print ('No layoutSelect')
            return
        else:
            # print layoutSelect.composerWindow().windowTitle()
            composition = layoutSelect
            # composition = QgsLayoutItemMap(layoutSelect)
            pass

        if self.tipoDP != 'MUNICIPAL':
            campo_id = 'ex_num'
            varMAPA = self.EX_NUMEXPRO.text()
            valTM = self.EX_TM.text()
            RC14 = self.EX_REF_CATASTRAL.text()
            self.comp_nombre = self.fechaACT+ '_' +varMAPA+ '_' + valTM + '_' + RC14 + '_PLANO'
        else:
            campo_id = 'EXPEDIENTE'
            varMAPA = self.DP_NUMEXPRO.text()
            RC14 = self.DP_REF_CATASTRAL.text()
            self.comp_nombre = self.fechaACT+ '_' +varMAPA+ '_' + RC14 + '_PLANO'

        varPersDatos = []
        tabla_datos = self.layerINFEXPnom
        # scopeComp = QgsExpressionContextUtils.compositionScope(composition)
        scopeComp = QgsExpressionContextUtils.layoutScope(composition)
        nomVar = scopeComp.variableNames()
        for var in nomVar:
            # print (var, ' - ', scopeComp.variable(var) )
            if not scopeComp.isReadOnly(var):
                if var == 'TABLA_DATOS':
                    scopeComp.setVariable('TABLA_DATOS',tabla_datos)
                    varPersDatos.append('TABLA_DATOS:'+scopeComp.variable(var))
                if var == 'CAMPO_ID':
                    scopeComp.setVariable('CAMPO_ID',campo_id)
                    varPersDatos.append('CAMPO_ID:'+scopeComp.variable(var))
                if var == 'VAR_DATO':
                    scopeComp.setVariable('VAR_DATO',varMAPA)
                    varPersDatos.append('VAR_DATO:'+scopeComp.variable(var))

        # print var_dato, campo_id, tabla_datos
        # print (varPersDatos)
        #self.fun.showJLMMessageERR( message,'','Impresión de ficha de desde tabla' )

        listaValores=[]
        layer = self.fun.getLayerByName(tabla_datos)
        if layer:
            for feature in layer.getFeatures():
                listaValores.append(feature[campo_id])
            # print listaValores
            listaValores = list(set(listaValores))
            listaValores.sort(reverse=True)
        else:
            text = 'Falta la capa '+tabla_datos
            self.fun.showMessage(text)

        self.cbxVARMAPA.clear()
        self.cbxVARMAPA.addItems(listaValores)
        if varMAPA in listaValores:
            self.cbxVARMAPA.setCurrentIndex(listaValores.index(varMAPA))
            self.lneVARMAPA.setText(varMAPA)
            self.cbxVARMAPA.setEnabled(True)

        # Nombre del mapa
        self.lneTITULO.setText(self.comp_nombre)


    def get_salidaPRESEN(self, iface, printAction):
        # composers = iface.activeComposers()

        Layouts = self.projectLayoutManager.layouts()
        composerListo = False

        iface.mainWindow().statusBar().showMessage(u'PREPARANDO IMPRESIÓN ... ... ... ... ... ')

        # Seleccionar el diseñador
        if len(self.Layout_list) == 0:
            self.close()
            composition, composer = self.makeComposer(iface)
            composerListo = True
            print ('composerListo ', composerListo)

        else:
            composer = Layouts[self.Layout_list.currentRow()]
            # print (composer.composerWindow().windowTitle())
            # iface.openLayoutDesigner(composer)
            # composer.refresh()

        # Cerramos el menu de impresión
        self.close()

        # varmapa = self.lneVARMAPA.text()
        varmapa = self.cbxVARMAPA.currentText()
        self.qs.setValue(f"{self.nombre_plugin}/last/lastVARMAPA", varmapa)
        # print varmapa
        # VAR_DATO
        # CAMPO_ID
        # TABLA_DATOS
        varPers = []
        # scopeComp = QgsExpressionContextUtils.compositionScope(composition)
        scopeComp = QgsExpressionContextUtils.layoutScope(composer)
        scopeComp.setVariable('layout_name',self.comp_nombre)
        # scopeComp.composerWindow().setWindowTitle(self.comp_nombre) # <-- set the name here

        for var in scopeComp.variableNames():
            print (var, ' - ', scopeComp.variable(var), ' - ', scopeComp.isReadOnly(var) )
            if not scopeComp.isReadOnly(var):
                # Asignamos -varmapa- a todas las variables no-readonly
                #print var, scopeComp.isReadOnly(var)
                if var == 'VAR_DATO':
                    # QgsExpressionContextUtils.setCompositionVariable(composition, var, varmapa)
                    QgsExpressionContextUtils.setLayoutVariable(composer, var, varmapa)
                varPers.append([var,scopeComp.variable(var)])

        print (varPers)
        if varPers == [] and composerListo == False:
            # Colocamos Titulo y Escala
            try:
                self.mapTITULO = composition.getComposerItemById('TITULO')
                titulo = self.lneTITULO.text()
                self.mapTITULO.setText(titulo)
            except:
                pass

            # Colocamos Escala y centramos mapa
            self.mapitem = composition.getComposerItemById('MAPA0')
            if self.mapitem is None:
                print ('NO APARECE UN MAPA LLAMADO -MAPA0-')
                for item in composer.items():
                    # if item.__class__ == qgis.core.QgsComposerMap:
                    if item.__class__ == QgsComposerMap:
                        print (type(item).__name__, item.id())
            centerAllCompositionMaps(composition, iface.mapCanvas().center())
            escala = float(self.lneESCALA.text())
            # escala = self.dialogui.comboBox_scale.scale()
            if math.isinf(escala) or math.isnan(escala) or abs(escala) < 1E-6:
                iface.mainWindow().statusBar().showMessage(u'')
                return
            # newscale = 1. / escala
            newscale = escala
            extent = self.mapitem.extent()
            center = extent.center()
            newwidth = extent.width() / self.mapitem.scale() * newscale
            newheight = extent.height() / self.mapitem.scale() * newscale
            x1 = center.x() - 0.5 * newwidth
            y1 = center.y() - 0.5 * newheight
            x2 = center.x() + 0.5 * newwidth
            y2 = center.y() + 0.5 * newheight
            self.mapitem.setNewExtent(QgsRectangle(x1, y1, x2, y2))

        iface.openLayoutDesigner(composer)
        composer.refresh()

