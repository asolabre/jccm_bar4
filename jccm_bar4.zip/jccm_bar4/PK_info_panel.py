# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           PK_info_panel.py
Purpose:

        --------------------------------------------------------------------
        begin                : 2019-06-05
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""


# SE CARGAN LAS LIBRERÍAS CON CLASES A CASCOPORRO
from qgis.PyQt.QtXml import *
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtWidgets import *
from qgis.PyQt.QtCore import *
from qgis.PyQt import QtGui, uic

import os

class info_panel(QObject):
    """This class controls all plugin-related GUI elements."""
 
    def __init__ (self,iface):
        """initialize the GUI control"""
        QObject.__init__(self)
        self.iface = iface

        #te = QTextEdit("<b>Project notes:</b>")
        #dw = QDockWidget("Perico de los palotes")
        path = os.path.dirname( u"c:/Users/agusa/.qgis2/python/plugins/jccm_bar4/menus/")
        dw  = uic.loadUi( os.path.join( path, "PK_dockGeometry.ui" ) )
        iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dw)
