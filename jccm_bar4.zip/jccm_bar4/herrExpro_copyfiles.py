# -*- coding: utf-8 -*-
"""
/***************************************************************************
 herrExpro_copyfiles.py
                                 A QGIS4 plugin
 herrExpro
                             -------------------
        begin                : 2017-01-25
        git sha              : $Format:%H$
        copyright            : (C) A.Solabre 2017
        email                : gis.carreteras@jccm.es
 ***************************************************************************/
"""
from qgis.PyQt.QtCore import Qt, QSettings
from qgis.PyQt.QtWidgets import QApplication, QDialog, QVBoxLayout, QLabel, QRadioButton, QButtonGroup, QDialogButtonBox
from qgis.gui import QgsMessageBar
from qgis.core import Qgis

import os, time, fnmatch
import shutil
import datetime
import sys
from stat import *
from os.path import isfile, join

from .config import configuration
from .functions4 import Functions

udConfig = u'U:'
sys.path.append(udConfig + '/cartografia/datos_Q/QSIG/config/')

class CopyTypeDialog(QDialog):
    """Diálogo para seleccionar el tipo de copia"""
    def __init__(self, parent=None):
        super(CopyTypeDialog, self).__init__(parent)
        self.setWindowTitle("Tipo de Copia")
        self.setModal(True)
        self.setMinimumWidth(400)
        
        layout = QVBoxLayout()
        
        # Título
        label = QLabel("<b>Seleccione el tipo de copia a realizar:</b>")
        label.setStyleSheet("font-size: 11pt; padding: 5px;")
        layout.addWidget(label)
        
        layout.addSpacing(10)
        
        # Opciones
        self.rb_backup = QRadioButton("1. SOLO Copia de Seguridad")
        self.rb_backup.setToolTip("Copia los ficheros al directorio de backup añadiendo fecha/hora")
        self.rb_backup.setChecked(True)
        layout.addWidget(self.rb_backup)
        
        self.rb_duplicate = QRadioButton("2. SOLO Copia a Directorios Duplicados")
        self.rb_duplicate.setToolTip("Copia los ficheros a los directorios duplicados sin cambiar nombre")
        layout.addWidget(self.rb_duplicate)
        
        self.rb_both = QRadioButton("3. AMBAS Operaciones (Backup + Duplicados)")
        self.rb_both.setToolTip("Realiza primero backup y luego copia a directorios duplicados")
        layout.addWidget(self.rb_both)
        
        layout.addSpacing(20)
        
        # Agrupar radios para exclusividad
        self.button_group = QButtonGroup()
        self.button_group.addButton(self.rb_backup)
        self.button_group.addButton(self.rb_duplicate)
        self.button_group.addButton(self.rb_both)
        
        # Botones
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
        self.setLayout(layout)
    
    def get_copy_type(self):
        """Devuelve el tipo de copia seleccionado"""
        if self.rb_backup.isChecked():
            return 'backup'
        elif self.rb_duplicate.isChecked():
            return 'duplicate'
        else:
            return 'both'

class copyFiles():

    def __init__(self, iface, parent=None):
        self.fun = Functions()
        self.iface = iface
        self.current_configuration = configuration()
        self.qs = QSettings()

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        # Mostrar diálogo de selección
        copy_dialog = CopyTypeDialog()
        if copy_dialog.exec() != QDialog.DialogCode.Accepted:
            return  # Usuario canceló
        
        self.copy_type = copy_dialog.get_copy_type()
        
        # Inicializar listas
        self.files = []
        self.extList = []
        self.backup_dirs = []  # Directorios de backup (con fecha)
        self.duplicate_dirs = []  # Directorios duplicados (sin fecha)
        
        # Cargar configuración
        self._load_configuration()
        
        # Verificar que hay algo que hacer
        if not self.files:
            self.fun.showMessage("No hay ficheros configurados para copiar")
            return
            
        if self.copy_type in ['backup', 'both'] and not self.backup_dirs:
            self.fun.showMessage("No hay directorio de backup configurado")
            return
            
        if self.copy_type in ['duplicate', 'both'] and not self.duplicate_dirs:
            self.fun.showMessage("No hay directorios duplicados configurados")
            return
        
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        progress = 'Iniciando copia de ficheros de EXPROPIACIONES...'
        self.iface.mainWindow().statusBar().showMessage(progress)
        
        # Presenta un messagebar de información
        self.iface.messageBar().pushMessage(
            'Copia de ficheros de EXPROPIACIONES', 
            f'Tipo: {self.copy_type}', 
            level=Qgis.Info, 
            duration=0
        )
        
        # Verificar unidades y crear directorios
        if not self._check_and_create_directories():
            QApplication.restoreOverrideCursor()
            return
        
        # Texto para el mensaje final
        textMsg = self._create_html_header()
        
        # Procesar cada fichero según el tipo de copia seleccionado
        if self.copy_type in ['backup', 'both']:
            textMsg = self._process_backup_copies(textMsg)
            
        if self.copy_type in ['duplicate', 'both']:
            textMsg = self._process_duplicate_copies(textMsg)
        
        # Finalizar
        self._finish_copy_process(textMsg)

    def _load_configuration(self):
        """Carga la configuración desde QSettings o configuración por defecto"""
        grupoCopyExpro = f"{self.nombre_plugin}/EXPROPIACION/EXP_COPYSEG"
        self.qs.beginGroup(grupoCopyExpro)
        listGrupoCopyExpro = self.qs.childKeys()
        self.qs.endGroup()
        
        if len(listGrupoCopyExpro) == 0:
            # Usar configuración por defecto
            self.files = self.current_configuration.ficherosCopySeg
            self.extList = self.current_configuration.extListCopySeg
            self.backup_dirs = [self.current_configuration.dstDirCopySeg]
            self.duplicate_dirs = self.current_configuration.dstDirCopyDupli or []
        else:
            # Cargar desde QSettings
            self.files = []
            self.extList = []
            self.backup_dirs = []
            self.duplicate_dirs = []
            
            for dato in listGrupoCopyExpro:
                valVar = self.qs.value(f"{grupoCopyExpro}/{dato}")
                
                if dato.startswith('EXP_COPYSEGfile'):
                    self.files.append(valVar)
                elif dato == 'EXP_COPYSEGext':
                    if isinstance(valVar, list):
                        self.extList = valVar
                    else:
                        self.extList = [valVar]
                elif dato == 'EXP_COPYSEGdirdst':
                    self.backup_dirs = [valVar]
                elif dato.startswith('EXP_COPYSEGdirdupli'):
                    self.duplicate_dirs.append(valVar)
    
        
    def _check_and_create_directories(self):
        """Verifica que existen las unidades y crea los directorios si es necesario"""
        all_ok = True
        
        # Verificar directorios de backup
        if self.copy_type in ('backup', 'both'):
            for dstDir in self.backup_dirs:
                if not self._ensure_directory_exists(dstDir, "COPIA DE SEGURIDAD"):
                    all_ok = False

        # Verificar directorios duplicados
        if self.copy_type in ('duplicate', 'both'):
            for dupDir in self.duplicate_dirs:
                if not self._ensure_directory_exists(dupDir, "DIRECTORIO DUPLICADO"):
                    all_ok = False

        return all_ok

    def _ensure_directory_exists(self, directory, dir_type):
        """
        Verifica que un directorio existe o puede crearse.
        Retorna True si existe o se creó correctamente, False en caso contrario.
        """
        # Verificar que la unidad existe
        unit = directory[:2]
        if not os.path.exists(unit):
            text = (f'NO EXISTE LA UNIDAD {unit}\n\n'
                    f'No se puede acceder al {dir_type}:\n\n'
                    f'{directory}\n\n'
                    f'Verifique que la unidad está disponible y conectada.')
            self.fun.showMessage(text)
            return False
        
        # Verificar si el directorio ya existe
        if os.path.exists(directory):
            return True
        
        # Intentar crear el directorio
        try:
            os.makedirs(directory)
            print(f"Directorio creado correctamente: {directory}")
            return True
            
        except PermissionError:
            text = (f'⚠️ ERROR DE PERMISOS ⚠️\n\n'
                    f'No se puede crear el {dir_type}:\n\n'
                    f'{directory}\n\n'
                    f'CAUSA: No tiene permisos de escritura en esta ubicación.\n\n'
                    f'POSIBLES SOLUCIONES:\n'
                    f'• Ejecute QGIS como administrador\n'
                    f'• Elija otra ubicación para guardar los archivos\n'
                    f'• Verifique los permisos de la carpeta')
            self.fun.showMessage(text)
            return False
            
        except OSError as e:
            # Error 17 significa que el directorio ya existe (carrera de condiciones)
            if e.errno == 17:  # errno.EEXIST
                return True
                
            text = (f'❌ ERROR AL CREAR DIRECTORIO ❌\n\n'
                    f'{dir_type}:\n'
                    f'{directory}\n\n'
                    f'ERROR: {str(e)}\n\n'
                    f'Verifique que la ruta es válida y tiene permisos suficientes.')
            self.fun.showMessage(text)
            return False
            
        except Exception as e:
            text = (f'❌ ERROR INESPERADO ❌\n\n'
                    f'{dir_type}:\n'
                    f'{directory}\n\n'
                    f'ERROR: {str(e)}')
            self.fun.showMessage(text)
            return False
    
    def _create_html_header(self):
        """Crea el header HTML para el mensaje final"""
        tipo_texto = {
            'backup': 'SOLO BACKUP',
            'duplicate': 'SOLO DUPLICADOS',
            'both': 'BACKUP + DUPLICADOS'
        }
        
        return (
            "<html>"
            "<body>"
            f"<h1 style='font-size:12pt; color:#34495E; text-align:center;'>"
            f"<b>FICHEROS COPIADOS - {tipo_texto[self.copy_type]}</b>"
            f"</h1>"
            "<br>"
        )
    
    def _process_backup_copies(self, textMsg):
        """Procesa las copias de seguridad (con fecha/hora)"""
        textMsg += "<h2 style='color:#27AE60;'>📦 COPIA DE SEGURIDAD (con fecha):</h2>"
        
        for dstDir in self.backup_dirs:
            textMsg += f"<p><b>Directorio destino:</b> {dstDir}</p>"
            
            for srcFile in self.files:
                result = self._copy_file_with_timestamp(srcFile, dstDir)
                textMsg += result
        
        return textMsg
    
    def _process_duplicate_copies(self, textMsg):
        """Procesa las copias a directorios duplicados (sin fecha/hora)"""
        textMsg += "<h2 style='color:#E67E22;'>📋 COPIA A DIRECTORIOS DUPLICADOS (sin fecha):</h2>"
        
        for dupDir in self.duplicate_dirs:
            textMsg += f"<p><b>Directorio destino:</b> {dupDir}</p>"
            
            for srcFile in self.files:
                result = self._copy_file_without_timestamp(srcFile, dupDir)
                textMsg += result
        
        return textMsg
    
    def _copy_file_with_timestamp(self, srcFile, dstDir):
        """Copia un fichero añadiendo timestamp al nombre"""
        try:
            if not os.path.isfile(srcFile):
                return (
                    f"<p style='color:#E74C3C;'>❌ NO EXISTE: {srcFile}</p>"
                )
            
            # Datos del fichero origen
            stSrc = os.stat(srcFile)
            srcSIZE = stSrc[ST_SIZE]
            srcDATEMt = stSrc[ST_MTIME]
            srcDir, srcFilExtName = os.path.split(srcFile)
            srcFilName, srcExt = os.path.splitext(srcFilExtName)
            
            # Solo procesar extensiones permitidas
            if srcExt not in self.extList:
                return ""
            
            # Buscar ficheros existentes en destino
            need_copy = self._check_if_needs_copy(srcFile, dstDir, srcSIZE, srcDATEMt)
            
            if need_copy:
                t = datetime.datetime.now()
                fechor = t.strftime('%Y%m%d%H%M')
                dstFilName = f"{srcFilName}_{fechor}"
                
                shutil.copy(srcFile, os.path.join(dstDir, f"{dstFilName}{srcExt}"))
                
                return (
                    f"<p><span style='color:#27AE60;'>✅ COPIADO:</span><br>"
                    f"<span style='font-size:9pt;'>{srcFile}</span></p>"
                )
            else:
                return (
                    f"<p><span style='color:#F39C12;'>⏭️ NO COPIADO (actual):</span><br>"
                    f"<span style='font-size:9pt;'>{srcFile}</span></p>"
                )
                
        except Exception as e:
            return (
                f"<p style='color:#E74C3C;'>❌ ERROR: {srcFile}<br>{str(e)}</p>"
            )
    
    def _copy_file_without_timestamp(self, srcFile, dstDir):
        """Copia un fichero sin modificar el nombre"""
        try:
            if not os.path.isfile(srcFile):
                return (
                    f"<p style='color:#E74C3C;'>❌ NO EXISTE: {srcFile}</p>"
                )
            
            # Datos del fichero origen
            stSrc = os.stat(srcFile)
            srcSIZE = stSrc[ST_SIZE]
            srcDATEMt = stSrc[ST_MTIME]
            srcDir, srcFilExtName = os.path.split(srcFile)
            
            # Solo procesar extensiones permitidas
            _, srcExt = os.path.splitext(srcFilExtName)
            if srcExt not in self.extList:
                return ""
            
            dstFile = os.path.join(dstDir, srcFilExtName)
            
            # Verificar si necesita copia
            need_copy = True
            
            if os.path.exists(dstFile):
                stDst = os.stat(dstFile)
                dstSIZE = stDst[ST_SIZE]
                dstDATEMt = stDst[ST_MTIME]
                
                if dstSIZE == srcSIZE and dstDATEMt >= srcDATEMt:
                    need_copy = False
            
            if need_copy:
                shutil.copy2(srcFile, dstFile)  # copy2 preserva metadatos
                return (
                    f"<p><span style='color:#27AE60;'>✅ COPIADO (duplicado):</span><br>"
                    f"<span style='font-size:9pt;'>{srcFile} → {dstFile}</span></p>"
                )
            else:
                return (
                    f"<p><span style='color:#F39C12;'>⏭️ NO COPIADO (actual):</span><br>"
                    f"<span style='font-size:9pt;'>{srcFile}</span></p>"
                )
                
        except Exception as e:
            return (
                f"<p style='color:#E74C3C;'>❌ ERROR: {srcFile}<br>{str(e)}</p>"
            )
    
    def _check_if_needs_copy(self, srcFile, dstDir, srcSIZE, srcDATEMt):
        """Verifica si un fichero necesita ser copiado comparando con existentes"""
        srcDir, srcFilExtName = os.path.split(srcFile)
        srcFilName, srcExt = os.path.splitext(srcFilExtName)
        
        # Buscar ficheros similares en destino
        pattern = f"{srcFilName}*{srcExt}"
        existing_files = fnmatch.filter(os.listdir(dstDir), pattern)
        
        if not existing_files:
            return True
        
        # Buscar el más moderno
        newest_file_time = 0
        for f in existing_files:
            file_path = os.path.join(dstDir, f)
            file_time = os.stat(file_path)[ST_MTIME]
            if file_time > newest_file_time:
                newest_file_time = file_time
        
        return newest_file_time < srcDATEMt
    
    def _finish_copy_process(self, textMsg):
        """Finaliza el proceso mostrando resultados"""
        textMsg += (
            "<br>"
            "<p style='font-size:10pt; color:#7F8C8D;'>"
            "Proceso completado"
            "</p>"
            "</body>"
            "</html>"
        )
        
        QApplication.restoreOverrideCursor()
        progress = 'Copiados Ficheros de EXPROPIACIONES'
        self.iface.mainWindow().statusBar().showMessage(progress)
        
        self.fun.showMessage(textMsg, '', 'Copia de Seguridad de ficheros')
        self.iface.messageBar().clearWidgets()