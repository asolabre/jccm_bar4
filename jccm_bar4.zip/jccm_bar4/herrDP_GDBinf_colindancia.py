# -*- coding: utf-8 -*-
"""
/***************************************************************************
herrDP_GDBinf_colindancia.py
                                 A QGIS4 plugin
                             -------------------
        begin                : 2026-03-7
        git sha              : $Format:%H$
        Codigo Original     : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

Gestión de BD de INFORMES DE COLINDANCIA Y EXPROPIACIONES                   #### VERSION FICHERO EXCEL

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""


#### TODO ####
# HACER ZOOM ALTERNATIVO A RC SI NO HAY FEATURE
# ADVERTIR DE SI EXCEL ESTÁ ABIERTO, AHORA DA ERROR
# REVISAR PROBLEMA DE ERRORES Y COLGADO EN MODIFICAR
# RESOLVER ERRORES DE AGREGAR Y MODIFICAR
# HACER COMBO EXNUM EDITABLE PARA BUSCAR EXPTES
# IMPLEMENTAR GESTIÓN DE DATOS DEL EXPEDIENTE EN GPKG EN UNA PESTAÑA NUEVA
# COMBINACIÓN DE DATOS CON INFORMES EN WORD
# DUPLICAR REGISTRO EN OTRO CON UN NUEVO 'NUMEXPRO'


from qgis.PyQt.QtGui import QIcon, QPixmap
from qgis.PyQt.QtWidgets import QDialog, QCompleter, QComboBox, QLineEdit, QTextEdit, QCheckBox, QDateEdit, QMessageBox, QApplication, QWidget
from qgis.PyQt.QtCore import QSettings, Qt, QDate, QEvent

from qgis.PyQt import uic
from qgis.core import QgsProject, QgsRectangle, QgsCoordinateTransform
from qgis.utils import iface

import os
import sys
import subprocess
import re
import pandas as pd
import sqlite3
import numpy as np
import shutil
import traceback
import glob

from datetime import datetime as dt
from datetime import timedelta

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES

from .jccm_bar_config_RT import GpkgHelper  # CLASE DE GESTIÓN DE GPKG

from .herr_BBDD_BUSCADOR import herr_BBDD_BUSCADOR # Menú buscador de registros

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrDP_GDB_informes_invasion.ui'))

current_configuration = configuration()

# VARIABLES
srcVal = current_configuration.general["EPSG"]

listINGENIERO   = current_configuration.listINGENIERO
listCORREOELEC  = current_configuration.listCORREOELEC
listINTERESADO  = current_configuration.listINTERESADO
listSOLICITANTE = current_configuration.listSOLICITANTE
listMARGEN      = current_configuration.listMARGEN
listTIPEXPTE    = current_configuration.listTIPOEXPTE
listArticuloLey = current_configuration.listArticuloLey

class herrDP_GDBinf_colindancia(QDialog, FORM_CLASS):
    def __init__(self, iface, parent=None):
        """Constructor."""
        super(herrDP_GDBinf_colindancia, self).__init__(parent)

        self.fun = Functions()
        self.iface = iface
        self.setupUi(self)

        # Configurar texto especial para fechas vacías
        for date_widget in [self.EX_FECHA, self.EX_FECHAARCHIVO, self.EX_FECHA_ULTIMO_TRAMITE]:
            date_widget.setSpecialValueText(" ")  # Un espacio para que parezca vacío
            date_widget.setDate(QDate())

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        self.qs = QSettings()
        self.conf = configuration()

        self.setFixedSize(810, 575)
        self.historial_busquedas = self.cargarHistorialBusquedas()

        #######################################################################
        ###         CONFIGURACIÓN DE PESTAÑAS                               ###
        #######################################################################
        # Pestaña 0: "Datos Parcelas" (GPKG) - No Visible
        # Pestaña 1: "Datos BD Informes" (Excel) - Visible
        self.tabWidget.tabBar().setTabVisible(0, False)     ### TODO RESOLVER ESTO ###
        self.tabWidget.tabBar().setTabVisible(1, True)

        self.logo.setPixmap(QPixmap(f":/plugins/jccm_bar4/iconos/jccm.jpg"))
        self.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/jccm_EXPR_INF.jpg'))
        self.logo.setFixedSize(110, 70)
        self.logo.move(10,10)
        self.prefEXPTE = u'EX-'
        self.campoTIPO = "ex_tipoinv"

        #######################################################################
        ###         VARIABLES DE CONFIGURACIÓN                              ###
        #######################################################################
        # GPKG - Capa en TOC (para pestaña Datos Parcelas)
        self.layerINFEXPnom = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPlayerINFOEXPRO")
        if self.layerINFEXPnom is None:
            self.layerINFEXPnom = self.conf.expropiacion["EXPlayerINFOEXPRO"]

        # GPKG - Capa de expedientes de expropiación (para combo EX_EXPTE_EXPROPIACION)
        self.layerExproExpNom = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPlayerLIMEXPRO")
        if self.layerExproExpNom is None:
            self.layerExproExpNom = self.conf.expropiacion.get("EXPlayerLIMEXPRO", "Expedientes_Expropiacion")

        # Variable para almacenar los valores del combo
        self.lista_exptes_expro = ["s/d"]  # Valor por defecto

        # EXCEL - Archivo de expedientes (para pestaña Datos BD Informes)
        self.ExcelInfEXPRO = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPFichExcelInfEXPRO")
        if self.ExcelInfEXPRO is None:
            self.ExcelInfEXPRO = self.conf.expropiacion["EXPFichExcelInfEXPRO"]

        # DIRECTORIO de expedientes (para pestaña Datos BD Informes)
        self.FichInfEXPROPIACIONESexptes = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPlayerINFOEXPROexptes")
        if self.FichInfEXPROPIACIONESexptes is None:
            self.FichInfEXPROPIACIONESexptes = self.conf.expropiacion["EXPlayerINFOEXPROexptes"]

        # Tabla de LISTADOS DE EXPEDIENTES DE EXPROPIACIÓN (lista completa)
        # La variable en QSettings es 'EXPFichExptesEXPRO', no 'EXPFichExptesEXPROFich'
        self.ExproTableFich = self.qs.value(f"{self.nombre_plugin}/EXPROPIACION/EXPFichExptesEXPRO")
        if self.ExproTableFich is None:
            # Intentar obtener del config
            if "EXPFichExptesEXPRO" in self.conf.expropiacion:
                self.ExproTableFich = self.conf.expropiacion["EXPFichExptesEXPRO"]
            elif hasattr(self.conf, "expropiacionB") and "EXPFichExptesEXPRO" in self.conf.expropiacionB:
                self.ExproTableFich = self.conf.expropiacionB["EXPFichExptesEXPRO"]
            else:
                self.ExproTableFich = ""

        # Separar ruta y capa
        self.ExproTablePath, self.ExproTableLayer = GpkgHelper.split_path_layer(self.ExproTableFich)

        # Variable para almacenar el DataFrame de expedientes de expropiación
        self.df_expro_table = None

        #######################################################################
        ###         VARIABLES DE CONTROL                                    ###
        #######################################################################
        # GPKG - Variables (para pestaña Datos Parcelas)
        self.registros_gpkg = []  # Lista para almacenar todos los registros ordenados
        self.capa_gpkg = None
        self.layerINFEXPfich = ""  # Path del archivo GPKG
        self.layerINFEXPlayer = ""  # Nombre de la capa dentro del GPKG

        # EXCEL - Variables (para pestaña Datos BD Informes)
        self.df_excel = None  # DataFrame con los datos del Excel
        self.registros_excel = []  # Lista de diccionarios con los registros del Excel
        self.indice_excel_actual = -1

        self.modo_edicion = False
        self.modo_agregar = False
        self.inicializacion_correcta = True  # Bandera para controlar la inicialización
        self.datos_modificados = False  # Bandera para controlar si hay cambios sin guardar

        # Diccionario para almacenar estilos originales de los widgets
        self.estilos_originales = {}

        # Lista de widgets obligatorios para el modo agregar
        self.widgets_obligatorios = []

        # Lista de widgets editables (todos los QLineEdit y QComboBox excepto cbxEX_NUM)
        self.widgets_editables = []

        # Variables para gestión de expedientes pendientes
        self.filtro_pendientes = False  # Indica si estamos filtrando solo pendientes
        self.registros_filtrados = []   # Lista de índices de registros que cumplen el filtro
        self.indice_filtrado_actual = -1 # Índice dentro de la lista filtrada

        #######################################################################
        ###         COMPROBACIÓN DE CAPA GPKG CARGADA                       ###
        #######################################################################
        self.capa_gpkg_disponible = self.comprobarCargaCapaGPKG()

        #######################################################################
        ###         CARGA DE DATOS EXCEL                                    ###
        #######################################################################
        exito_excel = self.cargarDatosExcel()

        # Si no hay Excel disponible
        if not exito_excel:
            self.inicializacion_correcta = False
            QMessageBox.critical(
                self,
                "Error - Sin datos",
                f"No se ha encontrado el archivo Excel:\n{self.ExcelInfEXPRO}\n\n"
                "No hay datos disponibles para mostrar.",
                QMessageBox.StandardButton.Ok
            )
            return

        # Se estudia el número de regustros de la excel
        if self.registros_excel:
            self.actualizar_contador_registros()

        #######################################################################
        ###         DATOS DE CAPA GPKG (si está disponible)                 ###
        #######################################################################
        if self.capa_gpkg_disponible:
            self.obtenerInfoFuenteGPKG()
            self.cargarRegistrosGPKG()

        #######################################################################
        ###         INICIALIZAR COMBOS                                      ###
        #######################################################################
        self.cargarCombos()

        #######################################################################
        ###         CONECTAR SEÑALES                                        ###
        #######################################################################
        self.conectarSenales()

        #######################################################################
        ###         CONFIGURAR TOOLTIPS                                     ###
        #######################################################################
        self.configurarTooltips()

        #######################################################################
        ###         CONFIGURAR ESTADO INICIAL DE WIDGETS                    ###
        #######################################################################
        self.configurarWidgets()
        self.setModoEdicion(False)
        self.setModoAgregar(False)

        #######################################################################
        ###         CONFIGURAR BOTONES                                      ###
        #######################################################################
        self.btnEDITAR.setEnabled(True)
        self.btnEDITAR.setVisible(True)
        self.btnEDITAR.setText("MODIFICAR")
        self.btnGUARDARCAMBIOS.setEnabled(False)
        self.btnGUARDARCAMBIOS.setVisible(False)
        self.btnVER_DOCUM.setEnabled(True)
        self.btnZoomElemento.setEnabled(True)
        self.btnZoomElemento.setVisible(True)
        self.btnAGREGAR.setEnabled(True)
        self.btnAGREGAR.setVisible(True)
        self.btnAGREGAR.setText("AGREGAR")
        self.btnVerExpteExpro.setVisible(False)
        
        self.actualizarColorBotonZoom() 

        # Inicializar el combo de navegación con los datos del Excel
        self.inicializarComboNavegacion()

        # Mostrar información de la fuente
        self.actualizarEtiquetaInfo()

        # Instalar event filter para capturar teclas
        self.installEventFilter(self)

        # Conectar señales de modificación de widgets
        self.conectarModificacionWidgets()

        # Configurar widgets obligatorios
        self.configurarWidgetsObligatorios()

        # Configurar estilo del botón guardar (rojo pálido)
        self.btnGUARDARCAMBIOS.setStyleSheet("""
            QPushButton {background-color: #ffcccc; border: 1px solid #ff6666; border-radius: 3px; padding: 5px; font-weight: bold;}
            QPushButton:hover {background-color: #ff9999; border: 1px solid #ff3333; }
            QPushButton:pressed {background-color: #ff6666;}
            QPushButton:disabled {background-color: #f0f0f0; border: 1px solid #c0c0c0; color: #808080; }
        """)

        # Configurar fecha si está vacía
        self.configurarFechaAlClic()

    def actualizarEtiquetaInfo(self):
        """Actualiza la etiqueta con información de las fuentes de datos"""
        info_text = ""

        if self.df_excel is not None:
            directorio = os.path.dirname(self.ExcelInfEXPRO)
            nombre_excel = os.path.basename(self.ExcelInfEXPRO)
            info_text = f"INFORMES (EXCEL): {directorio +'/'+ nombre_excel} ({len(self.df_excel)} registros)"

        self.lbGDBinformes.setText(info_text)
        self.lbGDBinformes.setWordWrap(True)

    def conectarSenales(self):
        """Conecta las señales de los botones y combos"""
        self.btnIrINICIO.clicked.connect(self.irInicio)
        self.btnANTERIOR.clicked.connect(self.irAnterior)
        self.btnSIGUIENTE.clicked.connect(self.irSiguiente)
        self.btnIrFINAL.clicked.connect(self.irFinal)
        self.cbxEX_NUM.currentIndexChanged.connect(self.cambioRegistro)
        self.btnVER_DOCUM.clicked.connect(self.onVerDocumClicked)
        self.btnZoomElemento.clicked.connect(self.onZoomElementoClicked)
        self.btnEDITAR.clicked.connect(self.onEditarClicked)
        self.btnGUARDARCAMBIOS.clicked.connect(self.onGuardarCambiosClicked)
        self.btnAGREGAR.clicked.connect(self.onAgregarClicked)
        self.btnSUPRIMIR.clicked.connect(self.onSuprimirClicked)
        self.btnSALIR.clicked.connect(self.onSalirClicked)
        self.btnBuscarREGISTRO.clicked.connect(self.onBuscarRegistroClicked)
        self.btnAbreExcel.clicked.connect(self.onAbrirExcelClicked)
        self.cbxPENDIENTES.stateChanged.connect(self.onPendientesClicked)
        self.EX_EXPTE_EXPROPIACION.currentTextChanged.connect(self.onExpedienteExpropiacionChanged)

        # Conectar señales de fecha para establecer fecha actual si está vacía
        self.EX_FECHA.dateChanged.connect(lambda: self.establecerFechaSiVacia(self.EX_FECHA))
        self.EX_FECHAARCHIVO.dateChanged.connect(lambda: self.establecerFechaSiVacia(self.EX_FECHAARCHIVO))
        self.EX_FECHA_ULTIMO_TRAMITE.dateChanged.connect(lambda: self.establecerFechaSiVacia(self.EX_FECHA_ULTIMO_TRAMITE))

    def configurarWidgets(self):
        """Configura la lista de widgets editables y su estado inicial"""
        for widget in self.findChildren(QLineEdit):
            if widget != self.EX_NUMEXPRO:
                self.widgets_editables.append(widget)

        for widget in self.findChildren(QComboBox):
            if widget != self.cbxEX_NUM:
                self.widgets_editables.append(widget)

        for widget in self.findChildren(QTextEdit):
            self.widgets_editables.append(widget)

        for widget in self.findChildren(QCheckBox):
            self.widgets_editables.append(widget)

        for widget in self.findChildren(QDateEdit):
            self.widgets_editables.append(widget)

        # Guardar estilos originales
        for widget in self.widgets_editables:
            self.estilos_originales[widget] = widget.styleSheet()

        self.setModoEdicion(False)

    def cargarCombos(self):
        """Carga los valores en los combos desde la configuración"""
        self.EX_INGENIERO.clear()
        self.EX_INGENIERO.addItems(listINGENIERO)
        self.EX_INGENIERO.setEditable(True)
        self.EX_INGENIERO.setCompleter(QCompleter(listINGENIERO))

        self.EX_INTERESADO.clear()
        self.EX_INTERESADO.addItems(listINTERESADO)
        self.EX_INTERESADO.setEditable(True)
        self.EX_INTERESADO.setCompleter(QCompleter(listINTERESADO))

        self.EX_SOLICITANTE.clear()
        self.EX_SOLICITANTE.addItems(listSOLICITANTE)
        self.EX_SOLICITANTE.setEditable(True)
        self.EX_SOLICITANTE.setCompleter(QCompleter(listSOLICITANTE))

        self.EX_MARGEN.clear()
        self.EX_MARGEN.addItems(listMARGEN)
        self.EX_MARGEN.setEditable(True)
        self.EX_MARGEN.setCompleter(QCompleter(listMARGEN))

        self.EX_TIPO_EXPEDIENTE.clear()
        self.EX_TIPO_EXPEDIENTE.addItems(listTIPEXPTE)
        self.EX_TIPO_EXPEDIENTE.setEditable(True)
        self.EX_TIPO_EXPEDIENTE.setCompleter(QCompleter(listTIPEXPTE))

        self.EX_ART_LEY.clear()
        self.EX_ART_LEY.addItems(listArticuloLey)
        self.EX_ART_LEY.setEditable(True)
        self.EX_ART_LEY.setCompleter(QCompleter(listArticuloLey))

        self.cargarExpedientesExpropiacion()

    #######################################################################
    ###         METODOS GENERALES MENÚ                                  ###
    #######################################################################
    def exec(self):
        """Sobrescribe el método exec_ para controlar la inicialización"""
        if not self.inicializacion_correcta:
            return QDialog.DialogCode.Rejected
        return super().exec()

    def showEvent(self, event):
        """Se ejecuta cuando se muestra el diálogo"""
        if not self.inicializacion_correcta:
            self.reject()
        super().showEvent(event)

    def closeEvent(self, event):
        """Se ejecuta al intentar cerrar el diálogo"""
        if self.modo_agregar:
            respuesta = QMessageBox.question(
                self,
                "Confirmar salida",
                "Está en modo agregar con datos sin guardar.\n"
                "Si sale ahora, se perderán los datos introducidos.\n\n"
                "¿Está seguro de que desea salir?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )
            if respuesta == QMessageBox.StandardButton.No:
                event.ignore()  # Cancelar el cierre
                return

        # Si estamos en modo edición con cambios sin guardar
        elif self.modo_edicion and self.datos_modificados:
            respuesta = QMessageBox.question(
                self,
                "Confirmar salida",
                "Hay cambios sin guardar en el registro actual.\n"
                "Si sale ahora, se perderán los cambios.\n\n"
                "¿Está seguro de que desea salir?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )
            if respuesta == QMessageBox.StandardButton.No:
                event.ignore()
                return

        # Si todo está bien, aceptar el cierre
        event.accept()

    def eventFilter(self, obj, event):
        """Captura eventos de teclado para navegación y eventos de foco para fechas"""
        # Manejar eventos de teclado para navegación
        if event.type() == QEvent.Type.KeyPress:
            # Avanzar página (SIGUIENTE - más moderno)
            if event.key() == Qt.Key.Key_PageDown:
                self.irSiguiente()
                return True
            # Retroceder página (ANTERIOR - más antiguo)
            elif event.key() == Qt.Key.Key_PageUp:
                self.irAnterior()
                return True
            # Inicio (primer registro - más antiguo)
            elif event.key() == Qt.Key.Key_Home:
                self.irInicio()
                return True
            # Fin (último registro - más moderno)
            elif event.key() == Qt.Key.Key_End:
                self.irFinal()
                return True

        # Manejar eventos de foco para QDateEdit (solo en modo edición o agregar)
        if event.type() == QEvent.Type.FocusIn:
            pass
            # ...

        return super().eventFilter(obj, event)


    def configurarFechaAlClic(self):
        """Configura los QDateEdit para que al hacer clic establezcan fecha actual si está vacía"""
        for date_widget in [self.EX_FECHA, self.EX_FECHAARCHIVO, self.EX_FECHA_ULTIMO_TRAMITE]:
            original_mouse_press = date_widget.mousePressEvent

            def create_mouse_handler(widget, original):
                def mouse_press_handler(event):
                    # Solo en modo edición o agregar
                    if self.modo_edicion or self.modo_agregar:
                        if not widget.date().isValid():
                            widget.setDate(QDate.currentDate())
                    if original:
                        original(event)
                return mouse_press_handler

            date_widget.mousePressEvent = create_mouse_handler(date_widget, original_mouse_press)

    def conectarModificacionWidgets(self):
        """Conecta señales de modificación de widgets para detectar cambios"""
        for widget in self.widgets_editables:
            if isinstance(widget, QLineEdit):
                widget.textChanged.connect(self.onDatoModificado)
            elif isinstance(widget, QComboBox):
                widget.currentTextChanged.connect(self.onDatoModificado)
            elif isinstance(widget, QTextEdit):
                widget.textChanged.connect(self.onDatoModificado)
            elif isinstance(widget, QCheckBox):
                widget.stateChanged.connect(self.onDatoModificado)
            elif isinstance(widget, QDateEdit):
                widget.dateChanged.connect(self.onDatoModificado)

    def configurarTooltips(self):
        """Configura los tooltips de todos los widgets de la interfaz"""

        # Tooltips para campos de identificación
        self.EX_NUMEXPRO.setToolTip("Número de expediente en formato EX-AAAANNN (ej: EX-2026001)")
        self.EX_REGISTRO.setToolTip("Número de registro de entrada/salida")
        self.EX_FECHA.setToolTip("Fecha de creación del expediente")

        # Tooltips para solicitante/interesado
        self.EX_SOLICITANTE.setToolTip("Servicio, sección o persona que solicita el informe")
        self.EX_INTERESADO.setToolTip("Persona o entidad interesada (propietario, promotor, etc.)")
        self.EX_CORREOELEC.setToolTip("Correo electrónico del interesado")

        # Tooltips para datos personales
        self.EX_NOMBRE.setToolTip("Nombre completo del titular/interesado")
        self.EX_DNI.setToolTip("DNI/NIF del titular/interesado")
        self.EX_TLFNO.setToolTip("Teléfono de contacto")

        # Tooltips para datos de la carretera
        self.EX_CARRETERA.setToolTip("Carretera afectada (ej: CM-3209)")
        self.EX_KILOMETRO.setToolTip("Punto kilométrico inicial")
        self.EX_KILOMET2.setToolTip("Punto kilométrico final")
        self.EX_MARGEN.setToolTip("Margen de la carretera (Derecha/Izquierda/Ambas)")
        self.EX_OBSERVAPK.setToolTip("Observaciones sobre el punto kilométrico")

        # Tooltips para datos de expediente
        self.EX_TIPO_EXPEDIENTE.setToolTip("Tipo de expediente (INVASION, NO INVASION, etc.)")
        self.EX_TIPO.setToolTip("Descripción detallada del objeto del informe")
        self.EX_EXPTE_EXPROPIACION.setToolTip("Expediente de expropiación relacionado")
        self.EX_EXPTES_RELACIONADOS.setToolTip("Otros expedientes relacionados")

        # Tooltips para datos catastrales
        self.EX_REF_CATASTRAL.setToolTip("Referencia(s) catastral(es) de la(s) parcela(s)")
        self.EX_POLIGONO.setToolTip("Polígono(s) catastral(es)")
        self.EX_PARCELAS.setToolTip("Parcela(s) catastral(es)")
        self.EX_TM.setToolTip("Término(s) municipal(es)")

        # Tooltips para datos de tramo
        self.EX_NOMBRE_TRAMO.setToolTip("Nombre del tramo de carretera")
        self.EX_TITULO_EXPROPIACION.setToolTip("Título del proyecto de expropiación")

        # Tooltips para fechas y trámites
        self.EX_FECHA_ULTIMO_TRAMITE.setToolTip("Fecha del último trámite realizado")
        self.EX_TRAMITE_EXPROPIACION.setToolTip("Trámite actual del expediente")
        self.EX_FECHAARCHIVO.setToolTip("Fecha de archivo del expediente")
        self.EX_ESTAARCHIVADO.setToolTip("Indica si el expediente está archivado")

        # Tooltips para otros campos
        self.EX_ART_LEY.setToolTip("Artículo de ley aplicable")
        self.EX_PROTOCOLO_REGISTRO.setToolTip("Número de protocolo de comunicación con el registro")
        self.EX_DECR_ACUERDO_RESOLUCION.setToolTip("Decreto, acuerdo o resolución relacionada")
        self.EX_ACTAS_PREVIAS.setToolTip("Actas previas del expediente")
        self.EX_REMISION_CATASTRAL.setToolTip("Fecha de remisión a Catastro")
        self.EX_NUMORDEN.setToolTip("Número de orden de la parcela")

        # Tooltips para elementos de navegación y control
        self.cbxEX_NUM.setToolTip("Seleccione o escriba el número de expediente para navegar")
        self.cbxPENDIENTES.setToolTip("Mostrar solo expedientes pendientes (no archivados)")
        self.numElementos.setToolTip("Posición actual / Total de registros")

        # Tooltips para botones
        self.btnIrINICIO.setToolTip("Ir al primer registro (el más antiguo)")
        self.btnANTERIOR.setToolTip("Ir al registro anterior (más antiguo)")
        self.btnSIGUIENTE.setToolTip("Ir al registro siguiente (más moderno)")
        self.btnIrFINAL.setToolTip("Ir al último registro (el más moderno)")
        self.btnSUPRIMIR.setToolTip("Eliminar el registro actual del Excel")
        self.btnEDITAR.setToolTip("Activar/desactivar modo edición")
        self.btnAGREGAR.setToolTip("Añadir un nuevo expediente")
        self.btnGUARDARCAMBIOS.setToolTip("Guardar los cambios realizados")
        self.btnVER_DOCUM.setToolTip("Abrir carpeta con la documentación del expediente")
        self.btnZoomElemento.setToolTip("Hacer zoom a la geometría en el mapa")
        self.btnBuscarREGISTRO.setToolTip("Buscar registros por cualquier campo")
        self.btnAbreExcel.setToolTip("Abrir el archivo Excel con todos los expedientes")
        self.btnSALIR.setToolTip("Cerrar el diálogo")

    def onDatoModificado(self):
        """Marca que hay datos modificados cuando estamos en modo edición"""
        if self.modo_edicion:
            self.datos_modificados = True

    def comprobarCargaCapaGPKG(self):
        """Comprueba si la capa GPKG está cargada en el TOC"""
        layers = QgsProject.instance().mapLayersByName(self.layerINFEXPnom)

        if not layers:
            return False

        self.capa_gpkg = layers[0]
        return True

    def obtenerInfoFuenteGPKG(self):
        """Obtiene la información de la fuente de la capa GPKG"""
        if self.capa_gpkg is None:
            return

        fuente = self.capa_gpkg.source()

        if '|layername=' in fuente:
            partes = fuente.split('|layername=')
            self.layerINFEXPfich = partes[0]
            self.layerINFEXPlayer = partes[1]
        else:
            self.layerINFEXPfich = fuente
            self.layerINFEXPlayer = self.capa_gpkg.name()

        # print(f"GPKG cargado: {self.layerINFEXPfich} | Capa: {self.layerINFEXPlayer}")

    def cargarRegistrosGPKG(self):
        """Carga todos los registros de la capa GPKG"""
        if self.capa_gpkg is None:
            return

        self.registros_gpkg = []
        features = list(self.capa_gpkg.getFeatures())
        self.registros_gpkg = features
        # print(f"GPKG registros cargados: {len(self.registros_gpkg)}")

    def cargarExpedientesExpropiacion(self):
        """
        Carga los valores del campo 'EXPTE_EXPROPIACION' de la tabla GPKG de expedientes de expropiación
        y los añade al combo EX_EXPTE_EXPROPIACION.
        """

        # Limpiar y configurar combo con valor por defecto
        self.EX_EXPTE_EXPROPIACION.clear()
        self.EX_EXPTE_EXPROPIACION.addItem("s/d")
        self.EX_EXPTE_EXPROPIACION.setEditable(True)


        if not self.ExproTablePath or not os.path.exists(self.ExproTablePath):
            # print(f"Tabla de expedientes no encontrada: {self.ExproTablePath}")
            return

        try:
            # Conectar directamente al GPKG usando sqlite3
            conn = sqlite3.connect(self.ExproTablePath)

            # Obtener la lista de tablas del GPKG
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = [row[0] for row in cursor.fetchall()]

            # Buscar la tabla que contiene los expedientes
            tabla_encontrada = None
            for table in tables:
                if 'EXPEDIENTE' in table.upper() or 'EXPTE' in table.upper():
                    tabla_encontrada = table
                    break

            if not tabla_encontrada:
                # Si no se encuentra, usar la primera tabla
                tabla_encontrada = tables[0] if tables else None

            if not tabla_encontrada:
                conn.close()
                return

            # Leer la tabla completa usando pandas
            query = f"SELECT * FROM \"{tabla_encontrada}\""
            self.df_expro_table = pd.read_sql_query(query, conn)
            conn.close()

            # Verificar que existe el campo 'EXPTE_EXPROPIACION'
            if 'EXPTE_EXPROPIACION' not in self.df_expro_table.columns:
                # print("ERROR: No se encuentra el campo 'EXPTE_EXPROPIACION' en la tabla")
                # print(f"Campos disponibles: {list(self.df_expro_table.columns)}")
                return

            # Recopilar valores únicos del campo 'EXPTE_EXPROPIACION'
            valores_unicos = set()
            valores_unicos.add("s/d")

            for valor in self.df_expro_table['EXPTE_EXPROPIACION']:
                if pd.notna(valor) and str(valor).strip():
                    valor_str = str(valor).strip()
                    valores_unicos.add(valor_str)

            # Ordenar valores (más reciente primero)
            lista_ordenada = sorted(list(valores_unicos), reverse=True)

            # Limpiar y llenar el combo
            self.EX_EXPTE_EXPROPIACION.clear()
            self.EX_EXPTE_EXPROPIACION.addItems(lista_ordenada)
            self.EX_EXPTE_EXPROPIACION.setEditable(True)

            # Configurar completer para búsqueda rápida
            completer = QCompleter(lista_ordenada)
            completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
            self.EX_EXPTE_EXPROPIACION.setCompleter(completer)

        except Exception as e:
            traceback.print_exc()

    def cargarDatosExcel(self):
        """Carga los datos del archivo Excel con recuperación automática"""

        # Primero, comprobar si hay backups disponibles aunque el Excel exista
        # Esto es útil para depuración
        backups_disponibles = self.obtener_ultima_copia_seguridad()
        # if backups_disponibles:
            # print(f"Backup disponible: {backups_disponibles}")
        # else:
            # print("No hay backups disponibles")

        excel_existia = os.path.exists(self.ExcelInfEXPRO)
        excel_vacio = False

        # Comprobar si el Excel existe pero está vacío
        if excel_existia:
            try:
                excel_vacio = self.excel_esta_vacio()
                if excel_vacio:
                    print(f"Excel encontrado pero vacío: {self.ExcelInfEXPRO}")
            except:
                # Si hay error al leer, asumimos que está dañado
                excel_vacio = True

        # CASO 1: El Excel no existe o está vacío
        if not excel_existia or excel_vacio:

            # Buscar copia de seguridad
            ultimo_backup = self.obtener_ultima_copia_seguridad()

            if ultimo_backup:
                # Preparar mensaje según el caso
                if not excel_existia:
                    msg = f"No se encuentra el archivo Excel:\n{self.ExcelInfEXPRO}"
                    detalle = "El archivo no existe."
                else:
                    msg = f"El archivo Excel está vacío o dañado:\n{self.ExcelInfEXPRO}"
                    detalle = "El archivo no contiene datos válidos."

                fecha_backup = dt.fromtimestamp(os.path.getmtime(ultimo_backup))
                fecha_str = fecha_backup.strftime("%d/%m/%Y %H:%M:%S")

                texto = (
                    f"{msg}\n\n"
                    f"{detalle}\n\n"
                    f"Se ha encontrado una copia de seguridad:\n"
                    f"{os.path.basename(ultimo_backup)}\n"
                    f"Fecha: {fecha_str}\n\n"
                    f"¿Desea restaurar esta copia?"
                )

                respuesta = QMessageBox.question(
                    self,
                    "Recuperación automática",
                    texto,
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.Yes
                )

                if respuesta == QMessageBox.StandardButton.Yes:
                    if self.restaurar_copia_seguridad(ultimo_backup):
                        # Mensaje de éxito
                        QMessageBox.information(
                            self,
                            "Recuperación exitosa",
                            f"Se ha restaurado la copia de seguridad.\n\n"
                            f"El archivo original ha sido respaldado como:\n"
                            f"{os.path.basename(self.ExcelInfEXPRO)}.DANADO_*",
                            QMessageBox.StandardButton.Ok
                        )
                        # Intentar cargar de nuevo
                        return self.cargarDatosExcel()  # Llamada recursiva
                    else:
                        return False
                else:
                    # El usuario no quiere restaurar
                    QMessageBox.warning(
                        self,
                        "Sin datos",
                        "No se cargarán datos. Puede intentar recuperar manualmente desde la carpeta COPIA_SEGURIDAD.",
                        QMessageBox.StandardButton.Ok
                    )
                    return False
            else:
                # No hay copias de seguridad
                if not excel_existia:
                    QMessageBox.critical(
                        self,
                        "Error - Sin datos",
                        f"No se encuentra el archivo Excel:\n{self.ExcelInfEXPRO}\n\n"
                        f"Tampoco se encontraron copias de seguridad en la carpeta COPIA_SEGURIDAD.\n\n"
                        f"No hay datos disponibles para mostrar.",
                        QMessageBox.StandardButton.Ok
                    )
                else:
                    QMessageBox.critical(
                        self,
                        "Error - Excel vacío",
                        f"El archivo Excel existe pero está vacío o dañado:\n{self.ExcelInfEXPRO}\n\n"
                        f"No se encontraron copias de seguridad para restaurar.\n\n"
                        f"No hay datos disponibles para mostrar.",
                        QMessageBox.StandardButton.Ok
                    )
                return False

        # CASO 2: El Excel existe y tiene datos (carga normal)
        try:
            self.df_excel = pd.read_excel(self.ExcelInfEXPRO)
            # ... resto del código de carga normal ...

            # Verificar que existe la columna NUMEXPRO
            if 'NUMEXPRO' not in self.df_excel.columns:
                QMessageBox.critical(
                    self,
                    "Error - Estructura Excel",
                    "El archivo Excel no contiene la columna 'NUMEXPRO'.\n\n"
                    "Por favor, verifique la estructura del archivo.",
                    QMessageBox.StandardButton.Ok
                )
                return False

            # Verificar que existe la columna ESTAARCHIVADO
            if 'ESTAARCHIVADO' not in self.df_excel.columns:
                # No es crítico, solo informativo
                pass

            # Convertir a lista de diccionarios, manejando NaN
            self.registros_excel = []
            for idx, row in self.df_excel.iterrows():
                registro = {}
                for col in self.df_excel.columns:
                    valor = row[col]
                    if pd.isna(valor):
                        registro[col] = None
                    else:
                        registro[col] = valor
                self.registros_excel.append(registro)

            if self.registros_excel:
                # Ordenar por NUMEXPRO descendente (más moderno primero)
                self.registros_excel.sort(key=lambda x: str(x.get('NUMEXPRO', '')), reverse=True)
                self.indice_excel_actual = 0

                # Inicializar el filtro de pendientes
                self.aplicarFiltroPendientes()
                self.actualizarNavegacionFiltrada()

                return True
            return False

        except Exception as e:
            print(f"Error cargando Excel: {str(e)}")

            # Si hay error al leer, ofrecer restaurar copia
            ultimo_backup = self.obtener_ultima_copia_seguridad()
            if ultimo_backup:
                respuesta = QMessageBox.question(
                    self,
                    "Error de lectura",
                    f"No se pudo leer el archivo Excel:\n{self.ExcelInfEXPRO}\n\n"
                    f"Error: {str(e)}\n\n"
                    f"¿Desea intentar restaurar desde la última copia de seguridad?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.Yes
                )

                if respuesta == QMessageBox.StandardButton.Yes:
                    if self.restaurar_copia_seguridad(ultimo_backup):
                        return self.cargarDatosExcel()  # Reintentar
                    return False

            QMessageBox.warning(
                self,
                "Error - Carga de Excel",
                f"No se pudo cargar el archivo Excel:\n{self.ExcelInfEXPRO}\n\nError: {str(e)}",
                QMessageBox.StandardButton.Ok
            )
            self.df_excel = None
            return False

        except Exception as e:
            print(f"Error cargando Excel: {str(e)}")
            QMessageBox.warning(
                self,
                "Error - Carga de Excel",
                f"No se pudo cargar el archivo Excel:\n{self.ExcelInfEXPRO}\n\nError: {str(e)}",
                QMessageBox.StandardButton.Ok
            )
            self.df_excel = None
            return False

    def actualizar_contador_registros(self):
        """
        Actualiza el contador de registros en formato "nnnnn de mmmmm"
        Asumiendo que tienes un QLineEdit llamado 'numElementos' (readOnly=True)
        """
        total = len(self.registros_excel) if hasattr(self, 'registros_excel') else 0

        if self.filtro_pendientes and hasattr(self, 'registros_filtrados'):
            # Si hay filtro activo, usar el índice filtrado
            indice_mostrar = self.indice_filtrado_actual + 1 if self.indice_filtrado_actual >= 0 else 0
            total_mostrar = len(self.registros_filtrados)

            # Tooltip informativo
            tooltip = f"Mostrando {total_mostrar} de {total} registros (filtro: solo pendientes)"
            color_fondo = "#FFF3CD"  # Amarillo suave
            color_texto = "#856404"
        else:
            # Sin filtro, usar el índice normal
            indice_mostrar = self.indice_excel_actual + 1 if self.indice_excel_actual >= 0 else 0
            total_mostrar = total

            if total > 0:
                tooltip = f"Total de registros: {total}"
            else:
                tooltip = "No hay registros"
            color_fondo = ""  # Por defecto
            color_texto = ""

        # Formatear el texto
        if total_mostrar > 0:
            texto = f"{indice_mostrar} de {total_mostrar}"
        else:
            texto = "0 de 0"

        # Asumiendo que tienes un QLineEdit llamado 'numElementos'
        if hasattr(self, 'numElementos'):
            self.numElementos.setText(texto)
            self.numElementos.setToolTip(tooltip)

            # Aplicar estilo si hay filtro
            if color_fondo:
                self.numElementos.setStyleSheet(f"background-color: {color_fondo}; color: {color_texto};")
            else:
                self.numElementos.setStyleSheet("")

    def configurarWidgetsObligatorios(self):
        """Configura la lista de widgets obligatorios"""
        self.widgets_obligatorios = [
            self.EX_REGISTRO,
            self.EX_SOLICITANTE,
            self.EX_INTERESADO,
            self.EX_TIPO
        ]

    def marcarObligatorios(self):
        """Marca los widgets obligatorios con borde rojo"""
        for widget in self.widgets_obligatorios:
            self.estilos_originales[widget] = widget.styleSheet()
            if isinstance(widget, QComboBox):
                # Para combos, usar un borde rojo en el combo completo
                widget.setStyleSheet(widget.styleSheet() + """
                    QComboBox {
                        border: 2px solid red;
                        border-radius: 3px;
                    }
                    QComboBox::drop-down {
                        border-left: 2px solid red;
                    }
                """)
            else:
                # Para QLineEdit y QTextEdit
                widget.setStyleSheet(widget.styleSheet() + "border: 2px solid red;")

    def desmarcarObligatorios(self):
        """Quita el marcado rojo de los widgets obligatorios"""
        for widget in self.widgets_obligatorios:
            if widget in self.estilos_originales:
                widget.setStyleSheet(self.estilos_originales[widget])

    def validarObligatorios(self):
        """Valida que los campos obligatorios no estén vacíos"""
        for widget in self.widgets_obligatorios:
            if isinstance(widget, QLineEdit):
                if not widget.text().strip():
                    return False
            elif isinstance(widget, QComboBox):
                if not widget.currentText().strip():
                    return False
            elif isinstance(widget, QTextEdit):
                if not widget.toPlainText().strip():
                    return False
        return True

    def setModoEdicion(self, activar):
        """Activa o desactiva el modo edición"""
        self.modo_edicion = activar

        if activar:
            # MODO EDICIÓN: widgets editables y activos
            for widget in self.widgets_editables:
                if isinstance(widget, QLineEdit):
                    widget.setReadOnly(False)
                    widget.setEnabled(True)
                elif isinstance(widget, QComboBox):
                    widget.setEnabled(True)
                    widget.setEditable(True)
                    widget.setFocusPolicy(Qt.FocusPolicy.StrongFocus)  # Permite recibir foco
                elif isinstance(widget, QTextEdit):
                    widget.setReadOnly(False)
                    widget.setEnabled(True)
                elif isinstance(widget, QDateEdit):
                    widget.setReadOnly(False)
                    widget.setEnabled(True)
                elif isinstance(widget, QCheckBox):
                    widget.setEnabled(True)
            self.btnEDITAR.setText("CANCELAR EDICIÓN")
            self.btnGUARDARCAMBIOS.setVisible(True)
            self.btnGUARDARCAMBIOS.setEnabled(True)
            self.datos_modificados = False
        else:
            # MODO VISUALIZACIÓN: widgets como solo lectura (no desactivados)
            for widget in self.widgets_editables:
                if isinstance(widget, QLineEdit):
                    widget.setReadOnly(True)
                    widget.setEnabled(True)
                elif isinstance(widget, QComboBox):
                    # IMPORTANTE: No deshabilitamos los combos, solo los hacemos no editables
                    widget.setEnabled(True)  # <-- Mantener habilitado
                    widget.setEditable(False)
                    widget.setFocusPolicy(Qt.FocusPolicy.NoFocus)  # No puede recibir foco
                    # Estilo para que parezca deshabilitado pero siga siendo funcional
                    widget.setStyleSheet("QComboBox { color: black; background-color: #f0f0f0; }")
                elif isinstance(widget, QTextEdit):
                    widget.setReadOnly(True)
                    widget.setEnabled(True)
                elif isinstance(widget, QDateEdit):
                    widget.setReadOnly(True)
                    widget.setEnabled(True)
                elif isinstance(widget, QCheckBox):
                    widget.setEnabled(False)
            self.btnEDITAR.setText("MODIFICAR")
            self.btnGUARDARCAMBIOS.setVisible(False)
            self.btnGUARDARCAMBIOS.setEnabled(False)

        # Estos widgets SIEMPRE deben estar habilitados y funcionales
        self.cbxEX_NUM.setEnabled(True)
        self.cbxEX_NUM.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.cbxEX_NUM.setEditable(True)  # <-- Permitir escribir para búsqueda rápida

        self.cbxPENDIENTES.setEnabled(True)  # <-- Asegurar que el checkbox siempre está habilitado
        self.cbxPENDIENTES.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        self.actualizar_contador_registros()

    def limpiarWidgets(self):
        """Limpia todos los widgets editables"""
        for widget in self.widgets_editables:
            if isinstance(widget, QLineEdit):
                widget.clear()
            elif isinstance(widget, QComboBox):
                # Para combos, establecer índice -1 (ninguna selección)
                widget.setCurrentIndex(-1)
                # Si es editable, limpiar el texto
                if widget.isEditable():
                    widget.setEditText("")
            elif isinstance(widget, QTextEdit):
                widget.clear()
            elif isinstance(widget, QCheckBox):
                widget.setChecked(False)
            # Los QDateEdit los manejamos aparte

    def establecerValoresPorDefecto(self):
        """Establece los valores por defecto para el modo agregar"""
        # Obtener el siguiente número de expediente
        numexpro = self.obtenerSiguienteNumeroExpediente()
        if numexpro:
            self.EX_NUMEXPRO.setText(f"EX-{numexpro}")

        # Fecha actual para los campos de fecha
        fecha_actual = QDate.currentDate()
        self.EX_FECHA.setDate(fecha_actual)
        self.EX_FECHA_ULTIMO_TRAMITE.setDate(fecha_actual)
        self.EX_FECHAARCHIVO.setDate(QDate())

        # Valor por defecto para TRAMITE_EXPROPIACION
        self.EX_TRAMITE_EXPROPIACION.setText("ENTRADA SOLICITUD")

        # Limpiar los combos obligatorios para que el usuario seleccione
        self.EX_SOLICITANTE.setCurrentIndex(-1)  # -1 significa ninguna selección
        self.EX_SOLICITANTE.setEditText("")      # Vaciar el texto editable

        self.EX_INTERESADO.setCurrentIndex(-1)
        self.EX_INTERESADO.setEditText("")

        self.EX_TIPO_EXPEDIENTE.setCurrentIndex(-1)
        self.EX_TIPO_EXPEDIENTE.setEditText("")

        # También limpiar EX_REGISTRO aunque es QLineEdit (ya se limpia en limpiarWidgets)
        # Pero por si acaso:
        self.EX_REGISTRO.clear()

        self.EX_INGENIERO.setCurrentIndex(-1)
        self.EX_INGENIERO.setEditText("")

        self.EX_MARGEN.setCurrentIndex(-1)
        self.EX_MARGEN.setEditText("")



    def inicializarComboNavegacion(self):
        """Inicializa el combo de navegación con los datos del Excel"""

        # Asegurar que el combo es editable
        self.cbxEX_NUM.setEditable(True)

        self.cbxEX_NUM.blockSignals(True)
        self.cbxEX_NUM.clear()

        if self.registros_excel:
            for i, registro in enumerate(self.registros_excel):
                numexpro = registro.get('NUMEXPRO', '')
                if numexpro and not pd.isna(numexpro):
                    # Añadir prefijo EX- para mostrar en el combo
                    ex_num_completo = f"EX-{numexpro}"
                    self.cbxEX_NUM.addItem(ex_num_completo)
                    if i < 3:  # Debug: mostrar primeros 3
                        pass

            if self.filtro_pendientes and self.registros_filtrados:
                # Si hay filtro activo, usar los índices filtrados
                pass  # Ya se maneja en actualizarNavegacionFiltrada
            elif self.indice_excel_actual >= 0:
                self.cbxEX_NUM.setCurrentIndex(self.indice_excel_actual)
                # Forzar la actualización de la visualización del combo
                self.cbxEX_NUM.setEditText(self.cbxEX_NUM.currentText())
                registro = self.registros_excel[self.indice_excel_actual]
                self.cargarRegistroExcelEnUI(registro)
        else:
            print("No hay registros Excel")
            pass

        self.cbxEX_NUM.blockSignals(False)

    def cargarRegistroExcelEnUI(self, registro):
        # Carga los datos del registro de excel en el menú

        for campo_excel, valor in registro.items():
            nombre_widget = f"EX_{campo_excel}"
            widget = self.findChild(object, nombre_widget)

            if widget is None:
                continue

            # --------- TRATAMIENTO ESPECIAL PARA NUMEXPRO ----------
            if campo_excel == 'NUMEXPRO':
                if isinstance(widget, QLineEdit):
                    if pd.isna(valor) or valor == "":
                        widget.clear()
                    else:
                        widget.setText(f"EX-{valor}")
                continue

            # --------- PARA FECHAARCHIVO, FUERZA DEBUG ----------
            if campo_excel == 'FECHAARCHIVO':
                # print(f"\n=== DEBUG FORZADO FECHAARCHIVO ===")
                # print(f"Tipo: {type(valor)}")
                # print(f"Valor: {repr(valor)}")
                # print(f"¿Es NaN?: {pd.isna(valor)}")
                pass

            # Manejar nulos de forma más agresiva
            es_nulo = False
            try:
                if pd.isna(valor):
                    es_nulo = True
                elif valor is None:
                    es_nulo = True
                elif isinstance(valor, str) and valor.strip() in ["", "-", "null", "NULL", "None"]:
                    es_nulo = True
            except:
                es_nulo = False

            if es_nulo:
                if campo_excel == 'FECHAARCHIVO':
                    pass
                if isinstance(widget, QDateEdit):
                    widget.setDate(QDate())
                elif isinstance(widget, QLineEdit):
                    widget.clear()
                elif isinstance(widget, QTextEdit):
                    widget.clear()
                elif isinstance(widget, QCheckBox):
                    widget.setChecked(False)
                elif isinstance(widget, QComboBox):
                    try:
                        valor_str = str(valor)
                        index = widget.findText(valor_str)
                        if index >= 0:
                            widget.setCurrentIndex(index)
                        else:
                            # Si no existe, añadirlo (porque es editable)
                            widget.addItem(valor_str)
                            widget.setCurrentText(valor_str)
                        widget.setEditable(True)
                    except:
                        widget.setCurrentIndex(-1)

                continue

            # --------- DATE ----------
            if isinstance(widget, QDateEdit):
                try:
                    fecha_obj = None
                    # from datetime import datetime as dt
                    # import pandas as pd

                    # CASO 1: Ya es datetime o timestamp
                    if isinstance(valor, (dt, pd.Timestamp)):
                        fecha_obj = valor
                        if campo_excel == 'FECHAARCHIVO':
                            # print(f"  -> Ya es datetime: {fecha_obj}")
                            pass

                    # CASO 2: Es string
                    elif isinstance(valor, str):
                        valor_str = valor.strip()
                        if campo_excel == 'FECHAARCHIVO':
                            # print(f"  -> String crudo: '{valor_str}'")
                            pass

                        # Quitar hora si existe
                        if ' ' in valor_str:
                            valor_str = valor_str.split(' ')[0]
                            if campo_excel == 'FECHAARCHIVO':
                                # print(f"  -> Sin hora: '{valor_str}'")
                                pass

                        # Reemplazar separadores comunes
                        for sep in ['/', '-', '.']:
                            if sep in valor_str:
                                partes = valor_str.split(sep)
                                if len(partes) == 3:
                                    # Detectar si es DD/MM/YYYY o YYYY/MM/DD
                                    if len(partes[0]) == 4:  # YYYY
                                        año, mes, dia = partes
                                    elif len(partes[2]) == 4:  # DD/MM/YYYY
                                        dia, mes, año = partes
                                    else:
                                        continue

                                    try:
                                        fecha_obj = dt(int(año), int(mes), int(dia))
                                        if campo_excel == 'FECHAARCHIVO':
                                            # print(f"  -> Parseado manual: {fecha_obj}")
                                            pass
                                        break
                                    except:
                                        continue

                        # Si no funcionó el parseo manual, probar strptime
                        if fecha_obj is None:
                            formatos = [
                                "%Y-%m-%d", "%d/%m/%Y", "%Y%m%d",
                                "%d-%m-%Y", "%d.%m.%Y", "%m/%d/%Y"
                            ]
                            for fmt in formatos:
                                try:
                                    fecha_obj = dt.strptime(valor_str, fmt)
                                    if campo_excel == 'FECHAARCHIVO':
                                        # print(f"  -> strptime con {fmt}: {fecha_obj}")
                                        pass
                                    break
                                except:
                                    continue

                    # CASO 3: Es número (fecha Excel)
                    elif isinstance(valor, (int, float)):
                        try:
                            # from datetime import datetime, timedelta
                            # Excel cuenta desde 1900-01-01 (con el bug de 1900)
                            # fecha_excel = datetime(1899, 12, 30) + timedelta(days=float(valor))
                            fecha_excel = dt(1899, 12, 30) + timedelta(days=float(valor))
                            fecha_obj = fecha_excel
                            if campo_excel == 'FECHAARCHIVO':
                                # print(f"  -> Número Excel: {fecha_obj} (días: {valor})")
                                pass
                        except:
                            pass

                    # Establecer la fecha
                    if fecha_obj is not None:
                        try:
                            qdate = QDate(fecha_obj.year, fecha_obj.month, fecha_obj.day)
                            if campo_excel == 'FECHAARCHIVO':
                                # print(f"  -> QDate: {qdate.toString('yyyy-MM-dd')}, válida: {qdate.isValid()}")
                                pass

                            if qdate.isValid():
                                widget.setDate(qdate)
                                if campo_excel == 'FECHAARCHIVO':
                                    # print(f"  -> ✅ FECHA ESTABLECIDA: {qdate.toString('yyyy-MM-dd')}")
                                    pass
                            else:
                                widget.setDate(QDate(1, 1, 1))
                                if campo_excel == 'FECHAARCHIVO':
                                    # print(f"  -> ❌ FECHA INVÁLIDA")
                                    pass
                        except Exception as e:
                            # print(f"Error: {e}")
                            widget.setDate(QDate(1, 1, 1))
                    else:
                        widget.setDate(QDate(1, 1, 1))
                        if campo_excel == 'FECHAARCHIVO':
                            # print(f"  -> ⚠️ NO SE PUDO PARSEAR")
                            pass

                except Exception as e:
                    # print(f"Error general en {campo_excel}: {e}")
                    widget.setDate(QDate(1, 1, 1))

            # --------- CHECK ----------
            elif isinstance(widget, QCheckBox):
                try:
                    check_value = str(valor).lower() in ["1", "true", "sí", "si", "x", "yes", "checked"]
                    widget.setChecked(check_value)
                except:
                    widget.setChecked(False)

            # --------- COMBO ----------
            elif isinstance(widget, QComboBox):
                try:
                    valor_str = str(valor)
                    index = widget.findText(valor_str)
                    if index >= 0:
                        widget.setCurrentIndex(index)
                    else:
                        widget.addItem(valor_str)
                        widget.setCurrentText(valor_str)
                    widget.setEditable(True)
                except:
                    widget.setCurrentIndex(-1)

            # --------- TEXT EDIT ----------
            elif isinstance(widget, QTextEdit):
                try:
                    widget.setPlainText(str(valor))
                except:
                    widget.clear()

            # --------- LINE EDIT ----------
            elif isinstance(widget, QLineEdit):
                try:
                    widget.setText(str(valor))
                except:
                    widget.clear()
        
        # Se actualiza el color del botón ZOOM A ELEMENTO
        self.actualizarColorBotonZoom()        

        # # Mapeo de columnas Excel a widgets según la lista proporcionada
        # mapeo_excel = {
            # 'NUMEXPRO':                 self.EX_NUMEXPRO,               # 00 (con prefijo EX-)
            # 'REGISTRO':                 self.EX_REGISTRO,               # 01
            # 'FECHA':                    self.EX_FECHA,                  # 02
            # 'SOLICITANTE':              self.EX_SOLICITANTE,            # 03
            # 'INTERESADO':               self.EX_INTERESADO,             # 04
            # 'DNI':                      self.EX_DNI,                    # 05
            # 'NOMBRE':                   self.EX_NOMBRE,                 # 06
            # 'TLFNO':                    self.EX_TLFNO,                  # 09
            # 'CARRETERA':                self.EX_CARRETERA,              # 11
            # 'KILOMETRO':                self.EX_KILOMETRO,              # 12
            # 'KILOMET2':                 self.EX_KILOMET2,               # 13
            # 'MARGEN':                   self.EX_MARGEN,                 # 14
            # 'OBSERVAPK':                self.EX_OBSERVAPK,              # 15
            # 'TIPO':                     self.EX_TIPO,                   # 16
            # 'INGENIERO':                self.EX_INGENIERO,              # 19
            # 'ESTAARCHIVADO':            self.EX_ESTAARCHIVADO,          # 21
            # 'FECHAARCHIVO':             self.EX_FECHAARCHIVO,           # 22
            # 'EXPTE_EXPROPIACION':       self.EX_EXPTE_EXPROPIACION,     # 23
            # 'EXPTES_RELACIONADOS':      self.EX_EXPTES_RELACIONADOS,    # 24
            # 'NOMBRE_TRAMO':             self.EX_NOMBRE_TRAMO,           # 25
            # 'DECR_ACUERDO_RESOLUCION':  self.EX_DECR_ACUERDO_RESOLUCION,# 26
            # 'ACTAS_PREVIAS':            self.EX_ACTAS_PREVIAS,          # 27
            # 'REMISION_CATASTRAL':       self.EX_REMISION_CATASTRAL,     # 28
            # 'NUMORDEN':                 self.EX_NUMORDEN,               # 29
            # 'POLIGONO':                 self.EX_POLIGONO,               # 30
            # 'PARCELAS':                 self.EX_PARCELAS,               # 31
            # 'TM':                       self.EX_TM,                     # 32
            # 'TIPO_EXPEDIENTE':          self.EX_TIPO_EXPEDIENTE,        # 33
            # 'TITULO_EXPROPIACION':      self.EX_TITULO_EXPROPIACION,    # 35
            # 'REF_CATASTRAL':            self.EX_REF_CATASTRAL,          # 37
            # 'FECHA_ULTIMO_TRAMITE':     self.EX_FECHA_ULTIMO_TRAMITE,   # 38
            # 'TRAMITE_EXPROPIACION':     self.EX_TRAMITE_EXPROPIACION,   # 39
            # 'CORREOELEC':               self.EX_CORREOELEC,             # 40
            # 'PROTOCOLO_REGISTRO':       self.EX_PROTOCOLO_REGISTRO,     # 41
            # 'ART_LEY' :                 self.EX_ART_LEY                 # 42
        # }

    def cambioRegistro(self, index):
        """Se ejecuta al cambiar el índice del combo"""
        if index < 0:
            return

        # Si estamos en modo agregar, no permitir cambiar de registro
        if self.modo_agregar:
            respuesta = QMessageBox.question(
                self,
                "Confirmar",
                "Está en modo agregar. Si cambia de registro, perderá los datos introducidos.\n¿Desea continuar?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if respuesta == QMessageBox.StandardButton.No:
                # Volver al índice anterior
                self.cbxEX_NUM.blockSignals(True)
                if self.filtro_pendientes:
                    self.cbxEX_NUM.setCurrentIndex(self.indice_filtrado_actual)
                else:
                    self.cbxEX_NUM.setCurrentIndex(self.indice_excel_actual)
                self.cbxEX_NUM.blockSignals(False)
                return
            else:
                self.setModoAgregar(False)

        # Si estamos en modo edición y hay cambios sin guardar, preguntar
        if self.modo_edicion and self.datos_modificados:
            respuesta = QMessageBox.question(
                self,
                "Confirmar",
                "Hay cambios sin guardar. ¿Desea descartarlos?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if respuesta == QMessageBox.StandardButton.No:
                # Volver al índice anterior
                self.cbxEX_NUM.blockSignals(True)
                if self.filtro_pendientes:
                    self.cbxEX_NUM.setCurrentIndex(self.indice_filtrado_actual)
                else:
                    self.cbxEX_NUM.setCurrentIndex(self.indice_excel_actual)
                self.cbxEX_NUM.blockSignals(False)
                return

        # Obtener el índice real en la lista de registros
        indice_real = self.obtenerIndiceRealDesdeCombo(index)

        if indice_real >= 0 and indice_real < len(self.registros_excel):
            self.indice_excel_actual = indice_real
            if self.filtro_pendientes:
                self.indice_filtrado_actual = index

            registro = self.registros_excel[self.indice_excel_actual]
            self.cargarRegistroExcelEnUI(registro)
            self.actualizar_contador_registros()
            
            # Agregar esto para actualizar el color
            self.actualizarColorBotonZoom()
            
            # Salir del modo edición al cambiar de registro
            if self.modo_edicion:
                self.setModoEdicion(False)
           
    def crearCopiaSeguridad(self):
        """Crea una copia de seguridad del archivo Excel antes de modificarlo"""
        if not os.path.exists(self.ExcelInfEXPRO):
            return False

        try:
            # Directorio donde está el Excel original
            directorio_original = os.path.dirname(self.ExcelInfEXPRO)
            nombre_base = os.path.basename(self.ExcelInfEXPRO)
            nombre_sin_ext, extension = os.path.splitext(nombre_base)

            # Crear subdirectorio COPIA_SEGURIDAD si no existe
            dir_backup = os.path.join(directorio_original, "COPIA_SEGURIDAD")
            if not os.path.exists(dir_backup):
                os.makedirs(dir_backup)

            # Generar nombre del backup con timestamp
            timestamp = dt.now().strftime("%Y%m%d_%H%M%S")
            nombre_backup = f"{nombre_sin_ext}_BAK_{timestamp}{extension}"
            ruta_backup = os.path.join(dir_backup, nombre_backup)

            # Copiar el archivo
            shutil.copy2(self.ExcelInfEXPRO, ruta_backup)

            # Mantener solo las últimas 5 copias de seguridad
            self.limpiarCopiasSeguridad(dir_backup, nombre_sin_ext)

            # Mostrar mensaje en statusBar
            self.iface.mainWindow().statusBar().showMessage(
                f"Copia de seguridad creada en carpeta COPIA_SEGURIDAD",
                3000
            )

            return True
        except Exception as e:
            # print(f"Error al crear copia de seguridad: {str(e)}")
            return False

    def limpiarCopiasSeguridad(self, directorio_backup, nombre_base):
        """Mantiene solo las últimas 5 copias de seguridad en el directorio especificado"""
        try:
            # Buscar todos los archivos que coincidan con el patrón *_BAK_* en el directorio de backups
            patron = re.compile(rf"{re.escape(nombre_base)}_BAK_\d{{8}}_\d{{6}}\.xlsx?")
            backups = []

            for archivo in os.listdir(directorio_backup):
                if patron.match(archivo):
                    ruta_completa = os.path.join(directorio_backup, archivo)
                    backups.append((ruta_completa, os.path.getmtime(ruta_completa)))

            # Ordenar por fecha de modificación (más reciente primero)
            backups.sort(key=lambda x: x[1], reverse=True)

            # Eliminar los backups más antiguos (mantener solo 5)
            for ruta_backup, _ in backups[5:]:
                os.remove(ruta_backup)
        except Exception as e:
            # print(f"Error al limpiar copias de seguridad: {str(e)}")
            pass

    def establecerFechaSiVacia(self, date_widget):
        """
        Si el widget de fecha tiene fecha nula, la cambia a la fecha actual.
        Solo actúa si estamos en modo edición o agregar.
        """
        # Solo si estamos en modo edición o agregar
        if self.modo_edicion or self.modo_agregar:
            if not date_widget.date().isValid():  # <--- CAMBIA: isValid() en lugar de == QDate(1,1,1)
                date_widget.setDate(QDate.currentDate())

    def onEditarClicked(self):
        """Maneja el click en el botón editar/cancelar"""
        # Si estamos en modo agregar, no permitir editar
        if self.modo_agregar:
            QMessageBox.warning(
                self,
                "Aviso",
                "No puede editar mientras está en modo agregar.\n"
                "Primero debe cancelar o guardar el nuevo expediente.",
                QMessageBox.StandardButton.Ok
            )
            return

        if self.modo_edicion:
            # Cancelar edición - preguntar si hay cambios sin guardar
            if self.datos_modificados:
                respuesta = QMessageBox.question(
                    self,
                    "Confirmar",
                    "Hay cambios sin guardar. ¿Desea descartarlos?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                )
                if respuesta == QMessageBox.StandardButton.No:
                    return
            self.setModoEdicion(False)
            # Recargar el registro actual para descartar cambios
            if self.indice_excel_actual >= 0:
                registro = self.registros_excel[self.indice_excel_actual]
                self.cargarRegistroExcelEnUI(registro)
        else:
            # Entrar en modo edición
            self.setModoEdicion(True)

    def onSalirClicked(self):
        """Maneja el click en el botón SALIR"""
        self.close()  # Esto activará closeEvent automáticamente

    #######################################################################
    ###   METODOS PARA BORRADO DE ELEMENTOS                              ###
    #######################################################################

    def verificarYPrepararEliminacion(self, numexpro, ex_num_completo):
        """
        Verifica la existencia de elementos relacionados con el expediente
        y prepara las opciones de eliminación.
        
        Args:
            numexpro: Número de expediente sin prefijo (puede ser int o str)
            ex_num_completo: Número completo con prefijo (ej: "EX-2026001")
        
        Returns:
            dict: Información sobre elementos encontrados
        """
        resultado = {
            'tiene_gpkg': False,
            'tiene_directorio': False,
            'ruta_directorio': None,
            'features_gpkg': [],
            'mensaje': ""
        }
        
        # Convertir numexpro a string si es necesario
        numexpro_str = str(numexpro)
        
        # 1. Verificar elementos en GPKG
        if self.capa_gpkg_disponible and self.capa_gpkg is not None:
            try:
                campo_idx = self.capa_gpkg.fields().indexFromName('ex_num')
                if campo_idx >= 0:
                    for feature in self.registros_gpkg:
                        feature_ex_num = feature[campo_idx]
                        if feature_ex_num and str(feature_ex_num).startswith(ex_num_completo):
                            resultado['features_gpkg'].append(feature)
                        
                        resultado['tiene_gpkg'] = len(resultado['features_gpkg']) > 0
            except Exception as e:
                print(f"Error verificando GPKG: {str(e)}")
        
        # 2. Verificar directorio
        dir_raiz = self.FichInfEXPROPIACIONESexptes
        if dir_raiz and os.path.exists(dir_raiz):
            año = numexpro_str[:4]  # Ahora numexpro_str es string
            carpetas_año_posibles = [
                f"Año_{año}", f"Año {año}", f"{año}",
                f"Expedientes_{año}", f"Expedientes {año}"
            ]
            
            for nombre in carpetas_año_posibles:
                ruta_año = os.path.join(dir_raiz, nombre)
                if os.path.exists(ruta_año) and os.path.isdir(ruta_año):
                    ruta_exacta = os.path.join(ruta_año, ex_num_completo)
                    if os.path.exists(ruta_exacta) and os.path.isdir(ruta_exacta):
                        resultado['tiene_directorio'] = True
                        resultado['ruta_directorio'] = ruta_exacta
                    else:
                        # Buscar por prefijo
                        for item in os.listdir(ruta_año):
                            ruta_item = os.path.join(ruta_año, item)
                            if os.path.isdir(ruta_item) and item.startswith(ex_num_completo):
                                resultado['tiene_directorio'] = True
                                resultado['ruta_directorio'] = ruta_item
                                break
                    break
        
        # Construir mensaje informativo
        mensaje = ""
        if resultado['tiene_gpkg']:
            mensaje += f"• {len(resultado['features_gpkg'])} elemento(s) en el GPKG\n"
        if resultado['tiene_directorio']:
            mensaje += f"• Carpeta de documentación: {os.path.basename(resultado['ruta_directorio'])}\n"
        
        resultado['mensaje'] = mensaje
        
        return resultado

    def mostrarDialogoEliminacion(self, ex_num_completo, elementos):
        """
        Muestra un diálogo personalizado para que el usuario elija qué eliminar.
        
        Returns:
            tuple: (eliminar_excel, eliminar_gpkg, renombrar_directorio)
        """
        from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QCheckBox, QDialogButtonBox, QGroupBox
        
        dialog = QDialog(self)
        dialog.setWindowTitle(f"Eliminar expediente {ex_num_completo}")
        dialog.setMinimumWidth(500)
        
        layout = QVBoxLayout()
        
        # Texto informativo
        lbl_info = QLabel(
            f"El expediente {ex_num_completo} será eliminado del Excel.\n\n"
            f"Elementos relacionados encontrados:\n{elementos['mensaje']}\n"
            f"Seleccione las acciones a realizar:"
        )
        layout.addWidget(lbl_info)
        
        # Checkbox para eliminar del Excel (siempre visible y marcado)
        chk_excel = QCheckBox("Eliminar del Excel (siempre se elimina)")
        chk_excel.setChecked(True)
        chk_excel.setEnabled(False)  # Siempre se elimina del Excel
        layout.addWidget(chk_excel)
        
        # Checkbox para eliminar del GPKG
        chk_gpkg = None
        if elementos['tiene_gpkg']:
            chk_gpkg = QCheckBox(f"Eliminar del GPKG ({len(elementos['features_gpkg'])} elemento(s))")
            chk_gpkg.setChecked(True)
            layout.addWidget(chk_gpkg)
        
        # Checkbox para renombrar directorio
        chk_dir = None
        if elementos['tiene_directorio']:
            chk_dir = QCheckBox("Renombrar carpeta de documentación (NO se borrará)")
            chk_dir.setChecked(True)
            chk_dir.setToolTip("La carpeta se renombrará como EX-aaaannn_ANTxx (no se perderán los datos)")
            layout.addWidget(chk_dir)
            
            # Etiqueta informativa
            lbl_nota = QLabel("Nota: La carpeta no se elimina, solo se renombra para mantener el historial.")
            lbl_nota.setStyleSheet("color: #666; font-size: 10px;")
            layout.addWidget(lbl_nota)
        
        # Botones
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(dialog.accept)
        button_box.rejected.connect(dialog.reject)
        layout.addWidget(button_box)
        
        dialog.setLayout(layout)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            eliminar_excel = True  # Siempre True
            eliminar_gpkg = chk_gpkg.isChecked() if chk_gpkg else False
            renombrar_directorio = chk_dir.isChecked() if chk_dir else False
            return (eliminar_excel, eliminar_gpkg, renombrar_directorio)
        else:
            return (False, False, False)

    def eliminarElementosGPKG(self, features):
        """
        Elimina los features especificados del GPKG.
        
        Args:
            features: Lista de features QgsFeature a eliminar
        
        Returns:
            bool: True si se eliminaron correctamente
        """
        if not features or not self.capa_gpkg:
            return False
        
        try:
            # Iniciar edición
            self.capa_gpkg.startEditing()
            
            # Eliminar cada feature
            ids_eliminados = []
            for feature in features:
                if self.capa_gpkg.deleteFeature(feature.id()):
                    ids_eliminados.append(feature.id())
            
            # Confirmar cambios
            if self.capa_gpkg.commitChanges():
                # Actualizar lista de registros GPKG en memoria
                self.registros_gpkg = [f for f in self.registros_gpkg if f.id() not in ids_eliminados]
                return True
            else:
                self.capa_gpkg.rollBack()
                return False
                
        except Exception as e:
            print(f"Error eliminando features del GPKG: {str(e)}")
            if self.capa_gpkg.isEditing():
                self.capa_gpkg.rollBack()
            return False

    def renombrarDirectorioExpediente(self, ruta_directorio, numexpro):
        """
        Renombra el directorio del expediente añadiendo sufijo _ANTxx
        
        Args:
            ruta_directorio: Ruta actual del directorio
            numexpro: Número de expediente (ej: "2026001")
        
        Returns:
            str: Nueva ruta del directorio o None si falló
        """
        if not os.path.exists(ruta_directorio):
            return None
        
        directorio_base = os.path.dirname(ruta_directorio)
        nombre_actual = os.path.basename(ruta_directorio)
        
        # Buscar el siguiente número disponible _ANTxx
        contador = 1
        nuevo_nombre = f"{nombre_actual}_ANT{contador:02d}"
        while os.path.exists(os.path.join(directorio_base, nuevo_nombre)):
            contador += 1
            nuevo_nombre = f"{nombre_actual}_ANT{contador:02d}"
        
        nueva_ruta = os.path.join(directorio_base, nuevo_nombre)
        
        try:
            os.rename(ruta_directorio, nueva_ruta)
            return nueva_ruta
        except Exception as e:
            print(f"Error renombrando directorio: {str(e)}")
            return None

    def onSuprimirClicked(self):
        """Elimina el registro actual del Excel y opcionalmente del GPKG y directorio"""
        # Verificar que estamos en la pestaña correcta
        if self.tabWidget.currentIndex() != 1:
            QMessageBox.warning(
                self,
                "Aviso",
                "La función 'SUPRIMIR' solo está disponible en la pestaña 'Datos BD Informes'.",
                QMessageBox.StandardButton.Ok
            )
            return

        # Verificar que hay un registro seleccionado
        if self.indice_excel_actual < 0 or not self.registros_excel:
            QMessageBox.warning(
                self,
                "Aviso",
                "No hay ningún registro seleccionado para eliminar.",
                QMessageBox.StandardButton.Ok
            )
            return

        # No permitir suprimir en modo edición o agregar
        if self.modo_edicion or self.modo_agregar:
            QMessageBox.warning(
                self,
                "Aviso",
                "No puede eliminar un registro mientras está en modo edición o agregar.\n"
                "Por favor, termine o cancele la operación actual primero.",
                QMessageBox.StandardButton.Ok
            )
            return

        # Obtener información del registro a eliminar
        registro = self.registros_excel[self.indice_excel_actual]
        numexpro = registro.get('NUMEXPRO', '')
        ex_num_completo = f"EX-{numexpro}" if numexpro else "desconocido"
        
        if not numexpro:
            QMessageBox.warning(
                self,
                "Aviso",
                "El registro no tiene un número de expediente válido.",
                QMessageBox.StandardButton.Ok
            )
            return

        # Verificar elementos relacionados
        elementos = self.verificarYPrepararEliminacion(numexpro, ex_num_completo)
        
        # Si no hay elementos relacionados, confirmación simple
        if not elementos['tiene_gpkg'] and not elementos['tiene_directorio']:
            respuesta = QMessageBox.question(
                self,
                "Confirmar eliminación",
                f"¿Está seguro de que desea eliminar el expediente {ex_num_completo} del Excel?\n\n"
                "No se encontraron elementos relacionados en GPKG ni en el sistema de archivos.\n"
                "Esta acción eliminará el registro del Excel permanentemente.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )
            if respuesta == QMessageBox.StandardButton.No:
                return
            eliminar_excel = True
            eliminar_gpkg = False
            renombrar_directorio = False
        else:
            # Mostrar diálogo personalizado con opciones
            eliminar_excel, eliminar_gpkg, renombrar_directorio = self.mostrarDialogoEliminacion(
                ex_num_completo, elementos
            )
            
            if not eliminar_excel:  # Si el usuario cancela
                return
        
        # Crear copia de seguridad antes de modificar
        if not self.crearCopiaSeguridad():
            respuesta = QMessageBox.question(
                self,
                "Confirmar",
                "No se pudo crear una copia de seguridad. ¿Desea continuar de todas formas?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )
            if respuesta == QMessageBox.StandardButton.No:
                return
        
        # Guardar el índice actual antes de eliminar
        indice_eliminado = self.indice_excel_actual
        registro_eliminado = registro.copy()  # Guardar copia por si hay que restaurar
        
        # 1. Eliminar del GPKG si se seleccionó
        gpkg_eliminado = False
        if eliminar_gpkg and elementos['tiene_gpkg']:
            if self.eliminarElementosGPKG(elementos['features_gpkg']):
                gpkg_eliminado = True
                self.iface.mainWindow().statusBar().showMessage(
                    f"Eliminados {len(elementos['features_gpkg'])} elementos del GPKG",
                    3000
                )
            else:
                QMessageBox.warning(
                    self,
                    "Advertencia",
                    "No se pudieron eliminar los elementos del GPKG.\n"
                    "Continúa con la eliminación del Excel.",
                    QMessageBox.StandardButton.Ok
                )
        
        # 2. Renombrar directorio si se seleccionó
        directorio_renombrado = None
        if renombrar_directorio and elementos['tiene_directorio']:
            nueva_ruta = self.renombrarDirectorioExpediente(elementos['ruta_directorio'], numexpro)
            if nueva_ruta:
                directorio_renombrado = nueva_ruta
                self.iface.mainWindow().statusBar().showMessage(
                    f"Carpeta renombrada a: {os.path.basename(nueva_ruta)}",
                    3000
                )
            else:
                QMessageBox.warning(
                    self,
                    "Advertencia",
                    f"No se pudo renombrar la carpeta:\n{elementos['ruta_directorio']}",
                    QMessageBox.StandardButton.Ok
                )
        
        # 3. Eliminar del Excel (siempre)
        del self.registros_excel[indice_eliminado]
        
        # Guardar los cambios en el Excel
        if self.guardarExcel():
            # Actualizar el índice actual
            if not self.registros_excel:
                # No quedan registros
                self.indice_excel_actual = -1
                self.limpiarWidgets()
                self.cbxEX_NUM.clear()
                self.cbxEX_NUM.setEditText("")
                self.btnEDITAR.setEnabled(False)
                self.btnZoomElemento.setEnabled(False)
                self.btnVER_DOCUM.setEnabled(False)

                QMessageBox.information(
                    self,
                    "Información",
                    "No quedan más registros en el Excel.",
                    QMessageBox.StandardButton.Ok
                )
            else:
                # Ajustar el índice si es necesario
                if indice_eliminado >= len(self.registros_excel):
                    self.indice_excel_actual = len(self.registros_excel) - 1
                else:
                    self.indice_excel_actual = indice_eliminado

                # Actualizar el combo y cargar el registro
                self.inicializarComboNavegacion()
                self.actualizarColorBotonZoom()

            self.actualizar_contador_registros()
            
            # Mostrar resumen de acciones realizadas
            mensaje_resumen = f"Expediente {ex_num_completo} eliminado del Excel"
            if gpkg_eliminado:
                mensaje_resumen += f" y del GPKG ({len(elementos['features_gpkg'])} elementos)"
            if directorio_renombrado:
                mensaje_resumen += f"\nCarpeta renombrada a: {os.path.basename(directorio_renombrado)}"
            
            QMessageBox.information(
                self,
                "Eliminación completada",
                mensaje_resumen,
                QMessageBox.StandardButton.Ok
            )
            
            # Mostrar mensaje en statusBar
            self.iface.mainWindow().statusBar().showMessage(
                f"Expediente {ex_num_completo} eliminado del Excel",
                5000
            )
        else:
            # Si falla guardar Excel, restaurar todo
            QMessageBox.critical(
                self,
                "Error",
                "No se pudo guardar el Excel después de eliminar el registro.\n"
                "Asegúrese de que el archivo no está abierto en otro programa.\n\n"
                "Se restaurará el estado anterior.",
                QMessageBox.StandardButton.Ok
            )
            
            # Restaurar registro en memoria
            self.registros_excel.insert(indice_eliminado, registro_eliminado)
            
            # Restaurar GPKG si se eliminó
            # Nota: No es fácil restaurar features eliminados, pero al menos mostramos advertencia
            if gpkg_eliminado:
                QMessageBox.warning(
                    self,
                    "Atención",
                    "Los elementos eliminados del GPKG NO se han restaurado.\n"
                    "Deberá recuperarlos manualmente si es necesario.",
                    QMessageBox.StandardButton.Ok
                )
            
            # Restaurar directorio si se renombró
            if directorio_renombrado and elementos['tiene_directorio']:
                try:
                    os.rename(directorio_renombrado, elementos['ruta_directorio'])
                    self.iface.mainWindow().statusBar().showMessage(
                        "Carpeta restaurada a su nombre original",
                        3000
                    )
                except:
                    pass

    def onGuardarCambiosClicked(self):
        """Guarda los cambios (edición o nuevo registro)"""
        if self.modo_agregar:
            # Guardar nuevo registro
            self.guardarNuevoRegistro()
        elif self.modo_edicion:
            # Guardar cambios en registro existente
            self.guardarCambiosRegistro()

    def onBuscarRegistroClicked(self):
        """Abre el diálogo de búsqueda de registros"""
        # Verificar que estamos en la pestaña correcta
        if self.tabWidget.currentIndex() != 1:
            QMessageBox.warning(
                self,
                "Aviso",
                "La función 'BUSCAR REGISTRO' solo está disponible en la pestaña 'Datos BD Informes'.",
                QMessageBox.StandardButton.Ok
            )
            return

        # Verificar que hay registros para buscar
        if not self.registros_excel:
            QMessageBox.warning(
                self,
                "Aviso",
                "No hay registros en el Excel para buscar.",
                QMessageBox.StandardButton.Ok
            )
            return

        # Obtener lista de campos disponibles
        campos_disponibles = list(self.df_excel.columns) if self.df_excel is not None else []

        # Crear y mostrar el diálogo de búsqueda
        buscador = herr_BBDD_BUSCADOR(self, campos_disponibles, self.historial_busquedas)

        # El diálogo se queda abierto hasta que el usuario cancela
        if buscador.exec():
            # Si el usuario cierra con BUSCAR, ya procesamos en onBusquedaRealizada
            pass

    def realizarBusqueda(self, texto_busqueda, campo_especifico=None, modo_coincidencia="Cualquier parte del campo"):
        """Realiza la búsqueda de registros según los criterios especificados"""

        # Determinar el orden de búsqueda (empezar desde el registro actual hacia el más antiguo)
        inicio = self.indice_excel_actual
        total_registros = len(self.registros_excel)

        # Crear lista de índices a buscar (desde actual+1 hasta el final, luego desde 0 hasta actual-1)
        indices_busqueda = []
        for i in range(inicio + 1, total_registros):
            indices_busqueda.append(i)
        for i in range(0, inicio):
            indices_busqueda.append(i)

        # Función para comprobar si un valor coincide con el criterio de búsqueda
        def valor_coincide(valor, texto, modo):
            if valor is None or (isinstance(valor, float) and np.isnan(valor)):
                return False

            # Convertir a string para la comparación
            valor_str = str(valor).lower()
            texto_lower = texto_busqueda.lower()

            if modo == "Cualquier parte del campo":
                return texto_lower in valor_str
            elif modo == "Hacer coincidir todo el campo":
                return valor_str == texto_lower
            elif modo == "Comienzo del campo":
                return valor_str.startswith(texto_lower)
            else:
                return False

        # Buscar el primer registro que coincida
        for idx in indices_busqueda:
            registro = self.registros_excel[idx]

            if campo_especifico and campo_especifico != "Cualquier campo":
                # Buscar en un campo específico
                if campo_especifico in registro:
                    valor = registro[campo_especifico]
                    if valor_coincide(valor, texto_busqueda, modo_coincidencia):
                        # Encontrado!
                        self.irAIndice(idx)
                        self.mostrarMensajeBusqueda(f"Registro encontrado en campo '{campo_especifico}'")
                        return
            else:
                # Buscar en todos los campos
                for campo, valor in registro.items():
                    if valor_coincide(valor, texto_busqueda, modo_coincidencia):
                        # Encontrado!
                        self.irAIndice(idx)
                        self.mostrarMensajeBusqueda(f"Registro encontrado en campo '{campo}'")
                        return

        # No se encontraron coincidencias
        self.mostrarMensajeBusqueda(f"No se encontraron más registros que coincidan con '{texto_busqueda}'")

    def cargarHistorialBusquedas(self):
        """Carga el historial de búsquedas desde QSettings"""
        historial = self.qs.value(f"{self.nombre_plugin}/last/lastBusquedas", [])
        if isinstance(historial, str):
            # Si es un string, convertirlo a lista
            historial = [historial]
        return list(historial)  # Asegurar que es lista

    def guardarHistorialBusquedas(self, historial):
        """Guarda el historial de búsquedas en QSettings"""
        self.qs.setValue(f"{self.nombre_plugin}/last/lastBusquedas", historial)

    def onBusquedaRealizada(self, params):
        """Recibe los parámetros de búsqueda del diálogo y realiza la búsqueda"""
        texto = params['texto']
        campo = params['campo']
        modo = params['modo']

        # Realizar la búsqueda
        self.realizarBusqueda(texto, campo, modo)

        # Actualizar historial si es necesario
        if texto not in self.historial_busquedas:
            self.historial_busquedas.insert(0, texto)
            self.historial_busquedas = self.historial_busquedas[:10]
            self.guardarHistorialBusquedas(self.historial_busquedas)



    def irAIndice(self, indice):
        """Navega a un índice específico"""
        if 0 <= indice < len(self.registros_excel):
            self.indice_excel_actual = indice
            self.cbxEX_NUM.blockSignals(True)
            self.cbxEX_NUM.setCurrentIndex(indice)
            self.cbxEX_NUM.setEditText(self.cbxEX_NUM.currentText())
            self.cbxEX_NUM.blockSignals(False)
            registro = self.registros_excel[indice]
            self.cargarRegistroExcelEnUI(registro)


    def mostrarMensajeBusqueda(self, mensaje):
        """Muestra un mensaje de búsqueda en la barra de estado"""
        self.iface.mainWindow().statusBar().showMessage(
            mensaje,
            3000
        )

    def guardarNuevoRegistro(self):
        """Guarda un nuevo registro en el Excel"""
        # Crear copia de seguridad antes de modificar
        if not self.crearCopiaSeguridad():
            respuesta = QMessageBox.question(
                self,
                "Confirmar",
                "No se pudo crear una copia de seguridad. ¿Desea continuar de todas formas?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )
            if respuesta == QMessageBox.StandardButton.No:
                return

        # Validar campos obligatorios
        if not self.validarObligatorios():
            QMessageBox.warning(
                self,
                "Aviso",
                "Los campos marcados en rojo son obligatorios.\n"
                "Por favor, complételos antes de guardar.",
                QMessageBox.StandardButton.Ok
            )
            return

        # Obtener el número de expediente
        numexpro_text = self.EX_NUMEXPRO.text()
        if not numexpro_text.startswith('EX-'):
            QMessageBox.warning(
                self,
                "Aviso",
                "El número de expediente no tiene el formato correcto.",
                QMessageBox.StandardButton.Ok
            )
            return

        numexpro = numexpro_text[3:]  # Quitar el prefijo EX-

        # Crear el directorio del expediente
        dir_resultado = self.crearDirectorioExpediente(numexpro)
        if not dir_resultado:
            return

        dir_expte, ex_principal = dir_resultado

        # Crear el fichero de intercambio usando functions4
        self.fun.creaFICHintercambio(dir_expte, self)

        # Obtener valores de los widgets
        valores = self.obtenerValoresWidgets()
        valores['NUMEXPRO'] = numexpro

        # Añadir el registro al DataFrame
        nuevo_registro = {}
        for campo in self.df_excel.columns:
            if campo in valores:
                nuevo_registro[campo] = valores[campo]
            else:
                nuevo_registro[campo] = None

        self.registros_excel.append(nuevo_registro)

        # Guardar en Excel
        if self.guardarExcel():
            # Actualizar la lista del combo
            self.registros_excel.sort(key=lambda x: str(x.get('NUMEXPRO', '')), reverse=True)

            # Encontrar el índice del nuevo registro
            for i, reg in enumerate(self.registros_excel):
                if reg.get('NUMEXPRO') == numexpro:
                    self.indice_excel_actual = i
                    break

            self.inicializarComboNavegacion()
            self.setModoAgregar(False)
            
            # Actualizar el color después de guardar
            self.actualizarColorBotonZoom()

            self.actualizar_contador_registros()

            QMessageBox.information(
                self,
                "Información",
                f"Expediente EX-{numexpro} creado correctamente.\n"
                f"Directorio: {dir_expte}",
                QMessageBox.StandardButton.Ok
            )

            # Mostrar mensaje en statusBar
            self.iface.mainWindow().statusBar().showMessage(
                f"Expediente EX-{numexpro} creado",
                5000
            )
        else:
            QMessageBox.critical(
                self,
                "Error",
                "No se pudo guardar el expediente en el Excel.\n"
                "Asegúrese de que el archivo no está abierto en otro programa.",
                QMessageBox.StandardButton.Ok
            )

    def guardarCambiosRegistro(self):
        """Guarda los cambios en el registro actual del Excel"""
        if not self.modo_edicion or self.indice_excel_actual < 0:
            return

        if not self.datos_modificados:
            QMessageBox.information(
                self,
                "Información",
                "No hay cambios para guardar.",
                QMessageBox.StandardButton.Ok
            )
            self.setModoEdicion(False)
            return

        # Crear copia de seguridad antes de modificar
        if not self.crearCopiaSeguridad():
            respuesta = QMessageBox.question(
                self,
                "Confirmar",
                "No se pudo crear una copia de seguridad. ¿Desea continuar de todas formas?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )
            if respuesta == QMessageBox.StandardButton.No:
                return

        # Confirmar guardado
        respuesta = QMessageBox.question(
            self,
            "Confirmar",
            "¿Desea guardar los cambios en el Excel?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if respuesta == QMessageBox.StandardButton.No:
            return

        # Obtener valores actuales de los widgets
        valores_actualizados = self.obtenerValoresWidgets()

        # Actualizar el registro en memoria
        registro_actual = self.registros_excel[self.indice_excel_actual]
        for campo, valor in valores_actualizados.items():
            if campo in registro_actual:
                registro_actual[campo] = valor

        # Guardar en el archivo Excel
        if self.guardarExcel():
            QMessageBox.information(
                self,
                "Información",
                "Cambios guardados correctamente.",
                QMessageBox.StandardButton.Ok
            )
            self.datos_modificados = False
            self.setModoEdicion(False)
            # Actualizar el color después de guardar cambios
            self.actualizarColorBotonZoom()

            # Mostrar mensaje en statusBar
            self.iface.mainWindow().statusBar().showMessage(
                f"Cambios guardados en expediente EX-{registro_actual.get('NUMEXPRO', '')}",
                3000
            )
        else:
            QMessageBox.critical(
                self,
                "Error",
                "No se pudieron guardar los cambios en el Excel.\n"
                "Asegúrese de que el archivo no está abierto en otro programa.",
                QMessageBox.StandardButton.Ok
            )

    def obtenerValoresWidgets(self):
        """Obtiene los valores actuales de los widgets para guardar"""
        valores = {}

        # Mapeo inverso de widgets a campos Excel
        mapeo_inverso = {
            self.EX_NUMEXPRO: 'NUMEXPRO',
            self.EX_REGISTRO: 'REGISTRO',
            self.EX_FECHA: 'FECHA',
            self.EX_SOLICITANTE: 'SOLICITANTE',
            self.EX_INTERESADO: 'INTERESADO',
            self.EX_DNI: 'DNI',
            self.EX_NOMBRE: 'NOMBRE',
            self.EX_TLFNO: 'TLFNO',
            self.EX_CARRETERA: 'CARRETERA',
            self.EX_KILOMETRO: 'KILOMETRO',
            self.EX_KILOMET2: 'KILOMET2',
            self.EX_MARGEN: 'MARGEN',
            self.EX_OBSERVAPK: 'OBSERVAPK',
            self.EX_TIPO: 'TIPO',
            self.EX_INGENIERO: 'INGENIERO',
            self.EX_ESTAARCHIVADO: 'ESTAARCHIVADO',
            self.EX_FECHAARCHIVO: 'FECHAARCHIVO',
            self.EX_EXPTE_EXPROPIACION: 'EXPTE_EXPROPIACION',
            self.EX_EXPTES_RELACIONADOS: 'EXPTES_RELACIONADOS',
            self.EX_NOMBRE_TRAMO: 'NOMBRE_TRAMO',
            self.EX_DECR_ACUERDO_RESOLUCION: 'DECR_ACUERDO_RESOLUCION',
            self.EX_ACTAS_PREVIAS: 'ACTAS_PREVIAS',
            self.EX_REMISION_CATASTRAL: 'REMISION_CATASTRAL',
            self.EX_NUMORDEN: 'NUMORDEN',
            self.EX_POLIGONO: 'POLIGONO',
            self.EX_PARCELAS: 'PARCELAS',
            self.EX_TM: 'TM',
            self.EX_TIPO_EXPEDIENTE: 'TIPO_EXPEDIENTE',
            self.EX_TITULO_EXPROPIACION: 'TITULO_EXPROPIACION',
            self.EX_REF_CATASTRAL: 'REF_CATASTRAL',
            self.EX_FECHA_ULTIMO_TRAMITE: 'FECHA_ULTIMO_TRAMITE',
            self.EX_TRAMITE_EXPROPIACION: 'TRAMITE_EXPROPIACION',
            self.EX_CORREOELEC: 'CORREOELEC',
            self.EX_PROTOCOLO_REGISTRO: 'PROTOCOLO_REGISTRO',
            self.EX_ART_LEY: 'ART_LEY'
        }

        for widget, campo in mapeo_inverso.items():
            if campo == 'NUMEXPRO':
                # Quitar el prefijo EX- para guardar solo los dígitos
                texto = widget.text()
                if texto.startswith('EX-'):
                    valores[campo] = texto[3:]
                else:
                    # Si no tiene prefijo, guardar tal cual (por si acaso)
                    valores[campo] = texto
            elif campo == 'ESTAARCHIVADO':
                valores[campo] = 'SI' if widget.isChecked() else 'NO'
            elif campo in ['FECHA', 'FECHAARCHIVO', 'FECHA_ULTIMO_TRAMITE']:
                # Solo guardar si la fecha es válida (no es la fecha especial de año 1)
                fecha = widget.date()
                if fecha.isValid():
                    valores[campo] = fecha.toString('dd/MM/yyyy')
                else:
                    valores[campo] = None  # Fecha vacía

            elif isinstance(widget, QComboBox):
                valores[campo] = widget.currentText()
            elif isinstance(widget, QTextEdit):
                valores[campo] = widget.toPlainText()
            elif isinstance(widget, QLineEdit):
                valores[campo] = widget.text()

        return valores

    def guardarExcel(self):
        """Guarda los cambios en el archivo Excel"""
        try:
            # Crear un nuevo DataFrame con los datos actualizados
            df_actualizado = pd.DataFrame(self.registros_excel)

            # Guardar usando pandas
            df_actualizado.to_excel(self.ExcelInfEXPRO, index=False)
            return True

        except Exception as e:
            # print(f"Error guardando Excel: {str(e)}")
            return False

    def obtenerDatosExpedienteExpropiacion(self, expte_numero):
        """
        Obtiene los datos de un expediente de expropiación específico desde la tabla GPKG.
        expte_numero es el valor de EXPTE_EXPROPIACION
        """
        if self.df_expro_table is None:
            return None

        # Verificar que existe el campo 'EXPTE_EXPROPIACION'
        if 'EXPTE_EXPROPIACION' not in self.df_expro_table.columns:
            # print("ERROR: No se encuentra el campo 'EXPTE_EXPROPIACION' en la tabla")
            return None

        try:
            # Buscar por EXPTE_EXPROPIACION
            mascara = self.df_expro_table['EXPTE_EXPROPIACION'].astype(str).str.strip() == expte_numero
            registros = self.df_expro_table[mascara]

            if len(registros) == 0:
                return None

            # Tomar el primer registro
            registro = registros.iloc[0].to_dict()

            # Convertir valores NaN a None
            for key, value in registro.items():
                if pd.isna(value):
                    registro[key] = None

            return registro

        except Exception as e:
            # print(f"Error buscando expediente {expte_numero}: {str(e)}")
            return None

    def onAgregarClicked(self):
        """Agrega un nuevo expediente manualmente"""
        # Verificar que estamos en la pestaña correcta
        if self.tabWidget.currentIndex() != 1:
            QMessageBox.warning(
                self,
                "Aviso",
                "La función 'AGREGAR' solo está disponible en la pestaña 'Datos BD Informes'.",
                QMessageBox.StandardButton.Ok
            )
            return

        if self.modo_agregar:
            # Cancelar modo agregar
            respuesta = QMessageBox.question(
                self,
                "Confirmar",
                "¿Está seguro de que desea cancelar la creación del nuevo expediente?\n"
                "Se perderán los datos introducidos.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if respuesta == QMessageBox.StandardButton.Yes:
                self.setModoAgregar(False)
                # Recargar el registro actual
                if self.indice_excel_actual >= 0:
                    registro = self.registros_excel[self.indice_excel_actual]
                    self.cargarRegistroExcelEnUI(registro)
                # if self.indice_excel_actual >= 0:
                    # self.cargarRegistroExcelEnUI()
        else:
            # Entrar en modo agregar
            # Verificar que tenemos datos para crear el expediente
            numexpro = self.obtenerSiguienteNumeroExpediente()
            if not numexpro:
                return

            self.setModoAgregar(True)

    def setModoAgregar(self, activar):
        """Activa o desactiva el modo agregar"""
        self.modo_agregar = activar

        if activar:
            # Desactivar modo edición si estaba activo
            if self.modo_edicion:
                self.setModoEdicion(False)

            # Deshabilitar combo de navegación
            self.cbxEX_NUM.setEnabled(False)

            # OCULTAR checkbox de pendientes
            self.cbxPENDIENTES.setVisible(False)

            # INUTILIZAR botones que no tienen sentido en modo agregar
            self.btnZoomElemento.setEnabled(False)
            self.btnBuscarREGISTRO.setEnabled(False)
            self.btnVER_DOCUM.setEnabled(False)
            self.btnAbreExcel.setEnabled(False)

            # Limpiar todos los widgets
            self.limpiarWidgets()

            # Establecer valores por defecto
            self.establecerValoresPorDefecto()

            # Hacer todos los widgets editables
            for widget in self.widgets_editables:
                if isinstance(widget, QLineEdit):
                    widget.setReadOnly(False)
                    widget.setEnabled(True)
                elif isinstance(widget, QComboBox):
                    widget.setEnabled(True)
                    widget.setEditable(True)
                    widget.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
                elif isinstance(widget, QTextEdit):
                    widget.setReadOnly(False)
                    widget.setEnabled(True)
                elif isinstance(widget, QDateEdit):
                    widget.setReadOnly(False)
                    widget.setEnabled(True)
                elif isinstance(widget, QCheckBox):
                    widget.setEnabled(True)

            # Marcar campos obligatorios
            self.marcarObligatorios()

            # Cambiar texto del botón
            self.btnAGREGAR.setText("CANCELAR")
            self.btnEDITAR.setEnabled(False)
            self.btnGUARDARCAMBIOS.setVisible(True)
            self.btnGUARDARCAMBIOS.setEnabled(True)
            self.btnGUARDARCAMBIOS.setText("GUARDAR NUEVO")

        else:
            # Restaurar estado normal
            self.desmarcarObligatorios()
            self.btnAGREGAR.setText("AGREGAR")
            self.btnEDITAR.setEnabled(True)
            self.btnGUARDARCAMBIOS.setVisible(False)
            self.btnGUARDARCAMBIOS.setEnabled(False)
            self.btnGUARDARCAMBIOS.setText("GUARDAR CAMBIOS")

            # Reactivar navegación
            self.cbxEX_NUM.setEnabled(True)
            self.cbxEX_NUM.setEditable(True)

            # MOSTRAR checkbox de pendientes
            self.cbxPENDIENTES.setVisible(True)
            self.cbxPENDIENTES.setEnabled(True)

            # REACTIVAR botones (solo si hay GPKG disponible para algunos)
            self.btnBuscarREGISTRO.setEnabled(True)
            self.btnVER_DOCUM.setEnabled(True)
            self.btnAbreExcel.setEnabled(True)

            # El botón de zoom solo si hay GPKG disponible
            self.btnZoomElemento.setEnabled(self.capa_gpkg_disponible)

            self.actualizar_contador_registros()

    def obtenerSiguienteNumeroExpediente(self):
        """Obtiene el siguiente número de expediente disponible"""
        dir_raiz = self.FichInfEXPROPIACIONESexptes

        if not dir_raiz or not os.path.exists(dir_raiz):
            QMessageBox.critical(
                self,
                "Error",
                f"No se encuentra el directorio raíz de documentación:\n{dir_raiz}",
                QMessageBox.StandardButton.Ok
            )
            return None

        current_year = dt.now().year

        # Buscar el año actual en los subdirectorios
        año_dir = None
        for nombre in os.listdir(dir_raiz):
            ruta = os.path.join(dir_raiz, nombre)
            if os.path.isdir(ruta):
                if nombre == f"Año_{current_year}":
                    año_dir = ruta
                    break
                elif nombre == f"Año {current_year}":
                    año_dir = ruta
                    break
                elif nombre == str(current_year):
                    año_dir = ruta
                    break

        # Si no existe el directorio del año actual, preguntar si crearlo
        if not año_dir:
            respuesta = QMessageBox.question(
                self,
                "Crear directorio",
                f"No existe el directorio para el año {current_year}.\n"
                "¿Desea crearlo?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if respuesta == QMessageBox.StandardButton.No:
                return None

            año_dir = os.path.join(dir_raiz, f"Año_{current_year}")
            try:
                os.makedirs(año_dir)
            except Exception as e:
                QMessageBox.critical(
                    self,
                    "Error",
                    f"No se pudo crear el directorio:\n{año_dir}\n\nError: {str(e)}",
                    QMessageBox.StandardButton.Ok
                )
                return None

        # Buscar el último expediente del año en el Excel
        max_num = 0
        for registro in self.registros_excel:
            numexpro = registro.get('NUMEXPRO', '')
            if numexpro and str(numexpro).startswith(str(current_year)):
                try:
                    num = int(str(numexpro)[4:])  # 2026001 -> 001 -> 1
                    if num > max_num:
                        max_num = num
                except:
                    pass

        # También buscar en el sistema de archivos por si acaso
        for item in os.listdir(año_dir):
            ruta_item = os.path.join(año_dir, item)
            if os.path.isdir(ruta_item) and item.startswith(f"EX-{current_year}"):
                try:
                    num = int(item[7:])  # EX-2025001 -> 001 -> 1
                    if num > max_num:
                        max_num = num
                except:
                    pass

        siguiente = max_num + 1
        numexpro = f"{current_year}{siguiente:03d}"

        return numexpro

    def obtener_ultima_copia_seguridad(self):
        """
        Busca la copia de seguridad más reciente en la carpeta COPIA_SEGURIDAD.
        Versión mejorada con más flexibilidad en la búsqueda.
        Returns:
            str: Ruta de la copia más reciente o None si no hay
        """

        if not os.path.exists(self.ExcelInfEXPRO):
            # print(f"ADVERTENCIA: El Excel original no existe: {self.ExcelInfEXPRO}")
            # Aún así, buscamos backups por si acaso
            pass
        else:
            # print(f"Buscando backups para: {self.ExcelInfEXPRO}")
            pass

        directorio_original = os.path.dirname(self.ExcelInfEXPRO)
        dir_backup = os.path.join(directorio_original, "COPIA_SEGURIDAD")

        if not os.path.exists(dir_backup):
            return None

        nombre_base = os.path.basename(self.ExcelInfEXPRO)
        nombre_sin_ext, extension = os.path.splitext(nombre_base)


        # MÉTODO 1: Usar glob para una búsqueda más flexible
        patron_glob = f"{nombre_sin_ext}_BAK_*{extension}"
        ruta_patron = os.path.join(dir_backup, patron_glob)
        backups_glob = glob.glob(ruta_patron)

        # for b in backups_glob:
            # print(f"  - {os.path.basename(b)}")

        # MÉTODO 2: Usar regex más flexible (por si glob no es suficiente)
        # Este patrón es más tolerante: permite cualquier cosa entre el nombre base y _BAK_
        # y entre _BAK_ y la extensión
        patron_flexible = re.compile(
            rf".*{re.escape(nombre_sin_ext)}.*_BAK_.*{re.escape(extension)}$",
            re.IGNORECASE
        )

        backups = []
        for archivo in os.listdir(dir_backup):
            ruta_completa = os.path.join(dir_backup, archivo)
            if os.path.isfile(ruta_completa):
                # Usar el patrón flexible para la comprobación
                if patron_flexible.match(archivo):
                    # print(f"  ✓ Coincide: {archivo}")
                    backups.append((ruta_completa, os.path.getmtime(ruta_completa)))
                else:
                    # Para depuración, mostrar archivos que NO coinciden
                    if 'BAK' in archivo:
                        # print(f"  ✗ No coincide (pero tiene BAK): {archivo}")
                        pass

        if not backups:
            return None

        # Ordenar por fecha de modificación (más reciente primero)
        backups.sort(key=lambda x: x[1], reverse=True)

        backup_reciente = backups[0][0]
        fecha_backup = dt.fromtimestamp(backups[0][1])

        return backup_reciente

    def restaurar_copia_seguridad(self, ruta_backup):
        """
        Restaura una copia de seguridad al archivo Excel original.

        Args:
            ruta_backup: Ruta de la copia de seguridad a restaurar
        Returns:
            bool: True si la restauración fue exitosa
        """
        try:
            # Verificar que el backup existe
            if not os.path.exists(ruta_backup):
                QMessageBox.critical(
                    self,
                    "Error - Restauración",
                    f"El archivo de backup no existe:\n{ruta_backup}",
                    QMessageBox.StandardButton.Ok
                )
                return False

            # Verificar que el backup no está vacío
            if os.path.getsize(ruta_backup) == 0:
                QMessageBox.critical(
                    self,
                    "Error - Restauración",
                    "El archivo de backup está vacío.",
                    QMessageBox.StandardButton.Ok
                )
                return False

            # Hacer una copia del Excel dañado si existe (por si acaso)
            if os.path.exists(self.ExcelInfEXPRO):
                timestamp = dt.now().strftime("%Y%m%d_%H%M%S")
                ruta_danado = self.ExcelInfEXPRO + f".DANADO_{timestamp}"
                shutil.copy2(self.ExcelInfEXPRO, ruta_danado)

            # Verificar que el archivo original no está siendo usado
            try:
                # Intentar abrir en modo escritura para ver si está bloqueado
                with open(self.ExcelInfEXPRO, 'ab') as f:
                    pass
            except PermissionError:
                QMessageBox.critical(
                    self,
                    "Error - Restauración",
                    "No se puede restaurar porque el archivo Excel está abierto.\n"
                    "Por favor, ciérrelo e intente de nuevo.",
                    QMessageBox.StandardButton.Ok
                )
                return False

            # Restaurar la copia de seguridad
            shutil.copy2(ruta_backup, self.ExcelInfEXPRO)

            # Mensaje en barra de estado
            self.iface.mainWindow().statusBar().showMessage(
                f"Restaurada copia de seguridad: {os.path.basename(ruta_backup)}",
                5000
            )

            return True

        except Exception as e:
            traceback.print_exc()
            QMessageBox.critical(
                self,
                "Error - Restauración",
                f"No se pudo restaurar la copia de seguridad:\n{str(e)}\n\n"
                "Verifique que el archivo Excel no está abierto en otro programa.",
                QMessageBox.StandardButton.Ok
            )
            return False

    def excel_esta_vacio(self):
        """
        Comprueba si el Excel existe pero está vacío (solo cabeceras o sin datos).
        Returns:
            bool: True si está vacío o solo tiene cabeceras
        """
        try:
            df = pd.read_excel(self.ExcelInfEXPRO)
            # Consideramos vacío si no tiene filas o solo tiene la fila de cabeceras
            return len(df) == 0
        except Exception as e:
            # print(f"Error comprobando si Excel está vacío: {e}")
            return False


    def crearDirectorioExpediente(self, numexpro):
        """Crea el directorio para el expediente"""
        dir_raiz = self.FichInfEXPROPIACIONESexptes
        año = numexpro[:4]
        ex_principal = f"EX-{numexpro}"

        # Buscar carpeta del año
        carpetas_año_posibles = [
            f"Año_{año}",
            f"Año {año}",
            f"{año}",
            f"Expedientes_{año}",
            f"Expedientes {año}"
        ]

        carpeta_año = None
        for nombre in carpetas_año_posibles:
            ruta_año = os.path.join(dir_raiz, nombre)
            if os.path.exists(ruta_año) and os.path.isdir(ruta_año):
                carpeta_año = ruta_año
                break

        if not carpeta_año:
            QMessageBox.critical(
                self,
                "Error",
                f"No se encuentra la carpeta del año {año} en:\n{dir_raiz}",
                QMessageBox.StandardButton.Ok
            )
            return None

        dir_expte = os.path.join(carpeta_año, ex_principal)

        try:
            os.makedirs(dir_expte, exist_ok=True)
            return dir_expte, ex_principal
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"No se pudo crear el directorio:\n{dir_expte}\n\nError: {str(e)}",
                QMessageBox.StandardButton.Ok
            )
            return None

    def abrirExplorador(self, ruta):
        """Abre el explorador de archivos en la ruta especificada"""
        try:
            if sys.platform == 'win32':
                os.startfile(ruta)
            elif sys.platform == 'darwin':
                subprocess.run(['open', ruta])
            else:
                subprocess.run(['xdg-open', ruta])

            # Mostrar mensaje en statusBar en lugar de lbGDBinformes
            self.iface.mainWindow().statusBar().showMessage(
                f"Abriendo carpeta: {ruta}",
                5000
            )

        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"No se pudo abrir la carpeta:\n{ruta}\n\nError: {str(e)}",
                QMessageBox.StandardButton.Ok
            )

    #######################################################################
    ###   METODO PARA ABRIR LA CARPETA DE LOS DOCUMENTOS                ###
    #######################################################################

    def onVerDocumClicked(self):
        """Abre el explorador de archivos en la carpeta de documentación del expediente"""
        ex_num = self.EX_NUMEXPRO.text()

        if not ex_num:
            QMessageBox.warning(
                self,
                "Aviso",
                "No hay un expediente seleccionado.",
                QMessageBox.StandardButton.Ok
            )
            return

        # Validar formato EX-aaaannn
        patron = r'^EX-(\d{7})$'
        match = re.match(patron, ex_num)
        if not match:
            QMessageBox.warning(
                self,
                "Aviso",
                f"El expediente '{ex_num}' no tiene el formato esperado (EX-aaaannn).\n\n"
                "No se puede determinar la carpeta de documentación.",
                QMessageBox.StandardButton.Ok
            )
            return

        numexpro = match.group(1)
        ex_principal = f"EX-{numexpro}"

        # Obtener el directorio raíz de documentación
        dir_raiz = self.FichInfEXPROPIACIONESexptes

        if not dir_raiz or not os.path.exists(dir_raiz):
            QMessageBox.critical(
                self,
                "Error",
                f"No se encuentra el directorio raíz de documentación:\n{dir_raiz}",
                QMessageBox.StandardButton.Ok
            )
            return

        # Extraer el año del expediente
        año = numexpro[:4]

        # Buscar carpeta del año
        carpetas_año_posibles = [
            f"Año_{año}",
            f"Año {año}",
            f"{año}",
            f"Expedientes_{año}",
            f"Expedientes {año}"
        ]

        carpeta_año = None
        for nombre in carpetas_año_posibles:
            ruta_año = os.path.join(dir_raiz, nombre)
            if os.path.exists(ruta_año) and os.path.isdir(ruta_año):
                carpeta_año = ruta_año
                break

        if not carpeta_año:
            QMessageBox.warning(
                self,
                "Aviso",
                f"No se encuentra la carpeta del año {año} en:\n{dir_raiz}",
                QMessageBox.StandardButton.Ok
            )
            return

        # Buscar carpeta del expediente
        carpeta_expediente = None
        ruta_exacta = os.path.join(carpeta_año, ex_principal)

        # print(f"Buscando carpeta: {ruta_exacta}")

        if os.path.exists(ruta_exacta) and os.path.isdir(ruta_exacta):
            carpeta_expediente = ruta_exacta
        else:
            try:
                for item in os.listdir(carpeta_año):
                    ruta_item = os.path.join(carpeta_año, item)
                    if os.path.isdir(ruta_item) and item.startswith(ex_principal):
                        carpeta_expediente = ruta_item
                        # print(f"Encontrada carpeta por prefijo: {ruta_item}")
                        break
            except (PermissionError, OSError) as e:
                QMessageBox.critical(
                    self,
                    "Error",
                    f"No se puede acceder al directorio:\n{carpeta_año}\n\nError: {str(e)}",
                    QMessageBox.StandardButton.Ok
                )
                return

        if not carpeta_expediente:
            QMessageBox.warning(
                self,
                "Aviso",
                f"No se encuentra la carpeta del expediente '{ex_principal}' en:\n{carpeta_año}",
                QMessageBox.StandardButton.Ok
            )
            return

        # Abrir la carpeta en el explorador de archivos
        self.abrirExplorador(carpeta_expediente)


    #######################################################################
    ###   METODO PARA HACER ZOOM A LOS FEATURES DEL GPKG                ###
    #######################################################################

    def onZoomElementoClicked(self):
        """Hace zoom a todos los features del GPKG que empiezan como el EX-aaaannn del excel"""
        if not self.capa_gpkg_disponible:
            QMessageBox.warning(
                self,
                "Aviso",
                "No hay capa GPKG disponible para hacer zoom.",
                QMessageBox.StandardButton.Ok
            )
            return

        ex_num = self.EX_NUMEXPRO.text()
        if not ex_num:
            QMessageBox.warning(
                self,
                "Aviso",
                "No hay un expediente seleccionado.",
                QMessageBox.StandardButton.Ok
            )
            return

        # Obtener el prefijo EX-aaaannn
        patron = r'^(EX-\d{7})'
        match = re.match(patron, ex_num)
        if not match:
            QMessageBox.warning(
                self,
                "Aviso",
                f"El expediente '{ex_num}' no tiene el formato esperado (EX-aaaannn).",
                QMessageBox.StandardButton.Ok
            )
            return

        prefijo = match.group(1)

        # Buscar features que comiencen con ese prefijo
        features_coincidentes = []
        for feature in self.registros_gpkg:
            feature_ex_num = feature['ex_num']
            if feature_ex_num and str(feature_ex_num).startswith(prefijo):
                features_coincidentes.append(feature)

        if not features_coincidentes:
            QMessageBox.warning(
                self,
                "Aviso",
                f"No se encontraron features en el GPKG que comiencen con '{prefijo}'. Para continuar debe existir una capa con geometrías en el TOC con el nombre de variable {self.layerINFEXPnom}.",
                QMessageBox.StandardButton.Ok
            )
            return

        # Hacer zoom al conjunto de features
        self.zoomAFeatures(features_coincidentes)

    def zoomAFeatures(self, features):
        """Hace zoom a un conjunto de features"""
        if not features:
            return

        # Combinar todas las geometrías
        geom_combinada = None
        for feature in features:
            if feature.hasGeometry() and not feature.geometry().isEmpty():
                if geom_combinada is None:
                    geom_combinada = feature.geometry()
                else:
                    geom_combinada = geom_combinada.combine(feature.geometry())

        if geom_combinada is None or geom_combinada.isEmpty():
            QMessageBox.warning(
                self,
                "Aviso",
                "Ninguno de los features tiene geometría válida.",
                QMessageBox.StandardButton.Ok
            )
            return

        rect = geom_combinada.boundingBox()

        margen_x = rect.width() * 0.1
        margen_y = rect.height() * 0.1

        if rect.width() == 0:
            margen_x = 50
        if rect.height() == 0:
            margen_y = 50

        rect_ampliado = QgsRectangle(
            rect.xMinimum() - margen_x,
            rect.yMinimum() - margen_y,
            rect.xMaximum() + margen_x,
            rect.yMaximum() + margen_y
        )

        canvas = self.iface.mapCanvas()
        crs_capa = self.capa_gpkg.crs()
        crs_canvas = canvas.mapSettings().destinationCrs()

        if crs_capa != crs_canvas:
            transform = QgsCoordinateTransform(crs_capa, crs_canvas, QgsProject.instance())
            rect_ampliado = transform.transform(rect_ampliado)

        canvas.setExtent(rect_ampliado)
        canvas.refresh()

        self.capa_gpkg.removeSelection()
        ids = [f.id() for f in features]
        self.capa_gpkg.selectByIds(ids)

        # Mostrar mensaje en statusBar
        self.iface.mainWindow().statusBar().showMessage(
            f"Zoom realizado a {len(features)} features con prefijo {self.EX_NUMEXPRO.text()[:10]}",
            3000
        )

    def verificarYColorearBotonZoom(self, prefijo_expediente=None):
        """
        Verifica si existen features en el GPKG que comiencen con el prefijo del expediente actual
        y colorea el botón btnZoomElemento según el resultado.
        """
        # Verificar que la capa GPKG está disponible
        if not self.capa_gpkg_disponible or self.capa_gpkg is None:
            self.btnZoomElemento.setStyleSheet("""
                QPushButton {background-color: #f0f0f0; border: 1px solid #c0c0c0; border-radius: 3px; padding: 5px;}
                QPushButton:hover {background-color: #e0e0e0;}
            """)
            return False
        
        # Obtener el prefijo del expediente si no se proporcionó
        if prefijo_expediente is None:
            ex_num = self.EX_NUMEXPRO.text()
            if not ex_num:
                self.btnZoomElemento.setStyleSheet("""
                    QPushButton {background-color: #f0f0f0; border: 1px solid #c0c0c0; border-radius: 3px; padding: 5px;}
                    QPushButton:hover {background-color: #e0e0e0;}
                """)
                return False
            
            # Validar formato EX-aaaannn
            patron = r'^(EX-\d{7})'
            match = re.match(patron, ex_num)
            if not match:
                self.btnZoomElemento.setStyleSheet("""
                    QPushButton {background-color: #f0f0f0; border: 1px solid #c0c0c0; border-radius: 3px; padding: 5px;}
                    QPushButton:hover {background-color: #e0e0e0;}
                """)
                return False
            
            prefijo_expediente = match.group(1)
        
        # Buscar features que comiencen con ese prefijo
        try:
            # Verificar que tenemos registros GPKG cargados
            if not hasattr(self, 'registros_gpkg') or not self.registros_gpkg:
                self.cargarRegistrosGPKG()
                if not self.registros_gpkg:
                    self.btnZoomElemento.setStyleSheet("""
                        QPushButton {background-color: #f0f0f0; border: 1px solid #c0c0c0; border-radius: 3px; padding: 5px;}
                        QPushButton:hover {background-color: #e0e0e0;}
                    """)
                    return False
            
            # Contar features que coinciden
            features_coincidentes = []
            
            # Obtener el índice del campo 'ex_num' (mejor que acceder por nombre cada vez)
            campo_idx = self.capa_gpkg.fields().indexFromName('ex_num')
            
            for feature in self.registros_gpkg:
                # Acceder correctamente al valor del campo usando el índice
                # feature[campo_idx] es la forma correcta de acceder
                feature_ex_num = feature[campo_idx] if campo_idx >= 0 else None
                
                if feature_ex_num and str(feature_ex_num).startswith(prefijo_expediente):
                    features_coincidentes.append(feature)
            
            existe_feature = len(features_coincidentes) > 0
            
            # Colorear según el resultado
            if existe_feature:
                # VERDE PÁLIDO - existen features
                self.btnZoomElemento.setStyleSheet("""
                    QPushButton {background-color: #ccffcc; border: 1px solid #66cc66; border-radius: 3px; padding: 5px;}
                    QPushButton:hover {background-color: #99ff99; border: 1px solid #33cc33;}
                    QPushButton:pressed {background-color: #66ff66;}
                """)
                self.btnZoomElemento.setToolTip(f"Hacer zoom a {len(features_coincidentes)} feature(s) con prefijo {prefijo_expediente}")
            else:
                # ROJO PÁLIDO - no existen features
                self.btnZoomElemento.setStyleSheet("""
                    QPushButton {background-color: #ffcccc; border: 1px solid #ff6666; border-radius: 3px; padding: 5px;}
                    QPushButton:hover {background-color: #ff9999; border: 1px solid #ff3333;}
                    QPushButton:pressed {background-color: #ff6666;}
                """)
                self.btnZoomElemento.setToolTip(f"No se encontraron features con prefijo {prefijo_expediente} en el GPKG")
            
            return existe_feature
            
        except Exception as e:
            print(f"Error en verificarYColorearBotonZoom: {str(e)}")
            traceback.print_exc()
            self.btnZoomElemento.setStyleSheet("""
                QPushButton {background-color: #f0f0f0; border: 1px solid #c0c0c0; border-radius: 3px; padding: 5px;}
                QPushButton:hover {background-color: #e0e0e0;}
            """)
            return False


    def actualizarColorBotonZoom(self):
        """
        Método auxiliar para actualizar el color del botón zoom 
        basado en el expediente actualmente seleccionado
        """
        if self.modo_agregar:
            # En modo agregar, poner color neutral
            self.btnZoomElemento.setStyleSheet("""
                QPushButton {background-color: #f0f0f0; border: 1px solid #c0c0c0; border-radius: 3px; padding: 5px;}
                QPushButton:hover {background-color: #e0e0e0;}
            """)
            return
        
        # Verificar y colorear según el expediente actual
        self.verificarYColorearBotonZoom()

    #######################################################################
    ###   METODOS PARA ABRIR EL EXCEL                                   ###
    #######################################################################

    def onAbrirExcelClicked(self):
        """Abre el archivo Excel en la aplicación predeterminada"""
        if not os.path.exists(self.ExcelInfEXPRO):
            QMessageBox.critical(
                self,
                "Error",
                f"No se encuentra el archivo Excel:\n{self.ExcelInfEXPRO}",
                QMessageBox.StandardButton.Ok
            )
            return

        try:
            if sys.platform == 'win32':
                os.startfile(self.ExcelInfEXPRO)
            elif sys.platform == 'darwin':
                subprocess.run(['open', self.ExcelInfEXPRO])
            else:
                subprocess.run(['xdg-open', self.ExcelInfEXPRO])

            # Mostrar mensaje en statusBar
            self.iface.mainWindow().statusBar().showMessage(
                f"Abriendo archivo Excel: {os.path.basename(self.ExcelInfEXPRO)}",
                3000
            )
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"No se pudo abrir el archivo Excel:\n{self.ExcelInfEXPRO}\n\nError: {str(e)}",
                QMessageBox.StandardButton.Ok
            )

    def onExpedienteExpropiacionChanged(self, texto):
        """
        Cuando se selecciona un expediente de expropiación (valor de EXPTE_EXPROPIACION),
        se cargan automáticamente los campos relacionados en los widgets.
        """
        if not texto or texto == "s/d":
            return

        # Solo en modo agregar o edición
        if self.modo_agregar or self.modo_edicion:
            datos = self.obtenerDatosExpedienteExpropiacion(texto)

            if datos:
                # Mapeo de campos
                mapeo = {
                    'EX_TITULO_EXPROPIACION': 'TITULO_EXPROPIACION',
                    'EX_NOMBRE_TRAMO': 'NOMBRE TRAMO',
                    'EX_ACTAS_PREVIAS': 'ACTAS PREVIAS',
                    'EX_DECR_ACUERDO_RESOLUCION': 'DECR_ACUE_RESO',
                    'EX_REMISION_CATASTRAL': 'REMISION_CATASTRAL',
                    'EX_CARRETERA': 'CTRA',
                    'EX_KILOMETRO': 'P K INI',
                    'EX_KILOMET2': 'P K FIN',
                    'EX_TM': 'TERMINO_MUNICIPAL'
                }

                for widget_name, campo_tabla in mapeo.items():
                    widget = getattr(self, widget_name)
                    if campo_tabla in datos and datos[campo_tabla]:
                        widget.setText(str(datos[campo_tabla]))
                    else:
                        widget.setText("")

                # EX_EXPTES_RELACIONADOS se deja vacío
                self.EX_EXPTES_RELACIONADOS.setText("")

                self.iface.mainWindow().statusBar().showMessage(
                    f"Datos del expediente de expropiación {texto} cargados",
                    3000
                )
            else:
                # Limpiar campos si no se encuentra
                self.EX_TITULO_EXPROPIACION.clear()
                self.EX_NOMBRE_TRAMO.clear()
                self.EX_EXPTES_RELACIONADOS.clear()
                self.EX_ACTAS_PREVIAS.clear()
                self.EX_DECR_ACUERDO_RESOLUCION.clear()
                self.EX_REMISION_CATASTRAL.clear()
                self.EX_CARRETERA.clear()
                self.EX_KILOMETRO.clear()
                self.EX_KILOMET2.clear()
                self.EX_TM.clear()


    #######################################################################
    ###   METODOS de Filtro para EXPEDIENTES PENDIENTES                 ###
    #######################################################################

    def onPendientesClicked(self, estado):
        """Maneja el cambio de estado del checkbox de pendientes"""
        self.filtro_pendientes = self.cbxPENDIENTES.isChecked()

        # Actualizar el filtro
        self.aplicarFiltroPendientes()

        # Reinicializar navegación con los registros filtrados
        self.actualizarNavegacionFiltrada()
        self.actualizar_contador_registros()
        # Actualizar el color después del cambio de filtro
        self.actualizarColorBotonZoom()

        # Mostrar mensaje informativo
        if self.filtro_pendientes:
            self.iface.mainWindow().statusBar().showMessage(
                f"Mostrando solo expedientes pendientes ({len(self.registros_filtrados)} registros)",
                3000
            )
        else:
            self.iface.mainWindow().statusBar().showMessage(
                f"Mostrando todos los expedientes ({len(self.registros_excel)} registros)",
                3000
            )

    def aplicarFiltroPendientes(self):
        """Aplica el filtro de pendientes a los registros"""
        self.registros_filtrados = []

        if not self.filtro_pendientes:
            # Si no hay filtro, todos los registros son válidos
            self.registros_filtrados = list(range(len(self.registros_excel)))
            return

        # Aplicar filtro: ESTAARCHIVADO debe ser False, vacío, 0, etc.
        for i, registro in enumerate(self.registros_excel):
            valor_archivado = registro.get('ESTAARCHIVADO', None)

            # Consideramos pendiente si:
            # - Es None (vacío)
            # - Es NaN
            # - Es 0, "0", "NO", "FALSE", "FALSO", etc.
            if self.esPendiente(valor_archivado):
                self.registros_filtrados.append(i)

    def esPendiente(self, valor):
        """Determina si un valor de ESTAARCHIVADO indica pendiente (no archivado)"""
        if valor is None:
            return True

        if isinstance(valor, float) and np.isnan(valor):
            return True

        if isinstance(valor, bool):
            return not valor  # False significa pendiente

        if isinstance(valor, (int, float)):
            return valor == 0  # 0 significa pendiente

        if isinstance(valor, str):
            valor_str = valor.strip().upper()
            # Valores que indican NO archivado (pendiente)
            return valor_str in ["", "0", "NO", "FALSE", "FALSO", "N", "PENDIENTE"]

        return False  # Por defecto, considerar archivado

    def actualizarNavegacionFiltrada(self):
        """Actualiza la navegación según el filtro actual"""
        if not self.registros_excel:
            self.cbxEX_NUM.clear()
            self.cbxEX_NUM.setEditText("")
            return

        # Asegurar que el combo es editable
        self.cbxEX_NUM.setEditable(True)

        # Guardar el registro actual si existe
        registro_actual = None
        if self.indice_excel_actual >= 0:
            registro_actual = self.registros_excel[self.indice_excel_actual]

        # Actualizar combo de navegación
        self.cbxEX_NUM.blockSignals(True)
        self.cbxEX_NUM.clear()

        # Determinar qué índices mostrar en el combo
        indices_mostrar = self.registros_filtrados if self.filtro_pendientes else range(len(self.registros_excel))

        # Guardar los números de expediente para referencia
        lista_ex_nums = []
        for idx in indices_mostrar:
            registro = self.registros_excel[idx]
            numexpro = registro.get('NUMEXPRO', '')
            if numexpro and not pd.isna(numexpro):
                ex_num_completo = f"EX-{numexpro}"
                self.cbxEX_NUM.addItem(ex_num_completo)
                lista_ex_nums.append(ex_num_completo)

        # Intentar mantener el registro actual si todavía está en el filtro
        if registro_actual and self.filtro_pendientes:
            numexpro_actual = registro_actual.get('NUMEXPRO', '')
            ex_num_actual = f"EX-{numexpro_actual}"

            if ex_num_actual in lista_ex_nums:
                index_en_combo = lista_ex_nums.index(ex_num_actual)
                self.cbxEX_NUM.setCurrentIndex(index_en_combo)
                self.indice_filtrado_actual = index_en_combo
            else:
                # El registro actual no está en el filtro, ir al más moderno (índice 0)
                if self.cbxEX_NUM.count() > 0:
                    self.cbxEX_NUM.setCurrentIndex(0)
                    self.indice_filtrado_actual = 0
                    idx_real = self.registros_filtrados[0]
                    self.indice_excel_actual = idx_real
                    self.cargarRegistroExcelEnUI(self.registros_excel[idx_real])
        elif self.cbxEX_NUM.count() > 0:
            # Sin filtro, mantener el registro actual
            if self.indice_excel_actual >= 0:
                self.cbxEX_NUM.setCurrentIndex(self.indice_excel_actual)
            else:
                self.cbxEX_NUM.setCurrentIndex(0)
                self.indice_excel_actual = 0
                self.cargarRegistroExcelEnUI(self.registros_excel[0])

        self.cbxEX_NUM.blockSignals(False)
        self.actualizar_contador_registros()

    def obtenerIndiceRealDesdeCombo(self, index_combo):
        """Convierte un índice del combo al índice real en self.registros_excel"""
        if self.filtro_pendientes:
            if 0 <= index_combo < len(self.registros_filtrados):
                return self.registros_filtrados[index_combo]
            return -1
        else:
            return index_combo


    #######################################################################
    ###   METODOS de NAVEGACIÓN POR LOS REGISTROS                       ###
    #######################################################################
    def irInicio(self):
        """Va al primer registro según el filtro actual (el más antiguo)"""
        # print("irInicio - va al más antiguo")
        if self.modo_agregar:
            return

        if self.filtro_pendientes and self.registros_filtrados:
            # Con filtro: el más antiguo es el último índice de la lista filtrada
            self.indice_filtrado_actual = len(self.registros_filtrados) - 1
            self.cbxEX_NUM.setCurrentIndex(self.indice_filtrado_actual)
        elif self.registros_excel:
            # Sin filtro: el más antiguo es el último índice de todos los registros
            self.cbxEX_NUM.setCurrentIndex(len(self.registros_excel) - 1)
        self.actualizar_contador_registros()
        self.actualizarColorBotonZoom() 

    def irAnterior(self):
        """Va al registro anterior (más antiguo) - Botón ANTERIOR y RePag"""
        if self.modo_agregar:
            return

        if self.filtro_pendientes and self.registros_filtrados:
            # Con filtro: anterior = más antiguo = aumentar índice
            if self.indice_filtrado_actual < len(self.registros_filtrados) - 1:
                self.indice_filtrado_actual += 1
                self.cbxEX_NUM.setCurrentIndex(self.indice_filtrado_actual)
        elif self.registros_excel and self.indice_excel_actual < len(self.registros_excel) - 1:
            # Sin filtro: anterior = más antiguo = aumentar índice
            self.cbxEX_NUM.setCurrentIndex(self.indice_excel_actual + 1)
        self.actualizar_contador_registros()
        self.actualizarColorBotonZoom()

    def irSiguiente(self):
        """Va al registro siguiente (más moderno) - Botón SIGUIENTE y AvPag"""
        if self.modo_agregar:
            return

        if self.filtro_pendientes and self.registros_filtrados:
            # Con filtro: siguiente = más moderno = disminuir índice
            if self.indice_filtrado_actual > 0:
                self.indice_filtrado_actual -= 1
                self.cbxEX_NUM.setCurrentIndex(self.indice_filtrado_actual)
        elif self.registros_excel and self.indice_excel_actual > 0:
            # Sin filtro: siguiente = más moderno = disminuir índice
            self.cbxEX_NUM.setCurrentIndex(self.indice_excel_actual - 1)
        self.actualizar_contador_registros()
        self.actualizarColorBotonZoom()

    def irFinal(self):
        """Va al último registro según el filtro actual (el más moderno)"""
        # print("irFinal - va al más moderno")
        if self.modo_agregar:
            return

        if self.filtro_pendientes and self.registros_filtrados:
            # Con filtro: el más moderno es el primer índice de la lista filtrada
            self.indice_filtrado_actual = 0
            self.cbxEX_NUM.setCurrentIndex(0)
        elif self.registros_excel:
            # Sin filtro: el más moderno es el primer índice de todos los registros
            self.cbxEX_NUM.setCurrentIndex(0)
        self.actualizar_contador_registros()
        self.actualizarColorBotonZoom()

