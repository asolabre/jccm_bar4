# -*- coding: utf-8 -*-
'''
/***************************************************************************
RT_CONFIG.py                                 A QGIS4 plugin
Configuración para migración de EJES a RT
                             -------------------
        begin                : 2026-08-23
        validacion transfQG4 : 2026-10-23
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es

Este módulo contiene TODAS las configuraciones, dominios y reglas de transformación
necesarias para la migración de la capa GEO_BTAcalibrada a formato RT_tramovial_JCCM.

NO debe contener lógica de negocio, solo datos de configuración.
***************************************************************************/
'''

# ============================================================================
# CONFIGURACIÓN DE CAPAS
# ============================================================================

CONFIG_CAPAS = {
    'origen': {
        'nombre': 'GEO_BTAcalibrada',
        'tipo': 'lineal',  # lineal, poligono, punto, tabla
        'url': 'https://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0',
        'estilo': {
            'color': '#09fc00',
            'ancho': 0.8
        }
    },
    'catalogo': {
        'nombre': 'rt_catcarreteras_a',
        'tipo': 'tabla',  # tabla, lineal, poligono, punto
        'fuente': 'U:/Z/10_RT_CLM/RT_CatalogoCarreteras/rt_catcarreteras_a.csv',
        'fecha': '2025/04/11'
    },
    'destino': {
        'nombre_por_defecto': 'RT_tramovial_JCCM',
        'tipo_geometria': 'MultiLineStringM',
        'crs': 'epsg:25830',
        'estilo': {
            'color': '#800080',
            'ancho': 0.8
        }
    }
}

# ============================================================================
# ESTRUCTURA DE LA CAPA ORIGEN (GEO_BTAcalibrada)
# ============================================================================

ESTRUCTURA_ORIGEN = {
    'campos': [
        {'nombre': 'idMatricula', 'tipo': 'Integer', 'longitud': 10, 'decimales': 0},
        {'nombre': 'Matricula', 'tipo': 'String', 'longitud': 50, 'decimales': 0},
        {'nombre': 'Matricula_Plan', 'tipo': 'String', 'longitud': 50, 'decimales': 0},
        {'nombre': 'Titularidad', 'tipo': 'String', 'longitud': 50, 'decimales': 0},
        {'nombre': 'Funcionalidad', 'tipo': 'String', 'longitud': 50, 'decimales': 0},
        {'nombre': 'Denominacion', 'tipo': 'String', 'longitud': 250, 'decimales': 0},
        {'nombre': 'Provincia', 'tipo': 'String', 'longitud': 50, 'decimales': 0},
        {'nombre': 'Longitud', 'tipo': 'Double', 'longitud': 10, 'decimales': 2},
        {'nombre': 'PkINI', 'tipo': 'Double', 'longitud': 10, 'decimales': 3},
        {'nombre': 'PkFin', 'tipo': 'Double', 'longitud': 10, 'decimales': 3},
        {'nombre': 'Origen', 'tipo': 'String', 'longitud': 250, 'decimales': 0},
        {'nombre': 'Destino', 'tipo': 'String', 'longitud': 250, 'decimales': 0},
        {'nombre': 'Long_Km', 'tipo': 'Double', 'longitud': 10, 'decimales': 3},
        {'nombre': 'Tipologia_DobleC', 'tipo': 'String', 'longitud': 50, 'decimales': 0},
        {'nombre': 'Tipologia_UnaC', 'tipo': 'String', 'longitud': 50, 'decimales': 0},
        {'nombre': 'idOrdenCtra', 'tipo': 'Integer', 'longitud': 6, 'decimales': 0},
        {'nombre': 'OBJECTID', 'tipo': 'OID', 'longitud': 0, 'decimales': 0},
        {'nombre': 'Shape.STLength()', 'tipo': 'Double', 'longitud': 10, 'decimales': 3}
    ],
    'campo_identificador': 'Matricula',
    'campo_identificador_alt': 'Matricula_Plan'
}

# ============================================================================
# ESTRUCTURA DE LA CAPA DESTINO (RT_tramovial_JCCM)
# ============================================================================

ESTRUCTURA_DESTINO = {
    'campos': [
        # Campos de rt_vial
        {'nombre': 'id_vial',      'tipo': 'Integer64', 'longitud': 12, 'comentario': 'Identificador único del elemento tipo vial (clave primaria)'},
        {'nombre': 'codigo',       'tipo': 'String',    'longitud': 10, 'comentario': 'Código único de vía (INE/DGC)'},
        {'nombre': 'dgc_via',      'tipo': 'String',    'longitud': 6,  'comentario': 'Código único de vía (DG Catastro)'},
        {'nombre': 'tipo_vial',    'tipo': 'Integer64', 'longitud': 4,  'comentario': 'Tipologías de viales (código)'},
        {'nombre': 'tipo_viald',   'tipo': 'String',    'longitud': 100,'comentario': 'Tipologías de viales (descripción)'},
        {'nombre': 'nombre',       'tipo': 'String',    'longitud': 100,'comentario': 'Nombre del vial'},
        {'nombre': 'nombre_alt',   'tipo': 'String',    'longitud': 100,'comentario': 'Nombre alternativo del vial'},
        {'nombre': 'nombre_red',   'tipo': 'String',    'longitud': 255,'comentario': 'Nombre en RED TENT'},
        {'nombre': 'Denominacion', 'tipo': 'String',    'longitud': 255,'comentario': 'Denominación oficial del vial'},
        {'nombre': 'PkINI',        'tipo': 'Double', 'longitud': 10, 'decimales': 3,  'comentario': 'Punto kilométrico origen del tramo (en km)'},
        {'nombre': 'PkFIN',        'tipo': 'Double', 'longitud': 10, 'decimales': 3,  'comentario': 'Punto kilométrico final del tramo (en km)'},
        {'nombre': 'Origen',       'tipo': 'String',    'longitud': 255,'comentario': 'Origen del tramo en texto'},
        {'nombre': 'Destino',      'tipo': 'String',    'longitud': 255,'comentario': 'Final del tramo en texto'},
        {'nombre': 'Provincia',    'tipo': 'String',    'longitud': 2,  'comentario': 'Abreviatura Provincia en texto (AB, CR, CU, GU, TO)'},
        {'nombre': 'idMatricula',  'tipo': 'Integer64', 'longitud': 12, 'comentario': 'Identificador Tramo en GEOBTA_calibrada'},

        # Campos de rt_tramo
        {'nombre': 'fuente_t',     'tipo': 'Integer64', 'longitud': 4,  'comentario': 'Origen de los datos tipo tramo (código)'},
        {'nombre': 'fuente_td',    'tipo': 'String',    'longitud': 100,'comentario': 'Origen de los datos tipo tramo (descripción)'},
        {'nombre': 'alta_db',      'tipo': 'String',    'longitud': 25, 'comentario': 'Fecha de alta o modificación en la base de datos'},
        {'nombre': 'version',      'tipo': 'Integer64', 'longitud': 1,  'comentario': 'Entero positivo, correspondiente a la versión de un elemento'},
        {'nombre': 'id_tramo',     'tipo': 'Integer64', 'longitud': 12, 'comentario': 'Identificador único del elemento tipo tramo (clave primaria)'},
        {'nombre': 'tipo_tramo',   'tipo': 'Integer64', 'longitud': 4,  'comentario': 'Tipología de tramo en relación al eje de la vía (código)'},
        {'nombre': 'tipo_tramd',   'tipo': 'String',    'longitud': 100,'comentario': 'Tipología de tramo en relación al eje de la vía (descripción)'},
        {'nombre': 'calzada',      'tipo': 'Integer64', 'longitud': 4,  'comentario': 'Calzada duplicada o única (código)'},
        {'nombre': 'calzadad',     'tipo': 'String',    'longitud': 100,'comentario': 'Calzada duplicada o única (descripción)'},
        {'nombre': 'acceso',       'tipo': 'Integer64', 'longitud': 4,  'comentario': 'Restricción de acceso a la vía (código)'},
        {'nombre': 'accesod',      'tipo': 'String',    'longitud': 100,'comentario': 'Restricción de acceso a la vía (descripción)'},
        {'nombre': 'firme',        'tipo': 'Integer64', 'longitud': 4,  'comentario': 'Tipo de firme de la calzada (código)'},
        {'nombre': 'firmed',       'tipo': 'String',    'longitud': 100,'comentario': 'Tipo de firme de la calzada (descripción)'},
        {'nombre': 'ncarriles',    'tipo': 'String',    'longitud': 50, 'comentario': 'Número de carriles de la calzada'},
        {'nombre': 'sentido',      'tipo': 'Integer64', 'longitud': 4,  'comentario': 'Sentido de circulación de la calzada (código)'},
        {'nombre': 'sentidod',     'tipo': 'String',    'longitud': 100,'comentario': 'Sentido de circulación de la calzada (descripción)'},
        {'nombre': 'situacion',    'tipo': 'Integer64', 'longitud': 4,  'comentario': 'Valor de la posición vertical relativa respecto a la superficie (código)'},
        {'nombre': 'situaciond',   'tipo': 'String',    'longitud': 100,'comentario': 'Valor de la posición vertical relativa respecto a la superficie (descripción)'},
        {'nombre': 'estadofis',    'tipo': 'Integer64', 'longitud': 4,  'comentario': 'Estado físico en que se encuentra la infraestructura en relación a su terminación y uso (código)'},
        {'nombre': 'estadofisd',   'tipo': 'String',    'longitud': 100,'comentario': 'Estado físico en que se encuentra la infraestructura en relación a su terminación y uso (descripción)'},
        {'nombre': 'tipovehic',    'tipo': 'String',    'longitud': 4,  'comentario': 'Usuarios que pueden transitar por la calzada (código)'},
        {'nombre': 'tipovehicd',   'tipo': 'String',    'longitud': 100,'comentario': 'Usuarios que pueden transitar por la calzada (descripción)'},
        {'nombre': 'titular',      'tipo': 'Integer64', 'longitud': 4,  'comentario': 'Titular de la infraestructura (código)'},
        {'nombre': 'titulard',     'tipo': 'String',    'longitud': 100,'comentario': 'Titular de la infraestructura (descripción)'},
        {'nombre': 'orden',        'tipo': 'String',    'longitud': 4,  'comentario': 'Clasificación basada en la importancia de la carretera en la red (código)'},
        {'nombre': 'ordend',       'tipo': 'String',    'longitud': 100,'comentario': 'Clasificación basada en la importancia de la carretera en la red (descripción)'},
        {'nombre': 'clase',        'tipo': 'Integer64', 'longitud': 4,  'comentario': 'Clase de tramo por sus características de circulación (troncal / otros) (código)'},
        {'nombre': 'clased',       'tipo': 'String',    'longitud': 100,'comentario': 'Clase de tramo por sus características de circulación (troncal / otros) (descripción)'},
        {'nombre': 'fuente_v',     'tipo': 'Integer64', 'longitud': 4,  'comentario': 'Origen de los datos tipo vial (código)'},
        {'nombre': 'fuente_vd',    'tipo': 'String',    'longitud': 100,'comentario': 'Origen de los datos tipo vial (descripción)'},
        {'nombre': 'Longitud',     'tipo': 'Double', 'longitud': 10, 'decimales': 2,  'comentario': 'Longitud de la geometría en m. (Proyectada)'},
        {'nombre': 'Long_KM',      'tipo': 'Double', 'longitud': 10, 'decimales': 3,  'comentario': 'Longitud entre PPKK en km. (Diferencia)'},
    ],
    'campo_clave': 'id_vial',
    'campo_nombre': 'nombre'
}
    # 'campos': [
        # # Campos de rt_vial
        # {'nombre': 'id_vial', 'tipo': 'Integer64', 'longitud': 12}, 'comentario': 's/d',
        # {'nombre': 'codigo', 'tipo': 'String', 'longitud': 10},
        # {'nombre': 'dgc_via', 'tipo': 'String', 'longitud': 6},
        # {'nombre': 'tipo_vial', 'tipo': 'Integer64', 'longitud': 4},
        # {'nombre': 'tipo_viald', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'nombre', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'nombre_alt', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'nombre_red', 'tipo': 'String', 'longitud': 255},
        # {'nombre': 'Denominacion', 'tipo': 'String', 'longitud': 255},
        # {'nombre': 'PkINI', 'tipo': 'Double', 'longitud': 10, 'decimales': 3},
        # {'nombre': 'PkFIN', 'tipo': 'Double', 'longitud': 10, 'decimales': 3},
        # {'nombre': 'Origen', 'tipo': 'String', 'longitud': 255},
        # {'nombre': 'Destino', 'tipo': 'String', 'longitud': 255},
        # {'nombre': 'Provincia', 'tipo': 'String', 'longitud': 2},
        # {'nombre': 'idMatricula', 'tipo': 'Integer64', 'longitud': 12},
        # # Campos de rt_tramo
        # {'nombre': 'fuente_t', 'tipo': 'Integer64', 'longitud': 4},
        # {'nombre': 'fuente_td', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'alta_db', 'tipo': 'String', 'longitud': 25},
        # {'nombre': 'version', 'tipo': 'Integer64', 'longitud': 1},
        # {'nombre': 'id_tramo', 'tipo': 'Integer64', 'longitud': 12},
        # {'nombre': 'tipo_tramo', 'tipo': 'Integer64', 'longitud': 4},
        # {'nombre': 'tipo_tramd', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'calzada', 'tipo': 'Integer64', 'longitud': 4},
        # {'nombre': 'calzadad', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'acceso', 'tipo': 'Integer64', 'longitud': 4},
        # {'nombre': 'accesod', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'firme', 'tipo': 'Integer64', 'longitud': 4},
        # {'nombre': 'firmed', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'ncarriles', 'tipo': 'String', 'longitud': 50},
        # {'nombre': 'sentido', 'tipo': 'Integer64', 'longitud': 4},
        # {'nombre': 'sentidod', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'situacion', 'tipo': 'Integer64', 'longitud': 4},
        # {'nombre': 'situaciond', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'estadofis', 'tipo': 'Integer64', 'longitud': 4},
        # {'nombre': 'estadofisd', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'tipovehic', 'tipo': 'String', 'longitud': 4},
        # {'nombre': 'tipovehicd', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'titular', 'tipo': 'Integer64', 'longitud': 4},
        # {'nombre': 'titulard', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'orden', 'tipo': 'String', 'longitud': 4},
        # {'nombre': 'ordend', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'clase', 'tipo': 'Integer64', 'longitud': 4},
        # {'nombre': 'clased', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'fuente_v', 'tipo': 'Integer64', 'longitud': 4},
        # {'nombre': 'fuente_vd', 'tipo': 'String', 'longitud': 100},
        # {'nombre': 'Longitud', 'tipo': 'Double', 'longitud': 10, 'decimales': 2},
        # {'nombre': 'Long_KM', 'tipo': 'Double', 'longitud': 10, 'decimales': 3}
    # ],

# ============================================================================
# MAPEO DIRECTO (campo_origen -> campo_destino)
# ============================================================================

MAPEO_DIRECTO = {
    'Matricula': 'nombre',
    'Matricula_Plan': 'nombre_alt',
    'Denominacion': 'Denominacion',
    'PkINI': 'PkINI',
    'PkFin': 'PkFIN',
    'Origen': 'Origen',
    'Destino': 'Destino',
    'Provincia': 'Provincia',
    'idMatricula': 'idMatricula',
    'Longitud': 'Longitud',
    'Long_Km': 'Long_KM'
}

# ============================================================================
# REGLAS DE TRANSFORMACIÓN POR CAMPO DESTINO
# ============================================================================

REGLAS_TRANSFORMACION = {
    'id_vial': {
        'descripcion': 'Identificador de vial. Se busca en catálogo RT por MATRICULA',
        'defecto': 9999,
        'origen': 'catalogo',  # indica que viene del catálogo
        'campo_catalogo': 'id_vial'
    },
    'codigo': {
        'descripcion': 'Código de vía',
        'defecto': '9999',
        'origen': 'catalogo',
        'campo_catalogo': 'codigo'
    },
    'dgc_via': {
        'descripcion': 'Código Catastro',
        'defecto': '9999'
    },
    'tipo_vial': {
        'descripcion': 'Tipologías de viales (código)',
        'defecto': 1000,
        'reglas': [
            # Enlaces (700-706) → carretera en principio (se refina con RT_IGN)
            {'campo': 'idOrdenCtra', 'valores': [1,2,3,4,5,6,700,701,702,703,705,706], 'resultado': 1000},
            # Caminos de servicio, tramos abandonados, otras SCL → vial camino
            {'campo': 'idOrdenCtra', 'valores': [800,801,10,99], 'resultado': 3000},
            # Carril bici
            {'campo': 'idOrdenCtra', 'valores': [9], 'resultado': 1004}
        ]
    },
    # 'tipo_vial': {
        # 'descripcion': 'Tipología de vial',
        # 'defecto': 1000,
        # 'reglas': [
            # {'campo': 'idOrdenCtra', 'valores': [1,2,3,4,5,6,700,701,702,703,705,706], 'resultado': 1000},
            # {'campo': 'idOrdenCtra', 'valores': [800,801,10,99], 'resultado': 3000},
            # {'campo': 'idOrdenCtra', 'valores': [9], 'resultado': 1004}
        # ]
    # },
    'nombre_red': {
        'defecto': 'N/C'
    },
    'fuente_t': {
        'defecto': 10
    },
    'alta_db': {
        'defecto': 'fecha_actual',  # valor especial: se usa fecha actual
        'es_fecha': True
    },
    'version': {
        'defecto': 1
    },
    'id_tramo': {
        'defecto': 0
    },
    'tipo_tramo': {
        'defecto': 1,  # Troncal
        'reglas': [
            # Enlaces funcionales → Nudo
            {'campo': 'Funcionalidad', 'valores': ['Enlace'], 'resultado': 2},
            # Resto → Troncal
            {'campo': 'Funcionalidad', 'valores': ['Básica alta capacidad','Básica','Comarcal','Local','Travesía','Ramal'], 'resultado': 1}
        ]
    },
    # 'tipo_tramo': {
        # 'defecto': 1,
        # 'reglas': [
            # {'campo': 'Funcionalidad', 'valores': ['Básica alta capacidad', 'Básica', 'Comarcal', 'Local', 'Travesía', 'Ramal'], 'resultado': 1},
            # {'campo': 'Funcionalidad', 'valores': ['Enlace'], 'resultado': 2}
        # ]
    # },
    'calzada': {
        'defecto': 1,
        'reglas': [
            {'campo': 'Tipologia_DobleC', 'valores': ['ATP','ATV','ATN','MTC'], 'resultado': 2},
            {'campo': 'Tipologia_DobleC', 'valores': ['CON','SCL'], 'resultado': 1},
            {'campo': 'Tipologia_UnaC', 'condicion': 'not_empty', 'resultado': 1}
        ]
    },
    'acceso': {
        'defecto': 1,  # Libre
        'reglas': [
            {'campo': 'Tipologia_DobleC', 'valores': ['ATP'], 'resultado': 2}  # Peaje
        ]
    },
    # 'acceso': {
        # 'defecto': 1
    # },
    'firme': {
        'defecto': 1
    },
    'ncarriles': {
        'defecto': 'Desconocido',
        'reglas': [
            {'campo': 'idOrdenCtra', 'valores': [1], 'resultado': '2'},
            {'campo': 'idOrdenCtra', 'valores': [2,3,4,5,6,800,801,9,10,99], 'resultado': '2'},
            {'campo': 'idOrdenCtra', 'valores': [700,701,702,703,705,706], 'resultado': 'Desconocido'}
        ]
    },
    'sentido': {
        'defecto': 2,  # Doble
        'reglas': [
            {'campo': 'Tipologia_DobleC', 'valores': ['ATP','ATV','ATN','MTC'], 'resultado': 1},  # Único
            {'campo': 'Tipologia_DobleC', 'valores': ['CON','SCL'], 'resultado': 2},
            {'campo': 'Tipologia_UnaC', 'condicion': 'not_empty', 'resultado': 2}
        ]
    },
    # 'sentido': {
        # 'defecto': 2,
        # 'reglas': [
            # {'campo': 'Tipologia_DobleC', 'valores': ['ATP','ATV','MTC'], 'resultado': 1},
            # {'campo': 'Tipologia_DobleC', 'valores': ['CON','SCL'], 'resultado': 2},
            # {'campo': 'Tipologia_UnaC', 'condicion': 'not_empty', 'resultado': 2}
        # ]
    # },
    'situacion': {
        'defecto': 9999
    },
    'estadofis': {
        'defecto': 1
    },
    'tipovehic': {
        'defecto': '111',
        'reglas': [
            {'campo': 'idOrdenCtra', 'valores': [1], 'resultado': '1'},
            {'campo': 'idOrdenCtra', 'valores': [9], 'resultado': '110'},
            {'campo': 'idOrdenCtra', 'valores': [2,3,4,5,6,700,701,702,703,705,706,800,801,10,99], 'resultado': '111'}
        ]
    },
    'titular': {
        'defecto': 99,
        'reglas': [
            {'campo': 'Titularidad', 'valores': ['Estatal'], 'resultado': 1},
            {'campo': 'Titularidad', 'valores': ['JCCM'], 'resultado': 2},
            {'campo': 'Titularidad', 'valores': ['Diputación'], 'resultado': 3},
            {'campo': 'Titularidad', 'valores': ['Ayuntamiento'], 'resultado': 5},
            {'campo': 'Titularidad', 'valores': ['Otras','CAM','JEX','SCL'], 'resultado': 99}
        ]
    },
    'orden': {
        'defecto': 'N',
        'reglas': [
            {'campo': 'idOrdenCtra', 'valores': [1, 701], 'resultado': 'P'},
            {'campo': 'idOrdenCtra', 'valores': [2, 702], 'resultado': '1'},
            {'campo': 'idOrdenCtra', 'valores': [3, 703], 'resultado': '2'},
            {'campo': 'idOrdenCtra', 'valores': [4,5,6,705,706], 'resultado': '3'},
            {'campo': 'idOrdenCtra', 'valores': [700,800,801,9,10,99], 'resultado': 'N'}
        ]
    },
    'clase': {
        'defecto': 1003,
        'reglas': [
            {'campo': 'Tipologia_DobleC', 'valores': ['ATP'], 'resultado': 1001},
            {'campo': 'Tipologia_DobleC', 'valores': ['ATV'], 'resultado': 1002},
            {'campo': 'Tipologia_DobleC', 'valores': ['MTC'], 'resultado': 1005},
            {'campo': 'Tipologia_DobleC', 'valores': ['CON','SCL'], 'resultado': 1003},
            {'campo': 'Tipologia_UnaC', 'condicion': 'not_empty', 'resultado': 1003}
        ]
    },
    'fuente_v': {
        'defecto': 10
    },
}

# ============================================================================
# VALORES EN TEXTO CAMPOS RT (CAMPOS CON SUFIJO -d)
# ----------------------------------------------------------------------------
# Según especificaciones oficiales IGN RT - capa 'rt_tramo_vial'
# Cada campo de texto (-d) es la representación textual del campo código sin -d.
# ============================================================================

VALORES_TEXTO_RT = {

    # ------------------------------------------------------------------------
    # tipo_viald : Texto de tipo_vial (rt_vial)
    # ------------------------------------------------------------------------
    'tipo_viald': {
        'descripcion': 'Tipologías de viales (descripción)',
        'campo_codigo': 'tipo_vial',
        'defecto': 'Carretera',
        'reglas': [
            {'campo': 'tipo_vial', 'valores': [1000], 'resultado': 'Carretera'},
            {'campo': 'tipo_vial', 'valores': [1004], 'resultado': 'Vial bici'},
            {'campo': 'tipo_vial', 'valores': [3000], 'resultado': 'Vial camino'},
            {'campo': 'tipo_vial', 'valores': [4005], 'resultado': 'Red TenT'},
            {'campo': 'tipo_vial', 'valores': [4006], 'resultado': 'Itinerario europeo'},
            {'campo': 'tipo_vial', 'valores': [4007], 'resultado': 'Vía verde'},
            # Tipos INE de viales urbanos (2001-2999)
            {'campo': 'tipo_vial', 'rango': (2001, 2999), 'resultado': 'Vial urbano'}
        ]
    },

    # ------------------------------------------------------------------------
    # fuente_td : Texto de fuente_t (rt_tramo)
    # ------------------------------------------------------------------------
    'fuente_td': {
        'descripcion': 'Origen de los datos (descripción)',
        'campo_codigo': 'fuente_t',
        'defecto': 'Castilla - La Mancha',
        'reglas': [
            {'campo': 'fuente_t', 'valores': [1],  'resultado': 'Instituto Geográfico Nacional'},
            {'campo': 'fuente_t', 'valores': [2],  'resultado': 'Dirección General del Catastro'},
            {'campo': 'fuente_t', 'valores': [3],  'resultado': 'Dirección General de Carreteras (MITMA)'},
            {'campo': 'fuente_t', 'valores': [4],  'resultado': 'Instituto Nacional de Estadística'},
            {'campo': 'fuente_t', 'valores': [5],  'resultado': 'Correos'},
            {'campo': 'fuente_t', 'valores': [10], 'resultado': 'Castilla - La Mancha'},
            {'campo': 'fuente_t', 'valores': [13], 'resultado': 'Ciudad de Ceuta'},
            {'campo': 'fuente_t', 'valores': [19], 'resultado': 'Illes Balears'},
            {'campo': 'fuente_t', 'valores': [21], 'resultado': 'Ciudad de Melilla'},
            {'campo': 'fuente_t', 'valores': [25], 'resultado': 'UNECE'},
            {'campo': 'fuente_t', 'valores': [26], 'resultado': 'DGT'},
            {'campo': 'fuente_t', 'valores': [27], 'resultado': 'ADIF'},
            {'campo': 'fuente_t', 'valores': [28], 'resultado': 'Puertos del Estado'},
            {'campo': 'fuente_t', 'valores': [29], 'resultado': 'ENAIRE'},
            {'campo': 'fuente_t', 'valores': [30], 'resultado': 'DGMove (CE)'}
        ]
    },

    # ------------------------------------------------------------------------
    # tipo_tramd : Texto de tipo_tramo (rt_tramo)
    # ------------------------------------------------------------------------
    'tipo_tramd': {
        'descripcion': 'Tipología de tramo en relación al eje de la vía (descripción)',
        'campo_codigo': 'tipo_tramo',
        'defecto': 'Troncal',
        'reglas': [
            {'campo': 'tipo_tramo', 'valores': [1], 'resultado': 'Troncal'},
            {'campo': 'tipo_tramo', 'valores': [2], 'resultado': 'Nudo'},
            {'campo': 'tipo_tramo', 'valores': [3], 'resultado': 'Vía de servicio, vía colectora-distribuidora o calzada lateral'},
            {'campo': 'tipo_tramo', 'valores': [4], 'resultado': 'Rotonda'}
        ]
    },

    # ------------------------------------------------------------------------
    # calzadad : Texto de calzada (rt_tramo)
    # ------------------------------------------------------------------------
    'calzadad': {
        'descripcion': 'Calzada duplicada o única (descripción)',
        'campo_codigo': 'calzada',
        'defecto': 'Única',
        'reglas': [
            {'campo': 'calzada', 'valores': [1], 'resultado': 'Única'},
            {'campo': 'calzada', 'valores': [2], 'resultado': 'Duplicada o superior'}
        ]
    },

    # ------------------------------------------------------------------------
    # accesod : Texto de acceso (rt_tramo)
    # ------------------------------------------------------------------------
    'accesod': {
        'descripcion': 'Restricción de acceso a la vía (descripción)',
        'campo_codigo': 'acceso',
        'defecto': 'Libre',
        'reglas': [
            {'campo': 'acceso', 'valores': [1], 'resultado': 'Libre'},
            {'campo': 'acceso', 'valores': [2], 'resultado': 'Peaje'}
        ]
    },

    # ------------------------------------------------------------------------
    # firmed : Texto de firme (rt_tramo)
    # ------------------------------------------------------------------------
    'firmed': {
        'descripcion': 'Tipo de firme de la calzada (descripción)',
        'campo_codigo': 'firme',
        'defecto': 'Pavimentado',
        'reglas': [
            {'campo': 'firme', 'valores': [1], 'resultado': 'Pavimentado'},
            {'campo': 'firme', 'valores': [2], 'resultado': 'Tratamiento superficial'},
            {'campo': 'firme', 'valores': [3], 'resultado': 'Sin tratamiento superficial'}
        ]
    },

    # ------------------------------------------------------------------------
    # sentidod : Texto de sentido (rt_tramo)
    # ------------------------------------------------------------------------
    'sentidod': {
        'descripcion': 'Sentido de circulación de la calzada (descripción)',
        'campo_codigo': 'sentido',
        'defecto': 'Doble',
        'reglas': [
            {'campo': 'sentido', 'valores': [1], 'resultado': 'Único'},
            {'campo': 'sentido', 'valores': [2], 'resultado': 'Doble'},
            {'campo': 'sentido', 'valores': [3], 'resultado': 'Reversible'}
        ]
    },

    # ------------------------------------------------------------------------
    # situaciond : Texto de situacion (rt_tramo)
    # ------------------------------------------------------------------------
    'situaciond': {
        'descripcion': 'Posición vertical relativa respecto a la superficie (descripción)',
        'campo_codigo': 'situacion',
        'defecto': 'N/C',
        'reglas': [
            {'campo': 'situacion', 'valores': [1], 'resultado': 'En superficie'},
            {'campo': 'situacion', 'valores': [2], 'resultado': 'Subterráneo'},
            {'campo': 'situacion', 'valores': [3], 'resultado': 'Elevado'},
            {'campo': 'situacion', 'valores': [4], 'resultado': 'En vado'},
            {'campo': 'situacion', 'valores': [5], 'resultado': 'En transbordador'}
        ]
    },

    # ------------------------------------------------------------------------
    # estadofisd : Texto de estadofis (rt_tramo)
    # ------------------------------------------------------------------------
    'estadofisd': {
        'descripcion': 'Estado físico en que se encuentra la infraestructura (descripción)',
        'campo_codigo': 'estadofis',
        'defecto': 'En uso',
        'reglas': [
            {'campo': 'estadofis', 'valores': [1], 'resultado': 'En servicio'},
            {'campo': 'estadofis', 'valores': [2], 'resultado': 'En construcción'},
            {'campo': 'estadofis', 'valores': [3], 'resultado': 'Fuera de servicio'}
        ]
    },

    # ------------------------------------------------------------------------
    # tipovehicd : Texto de tipovehic (rt_tramo)
    # ------------------------------------------------------------------------
    'tipovehicd': {
        'descripcion': 'Usuarios que pueden transitar por la calzada (descripción)',
        'campo_codigo': 'tipovehic',
        'defecto': 'Peatón+bici+vehículo',
        'reglas': [
            {'campo': 'tipovehic', 'valores': ['1'],   'resultado': 'Solo vehículo'},
            {'campo': 'tipovehic', 'valores': ['111'], 'resultado': 'Peatón+bici+vehículo'},
            {'campo': 'tipovehic', 'valores': ['110'], 'resultado': 'Peatón+bici'},
            {'campo': 'tipovehic', 'valores': ['10'],  'resultado': 'Solo bici'},
            {'campo': 'tipovehic', 'valores': ['100'], 'resultado': 'Solo peatón'}
        ]
    },

    # ------------------------------------------------------------------------
    # titulard : Texto de titular (rt_tramo)
    # ------------------------------------------------------------------------
    'titulard': {
        'descripcion': 'Titular de la infraestructura (descripción)',
        'campo_codigo': 'titular',
        'defecto': 'Otros',
        'reglas': [
            {'campo': 'titular', 'valores': [1],  'resultado': 'Administración General del Estado'},
            {'campo': 'titular', 'valores': [2],  'resultado': 'Comunidad Autónoma'},
            {'campo': 'titular', 'valores': [3],  'resultado': 'Diputación Provincial'},
            {'campo': 'titular', 'valores': [4],  'resultado': 'Cabildo o Consell Insular'},
            {'campo': 'titular', 'valores': [5],  'resultado': 'Ayuntamiento'},
            {'campo': 'titular', 'valores': [6],  'resultado': 'Confederación hidrográfica'},
            {'campo': 'titular', 'valores': [7],  'resultado': 'Autoridad portuaria'},
            {'campo': 'titular', 'valores': [8],  'resultado': 'Militar'},
            {'campo': 'titular', 'valores': [9],  'resultado': 'Empresa minera'},
            {'campo': 'titular', 'valores': [99], 'resultado': 'Otros'}
        ]
    },

    # ------------------------------------------------------------------------
    # ordend : Texto de orden (rt_tramo)
    # ------------------------------------------------------------------------
    'ordend': {
        'descripcion': 'Clasificación basada en la importancia de la carretera (descripción)',
        'campo_codigo': 'orden',
        'defecto': 'No catalogada',
        'reglas': [
            {'campo': 'orden', 'valores': ['P'], 'resultado': 'Principal'},
            {'campo': 'orden', 'valores': ['1'], 'resultado': 'Primer orden'},
            {'campo': 'orden', 'valores': ['2'], 'resultado': 'Segundo orden'},
            {'campo': 'orden', 'valores': ['3'], 'resultado': 'Tercer orden'},
            {'campo': 'orden', 'valores': ['N'], 'resultado': 'No catalogada'}
        ]
    },

    # ------------------------------------------------------------------------
    # clased : Texto de clase (rt_tramo)
    # ------------------------------------------------------------------------
    'clased': {
        'descripcion': 'Clase de tramo por sus características de circulación (descripción)',
        'campo_codigo': 'clase',
        'defecto': 'Carretera convencional',
        'reglas': [
            {'campo': 'clase', 'valores': [1001], 'resultado': 'Autopista'},
            {'campo': 'clase', 'valores': [1002], 'resultado': 'Autovía'},
            {'campo': 'clase', 'valores': [1003], 'resultado': 'Carretera convencional'},
            {'campo': 'clase', 'valores': [1004], 'resultado': 'Carril bici'},
            {'campo': 'clase', 'valores': [1005], 'resultado': 'Carretera multicarril'},
            {'campo': 'clase', 'valores': [2000], 'resultado': 'Urbano'},
            {'campo': 'clase', 'valores': [3001], 'resultado': 'Camino'},
            {'campo': 'clase', 'valores': [3002], 'resultado': 'Senda'}
        ]
    },

    # ------------------------------------------------------------------------
    # fuente_vd : Texto de fuente_v (rt_vial)
    # ------------------------------------------------------------------------
    'fuente_vd': {
        'descripcion': 'Origen de los datos (descripción)',
        'campo_codigo': 'fuente_v',
        'defecto': 'Castilla - La Mancha',
        'reglas': [
            {'campo': 'fuente_v', 'valores': [1],  'resultado': 'Instituto Geográfico Nacional'},
            {'campo': 'fuente_v', 'valores': [2],  'resultado': 'Dirección General del Catastro'},
            {'campo': 'fuente_v', 'valores': [3],  'resultado': 'Dirección General de Carreteras (MITMA)'},
            {'campo': 'fuente_v', 'valores': [4],  'resultado': 'Instituto Nacional de Estadística'},
            {'campo': 'fuente_v', 'valores': [5],  'resultado': 'Correos'},
            {'campo': 'fuente_v', 'valores': [10], 'resultado': 'Castilla - La Mancha'},
            {'campo': 'fuente_v', 'valores': [13], 'resultado': 'Ciudad de Ceuta'},
            {'campo': 'fuente_v', 'valores': [19], 'resultado': 'Illes Balears'},
            {'campo': 'fuente_v', 'valores': [21], 'resultado': 'Ciudad de Melilla'},
            {'campo': 'fuente_v', 'valores': [25], 'resultado': 'UNECE'},
            {'campo': 'fuente_v', 'valores': [26], 'resultado': 'DGT'},
            {'campo': 'fuente_v', 'valores': [27], 'resultado': 'ADIF'},
            {'campo': 'fuente_v', 'valores': [28], 'resultado': 'Puertos del Estado'},
            {'campo': 'fuente_v', 'valores': [29], 'resultado': 'ENAIRE'},
            {'campo': 'fuente_v', 'valores': [30], 'resultado': 'DGMove (CE)'}
        ]
    }
}




# ============================================================================
# VALORES POR DEFECTO PARA CAMPOS DESTINO (resumen)
# ============================================================================

# Se genera automáticamente a partir de REGLAS_TRANSFORMACION
VALORES_DEFECTO = {}
for campo, regla in REGLAS_TRANSFORMACION.items():
    if 'defecto' in regla:
        VALORES_DEFECTO[campo] = regla['defecto']

# ============================================================================
# PREFIJO ID_VIAL PARA CASTILLA-LA MANCHA
# ============================================================================

PREFIJO_ID_VIAL_CLM = 608000000000
RANGO_ID_VIAL_CLM = {'inicio': 608000000000, 'fin': 608999999999}

# ============================================================================
# CONFIGURACIÓN DE FILTROS (combos)
# ============================================================================

FILTROS = {
    'Provincia': {'campo': 'Provincia', 'valor_defecto': 'Todo'},
    'Titularidad': {'campo': 'Titularidad', 'valor_defecto': 'Todo'}
}

# ============================================================================
# CONFIGURACIÓN DE ESTILOS
# ============================================================================

ESTILOS = {
    'origen': {
        'archivo': None,  # nombre del archivo qml, None para estilo por defecto
        'color': '#008000',
        'ancho': 0.8
    },
    'destino': {
        'archivo': 'RT_TRAMOVIAL.qml',
        'color': '#800080',
        'ancho': 0.8
    }
}

# ============================================================================
# CONFIGURACIÓN DE SALIDA
# ============================================================================

CONFIG_SALIDA = {
    'directorio_por_defecto': 'c:/temp',
    'nombre_archivo_por_defecto': 'RT_CASTILLA_LAMANCHA.gpkg',
    'limite_pruebas_por_defecto': 10
}

# ============================================================================
# REGLAS DE REFINAMIENTO CON RT_IGN
# ============================================================================
# Cuando el valor calculado por nuestro algoritmo difiere de RT_IGN, se puede
# optar por ADOPTAR el valor de RT_IGN (porque puede ser más fiable) en
# determinados campos.
#
# Estructura:
#   'campo_jccm': {
#       'adoptar_rtign': True/False,   # Adoptar valor de RT_IGN si difiere
#       'condiciones': [               # (opcional) solo adoptar si se cumple
#           {'tipo': 'matricula_9000'},       # Solo si matricula='9000'
#           {'tipo': 'rtign_no_default'},     # Solo si RT_IGN no es valor por defecto
#           {'tipo': 'rtign_in', 'valores': [...]},  # Solo si RT_IGN está en lista
#       ],
#       'registrar_en_log': True/False,  # Registrar la adopción en el log
#       'excluir_comparacion': False,    # Excluir este campo de la comparación
#   }
# ============================================================================

REGLAS_REFINAMIENTO_RTIGN = {

    # tipo_viald / tipo_vial: adoptar siempre el valor de RT_IGN si es "Carretera"
    # (que es el caso general). Adoptar si difiere y RT_IGN != valor por defecto.
    'tipo_viald': {
        'adoptar_rtign': True,
        'condiciones': [
            {'tipo': 'rtign_no_vacio'}
        ],
        'registrar_en_log': True,
        'excluir_comparacion': False,
    },
    'tipo_vial': {
        'adoptar_rtign': True,
        'condiciones': [
            {'tipo': 'rtign_no_vacio'}
        ],
        'registrar_en_log': True,
        'excluir_comparacion': False,
        # Como RT_IGN solo nos da el texto, derivamos el código a partir del texto
        'derivar_codigo_desde_rtign': {
            'campo_codigo': 'tipo_vial',
            'campo_texto_rtign': 'tipo_viald',
            'mapa': {
                'Carretera': 1000,
                'Vial bici': 1004,
                'Vial camino': 3000,
                'Red TenT': 4005,
                'Itinerario europeo': 4006,
                'Vía verde': 4007,
                'Vial urbano': 2000,
            }
        }
    },

    # tipo_tramd / tipo_tramo: adoptar si RT_IGN no es 'Troncal' ni 'Nudo'
    # porque esos dos ya los calculamos bien.
    'tipo_tramd': {
        'adoptar_rtign': True,
        'condiciones': [
            {'tipo': 'rtign_in', 'valores': ['Vía de servicio, vía colectora-distribuidora o calzada lateral', 'Rotonda']}
        ],
        'registrar_en_log': True,
        'excluir_comparacion': False,
    },
    'tipo_tramo': {
        'adoptar_rtign': True,
        'condiciones': [
            {'tipo': 'rtign_no_vacio'}
        ],
        'registrar_en_log': True,
        'excluir_comparacion': False,
        'derivar_codigo_desde_rtign': {
            'campo_codigo': 'tipo_tramo',
            'campo_texto_rtign': 'tipo_tramod',
            'mapa': {
                'Troncal': 1,
                'Nudo': 2,
                'Vía de servicio, vía colectora-distribuidora o calzada lateral': 3,
                'Rotonda': 4,
            }
        }
    },

    # calzadad / calzada: adoptar si RT_IGN difiere
    'calzadad': {
        'adoptar_rtign': True,
        'condiciones': [
            {'tipo': 'rtign_no_vacio'}
        ],
        'registrar_en_log': True,   # ADVERTIR cuando se adopta
        'excluir_comparacion': False,
    },
    'calzada': {
        'adoptar_rtign': True,
        'condiciones': [
            {'tipo': 'rtign_no_vacio'}
        ],
        'registrar_en_log': True,
        'excluir_comparacion': False,
        'derivar_codigo_desde_rtign': {
            'campo_codigo': 'calzada',
            'campo_texto_rtign': 'calzadad',
            'mapa': {
                'Única': 1,
                'Duplicada o superior': 2,
            }
        }
    },

    # accesod / acceso: adoptar si RT_IGN difiere
    'accesod': {
        'adoptar_rtign': True,
        'condiciones': [
            {'tipo': 'rtign_no_vacio'}
        ],
        'registrar_en_log': True,
        'excluir_comparacion': False,
    },
    'acceso': {
        'adoptar_rtign': True,
        'condiciones': [
            {'tipo': 'rtign_no_vacio'}
        ],
        'registrar_en_log': True,
        'excluir_comparacion': False,
        'derivar_codigo_desde_rtign': {
            'campo_codigo': 'acceso',
            'campo_texto_rtign': 'accesod',
            'mapa': {
                'Libre': 1,
                'Peaje': 2,
            }
        }
    },

    # firmed / firme: adoptar si RT_IGN difiere
    'firmed': {
        'adoptar_rtign': True,
        'condiciones': [
            {'tipo': 'rtign_no_vacio'}
        ],
        'registrar_en_log': True,
        'excluir_comparacion': False,
    },
    'firme': {
        'adoptar_rtign': True,
        'condiciones': [
            {'tipo': 'rtign_no_vacio'}
        ],
        'registrar_en_log': True,
        'excluir_comparacion': False,
        'derivar_codigo_desde_rtign': {
            'campo_codigo': 'firme',
            'campo_texto_rtign': 'firmed',
            'mapa': {
                'Pavimentado': 1,
                'Tratamiento superficial': 2,
                'Sin tratamiento superficial': 3,
            }
        }
    },

    # sentidod / sentido: adoptar siempre si RT_IGN difiere
    'sentidod': {
        'adoptar_rtign': True,
        'condiciones': [
            {'tipo': 'rtign_no_vacio'}
        ],
        'registrar_en_log': True,
        'excluir_comparacion': False,
    },
    'sentido': {
        'adoptar_rtign': True,
        'condiciones': [
            {'tipo': 'rtign_no_vacio'}
        ],
        'registrar_en_log': True,
        'excluir_comparacion': False,
        'derivar_codigo_desde_rtign': {
            'campo_codigo': 'sentido',
            'campo_texto_rtign': 'sentidod',
            'mapa': {
                'Único': 1,
                'Doble': 2,
                'Reversible': 3,
            }
        }
    },

    # situaciond / situacion: EXCLUIR de la comparación (N/C en RT_JCCM)
    'situaciond': {
        'adoptar_rtign': False,
        'excluir_comparacion': True,
    },
    'situacion': {
        'adoptar_rtign': False,
        'excluir_comparacion': True,
    },
}