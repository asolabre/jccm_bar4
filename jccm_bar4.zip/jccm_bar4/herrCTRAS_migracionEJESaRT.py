# -*- coding: utf-8 -*-
"""
/***************************************************************************
Name:           herrCTRAS_migracionEJESaRT.py
                                 A QGIS4 plugin
Plugin:     jccm_bar4
Purpose:    Migración ejes de GEOBTA_calibrada a RT
        =================================================================
        begin                - 2026-08-23
        validacion transfQG4 : 2026-10-20
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
/***************************************************************************
 *  Permite migrar la capa ORIGEN actual de ejes de carreteras de Castilla *
 *  la Mancha 'GEO_BTAcalibrada' a una capa con estructura de datos        *
 *  similar a la oficial del Instituto Geográfico Nacional de España       *
 *  IGN RT (Redes de Transporte) 'RT_tramovial', con las mejoras           *
 *  necesarias para los trabajos de la DIRECCIÓN GENERAL DE CARRETERAS     *
 *  de la JCCM.                                                            *
 ***************************************************************************

 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import (QIcon, QPixmap, QColor, QAction)
from qgis.PyQt.QtCore import (QSettings, QCoreApplication, QTranslator, qVersion,
                              Qt, QFileInfo, QDate, QVariant)
from qgis.PyQt.QtWidgets import (QApplication, QMessageBox, QToolButton, QMenu,
                                 QDialog, QCheckBox, QFileDialog, QWidget,
                                 QTextEdit, QProgressBar, QPushButton,
                                 QLineEdit, QLabel)
from qgis.PyQt import uic

from qgis.gui import QgsMessageBar
from qgis.core import (QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer,
                       QgsApplication, QgsField, QgsVectorFileWriter,
                       QgsCoordinateTransformContext, QgsFeature, QgsExpression,
                       QgsFeatureRequest, QgsProcessingFeedback, QgsGeometry,
                       QgsWkbTypes, QgsPoint, QgsLineString,
                       QgsMultiLineString, QgsField, QgsCoordinateReferenceSystem,
                       QgsSimpleLineSymbolLayer, QgsSymbol, QgsRendererCategory,
                       QgsCategorizedSymbolRenderer, QgsLayerTreeLayer)

from qgis.utils import iface

import os
import timeit
import datetime
import re

from .config import configuration
from .functions4 import Functions
from .settings import Settings
from .cartoc_buscadorGeneral import cartoc_buscadorGeneral

# ============================================================================
# IMPORTAR CONFIGURACIÓN DESDE RT_CONFIG
# ============================================================================


try:
    from .RT_CONFIG import (
        CONFIG_CAPAS,
        ESTRUCTURA_ORIGEN,
        ESTRUCTURA_DESTINO,
        MAPEO_DIRECTO,
        REGLAS_TRANSFORMACION,
        VALORES_TEXTO_RT,
        VALORES_DEFECTO,
        PREFIJO_ID_VIAL_CLM,
        RANGO_ID_VIAL_CLM,
        FILTROS,
        ESTILOS,
        CONFIG_SALIDA
        )
    # print("RT_CONFIG importado correctamente")
except ImportError as e:
    print(f"ERROR: No se pudo importar RT_CONFIG: {e}")
    # Valores mínimos para no fallar
    CONFIG_CAPAS = {'origen': {'nombre': 'GEO_BTAcalibrada'}, 'catalogo': {'nombre': 'rt_catcarreteras_a'}}
    ESTRUCTURA_DESTINO = {'campos': []}
    MAPEO_DIRECTO = {}
    REGLAS_TRANSFORMACION = {}
    VALORES_DEFECTO = {}
    CONFIG_SALIDA = {'limite_pruebas_por_defecto': 10}
    raise

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrCTRAS_migracionEJESaRT.ui'))


class herrCTRAS_migracionEJESaRT(QDialog, FORM_CLASS):
    def __init__(self, iface, parent=None):
        super(herrCTRAS_migracionEJESaRT, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        try:
            self.setWindowIcon(QIcon(f':/plugins/{self.nombre_plugin}/iconos/IGN_RT.jpg'))
            self.logo.setPixmap(QPixmap(f":/plugins/{self.nombre_plugin}/iconos/IGN_RT.jpg"))
        except:
            pass

        self.fun = Functions()
        self.Sett = Settings()
        self.conf = configuration()
        self.cartoc = cartoc_buscadorGeneral(self.iface)
        self.msg_bar = iface.messageBar()

        try:
            userSIG, tipoUser = self.Sett.entrarUser()
        except:
            pass

        self.plugin_dir = QFileInfo(QgsApplication.qgisUserDatabaseFilePath()).path() + f"/python/plugins/{self.nombre_plugin}"
        self.QgisVersion = Qgis.QGIS_VERSION_INT

        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)
        self.progressBar.setValue(0)
        self.lblINFO.setText('INFO:')

        self.btnSeleccionfich.clicked.connect(self.salida_file_click)
        self.btn_MigrarEJESaRT.clicked.connect(self.ejecutar_migracion)

        # Campo de límite desde configuración
        limite_defecto = str(CONFIG_SALIDA.get('limite_pruebas_por_defecto', 10))
        self.lneLimitePruebas.setText(limite_defecto)

        self.capa_origen = None
        self.capa_catalogo = None
        self.validacion_ok = False

        # Cache para el catálogo
        self.cache_catalogo = {}

        # Llenar combos con capas del proyecto
        self.actualizar_combos_capas()

        # Verificar que exista capa de catálogo
        if self.cbx_nomCatRT.count() == 0:
            nombre_catalogo = CONFIG_CAPAS.get('catalogo', {}).get('nombre', 'rt_catcarreteras_a')
            self.fun.showMessageERR(
                f"No se encontró ninguna capa de catálogo '{nombre_catalogo}'.\n\n"
                "Esta capa es necesaria para la migración.\n"
                "Por favor, cargue la capa de catálogo en el proyecto."
            )
            self.validacion_ok = False
            self.reject()
            return

        self.validacion_ok = True
        self.llenar_combos()
        self.fecha_actual = datetime.datetime.now().strftime('%Y-%m-%d')

    def showEvent(self, event):
        if not self.validacion_ok:
            event.ignore()
            return
        super(herrCTRAS_migracionEJESaRT, self).showEvent(event)

    def closeEvent(self, event):
        QApplication.restoreOverrideCursor()

    def salida_file_click(self):
        dirFile = self.lneFICHsalida.text()
        filename, tipofile = QFileDialog.getSaveFileName(self, "Fichero GPKG de salida", dirFile, "*.gpkg")
        if filename:
            directorio = os.path.dirname(filename)
            if directorio and not os.path.exists(directorio):
                try:
                    os.makedirs(directorio)
                except Exception as e:
                    self.fun.showMessageERR(f"No se pudo crear el directorio: {str(e)}")
                    return
            self.lneFICHsalida.setText(filename)

    def actualizar_combos_capas(self):
        """
        Actualiza los combos con las capas del proyecto:
            * cbx_nomCatRT: solo capas sin geometría (tablas)
            * cbx_nomGeobta: solo capas vectoriales lineales
        """
        capas = QgsProject.instance().mapLayers().values()

        self.cbx_nomCatRT.clear()
        self.cbx_nomGeobta.clear()

        capas_tabla = []
        capas_lineales = []

        for capa in capas:
            if not isinstance(capa, QgsVectorLayer):
                continue

            geom_type = capa.geometryType()

            if geom_type == QgsWkbTypes.NullGeometry:
                capas_tabla.append(capa.name())
                continue

            if geom_type == QgsWkbTypes.LineGeometry:
                capas_lineales.append(capa.name())

        capas_tabla.sort()
        capas_lineales.sort()

        for nombre in capas_tabla:
            self.cbx_nomCatRT.addItem(nombre)

        for nombre in capas_lineales:
            self.cbx_nomGeobta.addItem(nombre)

        # Seleccionar por defecto desde configuración
        nombre_catalogo = CONFIG_CAPAS.get('catalogo', {}).get('nombre', 'rt_catcarreteras_a')
        idx = self.cbx_nomCatRT.findText(nombre_catalogo)
        if idx >= 0:
            self.cbx_nomCatRT.setCurrentIndex(idx)

        nombre_origen = CONFIG_CAPAS.get('origen', {}).get('nombre', 'GEO_BTAcalibrada')
        idx = self.cbx_nomGeobta.findText(nombre_origen)
        if idx >= 0:
            self.cbx_nomGeobta.setCurrentIndex(idx)

    def obtener_capa_por_nombre(self, nombre_capa):
        capas = QgsProject.instance().mapLayersByName(nombre_capa)
        if capas:
            return capas[0]
        return None

    def obtener_capa_seleccionada(self, combo):
        nombre_capa = combo.currentText()
        if not nombre_capa:
            return None
        return self.obtener_capa_por_nombre(nombre_capa)

    def llenar_combos(self):
        try:
            self.capa_origen = self.obtener_capa_seleccionada(self.cbx_nomGeobta)
            self.capa_catalogo = self.obtener_capa_seleccionada(self.cbx_nomCatRT)

            if self.capa_origen is None:
                print("No se encontró la capa origen seleccionada")
                return

            # Combo Provincia
            lista_Valores = self.fun.getValoresCampo('Provincia', '')
            self.cbxProvincia.clear()
            if lista_Valores is not None:
                self.cbxProvincia.addItem("Todo")
                self.cbxProvincia.addItems(lista_Valores)

            # Combo Titularidad
            lista_Valores = self.fun.getValoresCampo('Titularidad', '')
            self.cbxTitularidad.clear()
            if lista_Valores is not None:
                self.cbxTitularidad.addItem("Todo")
                self.cbxTitularidad.addItems(lista_Valores)
        except Exception as e:
            print(f"Error llenando combos: {e}")

    def obtener_limite_pruebas(self):
        try:
            if hasattr(self, 'lneLimitePruebas'):
                texto = self.lneLimitePruebas.text().strip()
                if texto:
                    return int(texto) if int(texto) > 0 else 0
            return CONFIG_SALIDA.get('limite_pruebas_por_defecto', 10)
        except:
            return CONFIG_SALIDA.get('limite_pruebas_por_defecto', 10)

    def obtener_attr_catalogo(self, matricula, matricula_plan=None):
        # Busca en el catálogo RT y devuelve diccionario con atributos
        if not matricula and not matricula_plan:
            return None

        if self.capa_catalogo is None:
            return None

        matricula = matricula.strip() if matricula else ''
        matricula_plan = matricula_plan.strip() if matricula_plan else ''

        cache_key = matricula if matricula else matricula_plan
        if cache_key in self.cache_catalogo:
            return self.cache_catalogo[cache_key]

        # Si Matricula es '9000', usar Matricula_Plan
        if matricula == '9000' and matricula_plan:
            matricula_principal = matricula_plan
        else:
            matricula_principal = matricula if matricula else matricula_plan

        busquedas = []
        if matricula_principal:
            busquedas.append((matricula_principal, 'nombre'))
        if matricula_plan and matricula_plan != matricula_principal:
            busquedas.append((matricula_plan, 'nombre_alt'))
        if matricula and matricula != matricula_principal and matricula != '9000':
            busquedas.append((matricula, 'nombre_alt'))
        if not matricula and matricula_plan:
            busquedas = [(matricula_plan, 'nombre'), (matricula_plan, 'nombre_alt')]

        for valor, campo in busquedas:
            if not valor:
                continue
            try:
                expression = QgsExpression(f'"{campo}" = \'{valor}\'')
                request = QgsFeatureRequest(expression)
                features = list(self.capa_catalogo.getFeatures(request))

                if features:
                    feature = features[0]
                    dict_attr = {}
                    for field in feature.fields():
                        try:
                            dict_attr[field.name()] = feature[field.name()]
                        except:
                            dict_attr[field.name()] = None
                    self.cache_catalogo[cache_key] = dict_attr
                    return dict_attr
            except Exception as e:
                print(f"Error buscando '{valor}' en '{campo}': {e}")
                continue

        self.cache_catalogo[cache_key] = None
        return None

    def aplicar_transformacion(self, nombre_campo, dict_origen, valor_catalogo=None):
        # Aplica las reglas de transformación definidas en RT_CONFIG para un campo

        if nombre_campo not in REGLAS_TRANSFORMACION:
            return None

        regla = REGLAS_TRANSFORMACION[nombre_campo]

        # Caso especial: campo desde catálogo
        if regla.get('origen') == 'catalogo' and valor_catalogo is not None:
            return valor_catalogo

        # Caso especial: fecha actual
        if regla.get('es_fecha', False):
            return self.fecha_actual

        # Si tiene reglas condicionales
        if 'reglas' in regla:
            for subregla in regla['reglas']:
                campo = subregla.get('campo')
                if not campo:
                    continue

                valor_origen = dict_origen.get(campo)

                # Caso: lista de valores
                if 'valores' in subregla:
                    if valor_origen in subregla['valores']:
                        return subregla['resultado']

                # Caso: condición especial (not_empty)
                if subregla.get('condicion') == 'not_empty':
                    if valor_origen and str(valor_origen).strip():
                        return subregla['resultado']

        # Valor por defecto
        return regla.get('defecto')

    def ejecutar_migracion(self):
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        try:
            start = timeit.default_timer()

            # Obtener capas desde los combos
            self.capa_origen = self.obtener_capa_seleccionada(self.cbx_nomGeobta)
            self.capa_catalogo = self.obtener_capa_seleccionada(self.cbx_nomCatRT)

            if self.capa_origen is None:
                self.fun.showMessageERR("No se encontró la capa origen seleccionada")
                QApplication.restoreOverrideCursor()
                return

            if self.capa_catalogo is None:
                self.fun.showMessageERR("No se encontró la capa catálogo seleccionada")
                QApplication.restoreOverrideCursor()
                return

            limite = self.obtener_limite_pruebas()

            # Obtener features (solo seleccionados si hay selección)
            selected_ids = self.capa_origen.selectedFeatureIds()
            if selected_ids:
                # Si hay elementos seleccionados, usar solo esos
                request = QgsFeatureRequest().setFilterFids(selected_ids)
                if limite > 0:
                    request.setLimit(limite)
                features = list(self.capa_origen.getFeatures(request))
            else:
                # Si no hay selección, obtener todos (con límite si aplica)
                if limite > 0:
                    request = QgsFeatureRequest().setLimit(limite)
                    features = list(self.capa_origen.getFeatures(request))
                else:
                    features = list(self.capa_origen.getFeatures())

            # Filtrar geometría válida
            features_validos = []
            for f in features:
                if f.hasGeometry() and not f.geometry().isNull():
                    features_validos.append(f)

            if not features_validos:
                self.fun.showMessageERR("No se encontraron elementos con geometría válida")
                QApplication.restoreOverrideCursor()
                return

            # ================================================================
            # CREAR CAPA DESTINO EN MEMORIA
            # ================================================================
            nombre_capa = self.lneNomCapa.text() or CONFIG_CAPAS.get('destino', {}).get('nombre_por_defecto', 'RT_tramovial_JCCM')

            crs = CONFIG_CAPAS.get('destino', {}).get('crs', 'epsg:25830')
            tipo_geom = CONFIG_CAPAS.get('destino', {}).get('tipo_geometria', 'MultiLineStringM')

            uri = f"{tipo_geom}?crs={crs}"
            capa_destino = QgsVectorLayer(uri, nombre_capa, "memory")

            if not capa_destino.isValid():
                # Fallback a MultiLineString
                uri = f"MultiLineString?crs={crs}"
                capa_destino = QgsVectorLayer(uri, nombre_capa, "memory")
                if not capa_destino.isValid():
                    self.fun.showMessageERR("No se pudo crear la capa destino")
                    QApplication.restoreOverrideCursor()
                    return

            # Añadir campos desde ESTRUCTURA_DESTINO
            pr = capa_destino.dataProvider()
            campos = []
            for campo in ESTRUCTURA_DESTINO.get('campos', []):
                nombre = campo.get('nombre', '')
                if nombre:
                    tipo = self.mapear_tipo_campo(campo.get('tipo', 'String'))
                    if tipo is not None:
                        campos.append(QgsField(nombre, tipo))

            if campos:
                pr.addAttributes(campos)
                capa_destino.updateFields()
            else:
                self.fun.showMessageERR("No se añadió ningún campo")
                QApplication.restoreOverrideCursor()
                return

            capa_destino.startEditing()

            # ================================================================
            # PROCESAR FEATURES
            # ================================================================
            total_features = len(features_validos)
            count_ok = 0
            count_error = 0
            errores = []

            field_names_origen = self.capa_origen.fields().names()
            campo_identificador = ESTRUCTURA_ORIGEN.get('campo_identificador', 'Matricula')
            campo_identificador_alt = ESTRUCTURA_ORIGEN.get('campo_identificador_alt', 'Matricula_Plan')

            for idx, feature in enumerate(features_validos):
                try:
                    progreso = int((idx + 1) / total_features * 100)
                    self.progressBar.setValue(progreso)
                    self.lblINFO.setText(f'INFO: Procesando {idx+1}/{total_features}')
                    QApplication.processEvents()

                    fet = QgsFeature(capa_destino.fields())

                    # ASIGNAR GEOMETRÍA
                    geom = feature.geometry()
                    if geom is None or geom.isNull():
                        count_error += 1
                        continue

                    if geom.isMultipart():
                        nueva_geom = QgsGeometry(geom)
                    else:
                        line = geom.asPolyline()
                        if line:
                            multi_line = QgsMultiLineString()
                            multi_line.addGeometry(QgsLineString(line))
                            nueva_geom = QgsGeometry(multi_line)
                        else:
                            nueva_geom = QgsGeometry(geom)

                    fet.setGeometry(nueva_geom)

                    # ============================================================
                    # ASIGNAR ATRIBUTOS USANDO LAS REGLAS DE RT_CONFIG
                    # ============================================================
                    atributos_asignados = 0

                    # Construir diccionario de origen
                    dict_origen = {}
                    for campo in field_names_origen:
                        try:
                            dict_origen[campo] = feature[campo]
                        except:
                            dict_origen[campo] = None

                    # 1. MAPEO DIRECTO (desde RT_CONFIG)
                    for campo_origen, campo_destino in MAPEO_DIRECTO.items():
                        try:
                            if campo_origen in field_names_origen:
                                valor = feature[campo_origen]
                                if valor is not None:
                                    fet.setAttribute(campo_destino, valor)
                                    atributos_asignados += 1
                        except Exception as e:
                            pass

                    # 2. OBTENER DATOS DEL CATÁLOGO
                    matricula = dict_origen.get(campo_identificador, '')
                    matricula_plan = dict_origen.get(campo_identificador_alt, '')

                    # Inicializar variable para matrícula extraída
                    matricula_extraida = None

                    # Si matricula es '9000' y matricula_plan es '9000' o está vacío,
                    # intentar extraer de Denominacion
                    if (matricula == '9000' or not matricula) and (matricula_plan == '9000' or not matricula_plan):
                        denominacion = dict_origen.get('Denominacion', '')
                        if denominacion:
                            matricula_extraida = self.extraer_matricula_de_denominacion(denominacion)
                            if matricula_extraida:
                                # Usar la matrícula extraída para buscar en el catálogo
                                matricula = matricula_extraida
                                matricula_plan = matricula_extraida
                                # Sobrescribir el campo 'nombre' que se asignó en MAPEO_DIRECTO
                                try:
                                    fet.setAttribute('nombre', matricula_extraida)
                                    fet.setAttribute('nombre_alt', matricula_extraida)
                                except Exception as e:
                                    print(f"Error asignando nombre extraído: {e}")

                    dict_catalogo = self.obtener_attr_catalogo(matricula, matricula_plan)

                    # 3. APLICAR REGLAS DE TRANSFORMACIÓN PARA CAMPOS NUMÉRICOS
                    dict_campos_calculados = {}  # Para almacenar valores calculados

                    for campo_destino in REGLAS_TRANSFORMACION.keys():
                        try:
                            # Obtener valor del catálogo si procede
                            valor_catalogo = None
                            if dict_catalogo is not None:
                                campo_catalogo = REGLAS_TRANSFORMACION[campo_destino].get('campo_catalogo')
                                if campo_catalogo:
                                    valor_catalogo = dict_catalogo.get(campo_catalogo)

                            # Aplicar transformación
                            valor = self.aplicar_transformacion(campo_destino, dict_origen, valor_catalogo)

                            if valor is not None:
                                fet.setAttribute(campo_destino, valor)
                                dict_campos_calculados[campo_destino] = valor  # Guardar para campos -d
                                atributos_asignados += 1
                        except Exception as e:
                            print(f"Error en transformación de {campo_destino}: {e}")

                    # 4. APLICAR REGLAS PARA CAMPOS DE TEXTO (SUFIJO -d)
                    for campo_destino in VALORES_TEXTO_RT.keys():
                        try:
                            valor = self.aplicar_transformacion_texto(campo_destino, dict_campos_calculados)

                            if valor is not None:
                                # Verificar que el campo existe en la capa destino
                                if campo_destino in [c['nombre'] for c in ESTRUCTURA_DESTINO.get('campos', [])]:
                                    fet.setAttribute(campo_destino, valor)
                                    atributos_asignados += 1
                        except Exception as e:
                            print(f"Error en transformación de texto {campo_destino}: {e}")


                    # AÑADIR EL FEATURE
                    if atributos_asignados > 5:
                        pr.addFeatures([fet])
                        count_ok += 1
                    else:
                        count_error += 1
                        if count_error <= 5:
                            matricula_val = dict_origen.get(campo_identificador, '?')
                            errores.append(f"Feature {idx}: Matricula={matricula_val} - Solo {atributos_asignados} atributos")

                except Exception as e:
                    count_error += 1
                    if count_error <= 5:
                        errores.append(f"Feature {idx}: {str(e)[:80]}")
                    print(f"Error en feature {idx}: {e}")

            # ================================================================
            # FINALIZAR CAPA EN MEMORIA
            # ================================================================

            try:
                capa_destino.commitChanges()
            except Exception as e:
                print(f"Error en commit: {e}")

            capa_destino.updateExtents()

            # ================================================================
            # EXPORTAR A GPKG
            # ================================================================
            if count_ok > 0:
                self.lblINFO.setText('INFO: Exportando a GPKG...')
                QApplication.processEvents()

                uri_salida = self.lneFICHsalida.text()
                if not uri_salida:
                    directorio_defecto = CONFIG_SALIDA.get('directorio_por_defecto', 'c:/temp')
                    archivo_defecto = CONFIG_SALIDA.get('nombre_archivo_por_defecto', 'RT_CASTILLA_LAMANCHA.gpkg')
                    uri_salida = os.path.join(directorio_defecto, archivo_defecto)
                    self.lneFICHsalida.setText(uri_salida)

                directorio = os.path.dirname(uri_salida)
                if directorio and not os.path.exists(directorio):
                    try:
                        os.makedirs(directorio)
                    except Exception as e:
                        self.fun.showMessageERR(f"No se pudo crear el directorio: {str(e)}")
                        QApplication.restoreOverrideCursor()
                        return

                error = self.guardar_capa_gpkg(capa_destino, uri_salida, nombre_capa)

                if error == QgsVectorFileWriter.NoError:
                    self.lblINFO.setText('INFO: Cargando capa desde GPKG...')
                    QApplication.processEvents()

                    capa_cargada = self.cargar_capa_gpkg(uri_salida, nombre_capa)

                    if capa_cargada:
                        root = QgsProject.instance().layerTreeRoot()
                        for child in root.children():
                            if child.name() == nombre_capa and isinstance(child, QgsLayerTreeLayer):
                                root.insertChildNode(0, child.clone())
                                root.removeChildNode(child)
                                break

                        self.aplicar_estilo_capa_destino(capa_cargada)
                        self.crear_indice_espacial(capa_cargada)
                    else:
                        errores.append("No se pudo cargar la capa desde GPKG")
                else:
                    errores.append(f"Error exportando a GPKG: {error}")
            else:
                self.fun.showMessageERR("No se migró ningún elemento. La capa no se exportará.")
                QApplication.restoreOverrideCursor()
                return

            # ================================================================
            # FINALIZAR
            # ================================================================
            self.progressBar.setValue(100)
            self.lblINFO.setText('INFO: Migración completada')

            tiempo = datetime.timedelta(seconds=(timeit.default_timer() - start))

            texto = f'MIGRACIÓN COMPLETADA'
            texto += f'\nElementos procesados: {total_features}'
            texto += f'\nElementos migrados: {count_ok}'
            texto += f'\nErrores: {count_error}'
            texto += f'\nTiempo: {str(tiempo).split(".")[0]}'
            texto += f'\n\nArchivo GPKG: {uri_salida}'
            texto += f'\nCapa en GPKG: {nombre_capa}'

            if errores:
                texto += f'\n\nErrores:'
                for err in errores[:5]:
                    texto += f'\n  - {err}'

            self.fun.showMessage("MIGRACIÓN EJES A RT", texto)

        except Exception as e:
            self.fun.showMessageERR(f"Error: {str(e)}")
            import traceback
            traceback.print_exc()
        finally:
            QApplication.restoreOverrideCursor()

    def aplicar_transformacion_texto(self, nombre_campo, dict_campos_calculados):
        """
        Aplica las reglas de transformación para campos de texto (sufijo -d)
        definidas en VALORES_TEXTO_RT.

        Args:
            nombre_campo (str): Nombre del campo destino (ej: 'tipo_viald')
            dict_campos_calculados (dict): Diccionario con los valores ya calculados
                                          de los campos numéricos

        Returns:
            str: Valor de texto transformado, o None si no hay regla
        """
        if nombre_campo not in VALORES_TEXTO_RT:
            return None

        regla = VALORES_TEXTO_RT[nombre_campo]

        # Si tiene reglas condicionales
        if 'reglas' in regla:
            for subregla in regla['reglas']:
                campo = subregla.get('campo')
                if not campo:
                    continue

                valor_campo = dict_campos_calculados.get(campo)
                if valor_campo is None:
                    continue

                # Caso 1: lista de valores exactos
                if 'valores' in subregla:
                    if valor_campo in subregla['valores']:
                        return subregla['resultado']

                # Caso 2: rango de valores (nuevo)
                if 'rango' in subregla:
                    try:
                        rango_min, rango_max = subregla['rango']
                        if isinstance(valor_campo, (int, float)) and rango_min <= valor_campo <= rango_max:
                            return subregla['resultado']
                    except (TypeError, ValueError):
                        pass

                # Caso 3: condición especial (not_empty)
                if subregla.get('condicion') == 'not_empty':
                    if valor_campo and str(valor_campo).strip():
                        return subregla['resultado']

        # Valor por defecto
        return regla.get('defecto')


    def extraer_matricula_de_denominacion(self, denominacion):
        """
        Extrae la matrícula de carretera del campo Denominacion.
        Busca patrones como: N-XXX, A-XXX, AP-XXX, CM-XXX, AB-XXX, etc.

        Ejemplos:
        - "Ant. CM-4019a (Mora de Toledo)" --> "CM-4019a"
        - "CM-9313 (Enlace)" --> "CM-9313"
        - "Enlace CM-41 - A-5" --> "CM-41" (toma el primero)
        - "N--401a" --> "N-401a" (corrige doble guión)
        """
        
        if not denominacion:
            return None

        # Patrón para matrículas de carretera
        # 1-3 letras mayúsculas, guión, 1-4 dígitos (opcional letra minúscula)
        patron = r'\b([A-Z]{1,3})-([0-9]{1,4}[a-z]?)\b'

        # Buscar todas las coincidencias
        matches = re.findall(patron, denominacion)

        if matches:
            # Tomar el primer match (el que aparece primero en el texto)
            letras, numeros = matches[0]
            matricula = f"{letras}-{numeros}"
            # Reemplazar posibles guiones dobles
            matricula = matricula.replace('--', '-')
            return matricula

        return None


    def mapear_tipo_campo(self, tipo_texto):
        tipos = {
            'String': QVariant.String,
            'Integer64': QVariant.LongLong,
            'Double': QVariant.Double,
            'Integer': QVariant.Int,
            'Real': QVariant.Double,
            'int': QVariant.Int,
            'str': QVariant.String,
            'float': QVariant.Double
        }
        return tipos.get(str(tipo_texto), QVariant.String)

    def guardar_capa_gpkg(self, capa, uri, nombre_capa):
        try:
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "GPKG"
            options.layerName = nombre_capa

            if os.path.exists(uri):
                options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

            error = QgsVectorFileWriter.writeAsVectorFormatV3(
                capa, uri, QgsCoordinateTransformContext(), options)
            return error[0]

            return error[0]

        except Exception as e:
            print(f"Error guardando: {e}")
            return QgsVectorFileWriter.ErrWriteError

    def cargar_capa_gpkg(self, uri, nombre_capa):
        try:
            uri_gpkg = f"{uri}|layername={nombre_capa}"
            capa = QgsVectorLayer(uri_gpkg, nombre_capa, "ogr")
            if capa.isValid():
                QgsProject.instance().addMapLayer(capa)
                return capa
            return None
        except Exception as e:
            print(f"Error cargando: {e}")
            return None


    def aplicar_estilo_capa_destino(self, capa):
        try:
            nombre_estilo = ESTILOS.get('destino', {}).get('archivo')

            if nombre_estilo:
                estiloCAPA = os.path.join(os.path.dirname(__file__), self.conf.general["carpeta_estilos"], nombre_estilo)
                estiloCAPA = os.path.normpath(estiloCAPA)

                if os.path.exists(estiloCAPA):
                    resultado, mensaje = capa.loadNamedStyle(estiloCAPA)
                    if mensaje:
                        self.msg_bar.pushMessage(
                            "Info",
                            f"Estilo cargado desde: {estiloCAPA}",
                            level=Qgis.Info, duration=3
                        )
                        return

            # Estilo por defecto
            color = ESTILOS.get('destino', {}).get('color', '#800080')
            ancho = ESTILOS.get('destino', {}).get('ancho', 0.8)

            simbolo = QgsSymbol.defaultSymbol(capa.geometryType())
            if simbolo:
                simbolo.setColor(QColor(color))
                simbolo.setWidth(ancho)
                capa.setRenderer(simbolo.clone())
                capa.triggerRepaint()
        except Exception as e:
            print(f"Error estilo: {e}")

    def crear_indice_espacial(self, capa):
        try:
            if hasattr(capa, 'createSpatialIndex'):
                capa.createSpatialIndex()
        except Exception as e:
            print(f"Error índice: {e}")
