#!/usr/bin/python
# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import QVariant, QMetaType

class configCreaCampos:
    listaDefinCampos = [
        {
        # CAMPOS A CREAR 'Datos Expropiaciones Consejeria +'
        'nameFields_to_add' : 'Datos Expropiaciones Consejeria +',
        'fields_to_add' : [
        # DATOS GENERALES
        {'name': 'EXPEDIENTE',  'type': QMetaType.Type.QString, 'len':  50, 'comment': "EXPEDIENTE.- Clave del expediente de Expropiaciones. Texto: 50", 'alias': 'EXPEDIENTE'},
        {'name': 'RC14',        'type': QMetaType.Type.QString, 'len':  20, 'comment': "Ref. Catrastal.- Referencia catastral o LOCALID -CASO DE RESTO PARCELA-.", 'alias': 'Ref. Catrastal 14Dig'},
        {'name': 'no_orden',    'type': QMetaType.Type.QString, 'len':  50, 'comment': "Nº Orden.- Número de orden de la finca relativo al proyecto; único para cada finca dentro del expediente.", 'alias': 'Nº Orden'},
        {'name': 'Entrada',     'type': QMetaType.Type.QString, 'len':  50, 'comment': "Entrada.- Tipo de dato PARCELA/TITULAR/BIENES. Texto: 50", 'alias': 'Entrada'},
        {'name': 'cod_parexp',  'type': QMetaType.Type.QString, 'len':  50, 'comment': "Dato Referencia: CLAVE(CCCCCCCCCC)+TIPOPRO(MMMM)+NORDEN(NNNN)+DATO1(DDDD) CCCCCCCCCCMMMMNNNNDDDD", 'alias': 'cod_parexp'},
        {'name': 'TIPORES',     'type': QMetaType.Type.QString, 'len': 25, 'comment': "TIPO PARCELA.- 'EXPRO', 'RESTO', 'DESCUENTO'", 'alias': 'TIPO PARCELA'},
        {'name': 'CAT_NMSPC',   'type': QMetaType.Type.QString, 'len': 25, 'comment': "Dato Namespace.- 'ES.SDGC.CP', 'ES.LOCAL.CP'", 'alias': 'Dato Namespace'},
        {'name': 'CAT_LOCALID', 'type': QMetaType.Type.QString, 'len': 25, 'comment': "Dato Localid.- Para 'ES.SDGC.CP', localid = RC; Para 'ES.LOCAL.CP', otro valor", 'alias': 'Dato Localid'},
        {'name': 'AREA_PARTE',  'type': QMetaType.Type.Double, 'len': 10, 'precision': 2, 'comment': "Superficie parte", 'alias': 'Superficie de la parte'},

        # DATOS PARCELA CATASTRAL
        {'name': 'term_munic',  'type': QMetaType.Type.QString, 'len': 150, 'comment': "term_munic.- Nombre término municipal donde radica la finca. Texto: 150", 'alias': 'term_munic'},
        {'name': 'cod_term_m',  'type': QMetaType.Type.QString, 'len':   5, 'comment': "Cod. Term. Municipal.- Código del término municipal donde radica la finca,", 'alias': 'Cod. Term. Municipal'},
        {'name': 'pedanía',     'type': QMetaType.Type.QString, 'len': 150, 'comment': "Pedanía.- En caso de que el término municipal esté dividido en pedanías, nombre de la pedanía donde se ubica la finca.", 'alias': 'Pedanía'},
        {'name': 'pol',         'type': QMetaType.Type.QString, 'len':   5, 'comment': "Poligono.- Polígono catastral donde se ubica la finca.", 'alias': 'Poligono'},
        {'name': 'par',         'type': QMetaType.Type.QString, 'len':   5, 'comment': "Parcela.- Parcela catastral donde se ubica la finca.", 'alias': 'Parcela'},
        {'name': 'subpar',      'type': QMetaType.Type.QString, 'len':   3, 'comment': "SubParcela.- Subparcela catastral donde ubica la finca (en caso de existir).", 'alias': 'SubParcela'},
        {'name': 'dirfinca',    'type': QMetaType.Type.QString, 'len': 255, 'comment': "Dirección.- Para aquellas fincas de las que se disponga de este dato.", 'alias': 'Dirección'},
        {'name': 'paraje',      'type': QMetaType.Type.QString, 'len': 255, 'comment': "Paraje.- Donde se encuentra la finca.", 'alias': 'Paraje'},
        {'name': 'uso',         'type': QMetaType.Type.QString, 'len': 150, 'comment': "Uso.- Uso del terreno de la finca.", 'alias': 'Uso'},
        {'name': 'concepto',    'type': QMetaType.Type.QString, 'len':  50, 'comment': "Concepto.- Dentro del proyecto a realizar, uso que se le dará al terreno; usado sobre todo por IACLM; ejemplo EDAR, línea eléctrica, tubería…", 'alias': 'Concepto'},
        {'name': 'tipopropi',   'type': QMetaType.Type.QString, 'len':   1, 'comment': "Propiedad Pública.- 0 en caso de propiedad privada, 1 en caso de propiedad a nombre de la JCCM y 2 en caso de propiedad pública no JCCM.", 'alias': 'Propiedad Pública'},
        {'name': 'supcat',      'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Superf. Catastral Comp.- Superficie completa de la finca según el catastro en metros cuadrados.", 'alias': 'Superf. Catastral Comp'},
        {'name': 'calificacion','type': QMetaType.Type.QString, 'len':   5, 'comment': "Calificación.- Urbana (U), o Rústica (R). Toda la columna de contener o R o U. Si es Dominio Público poner R.", 'alias': 'Calificación'},
 
        # DATOS CARRETERA
        {'name': 'carretera',    'type': QMetaType.Type.QString, 'len':  50, 'comment': "carretera.- CARRETERA. Texto: 50", 'alias': 'carretera'},
        {'name': 'pk',           'type': QMetaType.Type.QString, 'len':  20, 'comment': "pk.- pk en metros y en texto del inicio/centro de la finca", 'alias': 'PK'},
        {'name': 'margen',       'type': QMetaType.Type.QString, 'len':   5, 'comment': "margen.- Margen D/I/AMBOS", 'alias': 'margen'},
        {'name': 'plano',        'type': QMetaType.Type.QString, 'len':   5, 'comment': "plano.- Plano del proyecto donde encontrar la parcela", 'alias': 'plano'},
 
        # DATOS SUPERFICIES EXPROPIACIÓN
        {'name': 'superfnum',   'type': QMetaType.Type.Int, 'comment': "Num. Superficies.- Número de Superficies de distinto Valor.", 'alias': 'Num. Superf'},
        {'name': 'superfpd',    'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Superf. P.D.- Superficie en metros cuadrados a ser expropiada en pleno dominio.", 'alias': 'Superf. P.D'},
        {'name': 'valorunitpd', 'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Valor Unit. P.D.- Valor unitario por metro cuadrado que supone la expropiación en pleno dominio de esta finca.", 'alias': 'Valor Unit. P.D'},
        {'name': 'importepd',   'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Importe P.D.- Importe total a abonar por la parte expropiada en pleno dominio.", 'alias': 'Importe P.D'},
        {'name': 'superfot',    'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Superf. O.T.- Superficie en metros cuadrados a ser expropiada en ocupación temporal.", 'alias': 'Superf. O.T'},
        {'name': 'valorunitot', 'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Valor Unit. O.T.- Valor unitario por metro cuadrado que supone la expropiación en ocupación temporal de esta finca.", 'alias': 'Valor Unit. O.T'},
        {'name': 'importeot',   'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Importe O.T.- Importe total a abonar por la parte expropiada en ocupación temporal.", 'alias': 'Importe O.T'},
        {'name': 'superfsp',    'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Superf. S.P.- Superficie en metros cuadrados a ser expropiada en servidumbre de paso.", 'alias': 'Superf. S.P'},
        {'name': 'valorunitsp', 'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Valor Unit. S.P.- Valor unitario por metro cuadrado que supone la expropiación en servidumbre de paso de esta finca.", 'alias': 'Valor Unit. S.P'},
        {'name': 'importesp',   'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Importe S.P.- Importe total a abonar por la parte expropiada en servidumbre de paso.", 'alias': 'Importe S.P'},
        {'name': 'superfsv',    'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Superf. S.V.- Superficie en metros cuadrados a ser expropiada en servidumbre de vuelo.", 'alias': 'Superf. S.V'},
        {'name': 'valorunitsv', 'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Valor Unit. S.V.- Valor unitario por metro cuadrado que supone la expropiación en servidumbre de vuelo de esta finca.", 'alias': 'Valor Unit. S.V'},
        {'name': 'importesv',   'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Importe S.V.- Importe total a abonar por la parte expropiada en servidumbre de vuelo.", 'alias': 'Importe S.V'},

        # DATOS BIENES EXPROPIACIÓN
        {'name': 'bienesComp',  'type': QMetaType.Type.QString, 'len': 255, 'comment': "Bienes Completos.- Bienes y superficies/unidades", 'alias': 'Bienes Completos'},
        {'name': 'bienesDistnum','type':QMetaType.Type.Int,                'comment': "Num. Bienes distintos.- Número de distintos Bienes valorados.", 'alias': 'Num. Bienes distintos'},
        {'name': 'numBie',      'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Num. Bienes VU.- Número de Bienes por Valor Unitario.", 'alias': 'Num. Bienes VU'},
        {'name': 'valorunitBin','type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Valor Unit. Bienes.- Valor unitario de cada tipo de bienes.", 'alias': 'Valor Unit. Bienes'},
        {'name': 'importeBie',  'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Importe Bienes.- Importe total Bienes.", 'alias': 'Importe Bienes'},
        {'name': 'importeTotal','type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Importe TOTAL Tit.- Importe total PD+OT+SP+SV+BIE.", 'alias': 'Importe TOTAL Tit'},

        # DATOS LINDEROS
        {'name': 'lindeN',      'type': QMetaType.Type.QString, 'len': 200, 'comment': "Linderos Norte.- Linderos Norte de la parte a expropiar.", 'alias': 'Linderos Norte'},
        {'name': 'lindeS',      'type': QMetaType.Type.QString, 'len': 200, 'comment': "Linderos Sur.- Linderos Sur de la parte a expropiar.", 'alias': 'Linderos Sur'},
        {'name': 'lindeE',      'type': QMetaType.Type.QString, 'len': 200, 'comment': "Linderos Este.- Linderos Este de la parte a expropiar.", 'alias': 'Linderos Este'},
        {'name': 'lindeO',      'type': QMetaType.Type.QString, 'len': 200, 'comment': "Linderos Oeste.- Linderos Oeste de la parte a expropiar.", 'alias': 'Linderos Oeste'},

        # DATOS REGISTRALES
        {'name': 'registro',    'type': QMetaType.Type.QString, 'len': 100, 'comment': "Registro.- Datos registrales que se rellenarán en caso de ser conocidos", 'alias': 'Registro'},
        {'name': 'regtomo',     'type': QMetaType.Type.QString, 'len':  20, 'comment': "Tomo, Datos registrales que se rellenarán en caso de ser conocidos.", 'alias': 'Tomo'},
        {'name': 'reglibro',    'type': QMetaType.Type.QString, 'len':  20, 'comment': "Libro, Datos registrales que se rellenarán en caso de ser conocidos.", 'alias': 'Libro'},
        {'name': 'regfolio',    'type': QMetaType.Type.QString, 'len':  20, 'comment': "Folio, Datos registrales que se rellenarán en caso de ser conocidos.", 'alias': 'Folio'},
        {'name': 'regfinca',    'type': QMetaType.Type.QString, 'len':  20, 'comment': "Finca, Datos registrales que se rellenarán en caso de ser conocidos.", 'alias': 'Finca'},
        {'name': 'regsuperf',   'type': QMetaType.Type.QString, 'len':  20, 'comment': "Superficie Registral Completa.- Datos registrales que se rellenarán en caso de ser conocidos.", 'alias': 'Superficie Registral Completa'},

        # DATOS TITULARES
        {'name': 'titunum',     'type': QMetaType.Type.Int,                'comment': "Num. Titulares.- Número de titulares.", 'alias': 'Num. Titulares'},
        {'name': 'titunombre',  'type': QMetaType.Type.QString, 'len': 100, 'comment': "Nombre del Titular.- Nombre del titular de la finca o del derecho.", 'alias': 'Nombre del Titular'},
        {'name': 'tituapelli',  'type': QMetaType.Type.QString, 'len': 200, 'comment': "Apellidos del Titular.- Apellidos del titular de la finca o del derecho.", 'alias': 'Apellidos del Titular'},
        {'name': 'tituDNI',     'type': QMetaType.Type.QString, 'len':  50, 'comment': "DNI/NIF.- Dni o Nif del titular de la finca", 'alias': 'DNI/NIF'},
        {'name': 'tituDirNot',  'type': QMetaType.Type.QString, 'len': 255, 'comment': "Dirección Notificaciones.- Dirección donde el titular quiere que se envíen las notificaciones", 'alias': 'Dirección Notificaciones'},
        {'name': 'tituPorProp', 'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "% Propiedad.- Tanto por ciento de propiedad sobre la finca que tiene el titular; 100 en caso de titular único, 0 en caso de desconocimiento ,-1 en caso de arrendatario, -2 en caso de usufructuario y -3 en caso de concesionario", 'alias': '% Propiedad'},
        {'name': 'titulo',      'type': QMetaType.Type.QString, 'len': 200, 'comment': "Título Propiedad.- Título Propiedad o derecho.", 'alias': 'Título Propiedad'},

        # DATOS REPRESENTANTE
        {'name': 'repnombre',   'type': QMetaType.Type.QString, 'len': 100, 'comment': "Nombre del REP.- Nombre del REPRESENTANTE del titular de la finca o del derecho.", 'alias': 'Nombre del Rep'},
        {'name': 'repapelli',   'type': QMetaType.Type.QString, 'len': 200, 'comment': "Apellidos del REP.- Apellidos del REPRESENTANTE del titular de la finca o del derecho.", 'alias': 'Apellidos del Rep'},
        {'name': 'repuDNI',     'type': QMetaType.Type.QString, 'len':  50, 'comment': "DNI/NIF Rep.- Dni o Nif del REPRESENTANTE", 'alias': 'DNI/NIF Rep.'},

        # DATOS TITULARES OTROS DERECHOS
        {'name': 'tituDnum',    'type': QMetaType.Type.Int,                'comment': "Num. Tit. Otros Der.- Número de titulares (arrendador) de otros derechos.", 'alias': 'Num. Tit. Otros Der'},
        {'name': 'Derecho',     'type': QMetaType.Type.QString, 'len': 100, 'comment': "Derecho.- Derecho por el que se indemniza al arrendatario.", 'alias': 'Derecho'},
        {'name': 'tituDnombre', 'type': QMetaType.Type.QString, 'len': 100, 'comment': "Nombre Tit. Otros Der.- Nombre del titular del derecho.", 'alias': 'Nombre Tit. Otros Der'},
        {'name': 'tituDapelli', 'type': QMetaType.Type.QString, 'len': 200, 'comment': "Apellidos Tit. Otros Der.- Apellidos del titular del derecho.", 'alias': 'Apellidos Tit. Otros Der'},
        {'name': 'tituDerDNI',  'type': QMetaType.Type.QString, 'len':  50, 'comment': "DNI/NIF Otros Der.- Dni o Nif del titular del derecho", 'alias': 'DNI/NIF Otros Der'},
        {'name': 'tituDerDirNot', 'type': QMetaType.Type.QString, 'len': 255, 'comment': "Dir. Notif. Otros Der.- Dirección del titular del derecho", 'alias': 'Dir. Notif. Otros Der'},
        {'name': 'SuperfDER',   'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Superf. D.- Superficie en metros cuadrados a ser expropiados que afectan al derecho correspondiente.", 'alias': 'Superf. D'},
        {'name': 'ValorUnitD',  'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Valor Unit. D.- Valor unitario por metro cuadrado que supone la expropiación del derecho correspondiente", 'alias': 'Valor Unit. D'},
        {'name': 'ImporteD',    'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Importe D.- Importe total a abonar por la parte expropiada que afecta al derecho correspondiente.", 'alias': 'Importe D'},

        # DATOS EXPEDIENTE
        {'name': 'CodUniActa',  'type': QMetaType.Type.QString, 'len':  25, 'comment': "Cod. Unico Acta.- Codigo único acta (formado por clave expte+numorden+digito) VALOR INDICE.", 'alias': 'Cod. Unico Acta'},
        {'name': 'Carta',       'type': QMetaType.Type.QString, 'len':  25, 'comment': "Carta.- Recibe carta SI/NO.", 'alias': 'Carta'},
        {'name': 'FechaLAP',    'type': QMetaType.Type.QString, 'len':  25, 'comment': "Fecha Firma LAP.- Fecha Firma Levantamiento Actas Previas.", 'alias': 'Fecha Firma LAP'},
        {'name': 'horaCitaLAP', 'type': QMetaType.Type.QString, 'len':  25, 'comment': "Hora Cita LAP.- Hora Cita Levantamiento Actas Previas.", 'alias': 'Hora Cita LAP'},
        {'name': 'firmaLAP',    'type': QMetaType.Type.QString, 'len':  25, 'comment': "Firma LAP.- Firma Levantamiento actas Previas SI/NO.", 'alias': 'Firma LAP'},
        {'name': 'firmaJP',     'type': QMetaType.Type.QString, 'len':  25, 'comment': "Firma JP.- Firma Justiprecio SI/NO.", 'alias': 'Firma JP'},
        {'name': 'JuradoRV',    'type': QMetaType.Type.QString, 'len':  25, 'comment': "Jurado Reg. Val.- Acude a Jurado de Valoraciones SI/NO.", 'alias': 'Jurado Reg. Val'},
        {'name': 'ImporteDP',   'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Importe Dep. Previo.- Importe Depósito Previo.", 'alias': 'Importe Dep. Previo'},
        {'name': 'RenunciaDP',  'type': QMetaType.Type.QString, 'len':  25, 'comment': "Renuncia Dep. Previo.- Renuncia Dep. Prev. SI/NO.", 'alias': 'Renuncia Dep. Previo'},
        {'name': 'Intereses',   'type': QMetaType.Type.Double, 'len':  10, 'precision': 2, 'comment': "Importe Intereses Demora.- Importe Intereses Demora.", 'alias': 'Importe Intereses Demora'},
        {'name': 'ResolJudi',   'type': QMetaType.Type.QString, 'len': 255, 'comment': "Resolucion Judicial.- Datos Resolución Judicial.", 'alias': 'Resolucion Judicial'},
        {'name': 'DiaPago',     'type': QMetaType.Type.QString, 'len':  25, 'comment': "Fecha Pago.- Fecha de Pago.", 'alias': 'Fecha Pago'},

        # DATOS CAPA PARA GML
        {'name': 'Observaciones', 'type': QMetaType.Type.QString, 'len': 255, 'comment': "Observaciones.- ", 'alias': 'Observaciones'},
        {'name': 'X_LABEL',     'type': QMetaType.Type.Double, 'len': 10, 'precision': 2, 'comment': "X_LABEL. - X para etiquetado", 'alias': 'X_LABEL'},
        {'name': 'Y_LABEL',     'type': QMetaType.Type.Double, 'len': 10, 'precision': 2, 'comment': "Y_LABEL. - Y para etiquetado", 'alias': 'Y_LABEL'}
        ]
        }
        # Se pueden añadir más configuraciones de campos aquí
        ]
        
class configEquivalenciaDatos:
    """
    # Define las equivalencias de datos según el tipo seleccionado
        campoNue:  'EXPEDIENTE',    Nombre del campo nuevo creado al que se le asignan equivalencias
        tipoEQUIV: 'CAMPO',         Tipo de equivalencia.   CAMPO: Asigna el valor del campoANT a campoNue
                                                            VALOR: Asigna el valor fijo de 'valor' al campoNue
                                                            FORMULA: Asigna el valor del resultado de 'formula'
        campoANT:  'expt_expro',    Nombre del campo antiguo desde el que se asigna atributo al campo nuevo
        valor:     '',              Valor fijo asignado caso de tipoEQUIV: 'VALOR'
        formula:   ''               Fórmula que calcular caso de tipoEQUIV: 'FORMULA'
                                        ej: 'geometry().area()'
    
    """

    listaEquivalenciaDatos = [
        {
        'nameEquivalenciaDatos' : 'Datos Parcelas anteriores 2025',
        'equivalenciaDatos' : [
            # DATOS GENERALES
            {'campoNue': 'EXPEDIENTE', 'tipoEQUIV': 'CAMPO', 'campoANT': 'expt_expro', 'valor': '', 'formula': ''},
            {'campoNue': 'RC14', 'tipoEQUIV': 'CAMPO', 'campoANT': 'ref_cat', 'valor': '', 'formula': ''},
            {'campoNue': 'cod_parexp', 'tipoEQUIV': 'CAMPO', 'campoANT': 'cod_parexp', 'valor': '', 'formula': ''},
            {'campoNue': 'TIPORES', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': 'EXPRO', 'formula': ''},
            {'campoNue': 'CAT_NMSPC', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': 'ES.SDGC.CP', 'formula': ''},
            {'campoNue': 'CAT_LOCALID', 'tipoEQUIV': 'CAMPO', 'campoANT': 'ref_cat', 'valor': '', 'formula': ''},
            {'campoNue': 'AREA_PARTE', 'tipoEQUIV': 'FORMULA', 'campoANT': '', 'valor': '', 'formula': 'geometry().area()'},
            
            # DATOS PARCELA CATASTRAL
            {'campoNue': 'term_munic', 'tipoEQUIV': 'CAMPO', 'campoANT': 'term_muni', 'valor': '', 'formula': ''},
            {'campoNue': 'cod_term_m', 'tipoEQUIV': 'CAMPO', 'campoANT': 'cod_term_m', 'valor': '', 'formula': ''},
            {'campoNue': 'uso', 'tipoEQUIV': 'CAMPO', 'campoANT': 'tipo', 'valor': '', 'formula': ''},
            {'campoNue': 'concepto', 'tipoEQUIV': 'VALOR', 'campoANT': 'FUNCIONALIDAD', 'valor': '', 'formula': ''},
            {'campoNue': 'tipopropi', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '0', 'formula': ''},
            {'campoNue': 'supcat', 'tipoEQUIV': 'CAMPO', 'campoANT': 'sup_cat', 'valor': '', 'formula': ''},
            {'campoNue': 'calificacion', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': 'R', 'formula': ''},
            
            # DATOS BIENES EXPROPIACIÓN
            {'campoNue': 'bienesComp', 'tipoEQUIV': 'CAMPO', 'campoANT': 'bienes1', 'valor': '', 'formula': ''},
            
            # DATOS CAPA PARA GML
            {'campoNue': 'Observaciones', 'tipoEQUIV': 'CAMPO', 'campoANT': 'data1', 'valor': '', 'formula': ''},
            {'campoNue': 'X_LABEL', 'tipoEQUIV': 'FORMULA', 'campoANT': '', 'valor': '', 'formula': 'geometry().centroid().x()'},
            {'campoNue': 'Y_LABEL', 'tipoEQUIV': 'FORMULA', 'campoANT': '', 'valor': '', 'formula': 'geometry().centroid().y()'},
            ]
        },
        {
        'nameEquivalenciaDatos' : 'Listado Afectados BBDD Del. Prov. AB',
        'equivalenciaDatos' : [
            # DATOS GENERALES
            {'campoNue': 'EXPEDIENTE', 'tipoEQUIV': 'CAMPO', 'campoANT': 'CLAVE', 'valor': '', 'formula': ''},
            {'campoNue': 'RC14', 'tipoEQUIV': 'CAMPO', 'campoANT': 'REFCAT', 'valor': '', 'formula': ''},
            {'campoNue': 'no_orden', 'tipoEQUIV': 'CAMPO', 'campoANT': 'NO_DIG', 'valor': '', 'formula': ''},
            {'campoNue': 'Entrada', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': 'PARCELA', 'formula': ''},
            # {'campoNue': 'cod_parexp', 'tipoEQUIV': 'CAMPO', 'campoANT': 'cod_parexp', 'valor': '', 'formula': ''},
            # {'campoNue': 'TIPORES', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': 'EXPRO', 'formula': ''},
            # {'campoNue': 'CAT_NMSPC', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': 'ES.SDGC.CP', 'formula': ''},
            {'campoNue': 'CAT_LOCALID', 'tipoEQUIV': 'CAMPO', 'campoANT': 'REFCAT', 'valor': '', 'formula': ''},
            # {'campoNue': 'AREA_PARTE', 'tipoEQUIV': 'FORMULA', 'campoANT': '', 'valor': '', 'formula': 'geometry().area()'},
            
            # DATOS PARCELA CATASTRAL
            {'campoNue': 'term_munic', 'tipoEQUIV': 'CAMPO', 'campoANT': 'TM', 'valor': '', 'formula': ''},
            {'campoNue': 'cod_term_m', 'tipoEQUIV': 'CAMPO', 'campoANT': 'CDCMC', 'valor': '', 'formula': ''},
            # {'campoNue': 'pedanía', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            {'campoNue': 'pol', 'tipoEQUIV': 'CAMPO', 'campoANT': 'Poligono', 'valor': '', 'formula': ''},
            {'campoNue': 'par', 'tipoEQUIV': 'CAMPO', 'campoANT': 'Parcela', 'valor': '', 'formula': ''},
            {'campoNue': 'subpar', 'tipoEQUIV': 'CAMPO', 'campoANT': 'SUBPARCE', 'valor': '', 'formula': ''},
            # {'campoNue': 'dirfinca', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'paraje', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'uso', 'tipoEQUIV': 'CAMPO', 'campoANT': 'tipo', 'valor': '', 'formula': ''},
            # {'campoNue': 'concepto', 'tipoEQUIV': 'VALOR', 'campoANT': 'FUNCIONALIDAD', 'valor': '', 'formula': ''},
            # {'campoNue': 'tipopropi', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '0', 'formula': ''},
            # {'campoNue': 'supcat', 'tipoEQUIV': 'CAMPO', 'campoANT': 'sup_cat', 'valor': '', 'formula': ''},
            {'campoNue': 'calificacion', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': 'R', 'formula': ''},
            
            # # DATOS CARRETERA
            # {'campoNue': 'carretera', 'tipoEQUIV': 'CAMPO', 'campoANT': 'carretera', 'valor': '', 'formula': ''},
            # {'campoNue': 'pk', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'margen', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'plano', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            
            # # DATOS SUPERFICIES EXPROPIACIÓN
            # {'campoNue': 'superfnum', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'superfpd', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'valorunitpd', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'importepd', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'superfot', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'valorunitot', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'importeot', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'superfsp', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'valorunitsp', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'importesp', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'superfsv', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'valorunitsv', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'importesv', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            
            # # DATOS BIENES EXPROPIACIÓN
            {'campoNue': 'bienesComp', 'tipoEQUIV': 'FORMULA', 'campoANT': 'bienes1', 'valor': '', 
                'formula':  "[CULT1]+' ('+[M2_1] +') / '+[CULT2]+' ('+[M2_2] +')'"},
            # {'campoNue': 'bienesDistnum', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'numBie', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'valorunitBin', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'importeBie', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'importeTotal', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            
            # # DATOS LINDEROS
            # {'campoNue': 'lindeN', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'lindeS', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'lindeE', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'lindeO', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            
            # # DATOS REGISTRALES
            # {'campoNue': 'registro', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'regtomo', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'reglibro', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'regfolio', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'regfinca', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'regsuperf', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            
            # # DATOS TITULARES
            # {'campoNue': 'titunum', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'titunombre', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'tituapelli', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'tituDNI', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'tituDirNot', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'tituPorProp', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'titulo', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            
            # # DATOS REPRESENTANTE
            # {'campoNue': 'repnombre', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'repapelli', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'repuDNI', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            
            # # DATOS TITULARES OTROS DERECHOS
            # {'campoNue': 'tituDnum', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'Derecho', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'tituDnombre', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'tituDapelli', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'tituDerDNI', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'tituDerDirNot', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'SuperfDER', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'ValorUnitD', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'ImporteD', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            
            # # DATOS EXPEDIENTE
            # {'campoNue': 'CodUniActa', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'Carta', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'FechaLAP', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'horaCitaLAP', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'firmaLAP', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'firmaJP', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'JuradoRV', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'ImporteDP', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'RenunciaDP', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'Intereses', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'ResolJudi', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            # {'campoNue': 'DiaPago', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
            
            # # DATOS CAPA PARA GML
            # {'campoNue': 'Observaciones', 'tipoEQUIV': 'CAMPO', 'campoANT': 'data1', 'valor': '', 'formula': ''},
            # {'campoNue': 'X_LABEL', 'tipoEQUIV': 'FORMULA', 'campoANT': '', 'valor': '', 'formula': 'geometry().centroid().x()'},
            # {'campoNue': 'Y_LABEL', 'tipoEQUIV': 'FORMULA', 'campoANT': '', 'valor': '', 'formula': 'geometry().centroid().y()'},
        ]
        }
    ]



'''
if tipoEquivDatos == 'Datos Parcelas anteriores 2025':  # Nombre del tipo de equialencias
    equivalenciaDatos = [
        # DATOS GENERALES
        {'campoNue': 'EXPEDIENTE', 'tipoEQUIV': 'CAMPO', 'campoANT': 'expt_expro', 'valor': '', 'formula': ''},
        {'campoNue': 'RC14', 'tipoEQUIV': 'CAMPO', 'campoANT': 'ref_cat', 'valor': '', 'formula': ''},
        {'campoNue': 'no_orden', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'Entrada', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': 'PARCELA', 'formula': ''},
        {'campoNue': 'cod_parexp', 'tipoEQUIV': 'CAMPO', 'campoANT': 'cod_parexp', 'valor': '', 'formula': ''},
        {'campoNue': 'TIPORES', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': 'EXPRO', 'formula': ''},
        {'campoNue': 'CAT_NMSPC', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': 'ES.SDGC.CP', 'formula': ''},
        {'campoNue': 'CAT_LOCALID', 'tipoEQUIV': 'CAMPO', 'campoANT': 'ref_cat', 'valor': '', 'formula': ''},
        {'campoNue': 'AREA_PARTE', 'tipoEQUIV': 'FORMULA', 'campoANT': '', 'valor': '', 'formula': 'geometry().area()'},
        
        # DATOS PARCELA CATASTRAL
        {'campoNue': 'term_munic', 'tipoEQUIV': 'CAMPO', 'campoANT': 'term_muni', 'valor': '', 'formula': ''},
        {'campoNue': 'cod_term_m', 'tipoEQUIV': 'CAMPO', 'campoANT': 'cod_term_m', 'valor': '', 'formula': ''},
        {'campoNue': 'pedanía', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'pol', 'tipoEQUIV': 'CAMPO', 'campoANT': 'pol', 'valor': '', 'formula': ''},
        {'campoNue': 'par', 'tipoEQUIV': 'CAMPO', 'campoANT': 'par', 'valor': '', 'formula': ''},
        {'campoNue': 'subpar', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'dirfinca', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'paraje', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'uso', 'tipoEQUIV': 'CAMPO', 'campoANT': 'tipo', 'valor': '', 'formula': ''},
        {'campoNue': 'concepto', 'tipoEQUIV': 'VALOR', 'campoANT': 'FUNCIONALIDAD', 'valor': '', 'formula': ''},
        {'campoNue': 'tipopropi', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '0', 'formula': ''},
        {'campoNue': 'supcat', 'tipoEQUIV': 'CAMPO', 'campoANT': 'sup_cat', 'valor': '', 'formula': ''},
        {'campoNue': 'calificacion', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': 'R', 'formula': ''},
        
        # DATOS CARRETERA
        {'campoNue': 'carretera', 'tipoEQUIV': 'CAMPO', 'campoANT': 'carretera', 'valor': '', 'formula': ''},
        {'campoNue': 'pk', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'margen', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'plano', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        
        # DATOS SUPERFICIES EXPROPIACIÓN
        {'campoNue': 'superfnum', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'superfpd', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'valorunitpd', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'importepd', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'superfot', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'valorunitot', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'importeot', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'superfsp', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'valorunitsp', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'importesp', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'superfsv', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'valorunitsv', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'importesv', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        
        # DATOS BIENES EXPROPIACIÓN
        {'campoNue': 'bienesComp', 'tipoEQUIV': 'CAMPO', 'campoANT': 'bienes1', 'valor': '', 'formula': ''},
        {'campoNue': 'bienesDistnum', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'numBie', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'valorunitBin', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'importeBie', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'importeTotal', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        
        # DATOS LINDEROS
        {'campoNue': 'lindeN', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'lindeS', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'lindeE', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'lindeO', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        
        # DATOS REGISTRALES
        {'campoNue': 'registro', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'regtomo', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'reglibro', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'regfolio', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'regfinca', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'regsuperf', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        
        # DATOS TITULARES
        {'campoNue': 'titunum', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'titunombre', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'tituapelli', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'tituDNI', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'tituDirNot', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'tituPorProp', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'titulo', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        
        # DATOS REPRESENTANTE
        {'campoNue': 'repnombre', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'repapelli', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'repuDNI', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        
        # DATOS TITULARES OTROS DERECHOS
        {'campoNue': 'tituDnum', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'Derecho', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'tituDnombre', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'tituDapelli', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'tituDerDNI', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'tituDerDirNot', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'SuperfDER', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'ValorUnitD', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'ImporteD', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        
        # DATOS EXPEDIENTE
        {'campoNue': 'CodUniActa', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'Carta', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'FechaLAP', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'horaCitaLAP', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'firmaLAP', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'firmaJP', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'JuradoRV', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'ImporteDP', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'RenunciaDP', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'Intereses', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'ResolJudi', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        {'campoNue': 'DiaPago', 'tipoEQUIV': 'VALOR', 'campoANT': '', 'valor': '', 'formula': ''},
        
        # DATOS CAPA PARA GML
        {'campoNue': 'Observaciones', 'tipoEQUIV': 'CAMPO', 'campoANT': 'data1', 'valor': '', 'formula': ''},
        {'campoNue': 'X_LABEL', 'tipoEQUIV': 'FORMULA', 'campoANT': '', 'valor': '', 'formula': 'geometry().centroid().x()'},
        {'campoNue': 'Y_LABEL', 'tipoEQUIV': 'FORMULA', 'campoANT': '', 'valor': '', 'formula': 'geometry().centroid().y()'},
    ]

# EJEMPLOS:
# Concatenación de campos
# {'campoNue': 'Observaciones', 'tipoEQUIV': 'FORMULA', 'campoANT': '', 'valor': '', 'formula': "[dato1]+' / '+[dato2]+' / '+[dato3]"}
# Cálculo entre campos
# {'campoNue': 'superfpd', 'tipoEQUIV': 'FORMULA', 'campoANT': '', 'valor': '', 'formula': "[area_total] / 1000"}

# RESUMEN ESTRUCTURA CAMPOS
# -------------------------

# ### DATOS PARCELA CATASTRAL
# - EXPEDIENTE.- Clave del expediente de Expropiaciones. Texto: 50 
# - Nº Orden.- Número de orden de la finca relativo al proyecto; único para cada finca dentro del expediente
# - Entrada.- Tipo de dato PARCELA/TITULAR/BIENES. Texto: 50
# - term_munic.- Nombre término municipal donde radica la finca. Texto: 150
# - Cod. Term. Municipal.- Código del término municipal donde radica la finca
# - Pedanía.- En caso de que el término municipal esté dividido en pedanías, nombre de la pedanía donde se ubica la finca
# - Poligono.- Polígono catastral donde se ubica la finca
# - Parcela.- Parcela catastral donde se ubica la finca
# - SubParcela.- Subparcela catastral donde ubica la finca (en caso de existir)
# - Ref. Catrastal.- Referencia catastral o LOCALID -CASO DE RESTO PARCELA-
# - Dirección.- Para aquellas fincas de las que se disponga de este dato
# - Paraje.- Donde se encuentra la finca
# - Uso.- Uso del terreno de la finca
# - Concepto.- Dentro del proyecto a realizar, uso que se le dará al terreno; usado sobre todo por IACLM; ejemplo EDAR, línea eléctrica, tubería
# - Propiedad Pública.- 0 en caso de propiedad privada, 1 en caso de propiedad a nombre de la JCCM y 2 en caso de propiedad pública no JCCM.", 'alias': 'Propiedad Pública'
# - Superf. Catastral Comp.- Superficie completa de la finca según el catastro en metros cuadrados
# - Calificación.- Urbana (U), o Rústica (R). Toda la columna de contener o R o U. Si es Dominio Público poner R

# ### DATOS SUPERFICIES EXPROPIACIÓN
# - Num. Superficies.- Número de Superficies de distinto Valor.
# - Superf. P.D.- Superficie en metros cuadrados a ser expropiada en pleno dominio.
# - Valor Unit. P.D.- Valor unitario por metro cuadrado que supone la expropiación en pleno dominio de esta finca.
# - Importe P.D.- Importe total a abonar por la parte expropiada en pleno dominio.
# - Superf. O.T.- Superficie en metros cuadrados a ser expropiada en ocupación temporal.
# - Valor Unit. O.T.- Valor unitario por metro cuadrado que supone la expropiación en ocupación temporal de esta finca.
# - Importe O.T.- Importe total a abonar por la parte expropiada en ocupación temporal.
# - Superf. S.P.- Superficie en metros cuadrados a ser expropiada en servidumbre de paso.
# - Valor Unit. S.P.- Valor unitario por metro cuadrado que supone la expropiación en servidumbre de paso de esta finca.
# - Importe S.P.- Importe total a abonar por la parte expropiada en servidumbre de paso.
# - Superf. S.V.- Superficie en metros cuadrados a ser expropiada en servidumbre de vuelo.
# - Valor Unit. S.V.- Valor unitario por metro cuadrado que supone la expropiación en servidumbre de vuelo de esta finca.
# - Importe S.V.- Importe total a abonar por la parte expropiada en servidumbre de vuelo.

# # DATOS BIENES EXPROPIACIÓN
# - Num. Bienes distintos.- Número de distintos Bienes valorados.
# - Num. Bienes VU.- Número de Bienes por Valor Unitario.
# - Valor Unit. Bienes.- Valor unitario de cada tipo de bienes.
# - Importe Bienes.- Importe total Bienes.
# - Importe TOTAL Tit.- Importe total PD+OT+SP+SV+BIE.

# # DATOS LINDEROS
# - Linderos Norte.- Linderos Norte de la parte a expropiar.
# - Linderos Sur.- Linderos Sur de la parte a expropiar.
# - Linderos Este.- Linderos Este de la parte a expropiar.
# - Linderos Oeste.- Linderos Oeste de la parte a expropiar.

# # DATOS REGISTRALES
# - Registro.- Datos registrales que se rellenarán en caso de ser conocidos
# - Tomo, Datos registrales que se rellenarán en caso de ser conocidos.
# - Libro, Datos registrales que se rellenarán en caso de ser conocidos.
# - Folio, Datos registrales que se rellenarán en caso de ser conocidos.
# - Finca, Datos registrales que se rellenarán en caso de ser conocidos.
# - Superficie Registral Completa.- Datos registrales que se rellenarán en caso de ser conocidos.

# # DATOS TITULARES
# - Num. Titulares.- Número de titulares.
# - Nombre del Titular.- Nombre del titular de la finca o del derecho.
# - Apellidos del Titular.- Apellidos del titular de la finca o del derecho.
# - DNI/NIF.- Dni o Nif del titular de la finca
# - Dirección Notificaciones.- Dirección donde el titular quiere que se envíen las notificaciones
# - % Propiedad.- Tanto por ciento de propiedad sobre la finca que tiene el titular; 100 en caso de titular único, 0 en caso de desconocimiento ,-1 en caso de arrendatario, -2 en caso de usufructuario y -3 en caso de concesionario
# - Título Propiedad.- Título Propiedad o derecho.

# # DATOS REPRESENTANTE
# - Nombre del REP.- Nombre del REPRESENTANTE del titular de la finca o del derecho.
# - Apellidos del REP.- Apellidos del REPRESENTANTE del titular de la finca o del derecho.
# - DNI/NIF Rep.- Dni o Nif del REPRESENTANTE

# # DATOS TITULARES OTROS DERECHOS
# - Num. Tit. Otros Der.- Número de titulares (arrendador) de otros derechos.
# - Derecho.- Derecho por el que se indemniza al arrendatario.
# - Nombre Tit. Otros Der.- Nombre del titular del derecho.
# - Apellidos Tit. Otros Der.- Apellidos del titular del derecho.
# - DNI/NIF Otros Der.- Dni o Nif del titular del derecho
# - Dir. Notif. Otros Der.- Dirección del titular del derecho
# - Superf. D.- Superficie en metros cuadrados a ser expropiados que afectan al derecho correspondiente.
# - Valor Unit. D.- Valor unitario por metro cuadrado que supone la expropiación del derecho correspondiente
# - Importe D.- Importe total a abonar por la parte expropiada que afecta al derecho correspondiente.

# # DATOS EXPEDIENTE
# - Cod. Unico Acta.- Codigo único acta (formado por clave expte+numorden+digito) VALOR INDICE.
# - Carta.- Recibe carta SI/NO.
# - Fecha Firma LAP.- Fecha Firma Levantamiento Actas Previas.
# - Hora Cita LAP.- Hora Cita Levantamiento Actas Previas.
# - Firma LAP.- Firma Levantamiento actas Previas SI/NO.
# - Firma JP.- Firma Justiprecio SI/NO.
# - Jurado Reg. Val.- Acude a Jurado de Valoraciones SI/NO.
# - Importe Dep. Previo.- Importe Depósito Previo.
# - Renuncia Dep. Previo.- Renuncia Dep. Prev. SI/NO.
# - Importe Intereses Demora.- Importe Intereses Demora.
# - Resolucion Judicial.- Datos Resolución Judicial.
# - Fecha Pago.- Fecha de Pago.
# - Observaciones.- 

# # DATOS CAPA PARA GML
# - TIPO PARCELA.- 'EXPRO', 'RESTO', 'DESCUENTO'
# - Dato Namespace.- 'ES.SDGC.CP', 'ES.LOCAL.CP'
# - Dato Localid.- Para 'ES.SDGC.CP', localid = RC; Para 'ES.LOCAL.CP', otro valor
# - Superficie parte
# - X_LABEL. - X para etiquetado
# - Y_LABEL. - Y para etiquetado      
'''
