from qgis.PyQt.QtWidgets import QGraphicsView


class ZoomableGraphicsView(QGraphicsView):
    def wheelEvent(self, event):
        factor = 1.15 if event.angleDelta().y() > 0 else 1.0 / 1.15
        self.scale(factor, factor)