# -*- coding: utf-8 -*-
"""
/***************************************************************************
 herrCTRAS_catalogo.py
                                 A QGIS4 plugin
                             -------------------
        begin                : 2018-03-24
        git sha              : $Format:%H$
        copyright            : (C) 2016 by ASS
        email                : asolabre@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.
 *
 *   Based in 'Quick Export' pluggin
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import QIcon, QPixmap, QPageLayout, QPageSize
from qgis.PyQt.QtCore import (QSettings, QCoreApplication, QTranslator, qVersion, Qt, QFileInfo, QDate, QUrl, QMetaType)
from qgis.PyQt.QtWidgets import (QApplication, QMessageBox, QToolButton, QMenu, QAction, QDialog, QCheckBox, QFileDialog,
                            QWidget, QTextEdit)

from qgis.PyQt import uic

from qgis.gui import QgsMessageBar
from qgis.core import (QgsProject, Qgis, QgsMessageLog, QgsVectorLayer, QgsMapLayer, QgsApplication, QgsField,
                        QgsVectorFileWriter, QgsCoordinateTransformContext, QgsFeature, QgsExpression, QgsFeatureRequest,
                        QgsProcessingFeedback)
from qgis.utils import iface
from qgis.PyQt.QtPrintSupport import QPrinter, QPrintDialog
from qgis.PyQt.QtWebEngineWidgets import QWebEngineView
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtWidgets import QProgressBar

from os import path, makedirs, startfile
from osgeo import ogr, osr
from time import sleep
from functools import partial

import os
import timeit
import urllib
import json
import glob, codecs
import shutil
import datetime
import locale
import tempfile
import sys
import subprocess
import csv
import re


import xlrd     # Herramientas de lectura de EXCEL
import xlwt     # Herramientas de escritura de EXCEL
# ESTILOS xlwt https://github.com/python-excel/xlwt/blob/5a222d0315b6d3ce52a3cedd7c3e41309587c107/xlwt/Style.py#L103


from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .settings import Settings           # CLASE DE CONFIGURACIÓN DE VARIABLES GLOBALES
from .herrCTRAS_catalogoRT import herrCTRAS_catalogoRT   # Clase para creación de un catálgo RT

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), './menus/herrCTRAS_catalogo_RT.ui'))


class herrCTRAS_catalogo_RT(QDialog, FORM_CLASS):
    def __init__(self, iface,parent=None):
        """Constructor."""
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        
        super(herrCTRAS_catalogo_RT, self).__init__(parent)
        self.setupUi(self)
        self.iface = iface;

        self.nombre_plugin = os.path.basename(os.path.dirname(__file__))

        self.setWindowIcon(QIcon(f':/plugins/jccm_bar4/iconos/logo_general.jpg'))
        self.logo.setPixmap(QPixmap(f":/plugins/jccm_bar4/iconos/jccm.jpg"))

        self.fun = Functions()
        self.conf = configuration()
        self.Sett = Settings()
        self.catRT = herrCTRAS_catalogoRT(iface)
        self.fuenteDatos = 'QGIS4 - RT_JCCM'

        # Comprobamos el rol del usuario
        userSIG, tipoUser = self.Sett.entrarUser()

        self.plugin_dir = QFileInfo(QgsApplication.qgisUserDatabaseFilePath()).path() + f"/python/plugins/{self.nombre_plugin}"

        self.QgisVersion = Qgis.QGIS_VERSION_INT

        self.chbCtrasDENOM_CALCULADA.setChecked(False)
        self.chbRESUMEN.setChecked(True)
        self.chbCtrasTRAMO.setChecked(False)
        self.chbElementosNoCatal.setChecked(False)

        # PDF print options
        self.maxLinesPerPage = 40
        self.maxAttributesBeforeSmallFontSize = 15
        # self.orientation = QPrinter.Landscape
        self.orientation = QPageLayout.Orientation.Landscape
        # self.pageSize = QPrinter.A4
        # self.pageSize = QPageSize(QPageSize.A4)
        self.pageSize = QPageSize(QPageSize.PageSizeId.A4)

        # CSS template file
        self.cssPath = os.path.join(
            self.plugin_dir,
            "templates/table.css"
            )

        self.txeOUTFIELDS.setText('nombre, id_vial, Provincia, Denominacion, PkINI, Origen, PkFIN, Destino, calzadad, Longitud, Long_KM')
        self.txeOrderByFields.setText('titular, orden, nombre, PkINI, Provincia')

        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)
        self.progressBar.setValue(0)
        self.lblINFO.setText('INFO:')

        self.btnSeleccionfich.clicked.connect(self.salida_file_click)

        self.btnCreaEXCEL.setVisible(False)

        self.strPrecision = "{:."+str(self.spnPRECISION.value())+"f}"

        self.lneFICHsalida.setText('c:/temp/catalogo_QG4_RT.csv')

        self.btnLISTADO.clicked.connect(lambda: self.catalogoGDB('catalogoJCCM'))

        ###############################
        #   ESTUDIAR BOTÓN CATALOGO RT          ### TODO QUITAR
        ###############################
        if tipoUser == 'ADMINISTRADOR':
            self.btnCATALOGO_RT.setVisible(True)
        else:
            self.btnCATALOGO_RT.setVisible(False)
        # self.btnCATALOGO_RT.clicked.connect(lambda: self.catalogoGDB('catalogoRT'))
        self.btnCATALOGO_RT.hide()

        ###############################
        #   COMBOS DESPLEGABLES
        ###############################
        self._cargar_combo(self.cbxTitularidad, 'titulard', seleccion_defecto='Comunidad Autónoma')
        self._cargar_combo(self.cbxProvincia,   'Provincia')

        # # Combo selector salida
        # idx = self.cbxTipoExport.findText('Solo WEB')
        # if idx != -1:
            # self.cbxTipoExport.setCurrentIndex(idx)

        # DEFINICIONES DE CAMPOS PARA PRESENTACIÓN
        self.listaCamposData = [
            {'campo':'nombre',          'alias':u'Nombre',          'tipo': 'string', 'anchocol': 4500},
            {'campo':'id_vial',         'alias':u'id_vial',         'tipo': 'int',    'anchocol': 3500},
            {'campo':'nombre_alt',      'alias':u'Nombre alt.',     'tipo': 'string', 'anchocol': 4000},
            {'campo':'titular',         'alias':u'Titul.',          'tipo': 'string', 'anchocol': 4000},

            {'campo':'orden',           'alias':u'Func.',           'tipo': 'string', 'anchocol': 2000},
            {'campo':'clase',           'alias':u'Clase',           'tipo': 'int'   , 'anchocol': 2000},
            {'campo':'acceso',          'alias':u'Acceso',          'tipo': 'int'   , 'anchocol': 2000},
            {'campo':'tipo_tramo',      'alias':u'Tipo',            'tipo': 'int'   , 'anchocol': 2000},

            {'campo':'Provincia',       'alias':u'Provincia',       'tipo': 'string', 'anchocol': 3200},
            {'campo':'Denominacion',    'alias':u'Denominación',    'tipo': 'string', 'anchocol':12000},
            {'campo':'PkINI',           'alias':u'Pk INI',          'tipo': 'double', 'anchocol': 2500},
            {'campo':'Origen',          'alias':u'Origen',          'tipo': 'string', 'anchocol': 7500},
            {'campo':'PkFIN',           'alias':u'Pk FIN',          'tipo': 'double', 'anchocol': 2500},
            {'campo':'Destino',         'alias':u'Destino',         'tipo': 'string', 'anchocol': 7500},
            {'campo':'calzadad',        'alias':u'CALZ. Doble',     'orden':'string', 'anchocol': 2500},
            {'campo':'Longitud',        'alias':u'Long',            'tipo': 'double', 'anchocol': 3000},
            {'campo':'Long_KM',         'alias':u'Long. Km',        'tipo': 'double', 'anchocol': 2500},
            {'campo':'geom.STLength()', 'alias':u'STLength()',      'tipo': 'double', 'anchocol': 3000},
            {'campo':'OBJECTID',        'alias':u'OBJID',           'tipo': 'int',    'anchocol': 3000},
            {'campo':'Long_Total',      'alias':u'Long Total',      'tipo': 'string', 'anchocol': 3500}
            ]


        # DEFINICIONES DE REDES (titular, orden, acceso, funcionalidad)
        # Se definen las diferentes clasificaciones de titular, orden, acceso, y el equivalente a funcionalidad para cada grupo:
        self.listaTitulos = [
            #'Grupo',   Nombre del grupo o red en que se agrupan y suman longitudes, en virtud de 'titular', 'orden', 'acceso'
            #'Titulo',  Título para los listados de red (listados y resúmenes)
            #'titular', Valor del campo titular: 1: 'Administración General del Estado',2: 'Comunidad Autónoma',3: 'Diputación Provincial',5: 'Ayuntamiento',6: 'Confederación hidrográfica',8: 'Militar',9: 'Empresa minera',9: 'Otros'
            #'orden',   Valor del campo orden:   'P': 'Principal','1': 'Primer orden','2': 'Segundo orden','3': 'Tercer orden','N': 'No catalogada'
            #'acceso',  Valor del campo acceso:  1: 'Libre',2: 'Peaje'
            #'Color',           ej: u'rgb(90, 110, 255)'
            #'ColorCellFORE',   ej: 'light_blue'
            #'ColorCellTXT'     ej: 'white'},

            # ESTATALES
            {'Grupo' : u'Autopistas',           'Titulo' : u'RED ESTATALES - Autopistas',           'titular' : 1, 'orden' : 'P', 'acceso' : 1, 'Color' : u'rgb(90, 110, 255)', 'ColorCellFORE': 'light_blue', 'ColorCellTXT': 'white'},
            {'Grupo' : u'Autopistas Peaje',     'Titulo' : u'RED ESTATALES - Autopistas Peaje',     'titular' : 1, 'orden' : 'P', 'acceso' : 2, 'Color' : u'rgb(90, 110, 255)', 'ColorCellFORE': 'light_blue', 'ColorCellTXT': 'gray25'},
            {'Grupo' : u'Convencionales',       'Titulo' : u'RED ESTATALES - Convencionales',       'titular' : 1, 'orden' : '1', 'acceso' : 1, 'Color' : u'rgb(255, 90,  90)',  'ColorCellFORE': 'coral', 'ColorCellTXT': 'black'},

            # REGIONALES
            {'Grupo' : u'Básica alta capacidad','Titulo' : u'RED REGIONAL - BÁSICA ALTA CAPACIDAD', 'titular' : 2, 'orden' : 'P', 'acceso' : 1, 'Color' : u'rgb(90, 110, 255)', 'ColorCellFORE': 'dark_blue_ega', 'ColorCellTXT': 'white'},
            {'Grupo' : u'Básica A.C. Peaje',    'Titulo' : u'RED REGIONAL - BÁSICA A.C. PEAJE',     'titular' : 2, 'orden' : 'P', 'acceso' : 2, 'Color' : u'rgb(90, 110, 255)', 'ColorCellFORE': 'dark_blue_ega', 'ColorCellTXT': 'white'},
            {'Grupo' : u'Básica',               'Titulo' : u'RED REGIONAL - BÁSICA',                'titular' : 2, 'orden' : '1', 'acceso' : 1, 'Color' : u'rgb(255,170,   0)',  'ColorCellFORE': 'light_orange', 'ColorCellTXT': 'white'},
            {'Grupo' : u'Comarcal',             'Titulo' : u'RED REGIONAL - COMARCAL',              'titular' : 2, 'orden' : '2', 'acceso' : 1, 'Color' : u'rgb(85, 255,   0)',   'ColorCellFORE': 'dark_green_ega', 'ColorCellTXT': 'white'},
            {'Grupo' : u'Local',                'Titulo' : u'RED REGIONAL - LOCAL',                 'titular' : 2, 'orden' : '3', 'acceso' : 1, 'Color' : u'rgb(255, 255,  0)',  'ColorCellFORE': 'yellow', 'ColorCellTXT': 'black'},
            {'Grupo' : u'Ramal',                'Titulo' : u'RED REGIONAL - RAMALES (RED LOCAL)',   'titular' : 2, 'orden' : '31','acceso' : 1, 'Color' : u'rgb(255, 255,  0)',  'ColorCellFORE': 'yellow', 'ColorCellTXT': 'black'},
            {'Grupo' : u'Enlace',               'Titulo' : u'RED REGIONAL - ENLACES',               'titular' : 2, 'orden' : 'N', 'acceso' : 1, 'Color' : u'rgb(200, 200,200)','ColorCellFORE': 'light_green', 'ColorCellTXT': 'black'},

            # DIPUTACIÓN
            {'Grupo' : u'Diputación',           'Titulo' : u'RED DIPUTACIÓN PROVINCIAL',            'titular' : 3, 'orden' : '3', 'acceso' : 1, 'Color' : u'rgb(254, 254, 254)','ColorCellFORE': 'black', 'ColorCellTXT': 'white'},
            # AYUNTAMIENTO
            {'Grupo' : u'Otras',                'Titulo' : u'VIALES MUNICIPALES',                   'titular' : 5, 'orden' : 'N', 'acceso' : 1, 'Color' : u'rgb(254, 254, 254)','ColorCellFORE': 'black', 'ColorCellTXT': 'white'}
            ]

        QApplication.restoreOverrideCursor()


    def closeEvent(self, event):
        QApplication.restoreOverrideCursor()


    def encode(self,text):
        """
        For printing unicode characters to the console.
        """
        return text.encode('ISO-8859-14')


    def cambiatxeOUTFIELDS(self):
        if self.chbALLLAYERS.isChecked():
            self.txeOUTFIELDS.setEnabled(False)
        else:
            self.txeOUTFIELDS.setEnabled(True)


    def salida_file_click(self):
        dirFile = self.lneFICHsalida.text()
        fileTipe = self.cbxTipoExport.currentText()
        ext = "*.csv"
        if fileTipe!= 'IMPRESORA':
            filename, tipofile = QFileDialog.getSaveFileName(self, "Fichero GML de salida", dirFile, ext)
            if filename != None and filename != "":
                self.lneFICHsalida.setText(filename)
            else:
                filename = dirFile
            # Comprobamos que existe el directorio y si no se crea
            if not os.path.exists(os.path.dirname(filename)):
                os.makedirs(os.path.dirname(filename))

    def _limpiar_lista(self, lista):
        """Elimina None, '', 'null'/'NULL'/'Null' y solo espacios."""
        if not lista:
            return []
        return [
            v for v in lista
            if v is not None
            and str(v).strip() != ''
            and str(v).strip().lower() != 'null'
        ]

    def _cargar_combo(self, combo, campo, valor_todo="Todo", seleccion_defecto=None):
        """
        Carga un combo con los valores limpios de un campo.
        - Añade 'Todo' al principio.
        - Si seleccion_defecto está en la lista, lo selecciona (offset +1 por 'Todo').
        """
        valores = self._limpiar_lista(self.fun.getValoresCampo_RT(campo, ''))
        combo.clear()
        if not valores:
            return valores
        combo.addItem(valor_todo)
        combo.addItems(valores)
        if seleccion_defecto and seleccion_defecto in valores:
            combo.setCurrentIndex(1 + valores.index(seleccion_defecto))
        return valores

    def _claveGrupo(self, attributes):
        """Devuelve la clave de grupo (una de listaTitulos) para un dict de atributos."""
        if not attributes:
            return 'Otras'

        titular = attributes.get('titular', attributes.get('titulard'))
        orden   = attributes.get('orden')
        acceso  = attributes.get('acceso')

        # Normalización mínima: a str, sin espacios
        titular = str(titular).strip() if titular is not None else None
        orden   = str(orden).strip()   if orden   is not None else None
        acceso  = str(acceso).strip()  if acceso  is not None else None

        # Estatales
        if titular == '1':
            if orden == 'P':
                return 'Autopistas Peaje' if acceso == '2' else 'Autopistas'
            if orden == '1':
                return 'Convencionales'

        # Regionales
        if titular == '2':
            if orden == 'P':  return 'Básica A.C. Peaje' if acceso == '2' else 'Básica alta capacidad'
            if orden == '1':  return 'Básica'
            if orden == '2':  return 'Comarcal'
            if orden == '3':  return 'Local'
            if orden == '31': return 'Ramal'
            if orden == 'N':  return 'Enlace'

        # Diputación
        if titular == '3':
            return 'Diputación'

        return 'Otras'

    def _datosGrupo(self, claveGrupo):
        """
        Devuelve el dict de self.listaTitulos cuyo 'Grupo' == claveGrupo.
        Si no existe, devuelve un dict por defecto (VIALES SIN CLASIFICACIÓN).
        """
        for d in self.listaTitulos:
            if d['Grupo'] == claveGrupo:
                return d
        return {
            'Grupo': claveGrupo or u'Otras',
            'Titulo': u'VIALES SIN CLASIFICACIÓN',
            'Color': u'rgb(200, 200, 200)',
            'ColorCellFORE': 'black',
            'ColorCellTXT': 'white',
        }

    def _ordenGrupo(self, claveGrupo):
        for i, dataGrupos in enumerate(self.listaTitulos):
            if dataGrupos['Grupo'] == claveGrupo:
                return i
        return len(self.listaTitulos)

    def _ordenGrupo(self, claveGrupo):
        """Devuelve la posición de la clave de grupo en self.listaTitulos."""
        for i, dataGrupos in enumerate(self.listaTitulos):
            if dataGrupos['Grupo'] == claveGrupo:
                return i
        return len(self.listaTitulos)   # los no listados, al final


    #############################################################################################
    ########     TODO  ELIINAR CUANDO SE ASIGNE A LOS RAMALES ATRIBUTO  'orden' = '31'    #######
    def _esRamal(self, nombre):
        """
        Devuelve True si 'nombre' corresponde a un RAMAL según:
          - 'CM-XX[a]', 'CM-XXX[a]', 'CM-XXXX[a]'   -> 2-4 dígitos + 'a' OBLIGATORIA
          - 'CM-9XXX'                                -> 4 dígitos que empiezan por 9, sin 'a'
        Se ignoran espacios al inicio/fin y mayúsculas/minúsculas.
        """
        if not nombre:
            return False
        n = str(nombre).strip().upper()

        # Caso 1: CM-9XXX (4 dígitos empezando por 9, sin 'a')
        if re.fullmatch(r'CM-9\d{3}', n):
            return True

        # Caso 2: CM-XXa / CM-XXXa / CM-XXXXa  (la 'a' es OBLIGATORIA)
        if re.fullmatch(r'CM-\d{2,4}A', n):
            return True

        return False
    #############################################################################################
    #############################################################################################


    def catalogoGDB(self, tipoCat):
        start = timeit.default_timer()

        self.close()
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        ## Comprobamos la SALIDA DE FICHERO seleccionadas
        fileTipe = self.cbxTipoExport.currentText()
        if fileTipe == 'IMPRESORA': ## TODO NO FUNCIONA LA SALIDA DE IMPRESORA
            fileTipe = 'printer'
        if fileTipe == u'xls (excel)':
            fileTipe = 'xls'
        if fileTipe == u'Solo WEB':
            fileTipe = 'html'
        if fileTipe == u'Solo CSV':
            fileTipe = 'csv'


        ## Comprobamos la PROVINCIA, TITULARIDAD Y orden seleccionadas
        prov = self.cbxProvincia.currentText()
        if prov == 'Todo':
            prov = 'JCCM'

        valcbxTitularidad = self.cbxTitularidad.currentText()
        valcbxProvincia = self.cbxProvincia.currentText()
        if valcbxTitularidad == "Todo":
            valcbxTitularidad = '%'
        if valcbxProvincia == "Todo":
            valcbxProvincia = '%'

        ## Se crea la consulta SQL
        whereTXT = '('
        whereTXT+= ' titulard LIKE '+"'"+valcbxTitularidad+"'"      # titulard :        'EL QUE SEA'
        whereTXT+= ' AND Provincia LIKE '+"'"+valcbxProvincia+"'"   # Provincia :       'todas' o 'LA QUE SEA'
        whereTXT+= ' AND tipo_tramo = 1'                            # tipo_tramo = 1 :  'TRONCAL'
        if not self.chbElementosNoCatal.isChecked():
            whereTXT+= ' AND orden NOT LIKE '+"'"+'N'+"'"           # orden NOT LIKE "N"
        whereTXT+= ")"
        # print ('whereTXT:', whereTXT)

        # Campos a obtener en la CONSULTA
        outfields = '*'
        resp = self.defineListasGlobales()
        if resp == 'error':
            QApplication.restoreOverrideCursor()
            return

        # Comprobamos CAMPOS INCLUIDOS en la salida
        listBorrar = []
        for campo in self.listCampos:
            if not campo in self.listCamposCOMP:
                listBorrar.append(campo)
        for campo in listBorrar:
            self.listCampos.remove(campo)

        # Comprobamos CAMPOS INCLUIDOS en la lista de orden de campos
        listBorrar = []
        for campo in self.listCamposOrder:
            if not campo in self.listCamposCOMP:
                listBorrar.append(campo)
        for campo in listBorrar:
            self.listCamposOrder.remove(campo)
        orderByFields = ",".join(self.listCamposOrder)

        self.lblINFO.setText('INFO: Leyendo url .....')

        TipoExport = self.cbxTipoExport.currentText()

        # QUERY AL WFS RT_carreteras_Tramovial_WFS
        url = self.conf.lrs_rt["rest_carreteras_RT"]
        campoCtra = self.conf.lrs_rt["identificador_carretera_RT"]

        values = {'where' : whereTXT,
                  'text': '',
                  'objectIds': '',
                  'geometryType' : 'esriGeometryPolyline',
                  'returnGeometry' : False,
                  'returnM': False,
                  'outFields': outfields,
                  'orderByFields' : orderByFields,
                  'f': 'json'}

        self.restfeatures = self.fun.getFeaturesBTAcalibrada_RT(values)
        if not self.restfeatures:
            self.close()
            QApplication.restoreOverrideCursor()
            return

        # Precalculamos el grupo con los datos ORIGINALES del WFS
        # (antes de que el CSV coaccione 'acceso' a bool)
        for feat in self.restfeatures:
            attributes = feat["attributes"]
            
            #############################################################################################
            ########     TODO  ELIINAR CUANDO SE ASIGNE A LOS RAMALES ATRIBUTO  'orden' = '31'    #######

            # Asignación de '31' (Ramal) si el nombre encaja
            if self._esRamal( attributes.get('nombre')):
                attributes['orden'] = '31'
            #############################################################################################
            
            attributes['__grupo__'] = self._claveGrupo(feat.get("attributes", {}))

        # # --- ORDENAR FEATURES SEGÚN EL ORDEN DE self.listaTitulos ---
        self.restfeatures.sort(
            key=lambda feat: self._ordenGrupo(self._claveGrupo(feat.get("attributes", {})))
        )

        restfeaturesDESC = self.restfeatures

        numfeats = len(self.restfeatures)
        nfeat = 0

        # FICHEROS Y CAPAS
        fich_ext = self.lneFICHsalida.text()
        fich_solo, extension = os.path.splitext(fich_ext)
        fich_csv=fich_solo+'_'+prov.replace(' ', '')+'.csv'
        directorio, archivo = os.path.split(fich_csv)
        fich = fich_csv.replace('csv', fileTipe)
        # comprueba = self.fun.comprobar_directorio_archivo(directorio, archivo)

        if not self.fun.comprobar_directorio_archivo(directorio, archivo):
            QApplication.restoreOverrideCursor()
            return

        QgsMessageLog.logMessage( "Creando archivo de log",self.nombre_plugin)

        # ESCRIBIMOS ENCABEZADOS FICHERO 'CSV'
        target  = codecs.open(fich_csv, 'w+',encoding='utf-8')
        
        encabezado = ''
        for campo in self.listCamposCOMP:
            encabezado += campo + u';'

        # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
        encabezado += 'Long_Total;'
        encabezado += 'grupo;'

        target.write(encabezado)
        target.write("\n")

        # ESCRIBIMOS LISTA DE DATOS
        # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
        countFeat = 0
        Long_Total = 0
        self.listProvs = []
        self.listRESUMEN = []

        # Variables para grupos por tramos
        grupoProv = []
        grupoPkINI = 9999
        grupoOrigen = ''
        grupoPkFIN = 0
        grupoDestino = ''
        grupoLong_KM = 0

        self.listorden = []
        

        for feat in self.restfeatures:
            attributes = feat["attributes"]
            
            # # Asignación de '31' (Ramal) si el nombre encaja
            # if self._esRamal(attributes.get('nombre')):
                # attributes['orden'] = '31'
                # print ('RAMAL: ', attributes.get('nombre'))
                    
            # feat["attributes"]['__grupo__'] = self._claveGrupo(feat.get("attributes", {}))
            # print (attributes['idMatricula'],'attributes[Long_KM] =', attributes['Long_KM'])
            if attributes['Long_KM']:
                Long_KM_data = round(attributes['Long_KM'], 3)
            else:
                Long_KM_data = 0

            ## COMPROBAMOS DOBLE VIA
            # Si es doble carril se graba la mitad de Long_KM
            if not self.chbDOBLEVIA.isChecked():
                if attributes['calzada'] == 2:      # Calzada multiple
                    Long_KM_data = round(attributes['Long_KM']/2, 3)

            #######################################
            # AÑADIMOS DATOS A GRUPOS POR TRAMOS  #
            #######################################
            # Se añade la provincia al grupoProv para el caso de agrupar viales
            if attributes['Provincia'] not in grupoProv:
                grupoProv.append(attributes['Provincia'])
            # Se añade la provincia al self.listProvs para el caso de agrupar viales
            if attributes['Provincia'] not in self.listProvs:
                self.listProvs.append(attributes['Provincia'])
                self.listProvs.sort()

            # Se añade Long_KM a grupoLong_KM para el caso de agrupar viales
            grupoLong_KM += Long_KM_data

            # Se obtiene el PkINI, Origen -MINIMOS- y PkFIN, Destino -MAXIMOS-  para el caso de agrupar viales
            if attributes['PkINI'] != None and attributes['PkFIN'] != None:
                if attributes['PkINI'] < grupoPkINI:
                    grupoPkINI  = attributes['PkINI']
                    grupoOrigen = attributes['Origen']
                if attributes['PkFIN'] > grupoPkFIN:
                    grupoPkFIN  = attributes['PkFIN']
                    grupoDestino= attributes['Destino']


            #################################
            # SE HACEN TOTALES PARA RESUMEN #
            #################################
            if self.chbRESUMEN.isChecked():
                Provincia = attributes['Provincia']
                ordenNom = self._claveGrupo(attributes)

                if ordenNom not in self.listorden:
                    self.listorden.append(ordenNom)

                if not any((d['Provincia'] == Provincia and d['orden'] == ordenNom) for d in self.listRESUMEN):
                    self.listRESUMEN.append({'Provincia': Provincia, 'orden': ordenNom, 'LongTotal': Long_KM_data})
                else:
                    dataRESUMEN = next(dataRES for dataRES in self.listRESUMEN
                                       if dataRES['Provincia'] == Provincia and dataRES['orden'] == ordenNom)
                    dataRESUMEN['LongTotal'] += Long_KM_data

            #################################
            #      ANALISIS POR TRAMOS      #
            #################################
            if not self.chbCtrasTRAMO.isChecked():
                if countFeat+1 < len(self.restfeatures):
                    # SE ANALIZAN CASOS DE TRAMOS CM-XXXXa
                    if 'a' in attributes['nombre'] or 'A' in attributes['nombre']:
                        if attributes['nombre_alt'] == self.restfeatures[countFeat+1]["attributes"]['nombre_alt']:
                            # print (attributes['nombre_alt'], attributes['Long_KM'], grupoLong_KM, grupoProv, ' NO GRABA')
                            countFeat += 1
                            continue
                    # SE ANALIZAN CASOS EN EL QUE EL SIGUIENTE ELEMENTO ES OTRO TRAMO DE LA MISMA CTRA o CARRIL DERECHO EN DOBLE VÍA
                    elif attributes['nombre'] == self.restfeatures[countFeat+1]["attributes"]['nombre']:
                            # print (attributes['nombre_alt'], attributes['Long_KM'], grupoLong_KM, grupoProv, ' NO GRABA')
                            countFeat += 1
                            continue

            ## COMPROBAMOS DOBLE VIA
            # Si es doble carril no se graba EL ELEMENTO
            if not self.chbDOBLEVIA.isChecked():
                if attributes['calzada'] == 2:      # Calzada multiple
                    # if attributes['nombre'] == self.restfeatures[countFeat+1]["attributes"]['nombre'] and attributes['Origen'] == self.restfeatures[countFeat+1]["attributes"]['Origen'] and attributes['Tipologia_DobleC'] == self.restfeatures[countFeat+1]["attributes"]['Tipologia_DobleC']:
                    try:
                        if attributes['nombre'] == self.restfeatures[countFeat+1]["attributes"]['nombre'] and attributes['Origen'] == self.restfeatures[countFeat+1]["attributes"]['Origen'] and attributes['calzada'] == self.restfeatures[countFeat+1]["attributes"]['calzada']:
                            countFeat +=1
                            continue
                    except:
                        continue


            # Se crea la linea 'datos' para el CSV y el HTML
            datos = u''
            for attr in self.listCamposCOMP:
                # print (attributes[attr])
                dat = u''
                # Análisis de tipología de datos
                if isinstance(attributes[attr], str):
                    dat = attributes[attr]
                elif isinstance(attributes[attr], unicode):
                    dat = attributes[attr]
                elif isinstance(attributes[attr], int):
                    dat = str(attributes[attr])
                elif isinstance(attributes[attr], float):
                    dat = (self.strPrecision.format(attributes[attr]))

                if not self.chbCtrasTRAMO.isChecked():
                    if attr == 'Provincia':
                        dat = u''
                        for prov in grupoProv:
                            dat += prov
                            # print ('grupoProv.index(prov)-', grupoProv.index(prov), 'len(grupoProv)-', len(grupoProv) )
                            if grupoProv.index(prov)<len(grupoProv)-1: dat += ' / '
                        grupoProv = []
                    if attr == 'Long_KM':
                        dat = self.strPrecision.format(grupoLong_KM)

                    if self.chbCtrasDENOM_CALCULADA.isChecked() and attr == 'Denominacion':
                        dat = 'De '+grupoOrigen + ' a ' +grupoDestino
                    if attr == 'PkINI':
                        dat = self.strPrecision.format(grupoPkINI)
                        grupoPkINI = 9999
                    if attr == 'Origen':
                        dat = grupoOrigen
                        grupoOrigen = ''
                    if attr == 'PkFIN':
                        dat = self.strPrecision.format(grupoPkFIN)
                        grupoPkFIN = 0
                    if attr == 'Destino':
                        dat = grupoDestino
                        grupoDestino = ''

                if dat is None:
                    dat = ''
                datos += (dat + u';')
            # print (attributes['nombre'], attributes['orden'], attributes['Provincia'])


            # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
            if grupoLong_KM is not None:
                if not self.chbCtrasTRAMO.isChecked():
                    Long_Total += Long_KM_data
            if countFeat+1 < len(self.restfeatures):
                if attributes['nombre_alt'] != self.restfeatures[countFeat+1]["attributes"]['nombre_alt']:
                    datos += (self.strPrecision.format(grupoLong_KM) + u';')
                    Long_Total = 0
                    grupoLong_KM = 0
                else:
                    datos += u'-;'
            else:
                datos += (self.strPrecision.format(Long_Total) + u';')
                
            datos += (attributes.get('__grupo__', u'Otras') + u';')


            target.write(datos)
            target.write("\n")
            nfeat +=1
            prog = 50 * nfeat/numfeats
            self.progressBar.setValue(int(prog))
            self.lblINFO.setText(u'INFO: Añadiendo a CSV registro ' + str(nfeat) +'/' +str(numfeats))

            countFeat += 1

        # --- ORDENAR LAS CATEGORÍAS DEL RESUMEN SEGÚN self.listaTitulos ---
        if self.chbRESUMEN.isChecked():
            self.listorden.sort(key=self._ordenGrupo)

        # --- AÑADIENDO CAMPO CON VALORES CTRA TOTAL ---
        self.listCampos.append('Long_Total')
        self.listCamposCOMP.append ('Long_Total')

        target.close()

        fich_csv_uri = u"file:///"+ fich_csv +"?type=csv&geomType=none&subsetIndex=no&delimiter=%s&watchFile=no" % (";")

        abstract = ''
        if self.cbxTitularidad.currentText() != '%':
                    abstract += u'Titular - %s / '%self.cbxTitularidad.currentText()
        # if self.cbxFuncionalidad.currentText() != '%':
                    # abstract += u'Funcionalidad - %s / '%self.cbxFuncionalidad.currentText()
        if self.cbxProvincia.currentText() != '%':
                    abstract += u'Provincia - %s / '%self.cbxProvincia.currentText()

        # Esto crea la capa CSV
        #   Si existe la capa se debe borrar
        prov = self.cbxProvincia.currentText()
        if prov == 'Todo':
            prov = 'JCCM'
        nomcapa = u'CATALOGO CARRETERAS '+prov
        csv_lyrLIST = QgsProject.instance().mapLayersByName(nomcapa)
        if len(csv_lyrLIST) >0:
            for csv_lyr in csv_lyrLIST:
                QgsProject.instance().removeMapLayer(csv_lyr.id())

        csv_lyr = QgsVectorLayer(fich_csv_uri, nomcapa,'delimitedtext')
        QgsProject.instance().addMapLayer(csv_lyr, False)


        if tipoCat == 'catalogoRT':
            # text = 'Catalogo RT'
            # self.fun.showMessageERR(text,text2="",tittle="JCCM")
            uriCatRT = 'c:\\temp\\CatalogoRT_JCCM.gpkg'
            # Comprobar si existe el directorio destino y si no, se crea
            # self.fun.comprobarDirectorio(os.path.dirname(uriCatRT)+'\\')
            nameCapaRT = 'CatalogoRT_JCCM'
            capaRtLIST = QgsProject.instance().mapLayersByName(nameCapaRT)
            if len(capaRtLIST) >0:
                for capaRt in capaRtLIST:
                    QgsProject.instance().removeMapLayer(capaRt.id())

            # Obtener los atributos de todos los elementos en forma de lista de diccionarios
            features = csv_lyr.getFeatures()

            # Obtener nombres de campos para construir diccionarios con claves legibles
            field_names = [field.name() for field in csv_lyr.fields()]
            lista_dictionaries = [dict(zip(field_names, feature.attributes())) for feature in csv_lyr.getFeatures()]
            # print (lista_dictionaries)

            # Se llama a las funcionalidades de herrCTRAS_catalogoRT.py
            capaCatalogoRT = self.catRT.createCatalogoRT(lista_dictionaries, uriCatRT, nameCapaRT, GenHojaCalc = True, IncCamposGDB = False)
            
            QApplication.restoreOverrideCursor()
            return


        # Colocamos la capa arriba del todo
        root = QgsProject.instance().layerTreeRoot()
        root.insertLayer(0, csv_lyr)
        self.iface.setActiveLayer(csv_lyr)


        self.tbrURLCOMPLETA.setHtml(self.creaHTML(''))

        resultLAYER = self.exportLayer(fileTipe, fich)

        if resultLAYER == 'OK':
            # Abrir el fichero resultante

            if fileTipe == 'xls' and self.chbCreaHTML.isChecked():       # Abrimos también la web html
                os.startfile(self.htmFile)

            if fileTipe != 'csv':
                if os.path.exists(self.exportedFile):
                    os.startfile(self.exportedFile)
                else:
                    self.iface.messageBar().pushMessage('Parece que no se ha creado el fichero ' +self.exportedFile, self.nombre_plugin, QgsMessageBar.WARNING, 5)

            stop = timeit.default_timer()
            text = 'INFO:   --- TERMINADO ---'
            tiempo = 'Tiempo: '+"%0.2f"%(stop - start)+' seg.'
            self.lblINFO.setText(text+tiempo)
        else:
            self.lblINFO.setText('ERROR EN CATÁLOGO')

        QApplication.restoreOverrideCursor()
        self.progressBar.setValue(0)
        self.close


    def exportLayer(self, etype='csv', fich=''):
        # Se exporta la tabla de atributos de la tabla seleccionada al tipo de fichero elegido

        # Establece propiedades del tipo de salida
        # print ('etype = ', etype)
        self.etype = etype
        self.exportHiddenAttributes = False
        self.csvDelimiter = '\t'

        # Cojemos la capa activa
        layer = self.iface.activeLayer()
        msg= None

        # Comprobamos si la capa es valida para exportar
        if layer and layer.type() == QgsMapLayer.VectorLayer and hasattr(layer, 'providerType'):

            # Se acude al método adecuado según el tipo seleccionado
            if etype != 'printer':

                ePath = fich
                self.exportedFile = fich
                if self.chbCreaHTML.isChecked():
                    self.htmFile = fich.replace( 'xls', 'html')

                if etype == 'csv':
                    msg = u'La capa ha sido cargada adecuadamente.'
                    status = 'info'
                    return ('OK')

                elif etype == 'html':
                    msg, status = self.exportLayerToHtml(layer, fich, False, 'html')
                    return ('OK')

                elif etype == 'xls':
                    # if self.chbCreaEXCEL.isChecked():
                    # if self.cbxTipoExport.currentText() == u'xls (excel)':
                    if self.chbCreaHTML.isChecked():
                        msg, status = self.exportLayerToHtml(layer, self.htmFile, False, 'html')

                    resultXLS = self.exportLayerToEXCEL(layer, fich)
                    if resultXLS == 'OK':
                        return ('OK')
                    else:
                        return (resultXLS)

                elif etype == 'pdf':  ### TODO NO FUNCIONA SALIDA PDF

                    msg, status = self.exportLayerToPdf(layer)

            else:
                msg, status = self.exportLayerToPdf(layer, True)

        else:
            msg = u'Selecciona primero una capa vectorial'
            status = 'warning'


    def exportLayerToEXCEL(self, csv_lyr, ePath):
        '''
        #  EXPORTA LOS DATOS A EXCEL
        # Permite la exportación de los datos a EXCEL
        #   def exportLayerToEXCEL(self, csv_lyr):
        '''
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)


        # Datos del fichero de salida
        archivoXCL = ePath.replace('html', 'xls')
        hojaXCL = 'CATALOGO'

        # Renombrar fichero
        srcFilName, srcExt = os.path.splitext(archivoXCL)
        nombre_nuevo = srcFilName+'_'+srcExt.replace('.','')+'.bak'
        if os.path.exists(nombre_nuevo):
            os.remove(nombre_nuevo)

        ######################################################################
        #               Preparacion de TITULOS
        ######################################################################
        prov = self.cbxProvincia.currentText()
        if prov == 'Todo':
            prov = 'JCCM'

        # Campos a obtener en la CONSULTA
        # self.defineListasGlobales()

        if 'Long_Total' not in self.listCampos:
            self.listCampos.append('Long_Total')
        if 'Long_Total' not in self.listCamposCOMP:
            self.listCamposCOMP.append ('Long_Total')

        # FECHA DE CREACIÓN
        locale.setlocale(locale.LC_TIME,'')
        if hasattr(locale, 'nl_langinfo'):
            date_format = locale.nl_langinfo(locale.D_T_FMT)
        else:
            date_format = "%x %X"
        today = datetime.datetime.today()
        date = today.strftime(date_format)
        dt_date = u'JCCM. Dirección General de Carreteras '

        # OPCIONES ESCOGIDAS
        abstract = ''
        if self.cbxTitularidad.currentText() != '%':
                    abstract += u'Titularidad - %s / '%self.cbxTitularidad.currentText()
        # if self.cbxFuncionalidad.currentText() != '%':
                    # abstract += u'Funcionalidad - %s / '%self.cbxFuncionalidad.currentText()
        if self.cbxProvincia.currentText() != '%':
                    abstract += u'Provincia - %s / '%self.cbxProvincia.currentText()

        # VALORES TITULOS
        title = u'CATÁLOGO DE CARRETERAS   -'+prov+'-  '+self.fuenteDatos
        campoGrupo  = u'orden'
        campoGrupo1 = u'titular'
        campoSumaGrupo = u'Long_KM'
        udSuma = u'Km'

        # Icono, Titulo, Resumen, número de Carreteras
        fileIcono = f'python/plugins/{self.nombre_plugin}/iconos/jccm.jpg'
        dirPYTJCCM = QgsApplication.qgisSettingsDirPath()
        fileIcono = os.path.normpath(os.path.join(os.path.dirname(dirPYTJCCM), fileIcono))

        #########################################################
        #       Escritura del fichero EXCEL
        #########################################################
        # Se crea el workbook
        wb = xlwt.Workbook()
        wb = xlwt.Workbook(style_compression=2)

        # Se añade una HOJA  al WORKBOOK
        sheetWB = wb.add_sheet(hojaXCL)

        # TODO: INTENTO DE PONER ICONO
        # sheetWB.write(0,0, iconXCL)

        styleTITLE = self.estiloExcelCell('white', 'left', 'bold', 300)
        sheetWB.write(0,1, title, styleTITLE)
        styleDATA = self.estiloExcelCell('white', 'left', 'bold', 240)
        sheetWB.write(1,1, 'Datos:', styleDATA)
        sheetWB.write(1,2, abstract, styleDATA)
        styleDATA = self.estiloExcelCell('white', 'left', 'bold', 200)
        sheetWB.write(2,1, 'Fecha:', styleDATA)
        sheetWB.write(2,2, date, styleDATA)
        row = 5

        # Se obtienen los datos de la capa
        layerData, nb = self.getLayerData(csv_lyr)
        attrValues = layerData[1:]
        fields = csv_lyr.fields()

        # # Establecemos el estilo de contenidos de datos
        # styleDATA = xlwt.easyxf('font: color black')

        # Nombres de campos de la capa
        fieldNames = layerData[0]
        nbAttr = len(fieldNames)
        numcampoGrupo  = fieldNames.index(campoGrupo)

        # Calculamos posiciones de los campos a listar
        numColumnas = u'"'+str(len(self.listCampos))+u'"'
        poslistCampos = []
        col = 0
        for field in self.listCampos:
            poslistCampos.append(self.listCamposCOMP.index(field))
            # Establecemos los anchos
            ancho = 2500
            for dataCampos in self.listaCamposData:
                if dataCampos['campo'] == field:
                    ancho = dataCampos['anchocol']
            sheetWB.col(col).width = ancho
            col += 1

        # # Se obtienen los datos de la capa
        # layerData, nb = self.getLayerData(csv_lyr)

        # Obtenemos los tipos de cada campo
        tipoCampos = []
        for field in fields:
            tipoCampos.append(field.typeName())

        # Creamos el contenido del cuerpo de la hoja con los datos de atributos de los elementos
        numcampoGrupo1 = fieldNames.index(campoGrupo1)
        numcampoSumaGrupo = fieldNames.index(campoSumaGrupo )

        valcampoGrupo = ''
        tbody = ''
        page = 1
        totalGrup = 0
        totalGlobal = 0
        table = 0
        attrValues = layerData[1:]

        # Escribir la tabla de contenido como HTML

        # # Traducción orden RT -> Grupo de listaTitulos
        # MAPA_ORDEN_A_GRUPO = {
            # 'Principal':      'Básica alta capacidad',   # o 'Autopistas' si titular=Estatal, ver abajo
            # 'Primer orden':   'Básica',
            # 'Segundo orden':  'Comarcal',
            # 'Tercer orden':   'Local',
            # 'No catalogada':  'Otras',
        # }

        for values in attrValues:
            # Identificador de grupo por 'orden'
            attrsDict = dict(zip(fieldNames, values))
            # valorTestigo = self._claveGrupo(attrsDict)
            valorTestigo = attrsDict.get('grupo') or self._claveGrupo(attrsDict)

            if valorTestigo != valcampoGrupo:
                if table != 0:
                    ## Linea de TOTALES POR GRUPO
                    styleTOTtxt = self.estiloExcelCell('white', 'right', 'bold', 0)
                    # sheetWB.write(row, len(self.listCampos)-3, tituloGrupo+ ' -------------- '    , styleTOTtxt)
                    sheetWB.write_merge(row, row,0, len(self.listCampos)-2, tituloGrupo+ ' -------------- '    , styleTOTtxt)
                    styleTOTtxt = self.estiloExcelCell('gray25', 'double', 'bold', 0, True)
                    styleTOTtxt.num_format_str = '#0.000'
                    sheetWB.write(row, len(self.listCampos)-1  , round(float(totalGrup),3) , styleTOTtxt)

                    row += 3
                    totalGlobal += totalGrup
                    totalGrup = 0
                table+=1

                valcampoGrupo = valorTestigo
                datosG = self._datosGrupo(valcampoGrupo)
                tipoFUNC      = datosG['Grupo']
                tituloGrupo   = datosG['Titulo']
                ColorCellFORE = datosG['ColorCellFORE']
                ColorCellTXT  = datosG['ColorCellTXT']

                # tipoFUNC    = u'Otras'
                # tituloGrupo = u'VIALES SIN CLASIFICACIÓN'
                # ColorCellFORE = 'black'
                # ColorCellTXT  = 'white'
                # for dataGrupos in self.listaTitulos:
                    # if dataGrupos['Grupo'] == valcampoGrupo:
                        # tipoFUNC      = dataGrupos['Grupo']
                        # tituloGrupo   = dataGrupos['Titulo']
                        # ColorCellFORE = dataGrupos['ColorCellFORE']
                        # ColorCellTXT  = dataGrupos['ColorCellTXT']

                styleCAB = self.estiloExcelCell(ColorCellFORE, 'text', 'bold', 220, True, ColorCellTXT)
                # Se escribe encabezado en varias celdas
                sheetWB.write_merge(row, row, 0, len(self.listCampos)-1, tituloGrupo, styleCAB)
                row += 1

                ## Linea de encabezados para cada orden
                col = 0
                for field in self.listCampos:
                    styleCAB = self.estiloExcelCell(ColorCellFORE, 'text', 'bold', 220, True, ColorCellTXT)
                    campoENCAB = next(item for item in self.listaCamposData if item["campo"] == field)
                    sheetWB.write(row, col, campoENCAB["alias"], styleCAB)
                    col += 1
                row += 1

            # Se escribe cada dato en su sitio
            col = 0
            for pos in poslistCampos:
                styleDATA = self.estiloExcelCell('white', tipoCampos[pos], '', 0, True, 'black')
                styleDATActra = self.estiloExcelCell(ColorCellFORE, tipoCampos[pos], 'bold', 0, True, ColorCellTXT)
                if tipoCampos[pos] == 'int':
                    valueTD = values[pos]
                    styleDATA.num_format_str = '#0'
                elif tipoCampos[pos] == 'double':
                    valueTD = round(float(values[pos]),3)
                    styleDATA.num_format_str = '#0.000'
                elif self.listCamposCOMP[pos] == 'Long_Total' and self.fun.isFloat(values[pos]):
                    valueTD = round(float(values[pos]),3)
                    styleDATA.num_format_str = '#0.000'
                else:
                    valueTD = values[pos]

                # TODO revisar cuando no quedan alineados correctamente algunos campos
                if self.listCamposCOMP[pos] == 'nombre':
                    sheetWB.row(row).write(col, valueTD, styleDATActra)
                else:
                    sheetWB.row(row).write(col, valueTD, styleDATA)
                col += 1

            try:
                totalGrup += float(values[numcampoSumaGrupo])
            except:
                pass

            row += 1

        totalGlobal += totalGrup


        ## Linea de ÚLTIMOS TOTALES POR GRUPO
        styleTOTtxt = self.estiloExcelCell('white', 'otro', 'bold', 0)
        sheetWB.write(row, len(self.listCampos)-3, tituloGrupo+ ' -------------- '     , styleTOTtxt)
        styleTOTtxt = self.estiloExcelCell('gray25', 'double', 'bold', 0, True)
        styleTOTtxt.num_format_str = '#0.000'
        sheetWB.write(row, len(self.listCampos)-1  , round(float(totalGrup),3)  , styleTOTtxt)
        row += 2

        ## Linea de TOTAL GLOBAL
        styleTOTtxt = self.estiloExcelCell('white', 'otro', 'bold', 0)
        sheetWB.write(row, len(self.listCampos)-2,  ' ------- TOTAL ------- '   , styleTOTtxt)
        styleTOTtxt = self.estiloExcelCell('gray25', 'double', 'bold', 0, True)
        styleTOTtxt.num_format_str = '#0.000'
        sheetWB.write(row, len(self.listCampos)-1  , round(float(totalGlobal),3), styleTOTtxt)
        row += 2

        # Escribimos los totales de CARRETERAS y LONGKM EN LOS TITULOS INICIALES
        info = u'TOTAL %s Carreteras - %s Km'%(format(str(nb)), "{:.3f}".format(totalGlobal))
        styleDATA = self.estiloExcelCell('white', 'left', 'bold', 200)
        sheetWB.write(3,1, u'Información:', styleDATA)
        sheetWB.write(3,2, info, styleDATA)

        ######################################################################
        #                         TABLA RESUMEN                              #
        ######################################################################
        if self.chbRESUMEN.isChecked():

            # Se añade una HOJA DE RESUMEN al WORKBOOK
            sheetRES = wb.add_sheet('RESUMEN')

            tituloRESUMEN = '---- RED AUTONÓMICA DE CARRETERAS  ----'
            tituloRESUMEN01 = 'RESUMEN'
            tituloRESUMEN02 = '(c) Dirección General de Carreteras'

            styleTITLE = self.estiloExcelCell('white', 'left', 'bold', 300)
            sheetRES.write(0,1, tituloRESUMEN, styleTITLE)
            styleDATA = self.estiloExcelCell('white', 'left', 'bold', 240)
            sheetRES.write(1,2, tituloRESUMEN01, styleDATA)
            styleDATA = self.estiloExcelCell('white', 'left', 'bold', 200)
            sheetRES.write(2,2, tituloRESUMEN02, styleDATA)
            row = 5

            # RESUMEN ponemos ENCABEZADOS
            styleCAB = self.estiloExcelCell('blue', 'text', 'bold', 220, True, 'white')
            sheetRES.write(row, 0, u'CATEGORÍA', styleCAB)
            col = 1
            for prov in self.listProvs:
                styleCAB = self.estiloExcelCell('blue', 'center', 'bold', 220, True, 'white')
                sheetRES.write(row, col, prov, styleCAB)
                col += 1
            sheetRES.write(row, col, u'TOTAL', styleCAB)
            row = 6

            # RESUMEN ponemos CONTENIDO
            sheetRES.col(0).width = 7000 # Columna de CATEGORÍA
            Long_Prov_Total = {}
            col = 1
            for prov in self.listProvs:
                Long_Prov_Total[prov] = 0
                sheetRES.col(col).width = 4000 # Columna de PROVINCIA
                col += 1
            sheetRES.col(col).width = 4000 # Columna de TOTALES

            styleDATA = self.estiloExcelCell('white', 'double', '', 0, True, 'black')
            Sum_Func_Total = 0
            for dataorden in self.listorden:
                styleFUNC = self.estiloExcelCell('blue_gray', 'text', 'bold', 0, True, 'white')
                sheetRES.write(row, 0, dataorden, styleFUNC)
                Long_Func_Total = 0

                styleDATA = self.estiloExcelCell('white', 'double', '', 0, True, 'black')
                col = 1
                for prov in self.listProvs:
                    Long_Func = 0
                    for dataRES in self.listRESUMEN:
                        if (dataRES['Provincia'].upper() == prov.upper() and dataRES['orden'] == dataorden):
                            Long_Func = dataRES['LongTotal']
                            Long_Prov = Long_Prov_Total[prov] + Long_Func
                            Long_Prov_Total[prov] = Long_Prov
                            styleDATA.num_format_str = '#0.000'
                            sheetRES.write(row, col, round(float(Long_Func),3), styleDATA)
                            break
                    Long_Func_Total += Long_Func
                    col += 1
                Sum_Func_Total += Long_Func_Total
                styleTOT = self.estiloExcelCell('white', 'double', 'bold', 0, True, 'black')
                styleTOT.num_format_str = '#0.000'
                sheetRES.write(row, col, round(float(Long_Func_Total),3), styleTOT)
                row += 1

            # RESUMEN ponemos TOTALES PROVINCIALES
            styleTOT = self.estiloExcelCell('gray25', 'left', 'bold', 0, True, 'black')
            sheetRES.write(row, 0, 'TOTALES PROVINCIALES', styleTOT)
            Sum_Prov_Total = 0
            col = 1
            styleTOT = self.estiloExcelCell('gray25', 'double', 'bold', 0, True, 'black')
            styleTOT.num_format_str = '#0.000'
            for prov in self.listProvs:
                sheetRES.write(row, col, round(float(Long_Prov_Total[prov]),3), styleTOT)
                Sum_Prov_Total += Long_Prov_Total[prov]
                col += 1
            sheetRES.write(row, col, round(float(Sum_Prov_Total),3), styleTOT)
            row += 2

            # RESUMEN PONEMOS ANÁLISIS DE INCIDENCIAS ES TOTAL GLOBAL
            if abs(totalGlobal-Sum_Func_Total) > 0.01:      # Comparamos la suma por tramos 'totalGlobal' con la suma del resumen 'Sum_Func_Total'
                notINCtxt = 'TOTAL (1) ' + '{:.3f}'.format(Sum_Prov_Total)
                notINCtxt = 'TOTAL (1) - Hay una discrepancia entre el TOTAL POR TRAMOS = %s y TOTAL POR PROVINCIAS = %s'%('{:.3f}'.format(totalGlobal),'{:.3f}'.format(Sum_Prov_Total))
                styleTxt = self.estiloExcelCell('white', 'left', '', 150, False, 'black')
                sheetRES.write(row, 0, notINCtxt, styleTxt)
                sheetRES.write(row, col, round(float(Sum_Prov_Total),3), styleTOT)
                row += 2

            styleDATA = self.estiloExcelCell('white', 'left', '', 150, False, 'black')
            textFECHA = 'Fecha:  '+ date
            sheetRES.write(row, 0, textFECHA, styleDATA)



        QApplication.restoreOverrideCursor()

        # Guardamos el nuevo fichero si es posible
        try:
            wb.save(archivoXCL)
            os.startfile(archivoXCL)
            return ('OK')

        except:
            text = ' NO SE PUEDE ESCRIBIR POR ESTAR ABIERTA LA HOJA\n\n-%s-\n\n'%(archivoXCL)
            text+= '- Se debe cerrar para volver a grabar -'
            self.fun.showMessageERR(text)
            return ('ERROR EXCEL')


    def estiloExcelCell(self, colorFORE, tipoDATA, tipoFONT, sizeFONT, bordes = False, colorFONT = 'black'):
        '''
        Generador de estilos para una excel
        https://github.com/python-excel/xlwt/blob/master/xlwt/Style.py
        '''
        # colorFORE ; Color de fondo
        # tipoDATA  ; Alineación de texto text, justified = justified, double,int = right,
        # tipoFONT  ; bold
        # sizeFONT  ;
        # bordes    ; False = sin bordes
        # colorFONT ; default:'black'):

        if tipoFONT == 'bold':
            tipoFONTbold = 'bold 1'
        else:
            tipoFONTbold = 'bold 0'

        if sizeFONT != 0:
            tipoFONTbold += ',height %s'%(str(sizeFONT))

        if tipoDATA == 'right' or tipoDATA == 'double' or tipoDATA == 'int':
            alignFONT = 'right'
        elif tipoDATA == 'text' or tipoDATA == 'justified':
            alignFONT = 'justified'
        elif tipoDATA == 'center':
            alignFONT = 'center'
        else:
            alignFONT = 'left'     # left, center, right, filled, justified ...

        styleCELL = xlwt.easyxf('font: %s, color %s; align: horiz %s; align: vert top'%(tipoFONTbold, colorFONT, alignFONT))

        pattern = xlwt.Pattern()
        pattern.pattern = xlwt.Pattern.SOLID_PATTERN
        pattern.pattern_fore_colour = xlwt.Style.colour_map[colorFORE]
        styleCELL.pattern = pattern

        if bordes == True:
            borders = xlwt.Borders()
            borders.left = xlwt.Borders.THIN
            borders.right = xlwt.Borders.THIN
            borders.top = xlwt.Borders.THIN
            borders.bottom = xlwt.Borders.THIN
            styleCELL.borders = borders

        return styleCELL


    def exportLayerToHtml(self, csv_lyr, ePath=None, cutPages=False, etype=None):
        # def exportLayerToHtml(self, layer, ePath=None, cutPages=False, etype=None):
        '''
        Exporta la capa a HTML
        usando una plantilla y leyendo los datos
        desde la capa seleccionada
        '''
        prov = self.cbxProvincia.currentText()
        if prov == 'Todo':
            prov = 'JCCM'

        # VALORES ENCABEZADOS
        title = u'CATÁLOGO DE CARRETERAS   -'+prov+'-  '+self.fuenteDatos

        campoGrupo  = u'orden'
        campoGrupo1 = u'titular'
        campoSumaGrupo = u'Long_KM'
        udSuma = u'Km'


        # Icono, Titulo, Resumen, número de Carreteras
        fileIcono = f'python/plugins/{self.nombre_plugin}/iconos/jccm.jpg'
        dirPYTJCCM = QgsApplication.qgisSettingsDirPath()
        fileIcono = os.path.normpath(os.path.join(os.path.dirname(dirPYTJCCM), fileIcono))
        dt_icono = '<img src="%s" border="0" width="100" height="80">'%fileIcono
        dt_title = u''
        dt_abstract = u'Datos'
        dt_info = u'Información'

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        # Leemos el fichero de plantilla
        tplPath = self.plugin_dir + u"/TEMPLATES/htmlTempCATALOG.tpl"
        fin = open(tplPath)
        data = fin.read()
        fin.close()

        # Se obtienen los datos de la capa
        # layerData, nb = self.getLayerData(layer)
        layerData, nb = self.getLayerData(csv_lyr)

        # Obtenemos los tipos de cada campo
        fields = csv_lyr.fields()
        tipoCampos = []
        for field in fields:
            tipoCampos.append(field.typeName())


        # Nombres de campos de la capa
        fieldNames = layerData[0]
        nbAttr = len(fieldNames)
        numcampoGrupo  = fieldNames.index(campoGrupo)
        numcampoGrupo1 = fieldNames.index(campoGrupo1)
        numcampoSumaGrupo = fieldNames.index(campoSumaGrupo )

        # Calculamos posiciones de los campos a listar
        numColumnas = u'"'+str(len(self.listCampos))+u'"'
        poslistCampos = []
        for campo in self.listCampos:
            poslistCampos.append(self.listCamposCOMP.index(campo))


        # Creamos el contenido de 'tbody' con los datos de atributos de los elementos
        valcampoGrupo = ''
        tbody = ''
        i = 6 # num lineas
        page = 1
        totalGrup = 0
        totalGlobal = 0
        table = 0
        attrValues = layerData[1:]


        # Escribir la tabla de contenido como HTML
        for values in attrValues:
            prog = 50 +50 * attrValues.index(values)/len(attrValues)
            self.progressBar.setValue(int(prog))
            self.lblINFO.setText(u'INFO: Añadiendo a -'+etype+'- registro ' + str(attrValues.index(values)) +'/' +str(len(attrValues)))

            attrsDict = dict(zip(fieldNames, values))
            # valorTestigo = self._claveGrupo(attrsDict)
            valorTestigo = attrsDict.get('grupo') or self._claveGrupo(attrsDict)

            if valorTestigo != valcampoGrupo:
                if table != 0:
                    # Escribimos un pie por grupo finalizando la tabla
                    tbody+='                <tr>\n'
                    tbody+='                    <th colspan=%s align="right" style="background: %s">    TOTAL %s -- %s %s</th>'%(numColumnas, 'rgb(255, 255, 255)', tituloGrupo, '{:.3f}'.format(totalGrup), udSuma)
                    tbody+='                </tr>\n'
                    tbody+='            </tbody>\n'
                    tbody+='        </table>\n'
                    totalGlobal += totalGrup
                    totalGrup = 0
                    i += 2
                table+=1
                thead = ''

                valcampoGrupo = valorTestigo
                datosG = self._datosGrupo(valcampoGrupo)
                tituloGrupo = datosG['Titulo']
                colBck      = datosG['Color']
                # tituloGrupo = ''
                # colBck = 'rgb(200, 200, 200)'
                # for dataGrupos in self.listaTitulos:
                    # if dataGrupos['Grupo'] == valcampoGrupo:
                        # tituloGrupo = dataGrupos['Titulo']
                        # colBck = dataGrupos["Color"]

                thead+='        <table>\n'
                thead+='            <tbody>\n'
                thead+='                <tr>\n'
                thead+='                    <th colspan=%s align="left" style="background: %s">%s</th>'%(numColumnas, colBck, tituloGrupo)
                thead+='                </tr>\n\n'
                thead+='                <tr>\n'
                i += 3
                for field in self.listCampos:
                    campoENCAB = next(item for item in self.listaCamposData if item["campo"] == field)
                    thead+= '                    <th style="background: %s">%s</th>\n' %(colBck, campoENCAB["alias"])
                thead+= '                </tr>\n\n'
                tbody+= thead

            # Se crea la lista de valores de cada registro
            valuesLista = []
            tbody+= '                <tr>\n'
            for pos in poslistCampos:
                if tipoCampos[pos] == 'int':
                    try:
                        valueTD = "{:.0f}".format(float(values[pos]))
                        tbody+= '                    <td align="right">' + valueTD + '</td>\n'
                    except:
                        valueTD = valueTD = values[pos]
                elif tipoCampos[pos] == 'double':
                    try:
                        valueTD = "{:.3f}".format(float(values[pos]))
                        tbody+= '                    <td align="right">' + valueTD + '</td>\n'
                    except:
                        valueTD = valueTD = values[pos]
                elif self.listCamposCOMP[pos] == 'Long_Total' and self.fun.isFloat(values[pos]):
                    valueTD = "{:.3f}".format(float(values[pos]))
                    tbody+= '                    <td align="right">' + valueTD + '</td>\n'
                else:
                    valueTD = values[pos]
                    tbody+= '                    <td align="left">' + valueTD + '</td>\n'
            tbody+= '                    </td>\n'
            tbody+= '                </tr>\n\n'

            try:
                totalGrup += float(values[numcampoSumaGrupo])
            except:
                pass
            i+=1
            # Comprobamos SALTOPAGINA
            if i == self.maxLinesPerPage and cutPages and self.QgisVersion > 10900:
                i = 3
                tbody+= '</table>\n\n'
                tbody+= '<span>Page %s</span>' % page
                tbody+= '<div class="saltopagina"></div>\n\n'
                tbody+= '<table><thead>' + thead + '</thead><tbody>'
                page+=1

        # LÍNEAS FINALES
        totalGlobal += totalGrup

        tbody+='                <tr>\n'
        tbody+='                    <th colspan=%s align="right" style="background: %s">    TOTAL %s -- %s %s</th>'%(numColumnas, 'rgb(255, 255, 255)', tituloGrupo, '{:.3f}'.format(totalGrup), udSuma)
        tbody+='                </tr>\n'
        tbody+='                <tr>\n'
        tbody+='                    <th colspan=%s align="right" style="background: %s">    TOTAL %s -- %s %s</th>'%(numColumnas, 'rgb(255, 255, 255)', u'GENERAL', '{:.3f}'.format(totalGlobal), udSuma)
        tbody+='                </tr>\n'
        tbody+='            </tbody>\n'
        tbody+='        </table>\n'



        ######################################################################
        #                         TABLA RESUMEN                              #
        ######################################################################
        if self.chbRESUMEN.isChecked():

            numColumnas = len(self.listProvs)+2

            tituloRESUMEN = '---- RED AUTONÓMICA DE CARRETERAS  ----'
            tituloRESUMEN01 = 'RESUMEN'
            tituloRESUMEN02 = '(c) Dirección General de Carreteras'

            # TITULOS RESUMEN
            colBck = u'rgb(200, 200, 200)' # GRIS
            colBckClr = u'rgb(80, 250, 230)' # AZUL CLARO
            anno = datetime.datetime.today().year

            tresumen ='                \n\n'
            tresumen+='                <tr>\n'
            tresumen+='                    <th style="text-align:center;">'
            tresumen+='                    '+dt_icono
            tresumen+='                    </th>'
            tresumen+='                    <th colspan=%s style="text-align:center;font-size:15px;background: %s">'%(numColumnas-1, colBck)
            tresumen+='                         <dd>%s</dd>'%(tituloRESUMEN)
            tresumen+='                         <dd>%s</dd>'%(tituloRESUMEN01)
            tresumen+='                         <dd>%s</dd>'%(tituloRESUMEN02+' - '+str(anno))
            tresumen+='                    </th>'
            tresumen+='                </tr>'
            colBck = u'rgb(255, 255, 255)' # BLANCO
            tresumen+='                <tr>\n'
            tresumen+= '                    <th colspan=%s WIDTH="650" style="background: %s">'%(numColumnas, colBck)
            tresumen+='                         <dd></dd>'
            tresumen+= '                    </th>\n'
            tresumen+='                </tr>'

            # RESUMEN ENCABEZADOS
            colBck = u'rgb(90, 160, 240)' # AZUL
            tresumen+='                <tr>\n'
            tresumen+= '                    <th style="background: %s;text-align:center;color:white;font-size:12px">%s</th>\n' %(colBck, 'CATEGORÍA')
            for prov in self.listProvs:
                tresumen+= '                    <th style="background: %s;text-align:center;color:white;font-size:12px">%s</th>\n' %(colBck, prov)
            tresumen+= '                    <th style="background: %s;text-align:center;color:white;font-size:12px">%s</th>\n' %(colBck, 'TOTAL')
            tresumen+='                </tr>'

            # RESUMEN CONTENIDO
            colBck = u'rgb(255, 255, 255)' # BLANCO
            tresumen+='                <tr>\n'

            Long_Prov_Total = {}
            for prov in self.listProvs:
                Long_Prov_Total[prov] = 0

            Sum_Func_Total = 0
            for dataorden in self.listorden:
                tresumen+='                <tr>\n'
                tresumen+= '                    <th style="background: %s;text-align:center;font-size:12px">%s</th>\n' %(colBckClr, dataorden)
                Long_Func_Total = 0
                for prov in self.listProvs:
                    Long_Func = 0
                    for dataRES in self.listRESUMEN:
                        # print ('dataRES[Provincia] ', dataRES['Provincia'], ' == prov ', prov, 'dataRES[orden] ', dataRES['orden'], ' == dataorden ', dataorden, ' --->', dataRES['LongTotal'])
                        if (dataRES['Provincia'].upper() == prov.upper() and dataRES['orden'] == dataorden):
                            Long_Func = dataRES['LongTotal']
                            Long_Prov = Long_Prov_Total[prov] + Long_Func
                            Long_Prov_Total[prov] = Long_Prov
                            break
                    Long_Func_Total += Long_Func
                    tresumen+= '                    <th style="background: %s;text-align:right;padding-right:25px;font-size:12px">%s</th>\n' %(colBck, '{:.3f}'.format(Long_Func))
                tresumen+= '                    <th style="background: %s;text-align:right;padding-right:25px;font-size:12px">%s</th>\n' %(colBck,  '{:.3f}'.format(Long_Func_Total))
                tresumen+='                </tr>'
                Sum_Func_Total += Long_Func_Total


            # RESUMEN TOTALES PROVINCIALES
            colBck = u'rgb(90, 160, 240)' # AZUL
            tresumen+='                <tr>\n'
            tresumen+= '                    <th style="background: %s;text-align:center;color:white;font-size:12px">%s</th>\n' %(colBck, 'TOTALES PROVINCIALES')
            Sum_Prov_Total = 0
            for prov in self.listProvs:
                    tresumen+= '                    <th style="background: %s;text-align:right;padding-right:25px;color:white;font-size:12px">%s</th>\n' %(colBck, '{:.3f}'.format(Long_Prov_Total[prov]))
                    Sum_Prov_Total += Long_Prov_Total[prov]


            # RESUMEN ANÁLISIS DE INCIDENCIAS ES TOTAL GLOBAL
            NotInc = False
            if abs(totalGlobal-Sum_Func_Total) > 0.01:      # Comparamos la suma por tramos 'totalGlobal' con la suma del resumen 'Sum_Func_Total'
                tresumen+= '                    <th style="background: %s;text-align:right;padding-right:25px;color:white;font-size:12px">%s</th>\n' %(colBck, 'TOTAL (1) ' + '{:.3f}'.format(Sum_Prov_Total))
                NotInc = True
            else:
                tresumen+= '                    <th style="background: %s;text-align:right;padding-right:25px;color:white;font-size:12px">%s</th>\n' %(colBck, 'TOTAL ' + '{:.3f}'.format(Sum_Prov_Total))
            tresumen+='                </tr>'
            tbody+= '                \n\n'
            tbody+= '    <table>'
            tbody+= '        <tbody>' + tresumen
            tbody+= '        </tbody>'
            tbody+= '    </table>'

            if NotInc == True:
                colBck = u'rgb(255, 255, 255)' # BLANCO
                tincidencia ='                \n\n'
                tincidencia+='                <tr>\n'
                mensaje = '(1) Parece haber una discrepancia en los resultados de las sumas\n'
                mensaje += '  -----  Suma TOTALES por TRAMOS = %s   Suma Provincial = %s   Suma orden = %s'%('{:.3f}'.format(totalGlobal), '{:.3f}'.format(Sum_Prov_Total), '{:.3f}'.format(Sum_Func_Total) )
                tincidencia+= '                    <th style="background: %s;text-align:left;color:black;font-size:12px">%s</th>\n' %(colBck, mensaje)
                tincidencia+='                </tr>'

                tbody+= '    <table>'
                tbody+= '        <tbody>' + tincidencia
                tbody+= '        </tbody>'
                tbody+= '    </table>'

        # FECHA DE CREACIÓN
        locale.setlocale(locale.LC_TIME,'')
        if hasattr(locale, 'nl_langinfo'):
            date_format = locale.nl_langinfo(locale.D_T_FMT)
        else:
            date_format = "%x %X"
        today = datetime.datetime.today()
        date = today.strftime(date_format)
        dt_date = u'JCCM. Dirección General de Carreteras '

        try:
            abstract = csv_lyr.abstract()
        except:
            abstract = ''
            if self.cbxTitularidad.currentText() != '%':
                        abstract += u'Titularidad - %s / '%self.cbxTitularidad.currentText()
            # if self.cbxorden.currentText() != '%':
                        # abstract += u'orden - %s / '%self.cbxorden.currentText()
            if self.cbxProvincia.currentText() != '%':
                        abstract += u'Provincia - %s / '%self.cbxProvincia.currentText()

        info = u'TOTAL %s Carreteras - %s Km'%(format(str(nb)), "{:.3f}".format(totalGlobal))

        # ADAPTACIÓN DE ESTILOS EN CASO DE SER NECESARIO
        style = ''
        # Get CSS style from table.css
        with open(self.cssPath, 'r') as content_file:
            style = content_file.read()
        if nbAttr > self.maxAttributesBeforeSmallFontSize:
            style+= 'th, td {font-size:10px;}'


        # SE REEMPLAZAN LOS VALORES EN LA PLANTILLA
        data = data.replace('$icono', dt_icono)
        data = data.replace('$dt_title', dt_title)
        data = data.replace('$title', title)
        data = data.replace('$dt_abstract', dt_abstract)
        data = data.replace('$abstract', abstract)
        data = data.replace('$dt_info', dt_info)
        data = data.replace('$info', info)
        data = data.replace('$tbody', tbody)
        data = data.replace('$dt_date', dt_date)
        data = data.replace('$date', date)
        data = data.replace('$style', style)
        data = data.replace('$totalPages', "Pag. %s" % page)

        # DIRECTORIO DEL FICHERO DE EXPORTACIÓN
        if not ePath:
            ePath = self.exportedFile

        try:
            # write html content
            f = open(ePath, 'w')
            f.write(data)
            f.close()

        # except IOError, e:
        except:
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación')
            status = 'critical'
        finally:
            msg = QApplication.translate("quickExport", u'La capa ha sido adecuadamente exportada')
            status = 'info'

        QApplication.restoreOverrideCursor()

        return msg, status


    def exportLayerToPdf(self, layer, doPrint=False):
        ############################################################################
        ### TODO NO FUNCIONA SALIDA PDF
        ############################################################################

        '''
        Exports the layer to PDF
        First export to HTML then convert to PDF.
        If not output file given, send directly to the printer
        '''

        # Create temporary file path
        temp = tempfile.NamedTemporaryFile()
        try:
            # Create temporary HTML file
            tPath = "%s.html" % temp.name
            msg, status = self.exportLayerToHtml(layer, tPath, True, 'pdf')

            # NOTE: this method already relied on QWebView and QPrintDialog
            # without ever importing them (a pre-existing bug, present
            # before the QGIS4/Qt6 migration - it would raise a NameError
            # the moment it was called under Qt5 too). Fixed here using
            # QWebEngineView, the QtWebEngine-based replacement for the
            # QtWebKit-based QWebView removed in Qt6, along with the
            # missing QPrintDialog import.
            #
            # Create a web view and fill it with the html file content
            web = QWebEngineView()
            web.load(QUrl.fromLocalFile(tPath))

            # Keep a strong reference so the QWebEngineView isn't garbage
            # collected before the asynchronous load/print finishes (this
            # wasn't a concern with the old, synchronous QWebView).
            if not hasattr(self, '_pdfExportWebViews'):
                self._pdfExportWebViews = []
            self._pdfExportWebViews.append(web)

            # Print only when HTML content is loaded
            def printIt(ok=True):
                # Open the printer dialog if needed
                if doPrint:
                    dialog = QPrintDialog()
                    if dialog.exec() == QDialog.DialogCode.Accepted:
                        printer = dialog.printer()
                    else:
                        return
                # No print, only PDF export
                else:
                    # Set page options for PDF
                    printer = QPrinter()
                    printer.setPageSize(self.pageSize)
                    printer.setOrientation(self.orientation)
                    printer.setFontEmbeddingEnabled(True)
                    printer.setColorMode(QPrinter.ColorMode.Color)
                    # set output file name in case of PDF export
                    printer.setOutputFileName(self.exportedFile)

                # Set some metadata
                printer.setCreator(u"QGIS - Complemento JCCM Carreteras")
                printer.setDocName(u"Exportado - %s" % layer.title() and layer.title() or layer.name())

                # Print (asynchronous under QWebEngineView; the callback
                # just releases our reference to the view once it is done)
                def _printFinished(success):
                    try:
                        self._pdfExportWebViews.remove(web)
                    except ValueError:
                        pass
                web.page().print(printer, _printFinished)

            # Only print when the HTML content has been loaded in the QWebEngineView
            web.loadFinished.connect(printIt)

        except:
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación.')
            status = 'critical'
        finally:
            # Automatically cleans up the file
            temp.close()
            msg = QApplication.translate("quickExport", u'Ocurrió un error durante la exportación.')
            status = 'info'

        return msg, status


    def getLayerData(self, layer):
        '''
        Get fields and data from
        a vector layer
        '''
        data = []

        # Get layer fields names
        fields = layer.fields()
        fieldNames = [
            field.name() for i, field in enumerate(fields)
            ]
        data.append(fieldNames)

        # Get selected features or all features
        if layer.selectedFeatureCount():
            nb = layer.selectedFeatureCount()
        else:
            nb = layer.featureCount()



        # Get layer fields data

        # QGIS >= 2.0
        if self.QgisVersion > 10900:
            if layer.selectedFeatureCount():
                features = layer.selectedFeatures()
            else:
                features = layer.getFeatures()
            for feat in features:
                # Get attribute data
                values = [
                    self.displayAttributeValue(a) for i, a in enumerate(feat.attributes())
                    # if layer.editType(i) != QgsVectorLayer.Hidden
                    # or self.exportHiddenAttributes
                ]
                data.append(values)

        # QGIS 1.8
        else:
            provider = layer.dataProvider()
            allAttrs = provider.attributeIndexes()
            provider.select(allAttrs, QgsRectangle(), False)
            layer.select(allAttrs, QgsRectangle(), False)
            if layer.selectedFeatureCount():
                items = layer.selectedFeatures()
            else:
                items = layer
            for feat in items:
                attrs = feat.attributeMap()
                values = [
                    self.displayAttributeValue(v) for k,v in attrs.iteritems()
                    if layer.editType(k) != QgsVectorLayer.Hidden
                    or self.exportHiddenAttributes
                ]
                data.append(values)

        return data, nb


    def displayAttributeValue(self, value):
        '''
        Convert QGIS attribute data into readable values
        '''
        # QGIS version
        isQgis2 = self.QgisVersion > 10900

        # Get locale date representation
        locale.setlocale(locale.LC_TIME,'')
        if hasattr(locale, 'nl_langinfo'):
            date_format = locale.nl_langinfo(locale.D_FMT)
            datetime_format = locale.nl_langinfo(locale.D_T_FMT)
        else:
            date_format = "%x"
            datetime_format = "%x %X"

        # Convert value depending of type
        if hasattr(value, 'toPyDate'):
            output = value.toPyDate().strftime(date_format)
        elif hasattr(value, 'toPyDateTime'):
            output = value.toPyDateTime().strftime(datetime_format)
        else:
            output = u"%s" % value if isQgis2 else u"%s" % value.toString()

        return output


    def creaHTML(self, url):
        textHTML = u'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">'
        textHTML+= u'<html><head><meta name="qrichtext" content="1" /><style type="text/css">'
        textHTML+= u'p, li { white-space: pre-wrap; }'
        textHTML+= u'</style></head><body style=" font-family:'+"'Tahoma'"+'; font-size:8.25pt; font-weight:400; font-style:normal;">'
        textHTML+= u'<p style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><a href="'
        # textHTML+= u'http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?where=Matricula_Plan+LIKE+%27%25%27&amp;text=&amp;objectIds=&amp;time=&amp;geometry=&amp;geometryType=esriGeometryEnvelope&amp;inSR=&amp;spatialRel=esriSpatialRelIntersects&amp;relationParam=&amp;outFields=*&amp;returnGeometry=true&amp;returnTrueCurves=false&amp;maxAllowableOffset=&amp;geometryPrecision=&amp;outSR=&amp;returnIdsOnly=false&amp;returnCountOnly=true&amp;orderByFields=&amp;groupByFieldsForStatistics=&amp;outStatistics=&amp;returnZ=false&amp;returnM=true&amp;gdbVersion=&amp;returnDistinctValues=false&amp;resultOffset=&amp;resultRecordCount=&amp;queryByDistance=&amp;returnExtentsOnly=false&amp;datumTransformation=&amp;parameterValues=&amp;rangeValues=&amp;f=pjson">'
        textHTML+= url
        textHTML+= u'<span style=" font-size:8pt; text-decoration: underline; color:#0000ff;">'
        # textHTML+= u'http://geoservicios.castillalamancha.es/arcgis/rest/services/WFS/Plan_Carreteras_BTA_WFS/MapServer/0/query?where=Matricula_Plan+LIKE+%27%25%27&amp;text=&amp;objectIds=&amp;time=&amp;geometry=&amp;geometryType=esriGeometryEnvelope&amp;inSR=&amp;spatialRel=esriSpatialRelIntersects&amp;relationParam=&amp;outFields=*&amp;returnGeometry=true&amp;returnTrueCurves=false&amp;maxAllowableOffset=&amp;geometryPrecision=&amp;outSR=&amp;returnIdsOnly=false&amp;returnCountOnly=true&amp;orderByFields=&amp;groupByFieldsForStatistics=&amp;outStatistics=&amp;returnZ=false&amp;returnM=true&amp;gdbVersion=&amp;returnDistinctValues=false&amp;resultOffset=&amp;resultRecordCount=&amp;queryByDistance=&amp;returnExtentsOnly=false&amp;datumTransformation=&amp;parameterValues=&amp;rangeValues=&amp;f=pjson'
        textHTML+= url
        textHTML+= u'</span></a></p></body></html>'
        return textHTML


    def defineListasGlobales(self):
        # Lstados generales de campos para consulta y listado
        # Campos a obtener en la CONSULTA
        self.listCamposCOMP = []
        for campo in self.listaCamposData:
            if campo['campo'] != 'Long_Total':
                self.listCamposCOMP.append(campo['campo'])

        if self.chbALLLAYERS.isChecked():
            self.listCampos = self.listCamposCOMP
        else:
            self.listCampos = self.txeOUTFIELDS.toPlainText().replace(' ', '').split(',')
            for campo in self.listCampos:
                if campo not in self.listCamposCOMP:
                    text = ' El campo %s no está en la lista de campos posibles -listCamposCOMP-'%(campo)
                    print (self.listCamposCOMP)
                    self.fun.showMessageERR(text,text2="",tittle="JCCM")
                    return 'error'

            if not self.chbCtrasTRAMO.isChecked():
                if 'Long_KM' in self.listCampos:
                    self.listCampos.remove('Long_KM')
                if 'idMatricula' in self.listCampos:
                    self.listCampos.remove('idMatricula')

        # Orden de Campos a obtener en la CONSULTA
        orderByFields = self.txeOrderByFields.toPlainText()
        self.listCamposOrder = orderByFields.replace(' ', '').split(',')
        for campo in self.listCamposOrder:
            if campo not in self.listCamposCOMP:
                text = ' El campo %s no está en la lista de campos posibles -listCamposOrder-'%(campo)
                print (self.listCamposOrder)
                self.fun.showMessageERR(text,text2="",tittle="JCCM")
                return 'error'

