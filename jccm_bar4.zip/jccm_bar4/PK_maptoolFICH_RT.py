# -*- coding: utf-8 -*-
"""
/***************************************************************************
                                 A QGIS4 plugin
Name:           PK_maptoolFICH_RT.py
Purpose:
        --------------------------------------------------------------------
        begin                : 2020-10-02
        git sha              : $Format:%H$
        copyright            : (C) 2019 by JCCM. Dirección General de Carreteras
        Codigo               : Agustín Solabre (JCCM)
        email                : gis.carreteras@jccm.es
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import QIcon, QColor, QCursor
from qgis.PyQt.QtCore import QVariant, Qt, QSettings, QTranslator, QCoreApplication, QRect, QMetaType
from qgis.PyQt.QtWidgets import QAction, QApplication, QWidget, QPushButton, QMessageBox, QToolButton, QMenu, QDialogButtonBox, QLabel, QTableWidget, QTableWidgetItem, QTextEdit

from qgis.gui import QgsMapTool,QgsVertexMarker, QgsDialog
from qgis.core import (QgsProject, QgsVectorLayer, QgsField, QgsFeature, QgsGeometry, QgsWkbTypes, QgsPoint,
                    QgsPointXY, QgsLineString, QgsMapLayer)
from qgis.utils import iface

import os, glob, codecs

from .config import configuration        # CLASE DE CONFIGURACIÓN DE VARIABLES DEL PROGRAMA
from .functions4 import Functions        # CLASE DE CONFIGURACIÓN DE FUNCIONES GENERALES
from .PK_info_dialog import Form_PK_info
from .PK_balizas_carretera import balizas_carreteraDialog

nombre_plugin = os.path.basename(os.path.dirname(__file__))

# VARIABLES
srcVal = QSettings().value(f"{nombre_plugin}/GENERAL/EPSG")

#### VARIABLES DESDE /LRS/
dest_path = QSettings().value(f"{nombre_plugin}/LRS/bal_dest_path")
if dest_path is None:
    dest_path = configuration.lrs["bal_dest_path"]
    QSettings().setValue(f"{nombre_plugin}/LRS/bal_dest_path", dest_path)

nom_layer = QSettings().value(f"{nombre_plugin}/LRS/bal_nom_layer")
if nom_layer is None:
    nom_layer = configuration.lrs["bal_nom_layer"]
    QSettings().setValue(f"{nombre_plugin}/LRS/bal_nom_layer", nom_layer)

fich_estiloCAPA = QSettings().value(f"{nombre_plugin}/LRS/bal_estiloCAPA")
if fich_estiloCAPA is None:
    fich_estiloCAPA = configuration.lrs["bal_estiloCAPA"]
    QSettings().setValue(f"{nombre_plugin}/LRS/bal_estiloCAPA", fich_estiloCAPA)
estiloCAPA = os.path.join(os.path.dirname(__file__), fich_estiloCAPA)

#### VARIABLES DESDE /LRS_RT/
tipo_consultaCAPA = QSettings().value(f"{nombre_plugin}/LRS_RT/tipo_consultaCAPA_RT")
if tipo_consultaCAPA is None:
    tipo_consultaCAPA = configuration.lrs_rt["tipo_consultaCAPA_RT"]
    QSettings().setValue(f"{nombre_plugin}/LRS_RT/tipo_consultaCAPA_RT", tipo_consultaCAPA)

ruta_geopackage = QSettings().value(f"{nombre_plugin}/LRS_RT/ruta_geopackage_RT")
if ruta_geopackage is None:
    ruta_geopackage = configuration.lrs_rt["ruta_geopackage_RT"]
    QSettings().setValue(f"{nombre_plugin}/LRS_RT/ruta_geopackage_RT", ruta_geopackage)

nombre_capa_ctras = QSettings().value(f"{nombre_plugin}/LRS_RT/nombre_capa_ctras_RT")
if nombre_capa_ctras is None:
    nombre_capa_ctras = configuration.lrs_rt["nombre_capa_ctras_RT"]
    QSettings().setValue(f"{nombre_plugin}/LRS_RT/nombre_capa_ctras_RT", nombre_capa_ctras)

id_ctra_carreteras = QSettings().value(f"{nombre_plugin}/LRS_RT/identificador_carretera_RT")
if id_ctra_carreteras is None:
    id_ctra_carreteras = configuration.lrs_rt["identificador_carretera_RT"]
    QSettings().setValue(f"{nombre_plugin}/LRS_RT/identificador_carretera_RT", id_ctra_carreteras)

dest_path = 'en memoria'


class PkBalizaToolFICH_RT(QgsMapTool):

    def __init__(self,canvas,iface,action):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.fun = Functions()
        cursor = QCursor()
        cursor.setShape(Qt.CursorShape.CrossCursor)

        # POSIBLE SOLUCIOB DE SNAPPING
        # for item in QgsMapLayerRegistry.instance().mapLayers().values():
            # QgsProject.instance().setSnapSettingsForLayer(item.id(), False, 2, 0, 2, True)

        iface.mapCanvas().setCursor(cursor)
        self.iface = iface
        self.setAction(action)
        self.action = action
        self.dlgBalizaPK = balizas_carreteraDialog(iface)

        self.CAMPOS_BALIZA = [
            "CTRA", "PK", "CTRA1", "id_vial", "DIST", "ACIM",
            "XE", "YE", "ZE", "XP", "YP", "ZP", "DAT1", "DAT2"
        ]

    def canvasReleaseEvent(self, event):
        #Get the click
        x = event.pos().x()
        y = event.pos().y()

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        layerAct = self.iface.activeLayer()
        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

        self.getBalizaPK(point,self.iface)

        pass


    def getBalizaPK(self,point,iface):
        if dest_path == 'en memoria':
            dest = 'memory'
        else:
            dest = dest_path + nom_layer.replace(' ', '_') + ".shp"

        tipo_layer= "point"
        # src= "crs=epsg:25830"
        src= "crs=epsg:"+str(srcVal)

        # Comprobamos si existe la capa
        layerEXIST = QgsProject.instance().mapLayersByName(nom_layer)

        if not layerEXIST or layerEXIST[0].featureCount() == 0:
            if layerEXIST and layerEXIST[0].featureCount() == 0:
                vl = layerEXIST[0]
                QgsProject.instance().removeMapLayer( vl.id() )

            # CREACIÓN DE LA CAPA
            if dest == 'memory':
                vl = QgsVectorLayer(tipo_layer+'?'+src, nom_layer, dest)
            else:
                # print (dest)
                if not os.path.isfile(dest):
                    print (u'NO EXISTE %s - HAY QUE CREARLO'%(dest))
                vl = QgsVectorLayer(dest+'|'+tipo_layer+'?'+crs, nom_layer, "ogr")
            pr = vl.dataProvider()
            vl.startEditing()

            # AÑADIMOS LOS CAMPOS
            pr.addAttributes( [
                            QgsField("CTRA",    QMetaType.Type.QString),
                            QgsField("PK",      QMetaType.Type.Double),
                            QgsField("CTRA1",   QMetaType.Type.QString),
                            QgsField("id_vial", QMetaType.Type.LongLong),
                            QgsField("DIST",    QMetaType.Type.Double),
                            QgsField("ACIM",    QMetaType.Type.Double),
                            QgsField("XE",      QMetaType.Type.Double),
                            QgsField("YE",      QMetaType.Type.Double),
                            QgsField("ZE",      QMetaType.Type.Double),
                            QgsField("XP",      QMetaType.Type.Double),
                            QgsField("YP",      QMetaType.Type.Double),
                            QgsField("ZP",      QMetaType.Type.Double),
                            QgsField("DAT1",    QMetaType.Type.QString),
                            QgsField("DAT2",    QMetaType.Type.QString)
                            ] )

            vl.updateFields()

            # Añade la capa a la TOC
            QgsProject.instance().addMapLayer(vl)

            # Establecemos el estilo de la capa
            vl.loadNamedStyle(estiloCAPA)


            # Commit changes
            vl.commitChanges()
        else:
            vl = layerEXIST[0]

        # Ponemos la capa arriba
        root = QgsProject.instance().layerTreeRoot()
        myvl = root.findLayer(vl.id())
        myvlclone = myvl.clone()
        parent = myvl.parent()
        root.insertChildNode(0, myvlclone)
        parent.removeChildNode(myvl)

        # Hacemos la capa visible
        QgsProject.instance().layerTreeRoot().findLayer(vl.id()).setItemVisibilityChecked(True)

        carretera_pk = self.fun.pointToPK_GPKG_RT(point,iface,'NO'  ,  'SI', 1       , ruta_geopackage, nombre_capa_ctras)

        if carretera_pk is not None:
            ZE = self.fun.Zmdt([carretera_pk[7][0],carretera_pk[7][1]],iface,pintar='NO')
            ZP = self.fun.Zmdt(point,iface,pintar='NO')
            atributos = carretera_pk[4]


            listaVALORES = {
                'CTRA':       atributos['nombre'],
                'PK':         self.fun.mostrarPK(carretera_pk[1], 2),
                'CTRA1':      atributos['nombre_alt'],
                'id_vial':    str(atributos['id_vial']),
                'DIST':       str(round(carretera_pk[5], 2)),
                'ACIM':       str(round(carretera_pk[6], 4)),
                'XE':         str(round(carretera_pk[7][0], 2)),
                'YE':         str(round(carretera_pk[7][1], 2)),
                'ZE':         str(round(ZE, 3)),
                'XP':         str(round(point[0], 2)),
                'YP':         str(round(point[1], 2)),
                'ZP':         str(round(ZP, 3)),
            }

            # Se lanza el cuadro de diálogo de la baliza
            result = self.rundialogBalizaPK(listaVALORES)

            if result is None:
                QApplication.restoreOverrideCursor()
                vl.commitChanges()
                return
            else:
                vl.startEditing()

            if result['tipoPUN'] == 'ptoEJE':
                distEJE = 0
                geom = QgsGeometry.fromPointXY(carretera_pk[7])
            else:
                distEJE = carretera_pk[5]
                geom = QgsGeometry.fromPointXY(point)


            attr = {
                'CTRA':    atributos['nombre'],
                'PK':      carretera_pk[1],
                'CTRA1':   atributos['nombre_alt'],
                'id_vial': atributos['id_vial'],
                'DIST':    distEJE,
                'ACIM':    carretera_pk[6],
                'XE':      carretera_pk[7][0],
                'YE':      carretera_pk[7][1],
                'ZE':      str(round(ZE, 3)),
                'XP':      point[0],
                'YP':      point[1],
                'ZP':      str(round(ZP, 3)),
                'DAT1':    result['DAT1'],
                'DAT2':    result['DAT2'],
            }

            feat = QgsFeature()
            feat.setGeometry(geom)
            feat.setAttributes([attr[c] for c in self.CAMPOS_BALIZA])
            vl.addFeature(feat)
            vl.commitChanges()

            QApplication.restoreOverrideCursor()

        else:
            QApplication.restoreOverrideCursor()
            message = u"--- Se debe aproximar más a una carretera ---"
            self.fun.showMessage( message,'','Balizador de Carreteras' )

            pass

        pass


    def rundialogBalizaPK(self, valores):
        """Rellena el diálogo con `valores` (dict) y devuelve dict con la respuesta,
        o None si se cancela."""

        # Mapeo campo -> atributo del diálogo
        controles = {
            'CTRA':    self.dlgBalizaPK.Matricula,
            'PK':      self.dlgBalizaPK.PK,
            'CTRA1':   self.dlgBalizaPK.Matricula_Plan,
            'id_vial': self.dlgBalizaPK.idMatricula,
            'DIST':    self.dlgBalizaPK.DIST,
            'ACIM':    self.dlgBalizaPK.ACIM,
            'XE':      self.dlgBalizaPK.XE,
            'YE':      self.dlgBalizaPK.YE,
            'ZE':      self.dlgBalizaPK.ZE,
            'XP':      self.dlgBalizaPK.XP,
            'YP':      self.dlgBalizaPK.YP,
            'ZP':      self.dlgBalizaPK.ZP,
        }

        for campo, widget in controles.items():
            widget.setText(str(valores.get(campo, '')))

        QApplication.restoreOverrideCursor()

        if self.dlgBalizaPK.exec() == 0:
            return None

        # Leer valores del diálogo
        respuesta = {campo: widget.text() for campo, widget in controles.items()}
        respuesta['DAT1'] = self.dlgBalizaPK.DAT1.text()
        respuesta['DAT2'] = self.dlgBalizaPK.DAT2.text()

        if self.dlgBalizaPK.qrbPTOEJE.isChecked():
            respuesta['tipoPUN'] = 'ptoEJE'
        else:
            respuesta['tipoPUN'] = 'ptoPIN'

        return respuesta